const sql = require("mssql");
require("dotenv").config();

// Cấu hình kết nối Microsoft SQL Server (Tương thích SQL Server 2014)
const config = {
  user: process.env.DB_USER || "sa",
  password: process.env.DB_PASSWORD || "Password123!",
  server: process.env.DB_SERVER || "localhost",
  port: parseInt(process.env.DB_PORT, 10) || 1433,
  database: process.env.DB_NAME || "DuanHongEcommerceDB",
  options: {
    encrypt: false, // Bắt buộc false cho kết nối local / SQL Server 2014 nội bộ
    trustServerCertificate: true, // Cho phép chứng chỉ tự ký
    enableArithAbort: true
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

let poolPromise = null;
let isConnected = false;

try {
  const pool = new sql.ConnectionPool(config);
  poolPromise = pool
    .connect()
    .then((connectedPool) => {
      isConnected = true;
      console.log(`[SQL Server] Đã kết nối thành công tới database '${config.database}' tại ${config.server}:${config.port}`);
      return connectedPool;
    })
    .catch((err) => {
      console.warn(`[SQL Server Warning] Chưa kết nối được tới SQL Server: ${err.message}`);
      console.warn(`[Chế độ dự phòng] Server sẽ hoạt động và sử dụng bộ dữ liệu mock nội bộ cho tới khi SQL Server sẵn sàng.`);
      return null;
    });
} catch (error) {
  console.error("[SQL Server Init Error]", error);
}

module.exports = {
  sql,
  poolPromise,
  isDbConnected: () => isConnected
};
