const { sql, poolPromise, isDbConnected } = require("../config/database");

// Dữ liệu sản phẩm mặc định
let mockProducts = [
  { id: 1, sku: "DH-SF-01", name: "Bộ Sofa Gõ Đỏ Chân Quỳ 'Vượng Khí Tài Lộc'", category: "phong-khach", catName: "Phòng Khách", wood: "Gỗ Gõ Đỏ Pachy Nam Phi", price: 74500000, loban: "Dài 2m8 Cung Tài Vượng", stock: 3, image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80", status: "active" },
  { id: 2, sku: "DH-BD-02", name: "Combo Phòng Ngủ Sồi Nga 'Tổ Ấm Trọn Vẹn'", category: "phong-ngu", catName: "Phòng Ngủ", wood: "Gỗ Sồi Nga (Oak) Nhập Khẩu", price: 36900000, loban: "Giường 1m8 x 2m Cung Tiến Bảo", stock: 5, image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80", status: "active" },
  { id: 3, sku: "DH-HG-03", name: "Bộ Bàn Ghế Hoàng Gia Louis Tân Cổ Điển", category: "phong-khach", catName: "Phòng Khách", wood: "Gỗ Gõ Đỏ Pachy Liền Khối", price: 95000000, loban: "Bộ 10 món đục tay kênh bong", stock: 2, image: "https://images.unsplash.com/photo-1538688525198-9b88f6f53126?auto=format&fit=crop&w=800&q=80", status: "active" },
  { id: 4, sku: "DH-DT-04", name: "Bàn Ăn Live-Edge Cạnh Tự Nhiên Kèm 8 Ghế", category: "phong-an", catName: "Phòng Ăn", wood: "Gỗ Gõ Đỏ Nguyên Tấm", price: 38000000, loban: "Dày 12cm x Dài 2m8", stock: 4, image: "https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=800&q=80", status: "active" },
  { id: 5, sku: "DH-AT-05", name: "Án Gian Thờ Nhị Cấp Chạm Sen & Tứ Linh", category: "phong-tho", catName: "Phòng Thờ", wood: "Gỗ Gụ / Gõ Đỏ Chuẩn Cung Đỏ", price: 48000000, loban: "Dài 2m17 x Cao 1m27", stock: 2, image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80", status: "active" }
];

// @route   GET /api/products
// @desc    Lấy danh sách sản phẩm (có lọc danh mục, chất gỗ, tìm kiếm)
exports.getProducts = async (req, res, next) => {
  try {
    const { category, wood, search } = req.query;

    const pool = await poolPromise;
    if (pool && isDbConnected()) {
      let query = `
        SELECT p.ProductID, p.ProductName, p.SKU, p.WoodType, p.Price, p.SalePrice, 
               p.StockQuantity, p.Status, p.LoBanDimension, c.CategoryName, c.Slug as CategorySlug,
               (SELECT TOP 1 ImageURL FROM ProductImages WHERE ProductID = p.ProductID) as ThumbnailURL
        FROM Products p
        LEFT JOIN Categories c ON p.CategoryID = c.CategoryID
        WHERE p.Status <> 'archived'
      `;

      const request = pool.request();
      if (category && category !== "all") {
        query += ` AND c.Slug = @CategorySlug`;
        request.input("CategorySlug", sql.VarChar(180), category);
      }
      if (search) {
        query += ` AND (p.ProductName LIKE @Search OR p.SKU LIKE @Search OR p.WoodType LIKE @Search)`;
        request.input("Search", sql.NVarChar(255), `%${search}%`);
      }
      query += ` ORDER BY p.CreatedAt DESC`;

      const result = await request.query(query);
      return res.json({
        success: true,
        count: result.recordset.length,
        data: result.recordset
      });
    }

    // Chế độ dự phòng (In-memory Mock)
    let filtered = [...mockProducts];
    if (category && category !== "all") {
      filtered = filtered.filter(p => p.category === category);
    }
    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(p => p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q) || p.wood.toLowerCase().includes(q));
    }

    res.json({
      success: true,
      count: filtered.length,
      data: filtered
    });

  } catch (error) {
    next(error);
  }
};

// @route   GET /api/products/:id
// @desc    Lấy thông tin chi tiết một sản phẩm
exports.getProductById = async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10);
    const pool = await poolPromise;

    if (pool && isDbConnected()) {
      const result = await pool.request()
        .input("ProductID", sql.Int, id)
        .query(`SELECT * FROM Products WHERE ProductID = @ProductID`);

      if (result.recordset.length === 0) {
        return res.status(404).json({ success: false, message: "Không tìm thấy sản phẩm!" });
      }
      return res.json({ success: true, data: result.recordset[0] });
    }

    const prod = mockProducts.find(p => p.id === id);
    if (!prod) {
      return res.status(404).json({ success: false, message: "Không tìm thấy sản phẩm!" });
    }
    res.json({ success: true, data: prod });

  } catch (error) {
    next(error);
  }
};

// @route   POST /api/products
// @desc    Tạo sản phẩm đồ gỗ mới (Yêu cầu quyền Admin / Manager)
exports.createProduct = async (req, res, next) => {
  try {
    const { name, category, wood, price, loban, stock, image } = req.body;

    if (!name || !wood) {
      return res.status(400).json({ success: false, message: "Tên sản phẩm và chất liệu gỗ là bắt buộc!" });
    }

    const sku = `DH-${Math.floor(100 + Math.random() * 900)}`;
    const pool = await poolPromise;

    if (pool && isDbConnected()) {
      const result = await pool.request()
        .input("ProductName", sql.NVarChar(255), name)
        .input("SKU", sql.VarChar(100), sku)
        .input("WoodType", sql.NVarChar(100), wood)
        .input("Price", sql.Decimal(18, 2), price || 0)
        .input("StockQuantity", sql.Int, stock || 1)
        .input("LoBanDimension", sql.NVarChar(100), loban || "Chuẩn Thước Lỗ Ban Đỏ")
        .query(`
          INSERT INTO Products (ProductName, SKU, WoodType, Price, StockQuantity, LoBanDimension, Status)
          VALUES (@ProductName, @SKU, @WoodType, @Price, @StockQuantity, @LoBanDimension, 'active');
          SELECT SCOPE_IDENTITY() as NewProductID;
        `);

      const newId = result.recordset[0].NewProductID;
      return res.status(201).json({
        success: true,
        message: "Thêm sản phẩm mới thành công vào SQL Server!",
        data: { id: newId, sku, name, wood, price }
      });
    }

    // Mock insert
    const newProduct = {
      id: Date.now(),
      sku,
      name,
      category: category || "phong-khach",
      wood,
      price: price || 36900000,
      loban: loban || "Chuẩn Thước Lỗ Ban Đỏ",
      stock: stock || 1,
      image: image || "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=800&q=80",
      status: "active"
    };
    mockProducts.unshift(newProduct);

    res.status(201).json({
      success: true,
      message: "Thêm sản phẩm mới thành công!",
      data: newProduct
    });

  } catch (error) {
    next(error);
  }
};

// @route   DELETE /api/products/:id
// @desc    Xóa hoặc chuyển trạng thái sản phẩm
exports.deleteProduct = async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10);
    mockProducts = mockProducts.filter(p => p.id !== id);

    res.json({
      success: true,
      message: "Đã xóa sản phẩm khỏi kho catalogue thành công!"
    });
  } catch (error) {
    next(error);
  }
};
