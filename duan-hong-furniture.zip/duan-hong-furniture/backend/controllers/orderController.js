const { sql, poolPromise, isDbConnected } = require("../config/database");

let mockOrders = [
  { id: "DH-ORD-801", customer: "Anh Hoàng Nam", phone: "0912445889", address: "Khu đô thị Lạc Hồng Phúc, TX. Mỹ Hào, Hưng Yên", product: "Combo Sofa Gõ Đỏ Chân Quỳ", amount: 74500000, deposit: 25000000, mocSigned: true, stage: "carving", stageName: "Đang Ghép Mộng Đục Tay", date: "05/11/2026" },
  { id: "DH-ORD-802", customer: "Bác Trọng Cường", phone: "0904556778", address: "Đường Trưng Trắc, TP. Hưng Yên", product: "Án Gian Thờ Nhị Cấp 2m17", amount: 48000000, deposit: 15000000, mocSigned: true, stage: "finishing", stageName: "Đang Phun PU Lau Dầu", date: "04/11/2026" },
  { id: "DH-ORD-803", customer: "Chị Minh Tuyết", phone: "0983112334", address: "Thị Trấn Bần, Hưng Yên", product: "Combo Phòng Ngủ Sồi Nga Tổ Ấm", amount: 36900000, deposit: 12000000, mocSigned: false, stage: "seasoning", stageName: "Đang Sấy Phôi Mộc Thô", date: "03/11/2026" },
  { id: "DH-ORD-804", customer: "Anh Quốc Bảo", phone: "0977889900", address: "Vinhomes Ocean Park 2 (Gần Hưng Yên)", product: "Bàn Ăn Live-Edge Cạnh Tự Nhiên", amount: 38000000, deposit: 38000000, mocSigned: true, stage: "completed", stageName: "Đã Bàn Giao Hoàn Tất", date: "01/11/2026" }
];

// @route   GET /api/orders
// @desc    Lấy danh sách đơn hàng & tiến độ xưởng
exports.getOrders = async (req, res, next) => {
  try {
    const { status } = req.query;
    let list = [...mockOrders];

    if (status && status !== "all") {
      list = list.filter(o => o.stage === status);
    }

    res.json({
      success: true,
      count: list.length,
      data: list
    });
  } catch (error) {
    next(error);
  }
};

// @route   POST /api/orders
// @desc    Tạo đơn hàng đặt cọc may đo mới
exports.createOrder = async (req, res, next) => {
  try {
    const { customerName, phone, address, product, amount, deposit, note } = req.body;

    if (!customerName || !phone) {
      return res.status(400).json({ success: false, message: "Họ tên và số điện thoại là bắt buộc!" });
    }

    const orderId = `DH-ORD-${Math.floor(800 + Math.random() * 100)}`;
    const newOrder = {
      id: orderId,
      customer: customerName,
      phone,
      address: address || "Nguyễn Du, TP. Hưng Yên (Cần khảo sát)",
      product: product || "Đặt hàng may đo nội thất",
      amount: amount || 36900000,
      deposit: deposit || Math.round((amount || 36900000) * 0.3),
      mocSigned: false,
      stage: "pending",
      stageName: "Chờ Xác Nhận Báo Giá",
      note: note || "Khách yêu cầu đo thước Lỗ Ban tại nhà",
      date: new Date().toLocaleDateString("vi-VN")
    };

    mockOrders.unshift(newOrder);

    res.status(201).json({
      success: true,
      message: "Tạo đơn hàng thành công!",
      data: newOrder
    });
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/orders/:id/status
// @desc    Cập nhật công đoạn xưởng (Sấy phôi -> Đục mộng -> Hoàn thiện)
exports.updateOrderStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { stage } = req.body;

    const order = mockOrders.find(o => o.id === id);
    if (!order) {
      return res.status(404).json({ success: false, message: "Không tìm thấy đơn hàng!" });
    }

    const stageNames = {
      pending: "Chờ Xác Nhận Báo Giá",
      seasoning: "Đang Sấy Phôi Mộc Thô",
      carving: "Đang Ghép Mộng Đục Tay",
      finishing: "Đang Phun PU Lau Dầu",
      completed: "Đã Bàn Giao Hoàn Tất"
    };

    order.stage = stage;
    order.stageName = stageNames[stage] || stage;

    res.json({
      success: true,
      message: `Đã cập nhật tiến độ đơn hàng ${id} thành công!`,
      data: order
    });
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/orders/:id/moc-sign
// @desc    Xác nhận khách đã ký tên lên phôi mộc thô trước khi sơn
exports.toggleMocSigned = async (req, res, next) => {
  try {
    const { id } = req.params;
    const order = mockOrders.find(o => o.id === id);
    if (!order) {
      return res.status(404).json({ success: false, message: "Không tìm thấy đơn hàng!" });
    }

    order.mocSigned = !order.mocSigned;

    res.json({
      success: true,
      message: order.mocSigned 
        ? "Đã xác nhận gia chủ ký tên lên phôi mộc thô thành công!" 
        : "Đã hủy trạng thái ký mộc thô!",
      data: order
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/orders/track/:code
// @desc    Tra cứu tiến độ đơn hàng công khai cho khách hàng
exports.trackOrder = async (req, res, next) => {
  try {
    const { code } = req.params;
    const cleanCode = code.trim().toLowerCase();

    const order = mockOrders.find(o => 
      o.id.toLowerCase() === cleanCode || 
      (o.phone && o.phone.replace(/[^0-9]/g, '').includes(cleanCode))
    );

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Không tìm thấy thông tin đơn hàng! Vui lòng kiểm tra lại mã đơn hoặc số điện thoại."
      });
    }

    res.json({
      success: true,
      data: {
        orderCode: order.id,
        customerName: order.customer,
        productName: order.product,
        stage: order.stage,
        stageName: order.stageName,
        isMocSigned: order.mocSigned,
        timeline: [
          { step: 1, title: "Tiếp nhận & Đo đạc thước Lỗ Ban Cung Đỏ", completed: true },
          { step: 2, title: "Tẩm sấy phôi mộc chân không (Độ ẩm đạt 11%)", completed: ["seasoning", "carving", "finishing", "completed"].includes(order.stage) },
          { step: 3, title: "Ghép mộng âm dương & Đục chạm kênh bong", completed: ["carving", "finishing", "completed"].includes(order.stage) },
          { step: 4, title: "Gia chủ về xưởng Hưng Yên ký tên phôi mộc thô", completed: order.mocSigned },
          { step: 5, title: "Phun sơn PU 5 lớp & Bàn giao lắp đặt tận nhà", completed: order.stage === "completed" }
        ]
      }
    });
  } catch (error) {
    next(error);
  }
};
