const { executeQuery, isMockMode } = require("../config/database");

let mockCategories = [
  { CategoryID: 1, CategoryName: "Phòng Khách Hoàng Gia & Hiện Đại", Slug: "phong-khach", DisplayOrder: 1, IsActive: true },
  { CategoryID: 2, CategoryName: "Phòng Ăn & Bàn Ăn Nguyên Tấm", Slug: "phong-an", DisplayOrder: 2, IsActive: true },
  { CategoryID: 3, CategoryName: "Phòng Ngủ An Yên", Slug: "phong-ngu", DisplayOrder: 3, IsActive: true },
  { CategoryID: 4, CategoryName: "Không Gian Thờ Linh Thiêng", Slug: "phong-tho", DisplayOrder: 4, IsActive: true }
];

const getCategories = async (req, res, next) => {
  try {
    if (isMockMode()) {
      return res.json({ success: true, count: mockCategories.length, data: mockCategories });
    }
    const result = await executeQuery(`
      SELECT CategoryID, CategoryName, Slug, ParentID, Description, DisplayOrder, IsActive
      FROM Categories
      WHERE IsActive = 1
      ORDER BY DisplayOrder ASC
    `);
    res.json({ success: true, count: result.recordset.length, data: result.recordset });
  } catch (error) {
    next(error);
  }
};

const createCategory = async (req, res, next) => {
  try {
    const { categoryName, slug, description, displayOrder } = req.body;
    if (!categoryName || !slug) {
      return res.status(400).json({ success: false, message: "Tên danh mục và slug là bắt buộc" });
    }
    if (isMockMode()) {
      const newCat = {
        CategoryID: mockCategories.length + 1,
        CategoryName: categoryName,
        Slug: slug,
        DisplayOrder: displayOrder || mockCategories.length + 1,
        IsActive: true
      };
      mockCategories.push(newCat);
      return res.status(201).json({ success: true, data: newCat });
    }
    const sql = require("mssql");
    const result = await executeQuery(`
      INSERT INTO Categories (CategoryName, Slug, Description, DisplayOrder)
      OUTPUT INSERTED.*
      VALUES (@name, @slug, @desc, @order)
    `, [
      { name: "name", type: sql.NVarChar, value: categoryName },
      { name: "slug", type: sql.VarChar, value: slug },
      { name: "desc", type: sql.NVarChar, value: description || null },
      { name: "order", type: sql.Int, value: displayOrder || 0 }
    ]);
    res.status(201).json({ success: true, data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

module.exports = { getCategories, createCategory };
