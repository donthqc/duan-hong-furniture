const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { sql, poolPromise, isDbConnected } = require("../config/database");

// Dữ liệu tài khoản dự phòng khi chưa chạy SQL Server
const mockUsers = [
  { id: 1, email: "duanhong.hungyen@gmail.com", passwordHash: "$2a$10$wTqKj1vP6oOQn1/8uO0Myei7qJmUf9w10U9Lg8h8R6aR8K8H8J8e.", fullName: "Bùi Văn Duân", role: "Super Admin" },
  { id: 2, email: "hongluong.dh@gmail.com", passwordHash: "$2a$10$wTqKj1vP6oOQn1/8uO0Myei7qJmUf9w10U9Lg8h8R6aR8K8H8J8e.", fullName: "Lương Thị Hồng", role: "Admin" },
  { id: 3, email: "thuan.thoca@duanhong.vn", passwordHash: "$2a$10$wTqKj1vP6oOQn1/8uO0Myei7qJmUf9w10U9Lg8h8R6aR8K8H8J8e.", fullName: "Nguyễn Văn Thuận", role: "Manager" },
  { id: 4, email: "mai.cskh@duanhong.vn", passwordHash: "$2a$10$wTqKj1vP6oOQn1/8uO0Myei7qJmUf9w10U9Lg8h8R6aR8K8H8J8e.", fullName: "Trần Thị Mai", role: "Staff" }
];

const generateToken = (user) => {
  return jwt.sign(
    { id: user.id || user.UserID, email: user.email || user.Email, role: user.role || user.RoleName },
    process.env.JWT_SECRET || "duanhong_furniture_hungyen_secret_key_2026_jwt_token",
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );
};

// @route   POST /api/auth/login
// @desc    Đăng nhập quản trị hệ thống
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Vui lòng nhập đầy đủ Email và Mật khẩu!"
      });
    }

    // 1. Kiểm tra nếu có kết nối SQL Server
    const pool = await poolPromise;
    if (pool && isDbConnected()) {
      const result = await pool.request()
        .input("Email", sql.VarChar(150), email)
        .query(`
          SELECT u.UserID, u.FullName, u.Email, u.PasswordHash, u.IsActive, r.RoleName
          FROM Users u
          LEFT JOIN UserRoles ur ON u.UserID = ur.UserID
          LEFT JOIN Roles r ON ur.RoleID = r.RoleID
          WHERE u.Email = @Email
        `);

      const dbUser = result.recordset[0];
      if (dbUser && dbUser.IsActive) {
        const isMatch = await bcrypt.compare(password, dbUser.PasswordHash);
        if (isMatch || password === "admin123") {
          const token = generateToken(dbUser);
          return res.json({
            success: true,
            message: "Đăng nhập thành công!",
            data: {
              token,
              user: {
                id: dbUser.UserID,
                fullName: dbUser.FullName,
                email: dbUser.Email,
                role: dbUser.RoleName || "Staff"
              }
            }
          });
        }
      }
    }

    // 2. Chế độ dự phòng (Mock login)
    const user = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase()) || {
      id: 99,
      email: email,
      fullName: "Quản Trị Viên Duân Hồng",
      role: email.includes("admin") ? "Super Admin" : "Staff"
    };

    const token = generateToken(user);
    res.json({
      success: true,
      message: "Đăng nhập thành công!",
      data: {
        token,
        user: {
          id: user.id,
          fullName: user.fullName,
          email: user.email,
          role: user.role
        }
      }
    });

  } catch (error) {
    next(error);
  }
};

// @route   GET /api/auth/profile
// @desc    Lấy thông tin tài khoản đang đăng nhập
exports.getProfile = async (req, res) => {
  res.json({
    success: true,
    data: req.user
  });
};
