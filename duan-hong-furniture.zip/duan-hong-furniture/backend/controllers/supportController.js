let mockTickets = [
  { id: "CS001", customer: "Anh Hoàng Nam", phone: "0912445889", content: "Hỏi kích thước bàn trà Lỗ Ban & hẹn giờ về xưởng ký mộc", channel: "Live Chat", priority: "Bình thường", assignedTo: "Trần Thị Mai (CSKH)", status: "Đang xử lý" },
  { id: "CS002", customer: "Bác Trọng Cường", phone: "0904556778", content: "Yêu cầu thợ mang thước Lỗ Ban đo lại gian thờ nhà cổ Hưng Yên", channel: "Hotline/Zalo", priority: "Cao", assignedTo: "Thợ Cả Bùi Văn Duân", status: "Đã lên lịch" },
  { id: "CS003", customer: "Chị Minh Tuyết", phone: "0983112334", content: "Xin bảng bóc tách gỗ sồi Nga phòng ngủ Combo 36.9tr", channel: "Live Chat", priority: "Bình thường", assignedTo: "Trần Thị Mai (CSKH)", status: "Đã gửi bảng" },
  { id: "CS004", customer: "Anh Quốc Bảo", phone: "0977889900", content: "Bảo dưỡng định kỳ 6 tháng lau dầu bảo dưỡng vân gỗ", channel: "Hậu Mãi 6 Tháng", priority: "Định kỳ", assignedTo: "Tổ Kỹ Thuật Xưởng", status: "Hoàn tất" }
];

let mockMessages = [
  { id: 1, sender: "bot", text: "Dạ, em chào anh/chị! Em là thợ mộc tại xưởng Duân Hồng (đường Nguyễn Du, TP. Hưng Yên). Anh/chị đang quan tâm loại gỗ tự nhiên nào hoặc cần đo đạc thước Lỗ Ban đỏ cứ nhắn em hỗ trợ nhé!", time: "Vừa xong" }
];

// @route   GET /api/support/tickets
// @desc    Lấy danh sách Ticket hỗ trợ khách hàng
exports.getTickets = async (req, res, next) => {
  try {
    res.json({
      success: true,
      count: mockTickets.length,
      data: mockTickets
    });
  } catch (error) {
    next(error);
  }
};

// @route   POST /api/support/tickets
// @desc    Tạo Ticket CSKH mới
exports.createTicket = async (req, res, next) => {
  try {
    const { customer, phone, content, channel, priority } = req.body;
    const ticketId = `CS00${mockTickets.length + 1}`;

    const newTicket = {
      id: ticketId,
      customer: customer || "Khách Vãng Lai",
      phone: phone || "Chưa cung cấp",
      content: content || "Yêu cầu tư vấn kích thước và chất gỗ",
      channel: channel || "Web Form",
      priority: priority || "Bình thường",
      assignedTo: "Trần Thị Mai (CSKH)",
      status: "Mới tiếp nhận"
    };

    mockTickets.unshift(newTicket);
    res.status(201).json({ success: true, message: "Tạo Ticket thành công!", data: newTicket });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/support/chat/messages
// @desc    Lấy lịch sử tin nhắn Live Chat
exports.getChatMessages = async (req, res, next) => {
  try {
    res.json({ success: true, data: mockMessages });
  } catch (error) {
    next(error);
  }
};

// @route   POST /api/support/chat/messages
// @desc    Gửi tin nhắn Live Chat và phản hồi tự động
exports.sendChatMessage = async (req, res, next) => {
  try {
    const { text, sender } = req.body;
    const userMsg = { id: Date.now(), sender: sender || "user", text, time: "Vừa xong" };
    mockMessages.push(userMsg);

    // Kịch bản phản hồi thông minh nếu khách nhắn
    let botReply = null;
    const lower = (text || "").toLowerCase();
    if (lower.includes("lỗ ban") || lower.includes("kích thước")) {
      botReply = "Dạ, xưởng Duân Hồng đo chuẩn thước Lỗ Ban Cung Đỏ (Tài Vượng, Hỷ Sự). Xưởng cử thợ đến khảo sát tận nhà miễn phí ạ!";
    } else if (lower.includes("combo") || lower.includes("36.9") || lower.includes("74.5")) {
      botReply = "Dạ, Combo Tổ Ấm phòng ngủ Sồi Nga ưu đãi 36.9tr và Combo Vượng Khí Sofa Gõ Đỏ 74.5tr đều là giá gốc tại xưởng rẻ hơn 30% so với showroom phố ạ!";
    } else if (lower.includes("ký") || lower.includes("xưởng")) {
      botReply = "Dạ, xưởng Duân Hồng cam kết 100% khách được về tận xưởng tại đường Nguyễn Du, Hưng Yên ký tên phôi mộc thô trước khi phun sơn ạ!";
    }

    if (botReply) {
      setTimeout(() => {
        mockMessages.push({ id: Date.now() + 1, sender: "bot", text: botReply, time: "Vừa xong" });
      }, 500);
    }

    res.status(201).json({ success: true, data: userMsg, autoReply: botReply });
  } catch (error) {
    next(error);
  }
};
