const { executeQuery, isMockMode } = require("../config/database");

let mockCoupons = [
  { CouponID: 1, Code: "DUANHONG500", DiscountType: "fixed_amount", DiscountValue: 500000, MinOrderValue: 20000000, MaxDiscount: 500000, IsActive: true, Description: "Giảm 500.000đ cho đơn hàng mộc từ 20 triệu" },
  { CouponID: 2, Code: "LOCXUAN2026", DiscountType: "percentage", DiscountValue: 5, MinOrderValue: 35000000, MaxDiscount: 3000000, IsActive: true, Description: "Tặng 5% lộc xuân tối đa 3 triệu đồng" },
  { CouponID: 3, Code: "MIENPHISHIP", DiscountType: "fixed_amount", DiscountValue: 1000000, MinOrderValue: 10000000, MaxDiscount: 1000000, IsActive: true, Description: "Hỗ trợ 100% cước xe tải xưởng bán kính 30km" }
];

const getCoupons = async (req, res, next) => {
  try {
    if (isMockMode()) {
      return res.json({ success: true, count: mockCoupons.length, data: mockCoupons });
    }
    const result = await executeQuery(`
      SELECT CouponID, Code, DiscountType, DiscountValue, MinOrderValue, MaxDiscount, UsageLimit, TimesUsed, StartDate, EndDate, IsActive
      FROM Coupons
      WHERE IsActive = 1
      ORDER BY CouponID DESC
    `);
    res.json({ success: true, count: result.recordset.length, data: result.recordset });
  } catch (error) {
    next(error);
  }
};

const applyCoupon = async (req, res, next) => {
  try {
    const { code, orderAmount } = req.body;
    if (!code || !orderAmount) {
      return res.status(400).json({ success: false, message: "Mã giảm giá và giá trị đơn hàng là bắt buộc" });
    }

    const coupon = mockCoupons.find(c => c.Code.toUpperCase() === code.trim().toUpperCase() && c.IsActive);
    if (!coupon) {
      return res.status(404).json({ success: false, message: "Mã giảm giá không hợp lệ hoặc đã hết hạn" });
    }

    if (orderAmount < coupon.MinOrderValue) {
      return res.status(400).json({
        success: false,
        message: `Đơn hàng tối thiểu phải từ ${coupon.MinOrderValue.toLocaleString("vi-VN")} đ để áp dụng mã này`
      });
    }

    let discount = 0;
    if (coupon.DiscountType === "fixed_amount") {
      discount = coupon.DiscountValue;
    } else if (coupon.DiscountType === "percentage") {
      discount = Math.round((orderAmount * coupon.DiscountValue) / 100);
      if (coupon.MaxDiscount && discount > coupon.MaxDiscount) {
        discount = coupon.MaxDiscount;
      }
    }

    const finalAmount = Math.max(0, orderAmount - discount);
    const depositAmount = Math.round(finalAmount * 0.3); // 30% cọc mộc thô

    res.json({
      success: true,
      data: {
        code: coupon.Code,
        discountType: coupon.DiscountType,
        discountValue: discount,
        originalAmount: orderAmount,
        finalAmount,
        depositAmount,
        message: `Áp dụng thành công mã ${coupon.Code}: giảm ${discount.toLocaleString("vi-VN")} đ`
      }
    });
  } catch (error) {
    next(error);
  }
};

const createCoupon = async (req, res, next) => {
  try {
    const { code, discountType, discountValue, minOrderValue, maxDiscount, startDate, endDate } = req.body;
    if (!code || !discountValue) {
      return res.status(400).json({ success: false, message: "Mã coupon và giá trị giảm là bắt buộc" });
    }

    if (isMockMode()) {
      const newCoupon = {
        CouponID: mockCoupons.length + 1,
        Code: code.toUpperCase(),
        DiscountType: discountType || "fixed_amount",
        DiscountValue: Number(discountValue),
        MinOrderValue: Number(minOrderValue) || 0,
        MaxDiscount: Number(maxDiscount) || null,
        IsActive: true
      };
      mockCoupons.push(newCoupon);
      return res.status(201).json({ success: true, message: "Tạo coupon thành công", data: newCoupon });
    }

    const sql = require("mssql");
    const result = await executeQuery(`
      INSERT INTO Coupons (Code, DiscountType, DiscountValue, MinOrderValue, MaxDiscount, StartDate, EndDate, IsActive)
      OUTPUT INSERTED.*
      VALUES (@code, @type, @val, @minVal, @maxDisc, ISNULL(@start, GETDATE()), ISNULL(@end, DATEADD(month, 3, GETDATE())), 1)
    `, [
      { name: "code", type: sql.VarChar, value: code.toUpperCase() },
      { name: "type", type: sql.VarChar, value: discountType || "fixed_amount" },
      { name: "val", type: sql.Decimal(18, 2), value: discountValue },
      { name: "minVal", type: sql.Decimal(18, 2), value: minOrderValue || 0 },
      { name: "maxDisc", type: sql.Decimal(18, 2), value: maxDiscount || null },
      { name: "start", type: sql.DateTime, value: startDate || null },
      { name: "end", type: sql.DateTime, value: endDate || null }
    ]);

    res.status(201).json({ success: true, message: "Tạo coupon thành công", data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

module.exports = { getCoupons, applyCoupon, createCoupon };
