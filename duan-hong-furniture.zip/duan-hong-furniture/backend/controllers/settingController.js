const { executeQuery, isMockMode } = require("../config/database");

let mockSettings = {
  StoreName: "Công ty Đồ Gỗ Nội Thất Duân Hồng",
  Address: "Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên",
  Hotline: "0988.686.868",
  Zalo: "0988.686.868",
  WarrantyYears: "5",
  FreeDeliveryKM: "30",
  WoodCommitment: "Cam kết 100% gỗ tự nhiên chuẩn phôi mộc thô, khách về xưởng ký tên trước khi sơn PU",
  DepositPercentage: "30"
};

const getSettings = async (req, res, next) => {
  try {
    if (isMockMode()) {
      return res.json({ success: true, data: mockSettings });
    }
    const result = await executeQuery(`SELECT SettingKey, SettingValue, Description FROM Settings`);
    const settingsObj = {};
    result.recordset.forEach(row => {
      settingsObj[row.SettingKey] = row.SettingValue;
    });
    res.json({ success: true, data: { ...mockSettings, ...settingsObj } });
  } catch (error) {
    next(error);
  }
};

const updateSetting = async (req, res, next) => {
  try {
    const { key, value } = req.body;
    if (!key || value === undefined) {
      return res.status(400).json({ success: false, message: "Key và value là bắt buộc" });
    }

    if (isMockMode()) {
      mockSettings[key] = value;
      return res.json({ success: true, message: `Cập nhật cấu hình ${key} thành công`, data: mockSettings });
    }

    const sql = require("mssql");
    await executeQuery(`
      IF EXISTS (SELECT 1 FROM Settings WHERE SettingKey = @key)
          UPDATE Settings SET SettingValue = @val, UpdatedAt = GETDATE() WHERE SettingKey = @key
      ELSE
          INSERT INTO Settings (SettingKey, SettingValue) VALUES (@key, @val)
    `, [
      { name: "key", type: sql.VarChar, value: key },
      { name: "val", type: sql.NVarChar, value: String(value) }
    ]);

    mockSettings[key] = value;
    res.json({ success: true, message: `Cập nhật cấu hình ${key} thành công` });
  } catch (error) {
    next(error);
  }
};

module.exports = { getSettings, updateSetting };
