let mockCustomers = [
  { id: "KH-101", name: "Anh Hoàng Nam", phone: "0912445889", area: "Mỹ Hào, Hưng Yên", totalSpent: 74500000, note: "Đã về xưởng ký tên mộc 10/11. Thợ Lỗ Ban đo phòng khách 45m2." },
  { id: "KH-102", name: "Bác Trọng Cường", phone: "0904556778", area: "TP. Hưng Yên", totalSpent: 48000000, note: "Quan tâm phong thủy cung Tài Vượng. Chuẩn bị phun PU." },
  { id: "KH-103", name: "Chị Minh Tuyết", phone: "0983112334", area: "Yên Mỹ, Hưng Yên", totalSpent: 36900000, note: "Chọn Combo Tổ Ấm phòng ngủ sồi Nga. Hẹn xem phôi mộc cuối tuần." },
  { id: "KH-104", name: "Anh Quốc Bảo", phone: "0977889900", area: "Văn Giang, Hưng Yên", totalSpent: 38000000, note: "Bàn ăn nguyên tấm đã giao hoàn tất. Đánh giá 5 sao về chất lượng gỗ." }
];

// @route   GET /api/customers
// @desc    Lấy danh sách hồ sơ khách hàng & CSKH
exports.getCustomers = async (req, res, next) => {
  try {
    const { search } = req.query;
    let list = [...mockCustomers];

    if (search) {
      const q = search.toLowerCase();
      list = list.filter(c => c.name.toLowerCase().includes(q) || c.phone.includes(q) || c.area.toLowerCase().includes(q));
    }

    res.json({
      success: true,
      count: list.length,
      data: list
    });
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/customers/:id/notes
// @desc    Cập nhật ghi chú chăm sóc khách hàng (CRM Note)
exports.updateCustomerNotes = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { note } = req.body;

    const cust = mockCustomers.find(c => c.id === id);
    if (!cust) {
      return res.status(404).json({ success: false, message: "Không tìm thấy khách hàng!" });
    }

    cust.note = note;

    res.json({
      success: true,
      message: "Đã cập nhật ghi chú CSKH thành công!",
      data: cust
    });
  } catch (error) {
    next(error);
  }
};
