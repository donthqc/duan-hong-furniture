const { executeQuery, isMockMode } = require("../config/database");

let mockCarts = {}; // Key by sessionId or customerId

const getCart = async (req, res, next) => {
  try {
    const sessionId = req.headers["x-session-id"] || "guest_session";
    const cart = mockCarts[sessionId] || { items: [] };

    // Calculate totals
    const totalAmount = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const depositRequired = Math.round(totalAmount * 0.3); // 30% cọc mộc thô

    res.json({
      success: true,
      data: {
        sessionId,
        items: cart.items,
        totalItems: cart.items.reduce((sum, item) => sum + item.quantity, 0),
        totalAmount,
        depositRequired,
        freeShippingEligible: true,
        freeShippingNote: "Miễn phí vận chuyển bằng xe tải xưởng Duân Hồng trong bán kính 30km TP. Hưng Yên"
      }
    });
  } catch (error) {
    next(error);
  }
};

const addToCart = async (req, res, next) => {
  try {
    const sessionId = req.headers["x-session-id"] || "guest_session";
    const { productId, name, price, quantity = 1, woodType, lobanNote } = req.body;

    if (!productId || !price) {
      return res.status(400).json({ success: false, message: "Thiếu thông tin sản phẩm" });
    }

    if (!mockCarts[sessionId]) {
      mockCarts[sessionId] = { items: [] };
    }

    const existing = mockCarts[sessionId].items.find(i => i.productId === productId);
    if (existing) {
      existing.quantity += quantity;
      if (lobanNote) existing.lobanNote = lobanNote;
    } else {
      mockCarts[sessionId].items.push({
        id: Date.now(),
        productId,
        name,
        price: Number(price),
        quantity: Number(quantity),
        woodType: woodType || "Gỗ Tự Nhiên Cao Cấp",
        lobanNote: lobanNote || "Chuẩn Thước Lỗ Ban Cung Đỏ"
      });
    }

    return getCart(req, res, next);
  } catch (error) {
    next(error);
  }
};

const updateCartItem = async (req, res, next) => {
  try {
    const sessionId = req.headers["x-session-id"] || "guest_session";
    const itemId = parseInt(req.params.id);
    const { quantity, lobanNote } = req.body;

    if (!mockCarts[sessionId]) {
      return res.status(404).json({ success: false, message: "Giỏ hàng rỗng" });
    }

    const item = mockCarts[sessionId].items.find(i => i.id === itemId);
    if (!item) {
      return res.status(404).json({ success: false, message: "Không tìm thấy sản phẩm trong giỏ" });
    }

    if (quantity !== undefined) {
      if (quantity <= 0) {
        mockCarts[sessionId].items = mockCarts[sessionId].items.filter(i => i.id !== itemId);
      } else {
        item.quantity = quantity;
      }
    }

    if (lobanNote !== undefined) {
      item.lobanNote = lobanNote;
    }

    return getCart(req, res, next);
  } catch (error) {
    next(error);
  }
};

const removeFromCart = async (req, res, next) => {
  try {
    const sessionId = req.headers["x-session-id"] || "guest_session";
    const itemId = parseInt(req.params.id);

    if (mockCarts[sessionId]) {
      mockCarts[sessionId].items = mockCarts[sessionId].items.filter(i => i.id !== itemId);
    }

    return getCart(req, res, next);
  } catch (error) {
    next(error);
  }
};

module.exports = { getCart, addToCart, updateCartItem, removeFromCart };
