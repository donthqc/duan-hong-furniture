const { executeQuery, isMockMode } = require("../config/database");

let mockShipments = [
  { ShipmentID: 1, OrderCode: "DH-ORD-801", TrackingCode: "SHIP-DH-ORD-801", CarrierName: "Xe Tải Xưởng Duân Hồng (2.5 Tấn)", DriverName: "Nguyễn Văn Hùng", DriverPhone: "0912.987.654", ShippingStatus: "preparing", EstimatedArrival: "2026-11-15", Note: "Giao bán kính 15km - TX. Mỹ Hào (Miễn phí vận chuyển)" },
  { ShipmentID: 2, OrderCode: "DH-ORD-802", TrackingCode: "SHIP-DH-ORD-802", CarrierName: "Xe Tải Xưởng Duân Hồng (1.5 Tấn)", DriverName: "Lê Văn Tự", DriverPhone: "0973.445.566", ShippingStatus: "delivering", EstimatedArrival: "2026-11-08", Note: "Giao nội thành TP. Hưng Yên (Miễn phí vận chuyển)" },
  { ShipmentID: 3, OrderCode: "DH-ORD-804", TrackingCode: "SHIP-DH-ORD-804", CarrierName: "Xe Tải Xưởng Duân Hồng (2.5 Tấn)", DriverName: "Nguyễn Văn Hùng", DriverPhone: "0912.987.654", ShippingStatus: "delivered", EstimatedArrival: "2026-11-01", DeliveredAt: "2026-11-01", Note: "Đã bàn giao và nghiệm thu" }
];

const getShipments = async (req, res, next) => {
  try {
    if (isMockMode()) {
      return res.json({ success: true, count: mockShipments.length, data: mockShipments });
    }
    const result = await executeQuery(`
      SELECT s.ShipmentID, s.OrderID, o.OrderCode, s.TrackingCode, s.CarrierName,
             s.DriverName, s.DriverPhone, s.ShippingStatus, s.EstimatedArrival, s.DeliveredAt, s.Note
      FROM Shipments s
      JOIN Orders o ON s.OrderID = o.OrderID
      ORDER BY s.ShipmentID DESC
    `);
    res.json({ success: true, count: result.recordset.length, data: result.recordset });
  } catch (error) {
    next(error);
  }
};

const getShipmentByTracking = async (req, res, next) => {
  try {
    const { trackingCode } = req.params;
    if (isMockMode()) {
      const ship = mockShipments.find(s => s.TrackingCode === trackingCode || s.OrderCode === trackingCode);
      if (!ship) return res.status(404).json({ success: false, message: "Không tìm thấy thông tin vận chuyển" });
      return res.json({ success: true, data: ship });
    }
    const sql = require("mssql");
    const result = await executeQuery(`
      SELECT s.*, o.OrderCode, o.ShippingAddress, o.CustomerName, o.CustomerPhone
      FROM Shipments s
      JOIN Orders o ON s.OrderID = o.OrderID
      WHERE s.TrackingCode = @code OR o.OrderCode = @code
    `, [{ name: "code", type: sql.VarChar, value: trackingCode }]);

    if (result.recordset.length === 0) {
      return res.status(404).json({ success: false, message: "Không tìm thấy thông tin vận chuyển" });
    }
    res.json({ success: true, data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

const updateShipmentStatus = async (req, res, next) => {
  try {
    const shipmentId = parseInt(req.params.id);
    const { status, note, driverName, driverPhone } = req.body;

    if (isMockMode()) {
      const ship = mockShipments.find(s => s.ShipmentID === shipmentId);
      if (!ship) return res.status(404).json({ success: false, message: "Không tìm thấy vận chuyển" });
      if (status) ship.ShippingStatus = status;
      if (note) ship.Note = note;
      if (driverName) ship.DriverName = driverName;
      if (driverPhone) ship.DriverPhone = driverPhone;
      if (status === "delivered") ship.DeliveredAt = new Date().toISOString();
      return res.json({ success: true, message: "Cập nhật vận chuyển thành công", data: ship });
    }

    const sql = require("mssql");
    const result = await executeQuery(`
      UPDATE Shipments
      SET ShippingStatus = ISNULL(@status, ShippingStatus),
          Note = ISNULL(@note, Note),
          DriverName = ISNULL(@driverName, DriverName),
          DriverPhone = ISNULL(@driverPhone, DriverPhone),
          DeliveredAt = CASE WHEN @status = 'delivered' THEN GETDATE() ELSE DeliveredAt END
      OUTPUT INSERTED.*
      WHERE ShipmentID = @id
    `, [
      { name: "id", type: sql.Int, value: shipmentId },
      { name: "status", type: sql.VarChar, value: status || null },
      { name: "note", type: sql.NVarChar, value: note || null },
      { name: "driverName", type: sql.NVarChar, value: driverName || null },
      { name: "driverPhone", type: sql.VarChar, value: driverPhone || null }
    ]);

    if (result.recordset.length === 0) {
      return res.status(404).json({ success: false, message: "Không tìm thấy vận chuyển" });
    }
    res.json({ success: true, message: "Cập nhật vận chuyển thành công", data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

module.exports = { getShipments, getShipmentByTracking, updateShipmentStatus };
