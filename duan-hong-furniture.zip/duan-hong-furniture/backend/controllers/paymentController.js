const { executeQuery, isMockMode } = require("../config/database");

let mockPayments = [
  { PaymentID: 901, OrderCode: "DH-ORD-801", CustomerName: "Anh Hoàng Nam", Amount: 25000000, Phase: "deposit", Method: "bank_transfer", Status: "success", PaidAt: "2026-11-05" },
  { PaymentID: 902, OrderCode: "DH-ORD-802", CustomerName: "Bác Trọng Cường", Amount: 15000000, Phase: "deposit", Method: "cash", Status: "success", PaidAt: "2026-11-04" },
  { PaymentID: 903, OrderCode: "DH-ORD-803", CustomerName: "Chị Minh Tuyết", Amount: 12000000, Phase: "deposit", Method: "bank_transfer", Status: "success", PaidAt: "2026-11-03" }
];

const getPayments = async (req, res, next) => {
  try {
    if (isMockMode()) {
      return res.json({ success: true, count: mockPayments.length, data: mockPayments });
    }
    const result = await executeQuery(`
      SELECT p.PaymentID, p.OrderID, o.OrderCode, c.FullName AS CustomerName,
             p.Amount, p.PaymentPhase, p.PaymentMethod, p.TransactionRef, p.Status, p.PaidAt
      FROM Payments p
      JOIN Orders o ON p.OrderID = o.OrderID
      JOIN Customers c ON o.CustomerID = c.CustomerID
      ORDER BY p.PaidAt DESC
    `);
    res.json({ success: true, count: result.recordset.length, data: result.recordset });
  } catch (error) {
    next(error);
  }
};

const createPayment = async (req, res, next) => {
  try {
    const { orderCode, amount, paymentMethod, paymentPhase = "deposit", transactionRef, note } = req.body;
    if (!orderCode || !amount) {
      return res.status(400).json({ success: false, message: "Mã đơn hàng và số tiền là bắt buộc" });
    }

    if (isMockMode()) {
      const newPay = {
        PaymentID: mockPayments.length + 901,
        OrderCode: orderCode,
        CustomerName: "Khách Hàng Duân Hồng",
        Amount: Number(amount),
        Phase: paymentPhase,
        Method: paymentMethod || "bank_transfer",
        TransactionRef: transactionRef || ("VCB" + Date.now()),
        Status: "success",
        PaidAt: new Date().toISOString()
      };
      mockPayments.unshift(newPay);
      return res.status(201).json({ success: true, message: "Ghi nhận thanh toán thành công", data: newPay });
    }

    const sql = require("mssql");
    const result = await executeQuery(`
      DECLARE @OrderID INT;
      SELECT @OrderID = OrderID FROM Orders WHERE OrderCode = @orderCode;

      IF @OrderID IS NULL
      BEGIN
          RAISERROR(N'Không tìm thấy mã đơn hàng', 16, 1);
          RETURN;
      END

      INSERT INTO Payments (OrderID, PaymentMethod, Amount, TransactionRef, PaymentPhase, Status, Note, PaidAt)
      OUTPUT INSERTED.*
      VALUES (@OrderID, @method, @amount, @ref, @phase, 'success', @note, GETDATE());

      -- Cập nhật trạng thái đơn
      UPDATE Orders
      SET PaymentStatus = CASE WHEN @phase = 'deposit' THEN 'partial_deposit' ELSE 'paid' END
      WHERE OrderID = @OrderID;
    `, [
      { name: "orderCode", type: sql.VarChar, value: orderCode },
      { name: "method", type: sql.VarChar, value: paymentMethod || "bank_transfer" },
      { name: "amount", type: sql.Decimal(18, 2), value: amount },
      { name: "ref", type: sql.VarChar, value: transactionRef || null },
      { name: "phase", type: sql.VarChar, value: paymentPhase },
      { name: "note", type: sql.NVarChar, value: note || null }
    ]);

    res.status(201).json({ success: true, message: "Ghi nhận thanh toán thành công", data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

// @desc    Sinh thông tin mã VietQR ngân hàng cho đơn hàng
// @route   GET /api/payments/vietqr/:orderCode
const getVietQR = async (req, res, next) => {
  try {
    const { orderCode } = req.params;
    const amount = Number(req.query.amount) || 25000000;
    const bankAccount = "0988686868";
    const bankName = "Vietcombank";
    const bankBin = "970436"; // Vietcombank BIN
    const accountName = "NGUYEN VAN DUAN";
    const content = `DUANHONG ${orderCode}`;

    // Chuẩn URL VietQR chuẩn Napas 24/7
    const qrUrl = `https://img.vietqr.io/image/${bankBin}-${bankAccount}-compact2.png?amount=${amount}&addInfo=${encodeURIComponent(content)}&accountName=${encodeURIComponent(accountName)}`;

    res.json({
      success: true,
      data: {
        orderCode,
        amount,
        bankName,
        accountNumber: bankAccount,
        accountName,
        transferMemo: content,
        qrImageUrl: qrUrl,
        instruction: "Gia chủ vui lòng quét mã VietQR để thanh toán cọc mộc thô 30%. Xưởng sẽ liên hệ hẹn lịch ký mộc thô ngay khi phôi mộc hoàn thành."
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getPayments, createPayment, getVietQR };
