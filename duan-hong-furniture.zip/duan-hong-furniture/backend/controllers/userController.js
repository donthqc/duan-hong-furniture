const { executeQuery, isMockMode } = require("../config/database");

let mockUsers = [
  { UserID: 1, FullName: "Nguyễn Văn Duân", Email: "duan.director@duanhong.vn", Role: "Super Admin", Phone: "0988.686.868", IsActive: true },
  { UserID: 2, FullName: "Trần Thị Hồng", Email: "hong.admin@duanhong.vn", Role: "Admin", Phone: "0912.334.556", IsActive: true },
  { UserID: 3, FullName: "Bác Ba Mộc", Email: "thoca.ba@duanhong.vn", Role: "Manager", Phone: "0903.112.233", IsActive: true },
  { UserID: 4, FullName: "Lê Thu Thảo", Email: "thao.cskh@duanhong.vn", Role: "Staff", Phone: "0978.990.112", IsActive: true }
];

// @desc    Lấy danh sách nhân viên & phân quyền
// @route   GET /api/users
// @access  Private (Super Admin, Admin)
const getUsers = async (req, res, next) => {
  try {
    if (isMockMode()) {
      return res.json({ success: true, count: mockUsers.length, data: mockUsers });
    }
    const result = await executeQuery(`
      SELECT u.UserID, u.FullName, u.Email, u.Phone, u.IsActive, u.CreatedAt, r.RoleName AS Role
      FROM Users u
      LEFT JOIN UserRoles ur ON u.UserID = ur.UserID
      LEFT JOIN Roles r ON ur.RoleID = r.RoleID
      ORDER BY u.UserID ASC
    `);
    res.json({ success: true, count: result.recordset.length, data: result.recordset });
  } catch (error) {
    next(error);
  }
};

// @desc    Tạo tài khoản nhân viên mới
// @route   POST /api/users
// @access  Private (Super Admin)
const createUser = async (req, res, next) => {
  try {
    const { fullName, email, phone, role, password } = req.body;
    if (!fullName || !email) {
      return res.status(400).json({ success: false, message: "Họ tên và email là bắt buộc" });
    }

    if (isMockMode()) {
      const newUser = {
        UserID: mockUsers.length + 1,
        FullName: fullName,
        Email: email,
        Phone: phone || "",
        Role: role || "Staff",
        IsActive: true
      };
      mockUsers.push(newUser);
      return res.status(201).json({ success: true, message: "Tạo nhân viên thành công", data: newUser });
    }

    // Hash password & insert into SQL Server
    const bcrypt = require("bcryptjs");
    const hash = await bcrypt.hash(password || "DuanHong@2026", 10);
    const result = await executeQuery(`
      INSERT INTO Users (FullName, Email, PasswordHash, Phone, IsActive)
      OUTPUT INSERTED.UserID, INSERTED.FullName, INSERTED.Email, INSERTED.Phone
      VALUES (@fullName, @email, @hash, @phone, 1)
    `, [
      { name: "fullName", type: require("mssql").NVarChar, value: fullName },
      { name: "email", type: require("mssql").VarChar, value: email },
      { name: "hash", type: require("mssql").VarChar, value: hash },
      { name: "phone", type: require("mssql").VarChar, value: phone || "" }
    ]);

    res.status(201).json({ success: true, message: "Tạo nhân viên thành công", data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

// @desc    Khóa / Mở khóa tài khoản nhân viên
// @route   PUT /api/users/:id/toggle-status
// @access  Private (Super Admin)
const toggleUserStatus = async (req, res, next) => {
  try {
    const userId = parseInt(req.params.id);
    if (isMockMode()) {
      const user = mockUsers.find(u => u.UserID === userId);
      if (!user) return res.status(404).json({ success: false, message: "Không tìm thấy nhân viên" });
      user.IsActive = !user.IsActive;
      return res.json({ success: true, message: `Đã ${user.IsActive ? "mở khóa" : "khóa"} tài khoản`, data: user });
    }

    const result = await executeQuery(`
      UPDATE Users SET IsActive = CASE WHEN IsActive = 1 THEN 0 ELSE 1 END
      OUTPUT INSERTED.UserID, INSERTED.FullName, INSERTED.IsActive
      WHERE UserID = @id
    `, [{ name: "id", type: require("mssql").Int, value: userId }]);

    if (result.recordset.length === 0) {
      return res.status(404).json({ success: false, message: "Không tìm thấy nhân viên" });
    }
    res.json({ success: true, message: "Cập nhật trạng thái thành công", data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

module.exports = { getUsers, createUser, toggleUserStatus };
