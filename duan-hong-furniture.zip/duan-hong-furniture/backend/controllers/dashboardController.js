// @route   GET /api/dashboard/kpis
// @desc    Lấy số liệu tổng quan KPI
exports.getKPIs = async (req, res, next) => {
  try {
    res.json({
      success: true,
      data: {
        totalRevenue: 1480000000,
        formattedRevenue: "1.480.000.000 đ",
        revenueGrowthPercent: 18,
        activeOrdersCount: 4,
        totalCustomersCount: 128,
        inventoryStockCount: 24,
        averageOrderValue: "68.500.000 đ",
        mocSignedRatioPercent: 92
      }
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/dashboard/revenue-trend
// @desc    Lấy dữ liệu biểu đồ doanh thu theo tháng
exports.getRevenueTrend = async (req, res, next) => {
  try {
    res.json({
      success: true,
      data: {
        labels: ["Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11 (Nay)"],
        revenue: [820, 950, 1150, 1280, 1390, 1480], // Triệu VNĐ
        orders: [12, 16, 20, 24, 28, 32]
      }
    });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/dashboard/wood-demand
// @desc    Lấy tỷ lệ quan tâm theo chất liệu gỗ
exports.getWoodDemand = async (req, res, next) => {
  try {
    res.json({
      success: true,
      data: {
        labels: ["Gỗ Gõ Đỏ Pachy", "Gỗ Óc Chó Bắc Mỹ", "Gỗ Sồi Nga", "MDF Lõi Xanh An Cường"],
        percentages: [45, 30, 15, 10]
      }
    });
  } catch (error) {
    next(error);
  }
};
