const { executeQuery, isMockMode } = require("../config/database");

const getOverviewReport = async (req, res, next) => {
  try {
    const reportData = {
      totalRevenue: 284000000,
      totalOrders: 4,
      completedOrders: 1,
      processingOrders: 3,
      cancellationRate: "0%",
      depositCollected: 87000000,
      pendingCollection: 197000000,
      averageOrderValue: 71000000,
      customerSatisfactionRate: "98.5%",
      workshopEfficiency: "96%"
    };
    res.json({ success: true, data: reportData });
  } catch (error) {
    next(error);
  }
};

const getRevenueByPeriod = async (req, res, next) => {
  try {
    const data = [
      { period: "Tháng 06", revenue: 145000000, orders: 3 },
      { period: "Tháng 07", revenue: 180000000, orders: 4 },
      { period: "Tháng 08", revenue: 210000000, orders: 5 },
      { period: "Tháng 09", revenue: 195000000, orders: 4 },
      { period: "Tháng 10", revenue: 250000000, orders: 6 },
      { period: "Tháng 11", revenue: 284000000, orders: 7 }
    ];
    res.json({ success: true, data });
  } catch (error) {
    next(error);
  }
};

const exportCSV = async (req, res, next) => {
  try {
    // Generate CSV string
    const headers = "MaDonHang,KhachHang,SoDienThoai,DiaChi,SanPham,TongTien,DaCoc30,TrangThaiXUong,KyMocTho\n";
    const rows = [
      'DH-ORD-801,"Anh Hoàng Nam","0912.445.889","Mỹ Hào, Hưng Yên","Bộ Sofa Gõ Đỏ Chân Quỳ",74500000,25000000,"Đang Ghép Mộng",1',
      'DH-ORD-802,"Bác Trọng Cường","0904.556.778","TP. Hưng Yên","Án Gian Thờ Nhị Cấp",48000000,15000000,"Đang Phun Sơn PU",1',
      'DH-ORD-803,"Chị Minh Tuyết","0983.112.334","Yên Mỹ, Hưng Yên","Combo Phòng Ngủ Sồi Nga",36900000,12000000,"Đang Tẩm Sấy",0',
      'DH-ORD-804,"Anh Quốc Bảo","0977.889.900","Văn Giang, Hưng Yên","Bàn Ăn Live-Edge",38000000,38000000,"Đã Bàn Giao",1'
    ].join("\n");

    const csvContent = "\uFEFF" + headers + rows; // UTF-8 BOM for Excel display

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="Bao_Cao_Doanh_Thu_Duan_Hong.csv"');
    res.status(200).send(csvContent);
  } catch (error) {
    next(error);
  }
};

module.exports = { getOverviewReport, getRevenueByPeriod, exportCSV };
