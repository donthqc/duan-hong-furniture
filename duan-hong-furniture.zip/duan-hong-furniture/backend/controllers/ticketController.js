const { executeQuery, isMockMode } = require("../config/database");

let mockTickets = [
  { TicketID: 1, TicketCode: "CS001", CustomerName: "Anh Hoàng Nam", Phone: "0912.445.889", OrderCode: "DH-ORD-801", Title: "Hẹn lịch về xưởng Hưng Yên ký mộc thô", Description: "Khách muốn trực tiếp kiểm tra tom gỗ phôi sofa gõ đỏ trước khi xưởng chuyển vào phòng sơn PU", Channel: "zalo", Priority: "high", Status: "processing", AssignedTo: "Bác Ba Mộc (Thợ Cả)", CreatedAt: "2026-11-05" },
  { TicketID: 2, TicketCode: "CS002", CustomerName: "Bác Trọng Cường", Phone: "0904.556.778", OrderCode: "DH-ORD-802", Title: "Tư vấn kích thước Lỗ Ban Cung Đỏ án gian", Description: "Đo đạc kiểm tra lại chiều cao án gian thờ chuẩn 1m27 theo thước phong thủy", Channel: "live_chat", Priority: "normal", Status: "resolved", AssignedTo: "Lê Thu Thảo (CSKH)", CreatedAt: "2026-11-04" },
  { TicketID: 3, TicketCode: "CS003", CustomerName: "Chị Minh Tuyết", Phone: "0983.112.334", OrderCode: "DH-ORD-803", Title: "Bảo hành bảo dưỡng định kỳ 6 tháng lau dầu", Description: "Gia chủ đề nghị thợ mang dầu lau dưỡng bóng gỗ sồi định kỳ theo cam kết bảo hành 5 năm", Channel: "phone", Priority: "normal", Status: "new", AssignedTo: "Chưa phân công", CreatedAt: "2026-11-06" }
];

const getTickets = async (req, res, next) => {
  try {
    if (isMockMode()) {
      return res.json({ success: true, count: mockTickets.length, data: mockTickets });
    }
    const result = await executeQuery(`
      SELECT t.TicketID, t.TicketCode, t.Title, t.Description, t.Channel, t.Priority, t.Status,
             t.CreatedAt, t.ResolvedAt, c.FullName AS CustomerName, c.Phone, o.OrderCode, u.FullName AS AssignedTo
      FROM SupportTickets t
      JOIN Customers c ON t.CustomerID = c.CustomerID
      LEFT JOIN Orders o ON t.OrderID = o.OrderID
      LEFT JOIN Users u ON t.AssignedTo = u.UserID
      ORDER BY t.TicketID DESC
    `);
    res.json({ success: true, count: result.recordset.length, data: result.recordset });
  } catch (error) {
    next(error);
  }
};

const createTicket = async (req, res, next) => {
  try {
    const { customerName, phone, title, description, channel = "web_form", priority = "normal", orderCode } = req.body;
    if (!customerName || !phone || !title || !description) {
      return res.status(400).json({ success: false, message: "Họ tên, số điện thoại, tiêu đề và nội dung là bắt buộc" });
    }

    const code = "CS" + String(Date.now()).slice(-4);

    if (isMockMode()) {
      const newTicket = {
        TicketID: mockTickets.length + 1,
        TicketCode: code,
        CustomerName: customerName,
        Phone: phone,
        OrderCode: orderCode || "Tư vấn chung",
        Title: title,
        Description: description,
        Channel: channel,
        Priority: priority,
        Status: "new",
        AssignedTo: "Chưa phân công",
        CreatedAt: new Date().toISOString()
      };
      mockTickets.unshift(newTicket);
      return res.status(201).json({ success: true, message: "Tạo phiếu hỗ trợ CSKH thành công", data: newTicket });
    }

    const sql = require("mssql");
    const result = await executeQuery(`
      DECLARE @CustID INT;
      SELECT @CustID = CustomerID FROM Customers WHERE Phone = @phone;
      IF @CustID IS NULL
      BEGIN
          INSERT INTO Customers (FullName, Phone, CustomerType)
          VALUES (@name, @phone, 'retail');
          SET @CustID = SCOPE_IDENTITY();
      END

      DECLARE @OrdID INT;
      IF @orderCode IS NOT NULL
          SELECT @OrdID = OrderID FROM Orders WHERE OrderCode = @orderCode;

      INSERT INTO SupportTickets (TicketCode, CustomerID, OrderID, Title, Description, Channel, Priority, Status, CreatedAt)
      OUTPUT INSERTED.*
      VALUES (@code, @CustID, @OrdID, @title, @desc, @channel, @prio, 'new', GETDATE());
    `, [
      { name: "name", type: sql.NVarChar, value: customerName },
      { name: "phone", type: sql.VarChar, value: phone },
      { name: "code", type: sql.VarChar, value: code },
      { name: "title", type: sql.NVarChar, value: title },
      { name: "desc", type: sql.NVarChar, value: description },
      { name: "channel", type: sql.VarChar, value: channel },
      { name: "prio", type: sql.VarChar, value: priority },
      { name: "orderCode", type: sql.VarChar, value: orderCode || null }
    ]);

    res.status(201).json({ success: true, message: "Tạo phiếu hỗ trợ CSKH thành công", data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

const updateTicketStatus = async (req, res, next) => {
  try {
    const ticketId = parseInt(req.params.id);
    const { status, resolutionNote } = req.body;

    if (isMockMode()) {
      const ticket = mockTickets.find(t => t.TicketID === ticketId);
      if (!ticket) return res.status(404).json({ success: false, message: "Không tìm thấy ticket" });
      if (status) ticket.Status = status;
      if (resolutionNote) ticket.ResolutionNote = resolutionNote;
      return res.json({ success: true, message: "Cập nhật trạng thái ticket thành công", data: ticket });
    }

    const sql = require("mssql");
    const result = await executeQuery(`
      UPDATE SupportTickets
      SET Status = ISNULL(@status, Status),
          ResolutionNote = ISNULL(@note, ResolutionNote),
          ResolvedAt = CASE WHEN @status = 'resolved' THEN GETDATE() ELSE ResolvedAt END
      OUTPUT INSERTED.*
      WHERE TicketID = @id
    `, [
      { name: "id", type: sql.Int, value: ticketId },
      { name: "status", type: sql.VarChar, value: status || null },
      { name: "note", type: sql.NVarChar, value: resolutionNote || null }
    ]);

    if (result.recordset.length === 0) {
      return res.status(404).json({ success: false, message: "Không tìm thấy ticket" });
    }
    res.json({ success: true, message: "Cập nhật ticket thành công", data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

const assignTicket = async (req, res, next) => {
  try {
    const ticketId = parseInt(req.params.id);
    const { assignedToName, assignedToId } = req.body;

    if (isMockMode()) {
      const ticket = mockTickets.find(t => t.TicketID === ticketId);
      if (!ticket) return res.status(404).json({ success: false, message: "Không tìm thấy ticket" });
      ticket.AssignedTo = assignedToName || "Nhân viên CSKH Duân Hồng";
      return res.json({ success: true, message: "Phân công xử lý ticket thành công", data: ticket });
    }

    const sql = require("mssql");
    const result = await executeQuery(`
      UPDATE SupportTickets
      SET AssignedTo = @userId
      OUTPUT INSERTED.*
      WHERE TicketID = @id
    `, [
      { name: "id", type: sql.Int, value: ticketId },
      { name: "userId", type: sql.Int, value: assignedToId }
    ]);

    res.json({ success: true, message: "Phân công xử lý ticket thành công", data: result.recordset[0] });
  } catch (error) {
    next(error);
  }
};

module.exports = { getTickets, createTicket, updateTicketStatus, assignTicket };
