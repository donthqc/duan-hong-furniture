const express = require("express");
const router = express.Router();
const { getPayments, createPayment, getVietQR } = require("../controllers/paymentController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Public API để lấy mã VietQR thanh toán cọc đơn hàng
router.get("/vietqr/:orderCode", getVietQR);

// Quản trị thanh toán
router.get("/", protect, authorize("Super Admin", "Admin", "Manager"), getPayments);
router.post("/", protect, authorize("Super Admin", "Admin", "Manager"), createPayment);

module.exports = router;
