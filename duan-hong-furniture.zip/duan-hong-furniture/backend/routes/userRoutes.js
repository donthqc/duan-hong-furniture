const express = require("express");
const router = express.Router();
const { getUsers, createUser, toggleUserStatus } = require("../controllers/userController");
const { protect, authorize } = require("../middleware/authMiddleware");

router.get("/", protect, authorize("Super Admin", "Admin"), getUsers);
router.post("/", protect, authorize("Super Admin"), createUser);
router.put("/:id/toggle-status", protect, authorize("Super Admin"), toggleUserStatus);

module.exports = router;
