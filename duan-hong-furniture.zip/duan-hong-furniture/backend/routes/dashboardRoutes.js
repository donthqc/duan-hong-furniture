const express = require("express");
const router = express.Router();
const { getKPIs, getRevenueTrend, getWoodDemand } = require("../controllers/dashboardController");
const { protect } = require("../middleware/authMiddleware");

router.get("/kpis", getKPIs);
router.get("/revenue-trend", getRevenueTrend);
router.get("/wood-demand", getWoodDemand);

module.exports = router;
