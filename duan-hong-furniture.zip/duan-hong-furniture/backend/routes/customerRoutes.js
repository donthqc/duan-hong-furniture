const express = require("express");
const router = express.Router();
const { getCustomers, updateCustomerNotes } = require("../controllers/customerController");
const { protect } = require("../middleware/authMiddleware");

router.get("/", protect, getCustomers);
router.put("/:id/notes", protect, updateCustomerNotes);

module.exports = router;
