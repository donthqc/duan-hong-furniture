const express = require("express");
const router = express.Router();
const { getProducts, getProductById, createProduct, deleteProduct } = require("../controllers/productController");
const { protect, authorize } = require("../middleware/authMiddleware");

router.get("/", getProducts);
router.get("/:id", getProductById);
router.post("/", protect, authorize("Super Admin", "Admin", "Manager"), createProduct);
router.delete("/:id", protect, authorize("Super Admin", "Admin"), deleteProduct);

module.exports = router;
