const express = require("express");
const router = express.Router();
const { getShipments, getShipmentByTracking, updateShipmentStatus } = require("../controllers/shipmentController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Public tra cứu vận chuyển đơn hàng xưởng
router.get("/track/:trackingCode", getShipmentByTracking);

// Quản trị vận chuyển xưởng
router.get("/", protect, authorize("Super Admin", "Admin", "Manager", "Staff"), getShipments);
router.put("/:id/status", protect, authorize("Super Admin", "Admin", "Manager"), updateShipmentStatus);

module.exports = router;
