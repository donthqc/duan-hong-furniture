const express = require("express");
const router = express.Router();
const { getSettings, updateSetting } = require("../controllers/settingController");
const { protect, authorize } = require("../middleware/authMiddleware");

router.get("/", getSettings);
router.put("/", protect, authorize("Super Admin"), updateSetting);

module.exports = router;
