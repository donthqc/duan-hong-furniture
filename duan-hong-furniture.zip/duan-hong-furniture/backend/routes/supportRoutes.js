const express = require("express");
const router = express.Router();
const { getTickets, createTicket, getChatMessages, sendChatMessage } = require("../controllers/supportController");
const { protect } = require("../middleware/authMiddleware");

// Ticket CSKH
router.get("/tickets", protect, getTickets);
router.post("/tickets", createTicket);

// Live Chat CSKH
router.get("/chat/messages", getChatMessages);
router.post("/chat/messages", sendChatMessage);

module.exports = router;
