const express = require("express");
const router = express.Router();
const { getOverviewReport, getRevenueByPeriod, exportCSV } = require("../controllers/reportController");
const { protect, authorize } = require("../middleware/authMiddleware");

router.get("/overview", protect, authorize("Super Admin", "Admin"), getOverviewReport);
router.get("/revenue", protect, authorize("Super Admin", "Admin"), getRevenueByPeriod);
router.get("/export-csv", protect, authorize("Super Admin", "Admin"), exportCSV);

module.exports = router;
