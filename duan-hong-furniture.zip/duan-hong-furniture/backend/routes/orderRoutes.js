const express = require("express");
const router = express.Router();
const { getOrders, createOrder, updateOrderStatus, toggleMocSigned, trackOrder } = require("../controllers/orderController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Public API tra cứu đơn hàng cho khách hàng
router.get("/track/:code", trackOrder);

// API đơn hàng
router.get("/", getOrders);
router.post("/", createOrder);
router.put("/:id/status", protect, authorize("Super Admin", "Admin", "Manager"), updateOrderStatus);
router.put("/:id/moc-sign", protect, authorize("Super Admin", "Admin", "Manager"), toggleMocSigned);

module.exports = router;
