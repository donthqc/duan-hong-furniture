const express = require("express");
const router = express.Router();
const { getTickets, createTicket, updateTicketStatus, assignTicket } = require("../controllers/ticketController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Public khách hàng gửi yêu cầu / ticket
router.post("/", createTicket);

// Quản trị CSKH
router.get("/", protect, getTickets);
router.put("/:id/status", protect, updateTicketStatus);
router.post("/:id/assign", protect, authorize("Super Admin", "Admin", "Manager"), assignTicket);

module.exports = router;
