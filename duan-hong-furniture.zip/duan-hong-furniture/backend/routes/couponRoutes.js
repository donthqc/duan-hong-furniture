const express = require("express");
const router = express.Router();
const { getCoupons, applyCoupon, createCoupon } = require("../controllers/couponController");
const { protect, authorize } = require("../middleware/authMiddleware");

// Public
router.get("/", getCoupons);
router.post("/apply", applyCoupon);

// Admin
router.post("/", protect, authorize("Super Admin", "Admin"), createCoupon);

module.exports = router;
