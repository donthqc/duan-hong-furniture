require("dotenv").config();
const app = require("./app");
const { poolPromise } = require("./config/database");

const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, async () => {
  console.log("=================================================================");
  console.log(`🚀 DUAN HONG FURNITURE API SERVER ĐANG CHẠY TẠI CỔNG : ${PORT}`);
  console.log(`📍 Địa chỉ xưởng: Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên`);
  console.log(`📞 Hotline / Zalo: 0988.686.868 (Trực 24/7)`);
  console.log(`🌐 Base URL: http://localhost:${PORT}`);
  console.log(`📋 Kiểm tra sức khỏe hệ thống: http://localhost:${PORT}/api/health`);
  console.log("=================================================================");

  // Kích hoạt pool kết nối SQL Server
  try {
    await poolPromise;
  } catch (err) {
    console.log("[Info] SQL Server chưa sẵn sàng, server đang chạy với mock data in-memory.");
  }
});

// Xử lý dừng máy chủ an toàn
process.on("unhandledRejection", (err) => {
  console.error("Unhandled Rejection:", err);
});

process.on("SIGTERM", () => {
  console.log("Đang đóng HTTP Server an toàn...");
  server.close(() => {
    console.log("Process terminated.");
  });
});
