const jwt = require("jsonwebtoken");

// Middleware xác thực JWT token
const protect = (req, res, next) => {
  let token = null;

  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    token = req.headers.authorization.split(" ")[1];
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: "Không có quyền truy cập. Vui lòng đăng nhập!"
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "duanhong_furniture_hungyen_secret_key_2026_jwt_token");
    req.user = decoded; // { id, email, role }
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: "Phiên đăng nhập không hợp lệ hoặc đã hết hạn!"
    });
  }
};

// Middleware phân quyền theo vai trò (RBAC)
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Vai trò [${req.user?.role || "Khách"}] không được phép thực hiện hành động này!`
      });
    }
    next();
  };
};

module.exports = {
  protect,
  authorize
};
