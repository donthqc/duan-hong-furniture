// Middleware bắt lỗi 404 Not Found
const notFound = (req, res, next) => {
  const error = new Error(`Không tìm thấy endpoint API: ${req.originalUrl}`);
  res.status(404);
  next(error);
};

// Middleware xử lý lỗi tập trung
const errorHandler = (err, req, res, next) => {
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.status(statusCode).json({
    success: false,
    message: err.message || "Lỗi máy chủ nội bộ",
    stack: process.env.NODE_ENV === "production" ? null : err.stack
  });
};

module.exports = {
  notFound,
  errorHandler
};
