# HƯỚNG DẪN CÀI ĐẶT & VẬN HÀNH NODE.JS/EXPRESS API

> **Dự án:** Backend API Hệ Thống E-Commerce & Nội Thất Đồ Gỗ Duân Hồng  
> **Địa chỉ:** Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên  
> **Hotline/Zalo:** `0988.686.868`  
> **Cơ sở dữ liệu:** Tương thích Microsoft SQL Server 2014 / 2016 / 2019 / 2022

---

## 1. Yêu Cầu Cài Đặt Ban Đầu

1. **Môi trường:** Cài đặt Node.js phiên bản LTS (khuyến nghị $\ge 18.x$) từ [nodejs.org](https://nodejs.org).
2. **Cơ sở dữ liệu:** Microsoft SQL Server 2014 (hoặc bản mới hơn).  
   * Khởi chạy tệp script [database/schema.sql](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/database/schema.sql) trong SQL Server Management Studio (SSMS) để tạo database `DuanHongEcommerceDB`.

---

## 2. Hướng Dẫn Khởi Chạy

Mở Terminal trên máy tính của bạn và di chuyển vào thư mục `backend/`:

```bash
cd /Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/backend

# 1. Cài đặt các thư viện cần thiết
npm install

# 2. Chạy ở chế độ phát triển (Tự động tải lại khi sửa code)
npm run dev

# Hoặc chạy ở chế độ Production
npm start
```

Khi server khởi động thành công, màn hình sẽ thông báo:
```text
🚀 DUAN HONG FURNITURE API SERVER ĐANG CHẠY TẠI CỔNG : 5000
📍 Địa chỉ xưởng: Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên
📞 Hotline / Zalo: 0988.686.868 (Trực 24/7)
🌐 Base URL: http://localhost:5000
```

---

## 3. Danh Sách Endpoint RESTful API

### Xác thực & Phân quyền (Auth & RBAC)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/login` | Đăng nhập tài khoản quản trị (trả về JWT) | Public |
| `GET` | `/api/auth/profile` | Xem thông tin tài khoản hiện tại | Đã đăng nhập (Bearer Token) |

### Sản phẩm & Kho gỗ (Products & Inventory)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/products` | Lấy danh sách sản phẩm (hỗ trợ lọc danh mục, chất gỗ, tìm kiếm) | Public |
| `GET` | `/api/products/:id` | Xem chi tiết 1 sản phẩm | Public |
| `POST` | `/api/products` | Thêm mẫu đồ gỗ mới vào kho | Super Admin, Admin, Manager |
| `DELETE`| `/api/products/:id` | Xóa sản phẩm khỏi kho | Super Admin, Admin |

### Đơn hàng & Xưởng chế tác (Orders & Workshop)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/orders` | Danh sách đơn hàng & tiến độ xưởng | Public / Admin |
| `POST` | `/api/orders` | Tạo đơn hàng đặt cọc may đo mới | Public |
| `GET` | `/api/orders/track/:code` | **Tra cứu tiến độ 5 bước** (mã đơn hoặc SĐT) | Public |
| `PUT` | `/api/orders/:id/status` | Cập nhật công đoạn (Sấy phôi $\rightarrow$ Đục mộng $\rightarrow$ Phun PU) | Super Admin, Admin, Manager |
| `PUT` | `/api/orders/:id/moc-sign`| **Xác nhận gia chủ ký tên lên phôi mộc thô** | Super Admin, Admin, Manager |

### Chăm sóc khách hàng & CSKH (Support & CRM)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/support/tickets` | Danh sách Ticket CSKH (CS001, CS002...) | Đã đăng nhập |
| `POST` | `/api/support/tickets` | Tạo Ticket yêu cầu hỗ trợ mới | Public / Client |
| `GET` | `/api/support/chat/messages` | Lịch sử tin nhắn Live Chat | Public |
| `POST` | `/api/support/chat/messages` | Gửi tin nhắn Live Chat & nhận phản hồi | Public |

### Báo cáo & Thống kê (Dashboard Analytics)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/dashboard/kpis` | Lấy các chỉ số KPI doanh thu, đơn hàng, tồn kho | Public / Admin |
| `GET` | `/api/dashboard/revenue-trend` | Dữ liệu biểu đồ doanh thu theo tháng | Public / Admin |
| `GET` | `/api/dashboard/wood-demand` | Tỷ lệ cơ cấu chất liệu gỗ bán ra | Public / Admin |
