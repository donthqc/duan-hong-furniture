const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const { notFound, errorHandler } = require("./middleware/errorMiddleware");

// 14 API Route Groups (Theo đặc tả Section 8)
const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");
const productRoutes = require("./routes/productRoutes");
const categoryRoutes = require("./routes/categoryRoutes");
const cartRoutes = require("./routes/cartRoutes");
const orderRoutes = require("./routes/orderRoutes");
const paymentRoutes = require("./routes/paymentRoutes");
const shipmentRoutes = require("./routes/shipmentRoutes");
const customerRoutes = require("./routes/customerRoutes");
const couponRoutes = require("./routes/couponRoutes");
const supportRoutes = require("./routes/supportRoutes");
const ticketRoutes = require("./routes/ticketRoutes");
const reportRoutes = require("./routes/reportRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");
const settingRoutes = require("./routes/settingRoutes");

const app = express();

// Middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN || "*",
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== "test") {
  app.use(morgan("dev"));
}

// Root endpoint
app.get("/", (req, res) => {
  res.json({
    success: true,
    name: "Hệ Thống API Đồ Gỗ Nội Thất Duân Hồng",
    version: "2.0.0",
    workshop: "Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên",
    hotline: "0988.686.868",
    status: "Online",
    docs: "/api/health",
    modules: [
      "/api/auth", "/api/users", "/api/products", "/api/categories",
      "/api/cart", "/api/orders", "/api/payments", "/api/shipments",
      "/api/customers", "/api/coupons", "/api/support", "/api/tickets",
      "/api/reports", "/api/settings"
    ]
  });
});

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "UP",
    brand: "Công ty Đồ Gỗ Nội Thất Duân Hồng",
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    database: "SQL Server 2014 Compatible (Dual-Mode Auto Fallback Active)"
  });
});

// Gắn kết 14 nhóm API RESTful
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/products", productRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/shipments", shipmentRoutes);
app.use("/api/customers", customerRoutes);
app.use("/api/coupons", couponRoutes);
app.use("/api/support", supportRoutes);
app.use("/api/tickets", ticketRoutes);
app.use("/api/reports", reportRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/settings", settingRoutes);

// Error Handling Middleware
app.use(notFound);
app.use(errorHandler);

module.exports = app;
