# HƯỚNG DẪN TRIỂN KHAI HỆ THỐNG LÊN INTERNET (PRODUCTION DEPLOYMENT)
**Tệp:** `DEPLOYMENT_GUIDE.md`  
**Dự án:** Hệ Thống Thương Mại Điện Tử & Vận Hành Xưởng Đồ Gỗ Duân Hồng  
**Domain mục tiêu:** `duanhong.vn` / `noithatduanhong.vn`  
**Thương hiệu:** Công ty Đồ Gỗ Nội Thất Duân Hồng (Đường Nguyễn Du, TP. Hưng Yên)  
**Hotline / Zalo:** `0988.686.868` (Trực 24/7)

---

## 1. YÊU CẦU HẠ TẦNG MÁY CHỦ (SERVER SPECIFICATIONS)

- **Hệ điều hành:** Ubuntu Server 22.04 LTS (hoặc 20.04 LTS).
- **Cấu hình tối thiểu:**
  - CPU: 2 Cores
  - RAM: 4 GB (8 GB nếu chạy chung SQL Server trên cùng VPS)
  - SSD: 50 GB NVMe
- **Phần mềm cần cài đặt:**
  - Node.js LTS (Phiên bản $\ge 18.x$) & npm
  - PM2 Process Manager (Quản lý tiến trình chạy ngầm & tự khởi động lại khi reboot)
  - Nginx (Web Server & Reverse Proxy)
  - Certbot (Cấp chứng chỉ SSL HTTPS Let's Encrypt miễn phí tự động gia hạn)
  - Microsoft SQL Server 2014 / 2019 / 2022 (Local hoặc Dedicated Database Server)

---

## 2. QUY TRÌNH 7 BƯỚC TRIỂN KHAI THỰC TẾ

### Bước 1: Chuẩn Bị & Cập Nhật Hệ Thống Máy Chủ
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git nginx ufw fail2ban

# Cài đặt Node.js 20.x LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Cài đặt PM2 toàn cục
sudo npm install -g pm2
```

### Bước 2: Tải Mã Nguồn Dự Án
```bash
sudo mkdir -p /var/www/duanhong
sudo chown -R $USER:$USER /var/www/duanhong
cd /var/www/duanhong

# Clone hoặc giải nén mã nguồn dự án vào đây
# Cấu trúc: /var/www/duanhong/backend và /var/www/duanhong/frontend
```

### Bước 3: Cấu Hình Biến Môi Trường Production
Tạo file `/var/www/duanhong/backend/.env`:
```ini
PORT=5000
NODE_ENV=production

# Kết nối Microsoft SQL Server
DB_SERVER=127.0.0.1
DB_PORT=1433
DB_USER=sa
DB_PASSWORD=YourStrongPassword@2026
DB_NAME=DuanHongEcommerceDB

# Bảo mật & Mã hóa
JWT_SECRET=DuanHong_Secured_Key_988686868_!@#
JWT_EXPIRE=7d
CORS_ORIGIN=https://duanhong.vn

# Hotline & Địa chỉ xưởng
STORE_NAME="Công ty Đồ Gỗ Nội Thất Duân Hồng"
STORE_ADDRESS="Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên"
STORE_HOTLINE="0988.686.868"
```

### Bước 4: Cài Đặt Dependency & Chạy Backend Bằng PM2
```bash
cd /var/www/duanhong/backend
npm install --production

# Khởi chạy dịch vụ API bằng PM2
pm2 start server.js --name "duanhong-api" -i max
pm2 save
pm2 startup
```

### Bước 5: Cấu Hình Nginx Reverse Proxy & Phục Vụ Giao Diện
Tạo file cấu hình Nginx `/etc/nginx/sites-available/duanhong.vn`:
```nginx
server {
    listen 80;
    server_name duanhong.vn www.duanhong.vn;

    # Thư mục chứa giao diện Storefront & Admin
    root /var/www/duanhong/frontend;
    index index.html;

    # Giao diện chính Website Bán Hàng
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Bảng điều khiển Quản trị CMS
    location /admin {
        try_files /admin.html =404;
    }

    # Chuyển tiếp toàn bộ API sang Node.js Backend cổng 5000
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 60s;
    }

    # Giới hạn kích thước tải ảnh phôi mộc tối đa 15MB
    client_max_body_size 15M;
}
```

Kích hoạt cấu hình:
```bash
sudo ln -s /etc/nginx/sites-available/duanhong.vn /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Bước 6: Cấu Hình SSL / HTTPS Miễn Phí Với Certbot
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d duanhong.vn -d www.duanhong.vn --non-interactive --agree-tos -m admin@duanhong.vn
```

### Bước 7: Cấu Hình Tường Lửa (UFW Firewall)
```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable
```

---

## 3. KIỂM THỬ HOẠT ĐỘNG SAU TRIỂN KHAI (SMOKE TEST)

1. Kiểm tra API Health Check:
   ```bash
   curl -I https://duanhong.vn/api/health
   # Kết quả mong đợi: HTTP/2 200 OK
   ```
2. Kiểm tra giao diện Storefront:
   Truy cập `https://duanhong.vn` trên trình duyệt điện thoại và máy tính.
3. Kiểm tra Dashboard Quản trị:
   Truy cập `https://duanhong.vn/admin` đăng nhập bằng tài khoản quản trị.
