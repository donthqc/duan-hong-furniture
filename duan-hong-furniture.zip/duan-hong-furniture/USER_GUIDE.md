# SỔ TAY HƯỚNG DẪN VẬN HÀNH HỆ THỐNG NỘI THẤT DUÂN HỒNG
**Tệp:** `USER_GUIDE.md`  
**Dành cho:** Ban Giám Đốc, Quản Trị Viên, Thợ Cả Xưởng Mộc & Nhân Viên CSKH  
**Thương hiệu:** Công ty Đồ Gỗ Nội Thất Duân Hồng (Đường Nguyễn Du, TP. Hưng Yên)  
**Hotline / Zalo:** `0988.686.868` (Trực 24/7)

---

## 1. DÀNH CHO THỢ CẢ / QUẢN LÝ XƯỞNG MỘC (NGHIỆP VỤ KÝ MỘC THÔ)

> [!IMPORTANT]
> **Cam Kết Vàng Số 1 Của Xưởng Duân Hồng:** Tuyệt đối không đưa sản phẩm vào buồng phun sơn PU khi gia chủ chưa về xưởng kiểm tra chất gỗ và ký tên bằng bút lông lên phôi mộc thô!

### Quy Trình Thao Tác Trên CMS:
1. Đăng nhập trang quản trị [admin.html](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/admin.html) $\rightarrow$ Chọn phân hệ **"03. Đơn Hàng & Xưởng"**.
2. Tìm đơn hàng thi công tương ứng (ví dụ: `DH-ORD-801`).
3. Cập nhật tiến độ gia công xưởng:
   - `Đang Sấy Phôi Mộc Thô`: Theo dõi đồng hồ đo độ ẩm đạt chuẩn $10\% - 12\%$.
   - `Đang Ghép Mộng Đục Tay`: Thợ mộc đục mộng thủ công, đục hoa văn kênh bong.
4. Khi sản phẩm hoàn thành phần mộc thô:
   - Nhấn nút **"Hẹn Khách Về Xưởng Ký Mộc"** để chuyển thông tin sang bộ phận CSKH liên hệ gia chủ.
   - Khi gia chủ về xưởng tại **Đường Nguyễn Du, TP. Hưng Yên**, dẫn gia chủ kiểm tra tom gỗ, mắt gỗ và hướng dẫn dùng bút dạ/bút lông ký tên dưới đáy gầm bàn/giường.
   - Nhấn nút toggle **"✓ Đã Ký Mộc Thô"** trên màn hình đơn hàng.
5. Chuyển sản phẩm sang bước:
   - `Đang Phun PU Lau Dầu`: Lót 3 lớp, màu hạt dẻ/óc chó, phủ bóng mờ chống xước.
   - `Đang Giao Xe Tải Xưởng`: Bàn giao phiếu xuất xưởng cho lái xe tải (Miễn phí $\le 30$ km).

---

## 2. DÀNH CHO NHÂN VIÊN CSKH & TƯ VẤN BÁN HÀNG

### 2.1. Tiếp Nhận Khách Hàng Live Chat (24/7)
- Cửa sổ Live Chat trên trang chủ tự động hỗ trợ tư vấn các câu hỏi thường gặp:
  - Báo giá 2 gói Combo kích cầu (Phòng ngủ sồi Nga 36.9tr & Sofa Gõ Đỏ 74.5tr).
  - Kích thước Lỗ Ban Cung Đỏ (Cung Tài Vượng, Tiến Bảo, Đăng Khoa).
  - Chính sách xe xưởng giao miễn phí 30km quanh TP. Hưng Yên.
- Khi khách để lại số điện thoại: Hệ thống tự động tạo hồ sơ khách hàng mới trong phân hệ **"04. Khách Hàng & CSKH"**. Gọi lại ngay trong vòng **15 phút**.

### 2.2. Xử Lý Ticket Bảo Hành 5 Năm (CS001...)
- Khi khách hàng gọi điện báo sự cố (ví dụ: co ngót nhẹ do thời tiết hanh khô mùa đông):
  1. Vào phân hệ **"04. Khách Hàng & CSKH"** $\rightarrow$ Mục **"Ticket Hỗ Trợ"**.
  2. Bấm **"Tạo Ticket Mới"** $\rightarrow$ Nhập số điện thoại khách, chọn mức độ ưu tiên (`Bình thường` hoặc `Khẩn cấp`).
  3. Chọn thợ cả phụ trách để cử xe bảo dưỡng mang dầu lau chuyên dụng đến tận nhà gia chủ trong vòng 24 - 48 giờ.

---

## 3. DÀNH CHO QUẢN TRỊ VIÊN CMS (ADMIN)

### 3.1. Thêm & Chỉnh Sửa Sản Phẩm Gỗ
1. Vào phân hệ **"02. Sản Phẩm & Kho"**.
2. Nhấn nút **"+ Thêm Sản Phẩm Mới"**.
3. Điền đầy đủ thông tin:
   - Tên sản phẩm, chất gỗ (Gõ Đỏ Pachy Nam Phi, Gỗ Óc Chó FAS, Sồi Nga, Hương Đá).
   - Giá niêm yết, giá khuyến mãi.
   - Độ ẩm sấy chuẩn (khuyến nghị $11.5\%$).
   - Kích thước Lỗ Ban Cung Đỏ (ví dụ: Giường $1.8\text{m} \times 2\text{m}$ Cung Tiến Bảo).
4. Nhấn **"Lưu Sản Phẩm"**. Dữ liệu sẽ đồng bộ hiển thị ngay trên Website Bán Hàng.

### 3.2. Quản Lý Khuyến Mãi & Lộc Xuân
1. Vào phân hệ **"05. Khuyến Mãi & Combo"**.
2. Tạo mã giảm giá mới (ví dụ: `LOCXUAN2026` - Giảm 5% tối đa 3 triệu đồng).
3. Đặt ngày bắt đầu và kết thúc chương trình.

---

## 4. DÀNH CHO BAN GIÁM ĐỐC

- Truy cập phân hệ **"01. Tổng Quan"** và **"08. Thống Kê & Báo Cáo"**:
  - Xem tổng doanh thu trong tháng, số tiền cọc 30% đã thu về và số tiền 70% còn lại chờ thu khi bàn giao.
  - Xem biểu đồ biến động doanh thu 6 tháng gần nhất.
  - Xem biểu đồ cơ cấu tiêu thụ dòng gỗ (Gỗ Gõ Đỏ chiếm $\sim 45\%$, Sồi Nga $\sim 25\%$, Hương Đá $\sim 15\%$, Óc Chó $\sim 15\%$).
  - Bấm nút **"Xuất Báo Cáo Excel/CSV"** để lưu file `Bao_Cao_Doanh_Thu_Duan_Hong.csv` phục vụ quyết toán tài chính.
