# TÀI LIỆU KỸ THUẬT RESTful API NỘI THẤT DUÂN HỒNG
**Tệp:** `API_DOCUMENTATION.md`  
**Base URL:** `http://localhost:5000` (Môi trường phát triển) / `https://api.duanhong.vn` (Production)  
**Phiên bản API:** 2.0.0  
**Chuẩn dữ liệu:** JSON (UTF-8)  
**Thương hiệu:** Công ty Đồ Gỗ Nội Thất Duân Hồng (Đường Nguyễn Du, TP. Hưng Yên)  
**Hotline / Zalo:** `0988.686.868` (Trực 24/7)

---

## 1. CƠ CHẾ XÁC THỰC & PHÂN QUYỀN (JWT & RBAC)

Hầu hết các API quản trị nội bộ yêu cầu gửi Bearer Token trong Header:
```http
Authorization: Bearer <JWT_TOKEN>
```

Hệ thống phân định 4 cấp quyền nghiêm ngặt:
- `Super Admin`: Toàn quyền tối cao (khóa tài khoản, sửa cấu hình xưởng, xóa dữ liệu).
- `Admin`: Quản lý danh mục, sản phẩm, khuyến mãi và xuất báo cáo doanh thu.
- `Manager (Thợ Cả)`: Quản lý tiến độ gia công xưởng, xác nhận ký tên phôi mộc thô, phân công thợ.
- `Staff (Tư Vấn CSKH)`: Tiếp nhận đơn hàng, xử lý Ticket hỗ trợ, trả lời Live Chat.

---

## 2. BẢNG TỔNG HỢP 14 NHÓM ENDPOINT RESTful

### 2.1. Xác Thực Quản Trị (`/api/auth`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `POST` | `/api/auth/login` | Đăng nhập tài khoản quản trị viên / thợ cả | Public |
| `GET` | `/api/auth/profile` | Lấy thông tin tài khoản đang đăng nhập | Bearer Token |

### 2.2. Quản Lý Nhân Sự & Phân Quyền (`/api/users`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/users` | Danh sách nhân viên, thợ cả và vai trò | Super Admin, Admin |
| `POST` | `/api/users` | Tạo tài khoản nhân viên mới | Super Admin |
| `PUT` | `/api/users/:id/toggle-status` | Khóa / Mở khóa tài khoản nhân viên | Super Admin |

### 2.3. Sản Phẩm Nội Thất (`/api/products`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/products` | Danh sách sản phẩm (hỗ trợ lọc `category`, `wood`, `featured`) | Public |
| `GET` | `/api/products/:id` | Chi tiết sản phẩm, độ ẩm sấy và kích thước Lỗ Ban | Public |
| `POST` | `/api/products` | Thêm sản phẩm gỗ mới vào hệ thống | Super Admin, Admin |
| `PUT` | `/api/products/:id` | Cập nhật giá bán, thông số sấy và tồn kho | Super Admin, Admin |
| `DELETE` | `/api/products/:id` | Ngừng kinh doanh hoặc lưu trữ sản phẩm | Super Admin, Admin |

### 2.4. Danh Mục Không Gian Gỗ (`/api/categories`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/categories` | Lấy cây danh mục (Phòng Khách, Ăn, Ngủ, Thờ) | Public |
| `POST` | `/api/categories` | Tạo thêm danh mục mới | Super Admin, Admin |

### 2.5. Giỏ Hàng & Cọc Mộc 30% (`/api/cart`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/cart` | Lấy giỏ hàng theo session / khách (kèm tính cọc 30%) | Public (Session) |
| `POST` | `/api/cart/items` | Thêm sản phẩm vào giỏ kèm yêu cầu thước Lỗ Ban | Public (Session) |
| `PUT` | `/api/cart/items/:id` | Cập nhật số lượng hoặc chỉnh sửa ghi chú mộc | Public (Session) |
| `DELETE` | `/api/cart/items/:id` | Xóa sản phẩm khỏi giỏ hàng | Public (Session) |

### 2.6. Đơn Hàng & Xưởng Mộc (`/api/orders`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/orders` | Danh sách toàn bộ đơn hàng thi công | Staff, Manager, Admin |
| `POST` | `/api/orders` | Đặt hàng mới (tính cọc 30% và miễn phí xe 30km) | Public |
| `GET` | `/api/orders/track/:code` | Tra cứu tiến độ đơn hàng 5 bước theo mã đơn | Public |
| `PUT` | `/api/orders/:id/status` | Chuyển giai đoạn xưởng (Sấy $\rightarrow$ Mộng $\rightarrow$ Ký Mộc $\rightarrow$ Sơn PU) | Manager, Admin |
| `PUT` | `/api/orders/:id/moc-sign` | Bật/tắt xác nhận khách đã về xưởng ký tên mộc thô | Manager, Admin |

### 2.7. Thanh Toán & VietQR Tự Động (`/api/payments`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/payments/vietqr/:orderCode` | Sinh mã VietQR chuyển khoản ngân hàng chuẩn Napas | Public |
| `GET` | `/api/payments` | Danh sách các khoản thanh toán cọc & tất toán | Staff, Manager, Admin |
| `POST` | `/api/payments` | Ghi nhận thanh toán thủ công hoặc chuyển khoản | Staff, Manager, Admin |

### 2.8. Vận Chuyển Xe Tải Xưởng (`/api/shipments`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/shipments/track/:code` | Tra cứu lộ trình xe tải xưởng Duân Hồng giao tận nhà | Public |
| `GET` | `/api/shipments` | Danh sách các chuyến xe giao hàng trong ngày | Staff, Manager, Admin |
| `PUT` | `/api/shipments/:id/status` | Cập nhật trạng thái xe (xuất xưởng, đang chạy, đã giao) | Manager, Admin |

### 2.9. Khách Hàng & CRM (`/api/customers`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/customers` | Danh sách khách hàng và lịch sử chi tiêu | Staff, Manager, Admin |
| `PUT` | `/api/customers/:id/notes` | Cập nhật hồ sơ lưu ý thước Lỗ Ban và sở thích tom gỗ | Staff, Manager, Admin |

### 2.10. Mã Khuyến Mãi / Lộc Xuân (`/api/coupons`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/coupons` | Danh sách các chương trình khuyến mãi hiện hành | Public |
| `POST` | `/api/coupons/apply` | Kiểm tra và áp dụng mã giảm giá tính lại tiền cọc | Public |
| `POST` | `/api/coupons` | Tạo mã khuyến mãi mới | Super Admin, Admin |

### 2.11. Chăm Sóc Khách Hàng & Live Chat (`/api/support`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/support/chat/messages` | Lấy tin nhắn Live Chat tư vấn gỗ 24/7 | Public |
| `POST` | `/api/support/chat/messages` | Gửi tin nhắn Live Chat tư vấn kỹ thuật mộc | Public |

### 2.12. Phiếu Hỗ Trợ Kỹ Thuật & Bảo Hành (`/api/tickets`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/tickets` | Danh sách Ticket hỗ trợ khách hàng (CS001...) | Staff, Manager, Admin |
| `POST` | `/api/tickets` | Khách hàng hoặc nhân viên tạo yêu cầu hỗ trợ mới | Public |
| `PUT` | `/api/tickets/:id/status` | Đổi trạng thái xử lý ticket (Mới, Đang xử lý, Hoàn tất) | Staff, Manager, Admin |
| `POST` | `/api/tickets/:id/assign` | Phân công ticket cho thợ cả hoặc nhân viên chuyên trách | Super Admin, Admin, Manager |

### 2.13. Báo Cáo Doanh Thu & Xuất File (`/api/reports`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/reports/overview` | Tổng quan doanh thu, số đơn, tỷ lệ hủy, hiệu suất xưởng | Super Admin, Admin |
| `GET` | `/api/reports/revenue` | Doanh thu theo chu kỳ tháng / quý | Super Admin, Admin |
| `GET` | `/api/reports/export-csv` | Xuất file báo cáo `Bao_Cao_Doanh_Thu_Duan_Hong.csv` | Super Admin, Admin |

### 2.14. Cấu Hình Xưởng & Thương Hiệu (`/api/settings`)
| Method | Endpoint | Mô tả | Quyền truy cập |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/settings` | Lấy thông tin hotline, xưởng, năm bảo hành, bán kính xe | Public |
| `PUT` | `/api/settings` | Thay đổi cấu hình vận hành xưởng | Super Admin |

---

## 3. VÍ DỤ GIAO THỨC REQUEST / RESPONSE

### Đặt Hàng Mộc Mới (POST `/api/orders`)
**Request Body:**
```json
{
  "customerName": "Anh Hoàng Nam",
  "phone": "0912.445.889",
  "shippingAddress": "Khu đô thị Lạc Hồng Phúc, TX. Mỹ Hào, Hưng Yên",
  "deliveryDistanceKM": 15,
  "items": [
    {
      "productId": 1,
      "productName": "Bộ Sofa Gõ Đỏ Chân Quỳ Vượng Khí Tài Lộc",
      "price": 74500000,
      "quantity": 1,
      "lobanNotes": "Dài 2m8 Cung Tài Vượng"
    }
  ],
  "customerNote": "Tôi muốn trực tiếp về xưởng Hưng Yên ký tên lên mộc thô trước khi phun PU"
}
```

**Response (HTTP 201 Created):**
```json
{
  "success": true,
  "message": "Đặt hàng thành công. Xưởng Duân Hồng sẽ liên hệ trong 15 phút!",
  "data": {
    "orderCode": "DH-ORD-805",
    "totalAmount": 74500000,
    "depositRequired": 22350000,
    "remainingAmount": 52150000,
    "isMocSigned": false,
    "shippingFee": 0,
    "shippingNote": "Miễn phí vận chuyển bằng xe tải xưởng Duân Hồng (Khoảng cách 15km <= 30km)"
  }
}
```
