# HỆ THỐNG THƯƠNG MẠI ĐIỆN TỬ, VẬN HÀNH XƯỞNG & CSKH NỘI THẤT DUÂN HỒNG
**Công ty Đồ Gỗ Nội Thất Duân Hồng**  
📍 **Xưởng & Showroom:** Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên  
📞 **Hotline / Zalo (24/7):** `0988.686.868`  
🛡️ **Định vị:** Tinh hoa đồ gỗ truyền thống - Giá gốc tại xưởng - 100% Gỗ tự nhiên chuẩn mực  
📜 **Cam kết vàng:** Khách về xưởng ký tên phôi mộc thô trước khi sơn | Bảo hành 5 năm sấy chuẩn cong vênh | Đo đạc miễn phí thước Lỗ Ban Cung Đỏ | Xe tải xưởng giao miễn phí 30km.

---

## 1. BỘ TÀI LIỆU KỸ THUẬT & VẬN HÀNH DỰ ÁN

Hệ thống được thiết kế và bàn giao với bộ 7 tài liệu kỹ thuật hoàn chỉnh:

| Tệp Tài Liệu | Nội Dung Chính | Liên Kết |
| :--- | :--- | :---: |
| **Kế hoạch dự án** | Kiến trúc tổng thể, WBS, ma trận rủi ro và lộ trình golive | [PROJECT_PLAN.md](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/PROJECT_PLAN.md) |
| **Cơ sở dữ liệu** | Đặc tả 38 bảng SQL Server 2014, ERD, Index, Stored Procedure | [DATABASE.md](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/DATABASE.md) |
| **Tài liệu API** | Chi tiết 14 nhóm endpoint RESTful, JWT, RBAC, VietQR, CSV export | [API_DOCUMENTATION.md](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/API_DOCUMENTATION.md) |
| **Hướng dẫn triển khai** | Hướng dẫn cài đặt VPS Ubuntu, PM2, Nginx, Let's Encrypt SSL, Firewall | [DEPLOYMENT_GUIDE.md](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/DEPLOYMENT_GUIDE.md) |
| **Sổ tay vận hành** | Hướng dẫn thao tác cho Giám đốc, Thợ Cả (ký mộc thô) và CSKH | [USER_GUIDE.md](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/USER_GUIDE.md) |
| **Sao lưu & Phục hồi** | Kịch bản backup CSDL hàng ngày, transaction log 30 phút, khôi phục sự cố | [BACKUP_RESTORE.md](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/BACKUP_RESTORE.md) |
| **Script CSDL SQL 2014** | Tệp T-SQL tạo database, 38 bảng, Index, SP Transaction & Dữ liệu mẫu | [database/schema.sql](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/database/schema.sql) |

---

## 2. KIẾN TRÚC TAM GIÁC CỐT LÕI (3 HỆ THỐNG ĐỒNG BỘ)

```mermaid
flowchart TD
    ROOT["NỀN TẢNG SỐ ĐỒ GỖ DUÂN HỒNG"] --> P1["1. WEBSITE BÁN HÀNG<br>(index.html)"]
    ROOT --> P2["2. ADMIN DASHBOARD<br>(admin.html)"]
    ROOT --> P3["3. CSKH & CRM TICKET<br>(admin.html + Live Chat)"]
    ROOT --> P4["4. BACKEND RESTful API<br>(Node.js/Express :5000)"]

    P1 --> F1["Combo 36.9tr & 74.5tr"]
    P1 --> F2["Mini-Cart & Cọc Mộc 30%"]
    P1 --> F3["Tra Cứu Đơn 5 Bước"]
    P1 --> F4["Live Chat Thợ Mộc 24/7"]

    P2 --> A1["10 Phân Hệ Nghiệp Vụ"]
    P2 --> A2["Biểu Đồ Doanh Thu & Gỗ"]
    P2 --> A3["Xác Nhận Ký Tên Mộc Thô"]
    P2 --> A4["Phân Quyền RBAC 4 Cấp"]

    P3 --> C1["Ticket CSKH (CS001...)"]
    P3 --> C2["Lưu Ý Thước Lỗ Ban"]
    P3 --> C3["Yêu Cầu Bảo Hành 5 Năm"]
    P3 --> C4["Lịch Chăm Sóc Định Kỳ"]

    P4 --> B1["14 Nhóm Route RESTful"]
    P4 --> B2["Dual-Mode SQL 2014 & Mock"]
    P4 --> B3["Sinh Mã VietQR Tự Động"]
    P4 --> B4["Xuất Báo Cáo Doanh Thu CSV"]
```

---

## 3. CẤU TRÚC THƯ MỤC TOÀN BỘ DỰ ÁN

```text
duan-hong-furniture/
├── README.md                      # Master Overview & Chỉ mục tài liệu
├── PROJECT_PLAN.md                # Kế hoạch chi tiết và tiến độ golive
├── DATABASE.md                    # Tài liệu đặc tả kỹ thuật CSDL SQL Server 2014
├── API_DOCUMENTATION.md           # Hướng dẫn chi tiết 14 nhóm REST API
├── DEPLOYMENT_GUIDE.md            # Quy trình triển khai VPS, Nginx, SSL HTTPS
├── USER_GUIDE.md                  # Sổ tay vận hành xưởng, ký mộc thô & CSKH
├── BACKUP_RESTORE.md              # Chính sách sao lưu & khôi phục thảm họa
├── index.html                     # Website Bán Hàng (Storefront) giao diện gỗ cao cấp
├── admin.html                     # Bảng điều khiển CMS 10 phân hệ & Ticket CSKH
├── database/
│   └── schema.sql                 # Script T-SQL 38 bảng, Indexes & Stored Procedures
└── backend/                       # Nguồn Backend Node.js / Express REST API
    ├── package.json               # Cấu hình dependency
    ├── .env & .env.example        # Cấu hình cổng, DB và JWT Secret
    ├── server.js                  # Khởi động máy chủ cổng 5000 & graceful shutdown
    ├── app.js                     # Gắn kết 14 nhóm Router & CORS
    ├── config/database.js         # Kết nối SQL Server 2014 & Dual-Mode Fallback
    ├── middleware/                # JWT protect, RBAC authorize & Error handlers
    ├── controllers/               # 12 Bộ điều khiển nghiệp vụ chi tiết
    └── routes/                    # 14 Nhóm Route RESTful chuẩn OpenAPI
```

---

## 4. HƯỚNG DẪN TRẢI NGHIỆM HỆ THỐNG NGAY LẬP TỨC

### 1. Trải nghiệm Website Bán Hàng & Admin CMS (Chạy độc lập ngay trên máy)
```bash
# Mở trang bán hàng (Có giỏ hàng, tra cứu đơn & Live Chat CSKH)
open /Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/index.html

# Mở trang quản trị CMS 10 phân hệ & Ticket hỗ trợ
open /Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/admin.html
```

### 2. Khởi chạy Backend RESTful API
```bash
cd /Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/backend

# Cài đặt dependency và chạy máy chủ
npm install
npm run dev
# Mở kiểm tra sức khỏe hệ thống: http://localhost:5000/api/health
```
