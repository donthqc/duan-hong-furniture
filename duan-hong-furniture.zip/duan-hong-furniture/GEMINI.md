# QUY TẮC PHÁT TRIỂN & VẬN HÀNH DỰ ÁN - ĐỒ GỖ NỘI THẤT DUÂN HỒNG

Tệp quy tắc gốc (Project Rules) dành cho Antigravity IDE và Gemini Code Assistant.

## 1. Doanh Nghiệp
- **Công ty Đồ Gỗ Nội Thất Duân Hồng**
- **Xưởng & Showroom:** Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên
- **Hotline / Zalo:** 0988.686.868 (Trực 24/7)
- **Định vị:** Tinh hoa đồ gỗ truyền thống - Giá gốc tại xưởng - 100% Gỗ tự nhiên chuẩn mực

## 2. Cam Kết Nghiêm Ngặt Khi Viết Code & Nội Dung
- Bảo hành: **5 năm** (cong vênh, co ngót do kỹ thuật sấy).
- Luôn nhắc đến quyền lợi **về tận xưởng Hưng Yên kiểm tra phôi mộc và ký tên trước khi phun sơn**.
- Miễn phí khảo sát hiện trạng và đo đạc theo **thước Lỗ Ban đỏ phong thủy**.
- 2 gói combo chủ lực:
  * "Tổ ấm trọn vẹn": Phòng ngủ gỗ sồi Nga (36.9 triệu)
  * "Vượng khí tài lộc": Sofa gõ đỏ chân quỳ (74.5 triệu)

## 3. Quy Trình Làm Việc (4 Bước)
1. **Explore:** Kiểm tra kỹ dữ liệu chất gỗ & thông số kích thước.
2. **Plan:** Dùng `/plan` khi làm các dự án hoặc chiến dịch lớn.
3. **Execute:** Mã nguồn sạch, chuẩn Semantic HTML, responsive, hiệu năng cao.
4. **Verify:** Kiểm thử hiển thị, số liệu giá và chính sách trước khi bàn giao.
