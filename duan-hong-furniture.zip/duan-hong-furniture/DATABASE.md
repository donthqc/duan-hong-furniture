# TÀI LIỆU CƠ SỞ DỮ LIỆU MICROSOFT SQL SERVER 2014
**Tệp:** `DATABASE.md`  
**Cơ sở dữ liệu:** `DuanHongEcommerceDB`  
**Dự án:** Nền tảng E-Commerce, Vận hành Xưởng & CSKH Duân Hồng  
**Thương hiệu:** Công ty Đồ Gỗ Nội Thất Duân Hồng (Đường Nguyễn Du, TP. Hưng Yên)  
**Hotline / Zalo:** `0988.686.868` (Trực 24/7)

---

## 1. TỔNG QUAN THIẾT KẾ & TƯƠNG THÍCH

- **Hệ quản trị CSDL:** Microsoft SQL Server 2014 (Hỗ trợ tương thích ngược và tiến tới 2016, 2019, 2022, Azure SQL).
- **Tập ký tự / Collation:** `SQL_Latin1_General_CP1_CI_AS` hoặc `Vietnamese_CI_AS`. Tất cả dữ liệu tiếng Việt dùng kiểu `NVARCHAR` có tiền tố `N'...'`.
- **Nguyên tắc kỹ thuật nghiêm ngặt:**
  1. Không sử dụng các hàm chỉ có từ SQL Server 2016+ như `STRING_SPLIT()`, `JSON_VALUE()`, `DROP TABLE IF EXISTS` (dùng cấu trúc `IF OBJECT_ID(...) IS NOT NULL DROP TABLE...`).
  2. Bắt buộc có khóa chính `IDENTITY(1,1) PRIMARY KEY` và khóa ngoại `FOREIGN KEY` liên kết rõ ràng.
  3. Áp dụng Database Transaction (`BEGIN TRANSACTION ... COMMIT TRANSACTION`) với `TRY ... CATCH` cho các nghiệp vụ tạo đơn, cọc mộc 30% và trừ kho.
  4. Tạo Non-Clustered Indexes trên các cột tìm kiếm và liên kết thường xuyên.

---

## 2. SƠ ĐỒ THỰC THỂ QUAN HỆ (ERD - LOGICAL DATA MODEL)

```mermaid
erDiagram
    Users ||--o{ UserRoles : "gán vai trò"
    Roles ||--o{ UserRoles : "thuộc quyền"
    Roles ||--o{ RolePermissions : "chứa quyền"
    Permissions ||--o{ RolePermissions : "định nghĩa"

    Categories ||--o{ Products : "phân loại"
    Products ||--o{ ProductImages : "hình ảnh"
    Products ||--o{ ProductVariants : "biến thể quy cách"
    Products ||--o{ ProductAttributes : "thuộc tính mộc"
    Products ||--o{ Inventory : "tồn kho xưởng"
    Products ||--o{ InventoryTransactions : "biến động kho"

    Customers ||--o{ CustomerAddresses : "địa chỉ giao"
    Customers ||--o{ CustomerNotes : "ghi chú đo đạc"
    Customers ||--o{ Orders : "đặt hàng"
    Customers ||--o{ SupportTickets : "gửi ticket"
    Customers ||--o{ CustomerInteractions : "lịch sử tương tác"

    Orders ||--o{ OrderItems : "chi tiết món"
    Orders ||--o{ OrderStatusHistory : "tiến độ 5 bước"
    Orders ||--o{ Payments : "cọc 30% & thanh toán"
    Orders ||--o{ Shipments : "xe tải xưởng 30km"
    Orders ||--o{ WarrantyRequests : "bảo hành 5 năm"

    SupportTickets ||--o{ TicketMessages : "tin nhắn trao đổi"
    SupportTickets ||--o{ TicketAssignments : "chuyển giao thợ"
```

---

## 3. DANH MỤC 38 BẢNG DỮ LIỆU THEO PHÂN HỆ

### Nhóm 1: Tài Khoản & Phân Quyền (RBAC)
1. `Users`: Lưu thông tin tài khoản ban giám đốc, thợ cả và nhân viên CSKH (`UserID`, `FullName`, `Email`, `PasswordHash`, `Phone`, `IsActive`, `LastLogin`).
2. `Roles`: Định nghĩa 4 cấp quyền cốt lõi (`Super Admin`, `Admin`, `Manager (Thợ Cả)`, `Staff`).
3. `Permissions`: Danh mục quyền hạn chi tiết (`products.create`, `orders.edit`, `timber.sign`, `reports.export`).
4. `UserRoles`: Bảng liên kết người dùng và vai trò.
5. `RolePermissions`: Bảng liên kết vai trò và quyền hạn.

### Nhóm 2: Sản Phẩm, Thuộc Tính & Kho Phôi Mộc
6. `Categories`: Danh mục sản phẩm (Phòng Khách, Phòng Ăn, Phòng Ngủ, Phòng Thờ).
7. `Products`: Danh mục sản phẩm chính thức (`SKU`, `WoodType`, `Price`, `SalePrice`, `StockQuantity`, `MoisturePercent`, `LoBanDimension`).
8. `ProductImages`: Thư viện ảnh chụp thực tế phôi mộc và thành phẩm sơn PU.
9. `ProductVariants`: Quy cách kích thước (ví dụ: Bộ 6 món, Bộ 10 món, Dài 2m4, Dài 2m8).
10. `ProductAttributes`: Thuộc tính kỹ thuật mộc thô (độ dày mặt bàn, quy cách ghép mộng, nước sơn PU chống xước).
11. `Inventory`: Quản lý tồn kho xưởng chia tách 2 trạng thái: `RawTimberStock` (Phôi mộc thô) và `FinishedStock` (Thành phẩm đã sơn).
12. `InventoryTransactions`: Nhật ký nhập xuất phôi gỗ nguyên khối và gỗ xẻ sấy.

### Nhóm 3: Khách Hàng & CRM
13. `Customers`: Hồ sơ khách hàng, phân loại (gia chủ lẻ, kiến trúc sư, nhà thầu), sở thích dòng gỗ (`PreferredWood`) và lưu ý Lỗ Ban.
14. `CustomerAddresses`: Danh sách địa chỉ nhận hàng của khách.
15. `CustomerNotes`: Nhật ký chăm sóc, ghi chú kích thước phòng và kết quả đo đạc thước Lỗ Ban Cung Đỏ tại nhà gia chủ.

### Nhóm 4: Bán Hàng, Giỏ Hàng, Đơn Hàng & Vận Chuyển
16. `Carts`: Giỏ hàng theo khách hoặc session vãng lai.
17. `CartItems`: Chi tiết sản phẩm trong giỏ, kèm ghi chú Lỗ Ban tùy chỉnh.
18. `Orders`: Bảng đơn hàng cốt lõi (`OrderCode`, `TotalAmount`, `DepositAmount`, `RemainingAmount`, `OrderStatus`, `PaymentStatus`, `IsMocSigned`, `DeliveryDistanceKM`).
19. `OrderItems`: Chi tiết các món gỗ trong đơn hàng.
20. `OrderStatusHistory`: Audit trail lưu vết toàn bộ các lần đổi trạng thái sản xuất xưởng và người thực hiện.
21. `Payments`: Quản lý các đợt thanh toán (`deposit` 30% khi ký hợp đồng, `final` 70% khi nhận hàng tại nhà).
22. `Coupons`: Mã giảm giá / lộc xuân phong thủy (`DUANHONG500`, `LOCXUAN2026`).
23. `CouponUsages`: Lịch sử áp dụng mã giảm giá của từng đơn hàng.
24. `Shipments`: Quản lý xe tải xưởng Duân Hồng vận chuyển miễn phí bán kính 30km quanh TP. Hưng Yên (`TrackingCode`, `DriverName`, `DriverPhone`, `ShippingStatus`).

### Nhóm 5: Chăm Sóc Khách Hàng, Ticket & Bảo Hành 5 Năm
25. `SupportTickets`: Phiếu yêu cầu CSKH (`TicketCode`, `Priority`, `Status`, `Channel`).
26. `TicketMessages`: Lịch sử trao đổi giữa khách hàng và nhân viên hỗ trợ.
27. `TicketAssignments`: Nhật ký bàn giao ticket từ tư vấn viên sang thợ cả xưởng mộc.
28. `CustomerInteractions`: Lịch sử các cuộc gọi điện, chat Zalo hoặc đón tiếp khách trực tiếp tại xưởng Đường Nguyễn Du.
29. `WarrantyRequests`: Yêu cầu bảo hành 5 năm gỗ sấy cong vênh, co ngót, nứt nẻ hoặc dặm vá sơn PU.
30. `ReturnRequests`: Yêu cầu xử lý đổi trả nếu phát hiện phôi gỗ không đúng cam kết ban đầu.
31. `Conversations`: Hội thoại Live Chat trực tuyến trên trang chủ.
32. `Messages`: Tin nhắn trao đổi trực tiếp trong phiên Live Chat.
33. `ProductReviews`: Đánh giá chất lượng vân gỗ, mộng đục tay và dịch vụ chăm sóc.

### Nhóm 6: Nội Dung, Cấu Hình & Nhật Ký
34. `Banners`: Ảnh banner trang chủ quảng bá 2 gói Combo kích cầu (36.9tr & 74.5tr).
35. `Articles`: Bài viết chia sẻ kiến thức chọn gỗ, phong thủy Lỗ Ban, kinh nghiệm nhận biết gỗ gõ đỏ Pachy.
36. `Pages`: Các trang tĩnh (Giới thiệu lịch sử thương hiệu xưởng Duân Hồng, Chính sách bảo hành 5 năm).
37. `Notifications`: Thông báo đẩy cho ban quản trị và thợ xưởng.
38. `Settings`: Cấu hình hệ thống (Tên xưởng, hotline 24/7, địa chỉ, bán kính giao miễn phí 30km, tỷ lệ cọc 30%).
39. `AuditLogs`: Nhật ký ghi lại mọi thao tác quan trọng trên hệ thống bảo vệ an toàn dữ liệu.

---

## 4. QUY TRÌNH THỰC THI STORED PROCEDURES CÓ TRANSACTION

### Nghiệp Vụ Tạo Đơn Hàng & Cọc Mộc: `sp_CreateOrderWithDeposit`
```sql
EXEC dbo.sp_CreateOrderWithDeposit
    @CustomerID = 1,
    @OrderCode = 'DH-ORD-888',
    @TotalAmount = 74500000,
    @DepositAmount = 25000000,
    @DeliveryDistanceKM = 12,
    @ShippingAddress = N'Thị Xã Mỹ Hào, Hưng Yên',
    @CustomerPhone = '0912.445.889',
    @CustomerName = N'Anh Hoàng Nam',
    @CustomerNote = N'Đặt bộ Sofa Gõ Đỏ Chân Quỳ - Hẹn về ký mộc thô',
    @NewOrderID = @NewOrderID OUTPUT;
```
*Tác vụ tự động trong Transaction:*
1. Tạo bản ghi đơn hàng trong bảng `Orders` với trạng thái `pending` và `partial_deposit`.
2. Tạo bản ghi lịch sử `OrderStatusHistory`.
3. Tự động sinh bản ghi thanh toán cọc 30% trong bảng `Payments`.
4. Khởi tạo lộ trình vận chuyển trong bảng `Shipments` với xe tải xưởng Duân Hồng (Miễn phí nếu $\le 30$ km).

---

## 5. HƯỚNG DẪN KHỞI TẠO CƠ SỞ DỮ LIỆU TRÊN SSMS 2014

1. Mở **SQL Server Management Studio (SSMS)** và kết nối tới SQL Server 2014 Instance.
2. Mở file [database/schema.sql](file:///Users/mac/.gemini/antigravity/scratch/duan-hong-furniture/database/schema.sql).
3. Nhấn **Execute (F5)** để khởi tạo CSDL `DuanHongEcommerceDB`, 38 bảng quan hệ, toàn bộ Index, Stored Procedure và dữ liệu mộc mẫu.
