# KẾ HOẠCH TRIỂN KHAI HỆ THỐNG E-COMMERCE & CRM NỘI THẤT DUÂN HỒNG
**Tệp:** `PROJECT_PLAN.md`  
**Dự án:** Nền tảng Thương mại Điện tử, Quản trị Vận hành Xưởng & Chăm sóc Khách hàng Nội thất Đồ Gỗ Duân Hồng  
**Thương hiệu:** Công ty Đồ Gỗ Nội Thất Duân Hồng (Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên)  
**Hotline / Zalo:** `0988.686.868` (Trực 24/7)  
**Phiên bản kế hoạch:** 2.0 (Toàn diện Full-stack, Database & DevOps)

---

## 1. TỔNG QUAN VÀ MỤC TIÊU DỰ ÁN

Xây dựng và đưa vào vận hành một hệ thống thương mại điện tử đồng bộ khép kín gồm **3 hệ thống cốt lõi**:
1. **Website Bán Hàng (Storefront)**: Giới thiệu sản phẩm, lọc theo hệ phòng/chất gỗ, công cụ tính dự toán chi phí, giỏ hàng tính cọc mộc 30%, đặt hàng, tra cứu tiến độ đơn 5 bước và Live Chat tư vấn phong thủy Lỗ Ban 24/7.
2. **Bảng Điều Khiển Quản Trị (Admin Dashboard)**: 10 phân hệ nghiệp vụ quản lý sản phẩm, đơn hàng, tiến độ xưởng (ký tên phôi mộc thô), doanh thu, kho phôi, nhân sự RBAC và khuyến mãi.
3. **Hệ Thống Chăm Sóc Khách Hàng (CSKH / CRM)**: Quản lý vòng đời khách hàng, tiếp nhận Ticket (CS001...), quản lý yêu cầu bảo hành 5 năm cong vênh, lịch sử tương tác và đo lường chỉ số CSAT/SLA.

Hệ thống hỗ trợ trọn vẹn luồng kinh doanh:
$$\text{Khách truy cập} \longrightarrow \text{Xem sản phẩm} \longrightarrow \text{Thêm giỏ} \longrightarrow \text{Đặt cọc mộc 30\%} \longrightarrow \text{Ký tên phôi mộc} \longrightarrow \text{Sơn PU \& Giao xe xưởng} \longrightarrow \text{CSKH 5 năm}$$

---

## 2. ĐÁNH GIÁ KIẾN TRÚC & CÔNG NGHỆ HIỆN TẠI

### 2.1. Đánh giá Công nghệ Frontend
- **Hiện trạng:** Được phát triển dưới dạng kiến trúc HTML5 ngữ nghĩa kết hợp Tailwind CSS CDN, Lucide Icons CDN, Chart.js CDN và JavaScript ES6+ Module/State.
- **Đánh giá chuyên gia:**
  - *Ưu điểm:* Giao diện đã được thiết kế cực kỳ chi tiết (~170 KB mã nguồn tùy biến cao), chuẩn nhận diện thương hiệu gỗ cao cấp (Playfair Display + Be Vietnam Pro, màu hạt dẻ Walnut `#2C1810` và vàng kim `#C5A059`), tải trang tức thì, zero-build dependency (chạy được ngay trong môi trường chưa cài đặt Node.js/Vite/Webpack).
  - *Chiến lược tối ưu:* Không đập đi xây lại làm mất mát giao diện tinh tế và tốn kém thời gian. Giải pháp kiến trúc là **nâng cấp tầng giao tiếp dữ liệu (API Client Layer)**: Thêm file `js/api.js` hoặc service helper kết nối trực tiếp đến Node.js Backend API khi server hoạt động, đồng thời giữ chế độ Fallback LocalStorage khi chạy độc lập (Dual-Engine Architecture). Đồng thời cung cấp mẫu cấu trúc React + TypeScript dự phòng khi mở rộng quy mô đa nền tảng.

### 2.2. Đánh giá Backend API
- **Hiện trạng:** Node.js + Express.js tại thư mục `backend/` theo chuẩn MVC phân tầng (Config, Middleware, Controllers, Routes).
- **Đánh giá chuyên gia:**
  - Đã có cấu trúc chuẩn, hỗ trợ CORS, Morgan logger, JWT Authentication, phân quyền RBAC 4 cấp, bắt lỗi tập trung.
  - Cần mở rộng thêm các controller và endpoint chuyên sâu: Coupon, Cart, Customer Notes, Ticket Assignment, Report CSV Export và Settings theo yêu cầu Section 8.

### 2.3. Đánh giá Cơ Sở Dữ Liệu SQL Server 2014
- **Hiện trạng:** Script `database/schema.sql` gồm 30 bảng quan hệ, tương thích 100% Microsoft SQL Server 2014.
- **Cải tiến cần thiết:**
  - Bổ sung các bảng quan hệ nâng cao: `ProductAttributes`, `Inventory`, `CustomerNotes`, `TicketAssignments`, `CustomerInteractions`, `ReturnRequests`, `WarrantyRequests`, `Pages`, `Notifications`.
  - Bổ sung các Non-Clustered Indexes trên các trường tìm kiếm và khóa ngoại.
  - Bổ sung Stored Procedure với Transaction (`BEGIN TRANSACTION ... COMMIT`) cho nghiệp vụ đặt hàng và trừ kho.

---

## 3. KIẾN TRÚC HỆ THỐNG TOÀN DIỆN (SYSTEM ARCHITECTURE)

```mermaid
flowchart TB
    subgraph CLIENT_LAYER["1. CLIENT APPLICATION LAYER"]
        STORE["Website Bán Hàng (index.html)<br>• 2 Combo Kích Cầu<br>• Dự Toán Chi Phí<br>• Mini-Cart Cọc 30%<br>• Tra Cứu Đơn 5 Bước"]
        ADMIN["Admin Dashboard (admin.html)<br>• 10 Phân Hệ Quản Trị<br>• Giám Sát Phôi Mộc<br>• CRM & Ticket CSKH<br>• Biểu Đồ Doanh Thu"]
    end

    subgraph API_GATEWAY["2. BACKEND API GATEWAY (Node.js / Express :5000)"]
        AUTH_MW["JWT & RBAC Middleware<br>(Super Admin, Admin, Manager, Staff)"]
        ROUTERS["RESTful API Routers<br>/api/auth | /api/products | /api/orders<br>/api/customers | /api/support | /api/reports"]
        ERR_MW["Centralized Error Handler & Audit Log"]
    end

    subgraph SERVICE_LOGIC["3. BUSINESS SERVICES & REPOSITORIES"]
        ORDER_SVC["Order & Timber Workshop Service<br>(Ký tên phôi mộc, xe xưởng 30km)"]
        PAY_SVC["Payment & VietQR Service<br>(Cọc 30% & Tất toán 70%)"]
        CRM_SVC["CSKH Ticket & Warranty Service<br>(Bảo hành 5 năm, SLA Ticket)"]
    end

    subgraph DB_LAYER["4. PERSISTENCE LAYER (SQL Server 2014)"]
        DB[(DuanHongEcommerceDB<br>38 Relational Tables<br>Stored Procedures & Indexes)]
        MOCK_CACHE[(In-Memory Dual Mode Fallback<br>Auto-Active when DB Offline)]
    end

    CLIENT_LAYER -->|REST API Requests / JSON| API_GATEWAY
    API_GATEWAY --> AUTH_MW --> ROUTERS --> SERVICE_LOGIC
    SERVICE_LOGIC -->|T-SQL Queries / Transactions| DB
    SERVICE_LOGIC -.->|Fallback if Offline| MOCK_CACHE
```

---

## 4. CHI TIẾT CÁC MODULE CHỨC NĂNG CẦN THỰC HIỆN

| Mã Module | Tên Phân Hệ | Chức Năng Cốt Lõi | Mức Độ Ưu Tiên | Tiêu Chí Hoàn Thành (DoD) |
| :--- | :--- | :--- | :---: | :--- |
| **MOD-01** | **Database SQL Server 2014** | Hoàn thiện 38 bảng, khóa chính, khóa ngoại, Index, Stored Procedure có Transaction tạo đơn hàng và trừ kho. | **P0 (Tối cao)** | Script SQL thực thi không lỗi trên SSMS 2014, có dữ liệu mẫu Duân Hồng. |
| **MOD-02** | **Backend REST API Core** | Mở rộng đầy đủ 14 nhóm endpoint: Auth, Users, Products, Categories, Cart, Orders, Payments, Shipments, Customers, Coupons, Support, Tickets, Reports, Settings. | **P0 (Tối cao)** | Test chạy pass với mã phản hồi HTTP 200/201/400/401/403/404 rõ ràng. |
| **MOD-03** | **Xác Thực & Phân Quyền (RBAC)** | Đăng nhập băm mật khẩu bcrypt, cấp JWT Token, middleware phân quyền chặt chẽ 4 vai trò. | **P0 (Tối cao)** | Token hợp lệ mới truy cập được API nội bộ; chặn truy cập chéo. |
| **MOD-04** | **Cầu Nối Frontend - Backend (API Integration)** | Tích hợp thư viện kết nối dữ liệu từ `index.html` và `admin.html` sang API cổng 5000; giữ chế độ Dual-Mode. | **P1 (Cao)** | Tạo đơn hàng trên web bán hàng $\rightarrow$ API ghi nhận $\rightarrow$ hiển thị tức thì trên Admin. |
| **MOD-05** | **Nghiệp Vụ Đơn Hàng & Xưởng Mộc** | Quản lý quy trình 5 bước sản xuất, nút xác nhận `Đã Ký Mộc Thô`, tính toán cọc 30%, in hóa đơn / phiếu giao mộc. | **P1 (Cao)** | Chuyển trạng thái lưu log vào `OrderStatusHistory`; tính đúng số tiền cọc và còn lại. |
| **MOD-06** | **Hệ Thống CSKH / CRM & Bảo Hành** | Quản lý Ticket hỗ trợ (CS001...), ghi chú sở thích vân gỗ/thước Lỗ Ban, tiếp nhận yêu cầu bảo hành 5 năm cong vênh. | **P1 (Cao)** | Tạo ticket, phân công nhân viên, chuyển trạng thái và tính chỉ số SLA phản hồi. |
| **MOD-07** | **Thanh Toán & Vận Chuyển** | Tích hợp phương thức COD, Chuyển khoản ngân hàng VietQR tự động sinh mã đơn hàng, cấu hình xe xưởng 30km. | **P1 (Cao)** | Sinh mã QR chuyển khoản đúng cú pháp `DH-ORD-xxx`, kiểm tra khoảng cách giao hàng. |
| **MOD-08** | **Báo Cáo & Xuất Dữ Liệu** | Thống kê doanh thu theo ngày/tháng, tỷ lệ hủy đơn, nhu cầu các dòng gỗ (Gõ Đỏ, Sồi, Óc Chó, Hương Đá), xuất CSV. | **P2 (Trung bình)** | Tải được tệp CSV/Excel danh sách đơn và doanh thu về máy tính. |
| **MOD-09** | **DevOps & Triển Khai Production** | File cấu hình Docker, PM2 ecosystem, tài liệu hướng dẫn cài đặt VPS, cấu hình Nginx Reverse Proxy và SSL Let's Encrypt. | **P2 (Trung bình)** | Có đầy đủ script chạy production và cấu hình biến môi trường an toàn. |
| **MOD-10** | **Bộ Tài Liệu Bàn Giao Kỹ Thuật** | Tạo 7 file tài liệu: README.md, PROJECT_PLAN.md, DATABASE.md, API_DOCUMENTATION.md, DEPLOYMENT_GUIDE.md, USER_GUIDE.md, BACKUP_RESTORE.md. | **P2 (Trung bình)** | Toàn bộ tài liệu rõ ràng, có link điều hướng chi tiết. |

---

## 5. PHÂN TÍCH RỦI RO & PHƯƠNG ÁN XỬ LÝ (RISKS & MITIGATION)

| Rủi Ro Nhận Diện | Tác Động | Biện Pháp Giảm Thiểu |
| :--- | :---: | :--- |
| **1. Môi trường cục bộ chưa có Node.js/SQL Server** | Cao | Thiết kế kiến trúc **Dual-Mode**: Frontend chạy được ngay trên trình duyệt bất kỳ; Backend có cơ chế **In-Memory Mock Fallback** chạy mượt mà ngay cả khi chưa kết nối SQL Server thật. |
| **2. Sai lệch phiên bản cú pháp SQL Server 2014** | Nghiêm trọng | Tuyệt đối tuân thủ T-SQL 2014 chuẩn: dùng `IDENTITY(1,1)`, `DATETIME`, `NVARCHAR(MAX)`, `DECIMAL(18,2)`; không dùng cú pháp 2016+ như `STRING_SPLIT`, hàm JSON tích hợp. |
| **3. Lộ lọt mã bí mật hoặc thông tin thanh toán thật** | Nghiêm trọng | Đưa toàn bộ cấu hình vào `.env`, đưa `.env` vào `.gitignore`. Thanh toán dùng chế độ Sandbox và cấu trúc chuẩn bị sẵn chờ API Key thực từ đối tác. |
| **4. Xung đột dữ liệu khi nhiều người sửa đơn mộc** | Trung bình | Sử dụng Database Transactions cho luồng tạo đơn, cọc và trừ kho; ghi nhận lịch sử thay đổi vào bảng `OrderStatusHistory`. |

---

## 6. LỘ TRÌNH TRIỂN KHAI NHANH NHẤT ĐƯA VÀO VẬN HÀNH (FAST TRACK TO PRODUCTION)

```mermaid
flowchart LR
    S1["Bước 1:<br>Audit & Lập Plan<br>(Đang hoàn thành)"] --> S2["Bước 2:<br>Nâng cấp Database<br>& Script SP 2014"]
    S2 --> S3["Bước 3:<br>Mở rộng Backend API<br>& Nghiệp vụ CSKH"]
    S3 --> S4["Bước 4:<br>Tích hợp API Frontend<br>& In Hóa Đơn Mộc"]
    S4 --> S5["Bước 5:<br>Kiểm Thử Toàn Diện<br>& Bộ 7 Tài Liệu"]
    S5 --> S6["Bước 6:<br>Cấu hình Production<br>& Sẵn sàng Golive"]
```

1. **Giai đoạn tức thì (Hôm nay):**
   - Hoàn thiện bản báo cáo Audit chi tiết.
   - Nâng cấp `database/schema.sql` bổ sung toàn bộ 38 bảng, Index và Stored Procedure có Transaction.
   - Mở rộng đầy đủ các API Controllers & Routes trong `backend/` theo danh mục Section 8.
   - Tạo bộ tài liệu hướng dẫn kỹ thuật và vận hành.
2. **Giai đoạn kết nối máy chủ:**
   - Chủ dự án cài đặt Node.js và nạp script database vào SQL Server Management Studio (SSMS).
   - Chạy kiểm thử tự động toàn bộ 14 luồng nghiệp vụ.
   - Cấu hình VPS/Domain thật để phát hành website ra Internet.
