-- =========================================================================
-- HỆ THỐNG QUẢN TRỊ E-COMMERCE & NỘI THẤT ĐỒ GỖ DUÂN HỒNG
-- Phiên bản: 2.0 (Chuẩn hóa 38 bảng + Indexes + Stored Procedures Transaction)
-- Tương thích: Microsoft SQL Server 2014 / 2016 / 2019 / 2022
-- Thương hiệu: Công ty Đồ Gỗ Nội Thất Duân Hồng (Đường Nguyễn Du, TP. Hưng Yên)
-- Hotline / Zalo: 0988.686.868 (Trực 24/7)
-- =========================================================================

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'DuanHongEcommerceDB')
BEGIN
    CREATE DATABASE DuanHongEcommerceDB;
END
GO

USE DuanHongEcommerceDB;
GO

-- -------------------------------------------------------------------------
-- NHÓM 1: TÀI KHOẢN VÀ PHÂN QUYỀN (RBAC)
-- -------------------------------------------------------------------------

IF OBJECT_ID('dbo.RolePermissions', 'U') IS NOT NULL DROP TABLE dbo.RolePermissions;
IF OBJECT_ID('dbo.UserRoles', 'U') IS NOT NULL DROP TABLE dbo.UserRoles;
IF OBJECT_ID('dbo.Permissions', 'U') IS NOT NULL DROP TABLE dbo.Permissions;
IF OBJECT_ID('dbo.Roles', 'U') IS NOT NULL DROP TABLE dbo.Roles;
IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL DROP TABLE dbo.Users;

CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(150) NOT NULL,
    Email VARCHAR(150) NOT NULL UNIQUE,
    PasswordHash VARCHAR(255) NOT NULL,
    Phone VARCHAR(20) NULL,
    Avatar VARCHAR(255) NULL,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME DEFAULT GETDATE(),
    LastLogin DATETIME NULL
);

CREATE TABLE Roles (
    RoleID INT IDENTITY(1,1) PRIMARY KEY,
    RoleName VARCHAR(50) NOT NULL UNIQUE, -- Super Admin, Admin, Manager (Thợ Cả), Staff
    Description NVARCHAR(255) NULL
);

CREATE TABLE Permissions (
    PermissionID INT IDENTITY(1,1) PRIMARY KEY,
    PermissionKey VARCHAR(100) NOT NULL UNIQUE, -- products.view, products.create, orders.edit, etc.
    ModuleName VARCHAR(50) NOT NULL,
    Description NVARCHAR(255) NULL
);

CREATE TABLE UserRoles (
    UserID INT NOT NULL,
    RoleID INT NOT NULL,
    PRIMARY KEY (UserID, RoleID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE CASCADE,
    FOREIGN KEY (RoleID) REFERENCES Roles(RoleID) ON DELETE CASCADE
);

CREATE TABLE RolePermissions (
    RoleID INT NOT NULL,
    PermissionID INT NOT NULL,
    PRIMARY KEY (RoleID, PermissionID),
    FOREIGN KEY (RoleID) REFERENCES Roles(RoleID) ON DELETE CASCADE,
    FOREIGN KEY (PermissionID) REFERENCES Permissions(PermissionID) ON DELETE CASCADE
);

-- -------------------------------------------------------------------------
-- NHÓM 2: SẢN PHẨM, DANH MỤC, THUỘC TÍNH & KHO PHÔI MỘC
-- -------------------------------------------------------------------------

IF OBJECT_ID('dbo.InventoryTransactions', 'U') IS NOT NULL DROP TABLE dbo.InventoryTransactions;
IF OBJECT_ID('dbo.Inventory', 'U') IS NOT NULL DROP TABLE dbo.Inventory;
IF OBJECT_ID('dbo.ProductAttributes', 'U') IS NOT NULL DROP TABLE dbo.ProductAttributes;
IF OBJECT_ID('dbo.ProductVariants', 'U') IS NOT NULL DROP TABLE dbo.ProductVariants;
IF OBJECT_ID('dbo.ProductImages', 'U') IS NOT NULL DROP TABLE dbo.ProductImages;
IF OBJECT_ID('dbo.Products', 'U') IS NOT NULL DROP TABLE dbo.Products;
IF OBJECT_ID('dbo.Categories', 'U') IS NOT NULL DROP TABLE dbo.Categories;

CREATE TABLE Categories (
    CategoryID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(150) NOT NULL,
    Slug VARCHAR(180) NOT NULL UNIQUE,
    ParentID INT NULL,
    Description NVARCHAR(500) NULL,
    DisplayOrder INT DEFAULT 0,
    IsActive BIT DEFAULT 1,
    FOREIGN KEY (ParentID) REFERENCES Categories(CategoryID)
);

CREATE TABLE Products (
    ProductID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryID INT NULL,
    ProductName NVARCHAR(255) NOT NULL,
    SKU VARCHAR(100) NOT NULL UNIQUE,
    WoodType NVARCHAR(100) NOT NULL, -- Gỗ Gõ Đỏ Pachy, Gỗ Óc Chó, Gỗ Hương Đá, Gỗ Sồi Nga, MDF An Cường
    Description NVARCHAR(MAX) NULL,
    ShortDescription NVARCHAR(500) NULL,
    Price DECIMAL(18,2) NOT NULL,
    SalePrice DECIMAL(18,2) NULL,
    StockQuantity INT NOT NULL DEFAULT 0,
    MoisturePercent DECIMAL(5,2) DEFAULT 11.5, -- Độ ẩm gỗ sấy chuẩn (10-12%)
    LoBanDimension NVARCHAR(100) NULL, -- Kích thước cung đỏ Lỗ Ban phong thủy
    Status VARCHAR(30) NOT NULL DEFAULT 'draft', -- draft, active, out_of_stock, archived
    IsFeatured BIT DEFAULT 0,
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID),
    CHECK (Price >= 0),
    CHECK (SalePrice IS NULL OR SalePrice >= 0),
    CHECK (StockQuantity >= 0)
);

CREATE TABLE ProductImages (
    ImageID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    ImageURL VARCHAR(500) NOT NULL,
    IsThumbnail BIT DEFAULT 0,
    DisplayOrder INT DEFAULT 0,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID) ON DELETE CASCADE
);

CREATE TABLE ProductVariants (
    VariantID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    VariantName NVARCHAR(150) NOT NULL, -- 6 món, 10 món, Dài 2m4, Dài 2m8
    SKU VARCHAR(100) NOT NULL UNIQUE,
    Price DECIMAL(18,2) NOT NULL,
    SalePrice DECIMAL(18,2) NULL,
    StockQuantity INT NOT NULL DEFAULT 0,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID) ON DELETE CASCADE
);

CREATE TABLE ProductAttributes (
    AttributeID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    AttributeName NVARCHAR(100) NOT NULL, -- Ví dụ: Độ dày mặt bàn, Loại mộng, Nước sơn, Quy cách phôi
    AttributeValue NVARCHAR(255) NOT NULL,
    DisplayOrder INT DEFAULT 0,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID) ON DELETE CASCADE
);

CREATE TABLE Inventory (
    InventoryID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    VariantID INT NULL,
    WarehouseLocation NVARCHAR(150) DEFAULT N'Xưởng Gỗ Duân Hồng - Hưng Yên',
    RawTimberStock INT NOT NULL DEFAULT 0, -- Số lượng phôi mộc thô chưa sơn
    FinishedStock INT NOT NULL DEFAULT 0,   -- Số lượng thành phẩm đã sơn PU
    TotalAvailable AS (RawTimberStock + FinishedStock),
    LastAuditedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID) ON DELETE CASCADE,
    FOREIGN KEY (VariantID) REFERENCES ProductVariants(VariantID)
);

CREATE TABLE InventoryTransactions (
    TransactionID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    VariantID INT NULL,
    TransactionType VARCHAR(30) NOT NULL, -- 'import_raw_timber', 'export_sale', 'damage_adjust', 'assembly'
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NULL,
    Note NVARCHAR(500) NULL,
    CreatedBy INT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (VariantID) REFERENCES ProductVariants(VariantID),
    FOREIGN KEY (CreatedBy) REFERENCES Users(UserID)
);

-- -------------------------------------------------------------------------
-- NHÓM 3: KHÁCH HÀNG & HỒ SƠ CRM
-- -------------------------------------------------------------------------

IF OBJECT_ID('dbo.CustomerNotes', 'U') IS NOT NULL DROP TABLE dbo.CustomerNotes;
IF OBJECT_ID('dbo.CustomerAddresses', 'U') IS NOT NULL DROP TABLE dbo.CustomerAddresses;
IF OBJECT_ID('dbo.Customers', 'U') IS NOT NULL DROP TABLE dbo.Customers;

CREATE TABLE Customers (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(150) NOT NULL,
    Email VARCHAR(150) NULL,
    Phone VARCHAR(20) NOT NULL,
    CustomerType VARCHAR(30) DEFAULT 'retail', -- retail (Gia chủ lẻ), architect (Kiến trúc sư), contractor (Thầu thi công)
    PreferredWood NVARCHAR(100) NULL, -- Sở thích dòng gỗ (Gõ Đỏ, Hương Đá, Óc Chó, Sồi)
    LoBanNote NVARCHAR(255) NULL,     -- Lưu ý thước Lỗ Ban Cung Đỏ của gia chủ
    TotalSpent DECIMAL(18,2) DEFAULT 0,
    CreatedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE CustomerAddresses (
    AddressID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    ReceiverName NVARCHAR(150) NOT NULL,
    Phone VARCHAR(20) NOT NULL,
    AddressDetail NVARCHAR(255) NOT NULL,
    District NVARCHAR(100) NULL,
    City NVARCHAR(100) DEFAULT N'Hưng Yên',
    IsDefault BIT DEFAULT 0,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) ON DELETE CASCADE
);

CREATE TABLE CustomerNotes (
    NoteID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    CreatedBy INT NULL, -- UserID nhân viên tạo ghi chú
    NoteType VARCHAR(50) DEFAULT 'general', -- 'lo_ban_measurement', 'raw_timber_visit', 'post_sale'
    Content NVARCHAR(MAX) NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) ON DELETE CASCADE,
    FOREIGN KEY (CreatedBy) REFERENCES Users(UserID)
);

-- -------------------------------------------------------------------------
-- NHÓM 4: BÁN HÀNG, ĐƠN HÀNG, GIỎ HÀNG & VẬN CHUYỂN
-- -------------------------------------------------------------------------

IF OBJECT_ID('dbo.Shipments', 'U') IS NOT NULL DROP TABLE dbo.Shipments;
IF OBJECT_ID('dbo.Payments', 'U') IS NOT NULL DROP TABLE dbo.Payments;
IF OBJECT_ID('dbo.CouponUsages', 'U') IS NOT NULL DROP TABLE dbo.CouponUsages;
IF OBJECT_ID('dbo.Coupons', 'U') IS NOT NULL DROP TABLE dbo.Coupons;
IF OBJECT_ID('dbo.OrderStatusHistory', 'U') IS NOT NULL DROP TABLE dbo.OrderStatusHistory;
IF OBJECT_ID('dbo.OrderItems', 'U') IS NOT NULL DROP TABLE dbo.OrderItems;
IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID('dbo.CartItems', 'U') IS NOT NULL DROP TABLE dbo.CartItems;
IF OBJECT_ID('dbo.Carts', 'U') IS NOT NULL DROP TABLE dbo.Carts;

CREATE TABLE Carts (
    CartID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NULL,
    SessionID VARCHAR(100) NULL, -- Dành cho khách vãng lai
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID) ON DELETE CASCADE
);

CREATE TABLE CartItems (
    CartItemID INT IDENTITY(1,1) PRIMARY KEY,
    CartID INT NOT NULL,
    ProductID INT NOT NULL,
    VariantID INT NULL,
    Quantity INT NOT NULL DEFAULT 1,
    LoBanNote NVARCHAR(200) NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CartID) REFERENCES Carts(CartID) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (VariantID) REFERENCES ProductVariants(VariantID)
);

CREATE TABLE Orders (
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    OrderCode VARCHAR(50) NOT NULL UNIQUE,
    TotalAmount DECIMAL(18,2) NOT NULL,
    DepositAmount DECIMAL(18,2) DEFAULT 0, -- Cọc mộc thô 30%
    RemainingAmount AS (TotalAmount - DepositAmount), -- Tiền còn lại thanh toán khi nhận hàng
    OrderStatus VARCHAR(30) NOT NULL DEFAULT 'pending', 
    -- 'pending' (Chờ duyệt), 'confirmed' (Đã xác nhận), 'seasoning' (Tẩm sấy phôi mộc), 
    -- 'carving' (Đang ghép mộng đục tay), 'finishing' (Phun sơn PU & lau dầu), 'shipping' (Đang giao xe xưởng), 
    -- 'completed' (Hoàn tất & kích hoạt bảo hành), 'cancelled' (Đã hủy)
    PaymentStatus VARCHAR(30) NOT NULL DEFAULT 'unpaid', -- unpaid, partial_deposit, paid
    IsMocSigned BIT DEFAULT 0, -- Khách đã về xưởng kiểm tra & ký tên phôi mộc thô
    ArtisanInCharge NVARCHAR(100) NULL, -- Thợ cả phụ trách gia công
    DeliveryDistanceKM INT DEFAULT 0, -- Bán kính giao hàng (<= 30km miễn phí xe tải xưởng)
    ShippingAddress NVARCHAR(500) NULL,
    CustomerPhone VARCHAR(20) NULL,
    CustomerName NVARCHAR(150) NULL,
    CustomerNote NVARCHAR(MAX) NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    EstimatedDeliveryDate DATETIME NULL,
    CompletedAt DATETIME NULL,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE OrderItems (
    OrderItemID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    VariantID INT NULL,
    ProductName NVARCHAR(255) NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    Quantity INT NOT NULL,
    LoBanNotes NVARCHAR(200) NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID) ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    CHECK (Quantity > 0),
    CHECK (UnitPrice >= 0)
);

CREATE TABLE OrderStatusHistory (
    HistoryID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    OldStatus VARCHAR(30) NULL,
    NewStatus VARCHAR(30) NOT NULL,
    Note NVARCHAR(500) NULL,
    ChangedBy INT NULL, -- UserID nhân viên thao tác
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID) ON DELETE CASCADE,
    FOREIGN KEY (ChangedBy) REFERENCES Users(UserID)
);

CREATE TABLE Payments (
    PaymentID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    PaymentMethod VARCHAR(50) NOT NULL, -- 'bank_transfer', 'cash', 'cod', 'vietqr'
    Amount DECIMAL(18,2) NOT NULL,
    TransactionRef VARCHAR(100) NULL,
    PaymentPhase VARCHAR(30) DEFAULT 'deposit', -- 'deposit' (Cọc mộc 30%), 'final' (Tất toán 70%)
    Status VARCHAR(30) NOT NULL DEFAULT 'success',
    PaidAt DATETIME DEFAULT GETDATE(),
    Note NVARCHAR(500) NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

CREATE TABLE Coupons (
    CouponID INT IDENTITY(1,1) PRIMARY KEY,
    Code VARCHAR(50) NOT NULL UNIQUE,
    DiscountType VARCHAR(20) NOT NULL, -- 'percentage', 'fixed_amount'
    DiscountValue DECIMAL(18,2) NOT NULL,
    MinOrderValue DECIMAL(18,2) DEFAULT 0,
    MaxDiscount DECIMAL(18,2) NULL,
    UsageLimit INT DEFAULT 100,
    TimesUsed INT DEFAULT 0,
    StartDate DATETIME NOT NULL,
    EndDate DATETIME NOT NULL,
    IsActive BIT DEFAULT 1
);

CREATE TABLE CouponUsages (
    UsageID INT IDENTITY(1,1) PRIMARY KEY,
    CouponID INT NOT NULL,
    OrderID INT NOT NULL,
    CustomerID INT NOT NULL,
    UsedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CouponID) REFERENCES Coupons(CouponID),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Shipments (
    ShipmentID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    TrackingCode VARCHAR(50) NOT NULL UNIQUE,
    CarrierName NVARCHAR(100) DEFAULT N'Xe Tải Xưởng Duân Hồng',
    DriverName NVARCHAR(100) NULL,
    DriverPhone VARCHAR(20) NULL,
    ShippingStatus VARCHAR(30) DEFAULT 'preparing', -- preparing, picked_up, delivering, delivered, failed
    EstimatedArrival DATETIME NULL,
    DeliveredAt DATETIME NULL,
    Note NVARCHAR(500) NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

-- -------------------------------------------------------------------------
-- NHÓM 5: HỆ THỐNG CSKH, TICKET, BẢO HÀNH & ĐỔI TRẢ
-- -------------------------------------------------------------------------

IF OBJECT_ID('dbo.ProductReviews', 'U') IS NOT NULL DROP TABLE dbo.ProductReviews;
IF OBJECT_ID('dbo.Messages', 'U') IS NOT NULL DROP TABLE dbo.Messages;
IF OBJECT_ID('dbo.Conversations', 'U') IS NOT NULL DROP TABLE dbo.Conversations;
IF OBJECT_ID('dbo.WarrantyRequests', 'U') IS NOT NULL DROP TABLE dbo.WarrantyRequests;
IF OBJECT_ID('dbo.ReturnRequests', 'U') IS NOT NULL DROP TABLE dbo.ReturnRequests;
IF OBJECT_ID('dbo.CustomerInteractions', 'U') IS NOT NULL DROP TABLE dbo.CustomerInteractions;
IF OBJECT_ID('dbo.TicketAssignments', 'U') IS NOT NULL DROP TABLE dbo.TicketAssignments;
IF OBJECT_ID('dbo.TicketMessages', 'U') IS NOT NULL DROP TABLE dbo.TicketMessages;
IF OBJECT_ID('dbo.SupportTickets', 'U') IS NOT NULL DROP TABLE dbo.SupportTickets;

CREATE TABLE SupportTickets (
    TicketID INT IDENTITY(1,1) PRIMARY KEY,
    TicketCode VARCHAR(30) NOT NULL UNIQUE, -- CS001, CS002,...
    CustomerID INT NOT NULL,
    OrderID INT NULL,
    Title NVARCHAR(255) NOT NULL,
    Description NVARCHAR(MAX) NOT NULL,
    Channel VARCHAR(30) DEFAULT 'live_chat', -- live_chat, phone, zalo, facebook, web_form
    Priority VARCHAR(20) DEFAULT 'normal',   -- low, normal, high, urgent
    Status VARCHAR(30) DEFAULT 'new',         -- new, processing, waiting_customer, waiting_internal, resolved, overdue
    AssignedTo INT NULL, -- UserID nhân viên CSKH
    ResolutionNote NVARCHAR(MAX) NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    ResolvedAt DATETIME NULL,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (AssignedTo) REFERENCES Users(UserID)
);

CREATE TABLE TicketMessages (
    MessageID INT IDENTITY(1,1) PRIMARY KEY,
    TicketID INT NOT NULL,
    SenderType VARCHAR(20) NOT NULL, -- 'customer', 'agent', 'artisan'
    SenderID INT NULL,
    MessageText NVARCHAR(MAX) NOT NULL,
    AttachmentURL VARCHAR(500) NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (TicketID) REFERENCES SupportTickets(TicketID) ON DELETE CASCADE
);

CREATE TABLE TicketAssignments (
    AssignmentID INT IDENTITY(1,1) PRIMARY KEY,
    TicketID INT NOT NULL,
    AssignedFrom INT NULL,
    AssignedTo INT NOT NULL,
    Reason NVARCHAR(255) NULL,
    AssignedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (TicketID) REFERENCES SupportTickets(TicketID) ON DELETE CASCADE,
    FOREIGN KEY (AssignedFrom) REFERENCES Users(UserID),
    FOREIGN KEY (AssignedTo) REFERENCES Users(UserID)
);

CREATE TABLE CustomerInteractions (
    InteractionID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    Channel VARCHAR(50) NOT NULL, -- 'phone_call', 'zalo_chat', 'workshop_visit', 'live_chat'
    AgentID INT NULL,
    Summary NVARCHAR(500) NOT NULL,
    CustomerMood VARCHAR(30) DEFAULT 'neutral', -- satisfied, neutral, concerned
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (AgentID) REFERENCES Users(UserID)
);

CREATE TABLE WarrantyRequests (
    WarrantyID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    CustomerID INT NOT NULL,
    WarrantyCode VARCHAR(50) NOT NULL UNIQUE,
    IssueType VARCHAR(50) NOT NULL, -- 'wood_shrinkage', 'crack', 'finish_blemish', 'fitting_adjust'
    Description NVARCHAR(MAX) NOT NULL,
    ImageProofURL VARCHAR(500) NULL,
    ArtisanAssigned INT NULL,
    Status VARCHAR(30) DEFAULT 'pending', -- pending, inspecting, scheduled_repair, completed
    CreatedAt DATETIME DEFAULT GETDATE(),
    CompletedAt DATETIME NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (ArtisanAssigned) REFERENCES Users(UserID)
);

CREATE TABLE ReturnRequests (
    ReturnID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    CustomerID INT NOT NULL,
    Reason NVARCHAR(MAX) NOT NULL,
    Status VARCHAR(30) DEFAULT 'requested', -- requested, approved, rejected, refund_completed
    RefundAmount DECIMAL(18,2) DEFAULT 0,
    CreatedAt DATETIME DEFAULT GETDATE(),
    ProcessedAt DATETIME NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Conversations (
    ConversationID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NULL,
    VisitorName NVARCHAR(150) NULL,
    VisitorPhone VARCHAR(20) NULL,
    Status VARCHAR(30) DEFAULT 'active',
    AssignedAgentID INT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    LastMessageAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (AssignedAgentID) REFERENCES Users(UserID)
);

CREATE TABLE Messages (
    MessageID INT IDENTITY(1,1) PRIMARY KEY,
    ConversationID INT NOT NULL,
    SenderType VARCHAR(20) NOT NULL, -- 'visitor', 'agent', 'bot'
    MessageText NVARCHAR(MAX) NOT NULL,
    IsRead BIT DEFAULT 0,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (ConversationID) REFERENCES Conversations(ConversationID) ON DELETE CASCADE
);

CREATE TABLE ProductReviews (
    ReviewID INT IDENTITY(1,1) PRIMARY KEY,
    ProductID INT NOT NULL,
    CustomerID INT NOT NULL,
    OrderID INT NULL,
    Rating INT NOT NULL CHECK (Rating >= 1 AND Rating <= 5),
    ReviewTitle NVARCHAR(150) NULL,
    ReviewContent NVARCHAR(MAX) NULL,
    WoodQualityScore INT DEFAULT 5,
    IsApproved BIT DEFAULT 1,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);

-- -------------------------------------------------------------------------
-- NHÓM 6: NỘI DUNG, THÔNG BÁO, TRANG TĨNH & AUDIT LOGS
-- -------------------------------------------------------------------------

IF OBJECT_ID('dbo.Notifications', 'U') IS NOT NULL DROP TABLE dbo.Notifications;
IF OBJECT_ID('dbo.AuditLogs', 'U') IS NOT NULL DROP TABLE dbo.AuditLogs;
IF OBJECT_ID('dbo.Settings', 'U') IS NOT NULL DROP TABLE dbo.Settings;
IF OBJECT_ID('dbo.Pages', 'U') IS NOT NULL DROP TABLE dbo.Pages;
IF OBJECT_ID('dbo.Articles', 'U') IS NOT NULL DROP TABLE dbo.Articles;
IF OBJECT_ID('dbo.Banners', 'U') IS NOT NULL DROP TABLE dbo.Banners;

CREATE TABLE Banners (
    BannerID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(150) NULL,
    ImageURL VARCHAR(500) NOT NULL,
    LinkURL VARCHAR(500) NULL,
    Position VARCHAR(50) DEFAULT 'home_top',
    DisplayOrder INT DEFAULT 0,
    IsActive BIT DEFAULT 1
);

CREATE TABLE Articles (
    ArticleID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(255) NOT NULL,
    Slug VARCHAR(255) NOT NULL UNIQUE,
    Content NVARCHAR(MAX) NOT NULL,
    Summary NVARCHAR(500) NULL,
    Thumbnail VARCHAR(500) NULL,
    Category VARCHAR(50) DEFAULT 'news', -- 'knowledge_wood', 'feng_shui', 'projects', 'news'
    IsPublished BIT DEFAULT 1,
    AuthorID INT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (AuthorID) REFERENCES Users(UserID)
);

CREATE TABLE Pages (
    PageID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(255) NOT NULL,
    Slug VARCHAR(150) NOT NULL UNIQUE,
    Content NVARCHAR(MAX) NOT NULL,
    MetaTitle NVARCHAR(255) NULL,
    MetaDescription NVARCHAR(500) NULL,
    IsPublished BIT DEFAULT 1,
    UpdatedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE Notifications (
    NotificationID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT NULL, -- NULL nghĩa là phát thông báo toàn hệ thống admin
    Title NVARCHAR(200) NOT NULL,
    Message NVARCHAR(500) NOT NULL,
    Type VARCHAR(50) DEFAULT 'order_new', -- 'order_new', 'timber_signed', 'ticket_urgent'
    IsRead BIT DEFAULT 0,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE Settings (
    SettingKey VARCHAR(100) PRIMARY KEY,
    SettingValue NVARCHAR(MAX) NOT NULL,
    Description NVARCHAR(255) NULL,
    UpdatedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE AuditLogs (
    LogID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT NULL,
    Action VARCHAR(100) NOT NULL,
    IPAddress VARCHAR(50) NULL,
    UserAgent NVARCHAR(255) NULL,
    Details NVARCHAR(MAX) NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

GO

-- -------------------------------------------------------------------------
-- INDEXES TỐI ƯU HÓA HIỆU NĂNG CHO SQL SERVER 2014
-- -------------------------------------------------------------------------

CREATE NONCLUSTERED INDEX IX_Products_CategoryID ON Products(CategoryID);
CREATE NONCLUSTERED INDEX IX_Products_SKU ON Products(SKU);
CREATE NONCLUSTERED INDEX IX_Products_Status ON Products(Status);

CREATE NONCLUSTERED INDEX IX_Orders_CustomerID ON Orders(CustomerID);
CREATE NONCLUSTERED INDEX IX_Orders_OrderCode ON Orders(OrderCode);
CREATE NONCLUSTERED INDEX IX_Orders_OrderStatus ON Orders(OrderStatus);

CREATE NONCLUSTERED INDEX IX_SupportTickets_TicketCode ON SupportTickets(TicketCode);
CREATE NONCLUSTERED INDEX IX_SupportTickets_Status ON SupportTickets(Status);
CREATE NONCLUSTERED INDEX IX_SupportTickets_CustomerID ON SupportTickets(CustomerID);

CREATE NONCLUSTERED INDEX IX_CustomerAddresses_CustomerID ON CustomerAddresses(CustomerID);
CREATE NONCLUSTERED INDEX IX_Shipments_TrackingCode ON Shipments(TrackingCode);

GO

-- -------------------------------------------------------------------------
-- STORED PROCEDURES VỚI TRANSACTIONS (NGHIỆP VỤ BÁN HÀNG & TRỪ KHO)
-- -------------------------------------------------------------------------

-- 1. Tạo đơn hàng với cọc mộc 30% và cập nhật kho
IF OBJECT_ID('dbo.sp_CreateOrderWithDeposit', 'P') IS NOT NULL DROP PROCEDURE dbo.sp_CreateOrderWithDeposit;
GO

CREATE PROCEDURE dbo.sp_CreateOrderWithDeposit
    @CustomerID INT,
    @OrderCode VARCHAR(50),
    @TotalAmount DECIMAL(18,2),
    @DepositAmount DECIMAL(18,2),
    @DeliveryDistanceKM INT,
    @ShippingAddress NVARCHAR(500),
    @CustomerPhone VARCHAR(20),
    @CustomerName NVARCHAR(150),
    @CustomerNote NVARCHAR(MAX),
    @NewOrderID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        -- 1. Thêm bản ghi đơn hàng
        INSERT INTO Orders (
            CustomerID, OrderCode, TotalAmount, DepositAmount, OrderStatus, 
            PaymentStatus, IsMocSigned, DeliveryDistanceKM, ShippingAddress, 
            CustomerPhone, CustomerName, CustomerNote, CreatedAt
        )
        VALUES (
            @CustomerID, @OrderCode, @TotalAmount, @DepositAmount, 'pending',
            CASE WHEN @DepositAmount > 0 THEN 'partial_deposit' ELSE 'unpaid' END,
            0, @DeliveryDistanceKM, @ShippingAddress,
            @CustomerPhone, @CustomerName, @CustomerNote, GETDATE()
        );

        SET @NewOrderID = SCOPE_IDENTITY();

        -- 2. Ghi lịch sử trạng thái khởi tạo
        INSERT INTO OrderStatusHistory (OrderID, OldStatus, NewStatus, Note, CreatedAt)
        VALUES (@NewOrderID, NULL, 'pending', N'Đơn hàng mới được tạo trên hệ thống', GETDATE());

        -- 3. Tạo bản ghi thanh toán cọc nếu có cọc
        IF @DepositAmount > 0
        BEGIN
            INSERT INTO Payments (OrderID, PaymentMethod, Amount, PaymentPhase, Status, Note, PaidAt)
            VALUES (@NewOrderID, 'bank_transfer', @DepositAmount, 'deposit', 'success', N'Cọc mộc thô 30% theo quy chuẩn xưởng Duân Hồng', GETDATE());
        END

        -- 4. Tạo vận chuyển xưởng dự kiến
        INSERT INTO Shipments (OrderID, TrackingCode, CarrierName, ShippingStatus, Note)
        VALUES (
            @NewOrderID, 
            'SHIP-' + @OrderCode, 
            CASE WHEN @DeliveryDistanceKM <= 30 THEN N'Xe Tải Xưởng Duân Hồng (Miễn Phí)' ELSE N'Xe Vận Chuyển Liên Tỉnh' END,
            'preparing',
            N'Bán kính giao hàng: ' + CAST(@DeliveryDistanceKM AS NVARCHAR(10)) + ' km'
        );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        DECLARE @ErrMsg NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrMsg, 16, 1);
    END CATCH
END;
GO

-- 2. Cập nhật tiến độ xưởng mộc và xác nhận ký tên phôi mộc thô
IF OBJECT_ID('dbo.sp_UpdateOrderStageAndMocSign', 'P') IS NOT NULL DROP PROCEDURE dbo.sp_UpdateOrderStageAndMocSign;
GO

CREATE PROCEDURE dbo.sp_UpdateOrderStageAndMocSign
    @OrderID INT,
    @NewStatus VARCHAR(30),
    @IsMocSigned BIT,
    @ChangedBy INT,
    @Note NVARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @OldStatus VARCHAR(30);
        SELECT @OldStatus = OrderStatus FROM Orders WHERE OrderID = @OrderID;

        UPDATE Orders
        SET OrderStatus = @NewStatus,
            IsMocSigned = @IsMocSigned,
            CompletedAt = CASE WHEN @NewStatus = 'completed' THEN GETDATE() ELSE CompletedAt END
        WHERE OrderID = @OrderID;

        INSERT INTO OrderStatusHistory (OrderID, OldStatus, NewStatus, Note, ChangedBy, CreatedAt)
        VALUES (@OrderID, @OldStatus, @NewStatus, @Note, @ChangedBy, GETDATE());

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        
        DECLARE @ErrMsg NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrMsg, 16, 1);
    END CATCH
END;
GO

-- -------------------------------------------------------------------------
-- SEED DATA MẪU: CÔNG TY ĐỒ GỖ NỘI THẤT DUÂN HỒNG
-- -------------------------------------------------------------------------

INSERT INTO Settings (SettingKey, SettingValue, Description) VALUES
('StoreName', N'Công ty Đồ Gỗ Nội Thất Duân Hồng', N'Tên thương hiệu'),
('Address', N'Đường Nguyễn Du, TP. Hưng Yên, Tỉnh Hưng Yên', N'Địa chỉ xưởng & showroom'),
('Hotline', '0988.686.868', N'Hotline/Zalo 24/7'),
('WarrantyYears', '5', N'Số năm bảo hành cong vênh, sấy gỗ'),
('FreeDeliveryKM', '30', N'Bán kính giao hàng miễn phí');

INSERT INTO Roles (RoleName, Description) VALUES
('Super Admin', N'Toàn quyền quản trị hệ thống'),
('Admin', N'Quản trị trang web & xuất báo cáo'),
('Manager', N'Thợ Cả / Quản lý xưởng & tiến độ đơn hàng'),
('Staff', N'Nhân viên bán hàng & CSKH');

INSERT INTO Categories (CategoryName, Slug, DisplayOrder) VALUES
(N'Phòng Khách Hoàng Gia & Hiện Đại', 'phong-khach', 1),
(N'Phòng Ăn & Bàn Ăn Nguyên Tấm', 'phong-an', 2),
(N'Phòng Ngủ An Yên', 'phong-ngu', 3),
(N'Không Gian Thờ Linh Thiêng', 'phong-tho', 4);

-- Seed sản phẩm Duân Hồng
INSERT INTO Products (CategoryID, ProductName, SKU, WoodType, Price, SalePrice, StockQuantity, MoisturePercent, LoBanDimension, Status, IsFeatured) VALUES
(1, N'Bộ Sofa Gõ Đỏ Chân Quỳ Vượng Khí Tài Lộc', 'DH-SF-01', N'Gỗ Gõ Đỏ Pachy Nam Phi Loại 1', 74500000, 74500000, 3, 11.2, N'Dài 2m8 Cung Tài Vượng', 'active', 1),
(3, N'Combo Phòng Ngủ Sồi Nga Tổ Ấm Trọn Vẹn', 'DH-BD-02', N'Gỗ Sồi Nga (Oak) Nhập Khẩu', 36900000, 36900000, 5, 10.8, N'Giường 1m8 x 2m Cung Tiến Bảo', 'active', 1),
(1, N'Bộ Bàn Ghế Hoàng Gia Louis Tân Cổ Điển', 'DH-HG-03', N'Gỗ Gõ Đỏ Pachy Liền Khối', 95000000, 95000000, 2, 11.5, N'Bộ 10 món đục tay kênh bong', 'active', 1),
(2, N'Bàn Ăn Live-Edge Cạnh Tự Nhiên Kèm 8 Ghế', 'DH-DT-04', N'Gỗ Gõ Đỏ Nguyên Tấm', 38000000, 38000000, 4, 11.0, N'Dày 12cm x Dài 2m8', 'active', 1),
(4, N'Án Gian Thờ Nhị Cấp Chạm Sen & Tứ Linh', 'DH-AT-05', N'Gỗ Gụ / Gõ Đỏ Chuẩn Cung Đỏ', 48000000, 48000000, 2, 10.5, N'Dài 2m17 x Cao 1m27', 'active', 1);

-- Seed khách hàng & Đơn hàng mẫu
INSERT INTO Customers (FullName, Phone, CustomerType, PreferredWood, LoBanNote, TotalSpent) VALUES
(N'Anh Hoàng Nam', '0912.445.889', 'retail', N'Gỗ Gõ Đỏ Pachy', N'Phòng khách 45m2 Cung Tài Vượng', 74500000),
(N'Bác Trọng Cường', '0904.556.778', 'retail', N'Gỗ Hương Đá', N'Phòng thờ gia tiên 25m2 Thước Lỗ Ban Đỏ', 48000000),
(N'Chị Minh Tuyết', '0983.112.334', 'retail', N'Gỗ Sồi Nga', N'Phòng ngủ 22m2 Cung Tiến Bảo', 36900000);

-- Seed đơn hàng mẫu
INSERT INTO Orders (CustomerID, OrderCode, TotalAmount, DepositAmount, OrderStatus, PaymentStatus, IsMocSigned, DeliveryDistanceKM, ShippingAddress) VALUES
(1, 'DH-ORD-801', 74500000, 25000000, 'carving', 'partial_deposit', 1, 15, N'Khu đô thị Lạc Hồng Phúc, TX. Mỹ Hào, Hưng Yên'),
(2, 'DH-ORD-802', 48000000, 15000000, 'finishing', 'partial_deposit', 1, 5, N'Đường Trưng Trắc, TP. Hưng Yên'),
(3, 'DH-ORD-803', 36900000, 12000000, 'seasoning', 'partial_deposit', 0, 20, N'Thị Trấn Bần, Hưng Yên');

-- Seed Ticket CSKH mẫu
INSERT INTO SupportTickets (TicketCode, CustomerID, OrderID, Title, Description, Channel, Priority, Status) VALUES
('CS001', 1, 1, N'Hẹn lịch về xưởng Hưng Yên ký mộc thô', N'Khách muốn trực tiếp kiểm tra tom gỗ phôi sofa gõ đỏ trước khi xưởng chuyển vào phòng sơn PU', 'zalo', 'high', 'processing'),
('CS002', 2, 2, N'Tư vấn kích thước Lỗ Ban Cung Đỏ án gian', N'Đo đạc kiểm tra lại chiều cao án gian thờ chuẩn 1m27 theo thước phong thủy', 'live_chat', 'normal', 'resolved'),
('CS003', 3, 3, N'Bảo hành bảo dưỡng định kỳ 6 tháng lau dầu', N'Gia chủ đề nghị thợ mang dầu lau dưỡng bóng gỗ sồi định kỳ theo cam kết', 'phone', 'normal', 'new');

GO
