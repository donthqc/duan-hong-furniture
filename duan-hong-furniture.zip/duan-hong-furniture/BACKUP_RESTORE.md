# QUY TRÌNH SAO LƯU & KHÔI PHỤC DỮ LIỆU (BACKUP & DISASTER RECOVERY)
**Tệp:** `BACKUP_RESTORE.md`  
**Cơ sở dữ liệu:** `DuanHongEcommerceDB` (Microsoft SQL Server 2014)  
**Dự án:** Hệ Thống Thương Mại Điện Tử & Vận Hành Xưởng Đồ Gỗ Duân Hồng  
**Thương hiệu:** Công ty Đồ Gỗ Nội Thất Duân Hồng (Đường Nguyễn Du, TP. Hưng Yên)  
**Hotline / Zalo:** `0988.686.868` (Trực 24/7)

---

## 1. CHÍNH SÁCH SAO LƯU DỮ LIỆU (BACKUP POLICY)

Nhằm đảm bảo an toàn tuyệt đối cho các hợp đồng đóng mộc thô, lịch sử ký tên phôi mộc và hồ sơ bảo hành 5 năm của khách hàng, hệ thống áp dụng chính sách sao lưu 3 cấp độ:

| Loại Sao Lưu | Tần Suất Thực Hiện | Thời Điểm Chạy | Thời Gian Lưu Trữ | Mục Tiêu RPO |
| :--- | :--- | :--- | :--- | :--- |
| **Full Backup (Toàn phần)** | Hàng ngày | 01:00 AM mỗi đêm | Lưu trữ 30 ngày | $\le 24$ giờ |
| **Differential Backup (Vi sai)** | Mỗi 6 giờ | 07:00, 13:00, 19:00 | Lưu trữ 7 ngày | $\le 6$ giờ |
| **Transaction Log Backup** | Mỗi 30 phút | Suốt ca làm việc xưởng | Lưu trữ 48 giờ | $\le 30$ phút |
| **Media Assets (Ảnh phôi mộc)** | Hàng tuần | Chủ nhật 02:00 AM | Lưu trữ 60 ngày | $\le 7$ ngày |

---

## 2. KỊCH BẢN T-SQL SAO LƯU SQL SERVER 2014

### 2.1. Lệnh Sao Lưu Toàn Phần (Full Backup)
```sql
-- Thực thi trên SQL Server Management Studio (SSMS) 2014
DECLARE @BackupPath NVARCHAR(500);
SET @BackupPath = N'C:\SQL_Backups\DuanHongEcommerceDB_Full_' 
                  + CONVERT(VARCHAR(8), GETDATE(), 112) + '_' 
                  + REPLACE(CONVERT(VARCHAR(8), GETDATE(), 108), ':', '') + '.bak';

BACKUP DATABASE [DuanHongEcommerceDB]
TO DISK = @BackupPath
WITH FORMAT,
     MEDIANAME = 'DuanHong_Backup_Media',
     NAME = 'DuanHong-Full Database Backup',
     COMPRESSION, -- Nén dữ liệu giúp giảm 70% dung lượng đĩa
     STATS = 10;
GO
```

### 2.2. Lệnh Sao Lưu Transaction Log (Mỗi 30 Phút)
```sql
DECLARE @LogPath NVARCHAR(500);
SET @LogPath = N'C:\SQL_Backups\DuanHongEcommerceDB_Log_' 
               + CONVERT(VARCHAR(8), GETDATE(), 112) + '_' 
               + REPLACE(CONVERT(VARCHAR(8), GETDATE(), 108), ':', '') + '.trn';

BACKUP LOG [DuanHongEcommerceDB]
TO DISK = @LogPath
WITH COMPRESSION, STATS = 10;
GO
```

---

## 3. QUY TRÌNH KHÔI PHỤC DỮ LIỆU KHI XẢY RA SỰ CỐ (DISASTER RESTORE)

Khi gặp sự cố hỏng hóc phần cứng hoặc lỗi máy chủ, quản trị viên thực hiện khôi phục theo trình tự nghiêm ngặt sau:

### Bước 1: Ngắt Kết Nối Các Ứng Dụng Đang Truy Cập
```sql
ALTER DATABASE [DuanHongEcommerceDB] 
SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
```

### Bước 2: Khôi Phục Bản Full Backup Gần Nhất (Kèm cờ NORECOVERY)
```sql
RESTORE DATABASE [DuanHongEcommerceDB]
FROM DISK = N'C:\SQL_Backups\DuanHongEcommerceDB_Full_20261106_010000.bak'
WITH REPLACE, NORECOVERY, STATS = 5;
GO
```

### Bước 3: Áp Dụng Bản Differential Hoặc Log Cuối Cùng (Kèm cờ RECOVERY)
```sql
RESTORE LOG [DuanHongEcommerceDB]
FROM DISK = N'C:\SQL_Backups\DuanHongEcommerceDB_Log_20261106_143000.trn'
WITH RECOVERY, STATS = 5;
GO
```

### Bước 4: Mở Lại Chế Độ Đa Người Dùng
```sql
ALTER DATABASE [DuanHongEcommerceDB] 
SET MULTI_USER;
GO
```

---

## 4. KỊCH BẢN TỰ ĐỘNG HÓA TRÊN LINUX (NẾU DÙNG SQL SERVER TRÊN UBUNTU)

Tạo script tự động `/usr/local/bin/backup_duanhong_db.sh`:
```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/var/backups/sqlserver"
mkdir -p $BACKUP_DIR

/opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P "YourPassword" -Q \
"BACKUP DATABASE [DuanHongEcommerceDB] TO DISK = N'$BACKUP_DIR/DuanHong_$DATE.bak' WITH COMPRESSION;"

# Xóa các bản sao lưu cũ hơn 30 ngày để tiết kiệm dung lượng đĩa
find $BACKUP_DIR -name "*.bak" -type f -mtime +30 -delete
```

Gắn vào Cron Job chạy hàng đêm lúc 01:30:
```bash
30 1 * * * /usr/local/bin/backup_duanhong_db.sh >> /var/log/db_backup.log 2>&1
```
