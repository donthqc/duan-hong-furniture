# XƯỞNG MỘC MAY ĐO DUÂN HỒNG — DỰ ÁN WEBSITE 2026

Website chính thức của **Xưởng mộc Duân Hồng** (TP. Hưng Yên) — Chuyên đồ gỗ nội thất may đo theo kích thước và phong thủy Lỗ Ban.

---

## 1. Thông tin xưởng

* **Thương hiệu**: Xưởng mộc Duân Hồng
* **Hotline / Zalo**: `0378.914.207`
* **Địa chỉ xưởng**: Đường Nguyễn Du, TP. Hưng Yên
* **Giờ mở cửa**: 07:30 – 18:00 (Thứ 2 – Chủ Nhật)
* **Chính sách**: Bán kính đo đạc miễn phí 30 km; Cọc 30% khi duyệt bản vẽ, 70% khi nghiệm thu lắp đặt; Bảo hành kết cấu 5 năm.

---

## 2. Cấu trúc dự án

```text
qa-web-ban-hang/
├── design/                 # Giao diện Web tĩnh (HTML/CSS/JS thuần + hiệu ứng Motion)
│   ├── trang-chu.html      # Trang chủ (Hero, Giới thiệu, Cam kết, Đặt lịch)
│   ├── pdp.html            # Trang chi tiết sản phẩm may đo
│   ├── quy-trinh.html      # Quy trình 5 bước may đo & bàn giao
│   ├── cong-trinh.html     # Thư viện công trình thực tế đã thi công
│   ├── lo-ban.html         # Công cụ tra cứu thước Lỗ Ban 52.2 / 42.9 / 38.8 cm
│   ├── tra-cuu.html        # Tra cứu tiến độ đơn hàng theo mã đơn & SĐT
│   ├── dat-lich.html       # Form đặt lịch tư vấn & đo đạc tại nhà (1 bước)
│   ├── design-tokens.css   # Bảng màu gỗ Óc chó, typography & biến giao diện
│   ├── motion.css & .js    # Hiệu ứng chuyển động (3D Tilt, spotlight, magnetic button)
│   └── ui.js               # Logic tương tác người dùng, gửi lead & tra cứu
│
├── server/                 # Backend API (Node.js thuần + SQLite, không framework)
│   ├── src/                # Mã nguồn API: app.js, db.js, server.js, sheets/
│   ├── data/               # Cơ sở dữ liệu SQLite: duanhong.db
│   ├── google-apps-script/ # Code.gs đồng bộ Google Sheets tự động
│   ├── test/               # Bộ kiểm thử API: api.test.js, apps-script.test.js...
│   └── .env                # File cấu hình biến môi trường (PORT, URL Webhook...)
│
├── deploy/                 # Cấu hình triển khai máy chủ Production (Nginx, Systemd)
│   ├── nginx-duanhong.conf # Cấu hình Nginx reverse proxy + static cache
│   ├── duanhong-api.service# Dịch vụ chạy ngầm systemd cho Linux
│   └── deploy.sh           # Script triển khai tự động
│
├── tools/                  # Công cụ hỗ trợ
│   └── photos.js           # Script quản lý ảnh sản phẩm
│
└── qa-node/                # Bộ kịch bản kiểm thử tự động (E2E & Code review)
```

---

## 3. Cách chạy dự án

### Chạy Backend API (Cổng 5055):
```bash
cd server
node --env-file=.env src/server.js
```

### Chạy Giao diện Web (Cổng 8098):
```bash
cd design
python -m http.server 8098 --bind 127.0.0.1
```
*Truy cập trình duyệt: `http://127.0.0.1:8098/trang-chu.html`*

### Kiểm thử hệ thống:
```bash
cd server
node test/api.test.js           # 46/46 PASS
node test/sheets-sync.test.js   # 61/61 PASS
node test/apps-script.test.js   # 12/12 PASS
```

---

## 4. Tài liệu quan trọng kèm theo

1. **`HUONG-DAN-GOOGLE-APPS-SCRIPT.md`**: Hướng dẫn cài đặt và đồng bộ dữ liệu khách hàng về Google Sheets của xưởng.
2. **`HUONG-DAN-THEM-ANH.md`**: Hướng dẫn cách chụp và bổ sung ảnh xưởng mộc thật thay thế các ô "VỊ TRÍ ẢNH".
3. **`KE-HOACH-PHAT-TRIEN-WEBSITE-2026.md`**: Lộ trình 8 giai đoạn phát triển website 2026.
4. **`SPEC-GOOGLE-SHEETS.md`**: Đặc tả kỹ thuật chi tiết cơ chế đồng bộ.
