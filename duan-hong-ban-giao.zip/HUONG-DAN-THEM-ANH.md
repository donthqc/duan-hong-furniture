# Thêm ảnh vào website — 3 bước

Toàn bộ 18 ô ảnh trên site đã được đánh dấu sẵn. Bạn **không cần sửa HTML hay JS**.

## Bước 1 — Đặt file vào một thư mục

`design/assets/img/`

## Bước 2 — Đặt đúng tên file

| Tên file | Dùng ở đâu | Tỉ lệ |
|---|---|---|
| `hero-workshop` | Ảnh lớn đầu trang chủ | 4:3 |
| `step-1` … `step-5` | 5 công đoạn ở trang Quy trình | 5:4 |
| `project-1` … `project-5` | 5 công trình ở trang Công trình | 16:9 |
| `product-sofa-go-do` | Ảnh đại diện sofa gõ đỏ | 4:3 |
| `product-an-gian-tho` | Án gian thờ | 4:3 |
| `product-combo-phong-ngu` | Combo phòng ngủ | 4:3 |
| `product-ban-an-live-edge` | Bàn ăn live-edge | 4:3 |
| `product-tu-bep-mdf` | Tủ bếp MDF | 4:3 |
| `product-tu-quan-ao-soi` | Tủ quần áo sồi | 4:3 |
| `product-<slug>-2` `-3` `-4` | Ảnh phụ (thumbnail) của trang sản phẩm | 4:3 |
| `order-latest` | Ảnh cập nhật ở trang Tra cứu | 16:9 |

Đuôi file nhận `.webp`, `.jpg`, `.png`, `.avif`. Nếu có nhiều đuôi cho cùng một tên, ưu tiên `webp` → `avif` → `jpg` → `png`.

## Bước 3 — Chạy một lệnh

```bash
node tools/photos.js
```

Lệnh in ra còn thiếu ảnh nào và ghi `design/assets/img/manifest.json`. Tải lại trang là ảnh hiện.

```
Đã có       : 3/18 ảnh bắt buộc (17%)
  ✓ hero-workshop, step-1, product-sofa-go-do
  ✗ thiếu: step-2, step-3, step-4, step-5, project-1, ...
```

Chỉ muốn xem còn thiếu gì, không ghi file: `node tools/photos.js --check`

## Ảnh nào chưa có thì sao

Ô đó vẫn hiện khung ghi **"VỊ TRÍ ẢNH: …"** — không giả vờ là ảnh thật, không hiện ảnh của sản phẩm khác.
Ví dụ: thumbnail "Mặt bàn" chưa có file thì bấm vào vẫn ra khung `VỊ TRÍ ẢNH: Mặt bàn — Sofa gõ đỏ chân quỳ`,
chứ không lấy ảnh "Toàn cảnh" gắn vào và ghi đè nhãn.

## Lưu ý kỹ thuật (đã xử lý sẵn)

- Ảnh hero dùng `loading="eager"` + `fetchpriority="high"` (tốt cho LCP); ảnh còn lại `loading="lazy"`.
- Khung ảnh đã có `aspect-ratio` cố định → thay ảnh **không làm nhảy bố cục** (đo được: hero cao 439px trước và sau khi thay ảnh).
- Ảnh được `object-fit: cover` nên không bị méo; ảnh dọc sẽ bị cắt hai bên.
- Nên nén ≤ 300 KB/ảnh (hero ≤ 400 KB).
- Ảnh có mặt khách: xin phép trước khi đăng (Nghị định 13/2023/NĐ-CP).

## Ảnh tiến độ của từng đơn (khác với ảnh tĩnh)

Ảnh "xưởng vừa ghép mộng bàn của anh Nam" không nằm trong thư mục này. Nó là cột
`photo_url` của bảng `order_steps`, cập nhật qua API quản trị:

```bash
curl -X PATCH http://127.0.0.1:5055/api/admin/orders/DH-801 \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"stage":3,"note":"Đã ghép mộng xong","photo_url":"https://.../dh-801-mong.jpg"}'
```

Tracker sẽ hiện ảnh đó ngay dưới bước tương ứng. Hiện **chưa có phần upload** — ảnh phải
nằm ở một URL công khai (Supabase Storage / Cloudinary). Đây là việc còn lại nếu bạn muốn
thợ cả tự chụp và đăng từ điện thoại.
