const puppeteer = require('puppeteer');
const fs = require('fs');
const OUT = 'C:/Users/DELL/Documents/qa-web-ban-hang/design/shots/';
fs.mkdirSync(OUT, { recursive: true });
const B = process.env.DH_WEB || 'http://127.0.0.1:8098';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const res = [];
const rec = (id, s, d) => { res.push({ id, s, d }); console.log(`[${s}] ${id} :: ${d}`); };

const PAGES = [
  ['trang-chu.html', 'Trang chủ'],
  ['pdp.html', 'Chi tiết sản phẩm'],
  ['quy-trinh.html', 'Quy trình'],
  ['cong-trinh.html', 'Công trình'],
  ['lo-ban.html', 'Thước Lỗ Ban'],
  ['tra-cuu.html', 'Tra cứu'],
  ['dat-lich.html', 'Đặt lịch'],
];

(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 180000 });
  const errors = [];

  // ---- 1. tất cả trang: 200, không lỗi console, 1 h1, không tràn ngang ----
  for (const [file, label] of PAGES) {
    const p = await browser.newPage();
    await p.setViewport({ width: 1440, height: 900 });
    p.on('pageerror', e => errors.push(file + ' pageerror: ' + e.message.slice(0, 120)));
    p.on('console', m => { if (m.type() === 'error') errors.push(file + ' console: ' + m.text().slice(0, 120)); });
    const r = await p.goto(B + '/' + file, { waitUntil: 'networkidle2', timeout: 60000 });
    await sleep(600);
    const info = await p.evaluate(() => ({
      h1: document.querySelectorAll('h1').length,
      sw: document.documentElement.scrollWidth,
      cw: document.documentElement.clientWidth,
      imgsNoAlt: [...document.images].filter(i => !i.hasAttribute('alt')).length,
      noLabel: [...document.querySelectorAll('input,select,textarea')].filter(i => !(i.id && document.querySelector('label[for="' + i.id + '"]')) && !i.getAttribute('aria-label')).length,
      landmarks: ['header', 'main', 'footer', 'nav'].filter(t => document.querySelector(t)).length,
      activeNav: document.querySelectorAll('[aria-current="page"]').length,
      height: document.body.scrollHeight,
    }));
    const ok = r.status() === 200 && info.h1 === 1 && info.sw <= info.cw + 1 && info.imgsNoAlt === 0 && info.noLabel === 0 && info.landmarks === 4;
    rec(file, ok ? 'PASS' : 'FAIL',
      `HTTP ${r.status()} · h1=${info.h1} · ${info.sw}/${info.cw}px · alt=${info.imgsNoAlt} · label=${info.noLabel} · landmark=${info.landmarks}/4 · navActive=${info.activeNav} · ${info.height}px`);
    await p.screenshot({ path: OUT + file.replace('.html', '') + '-1440.png' });
    if (file !== 'trang-chu.html' && file !== 'pdp.html') {
      await p.screenshot({ path: OUT + file.replace('.html', '') + '-full.png', fullPage: true });
    }
    await p.close();
  }

  // ---- 2. mobile 375 cho tất cả trang ----
  for (const [file] of PAGES) {
    const p = await browser.newPage();
    await p.setViewport({ width: 375, height: 812, isMobile: true, hasTouch: true });
    await p.goto(B + '/' + file, { waitUntil: 'networkidle2', timeout: 60000 });
    await sleep(400);
    const o = await p.evaluate(() => {
      const els = [...document.querySelectorAll('a,button,input,select')].filter(e => e.offsetParent);
      return {
        sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth,
        small: els.filter(e => e.getBoundingClientRect().height < 40).length,
        total: els.length
      };
    });
    rec('mobile-' + file, o.sw <= o.cw + 1 ? 'PASS' : 'FAIL', `tràn=${o.sw}/${o.cw} · tap<40px=${o.small}/${o.total}`);
    if (file === 'trang-chu.html' || file === 'dat-lich.html') {
      await p.screenshot({ path: OUT + file.replace('.html', '') + '-375.png' });
    }
    await p.close();
  }

  // ---- 3. lọc công trình ----
  const c = await browser.newPage();
  await c.setViewport({ width: 1440, height: 900 });
  await c.goto(B + '/cong-trinh.html', { waitUntil: 'networkidle2' });
  await sleep(400);
  const all = await c.evaluate(() => document.querySelectorAll('#cases .cs').length);
  await c.click('[data-case="ngu"]');
  await sleep(300);
  const one = await c.evaluate(() => ({
    n: [...document.querySelectorAll('#cases .cs')].filter(e => e.style.display !== 'none').length,
    count: document.getElementById('case-count').textContent
  }));
  await c.click('[data-case="bep"]');
  await sleep(300);
  const two = await c.evaluate(() => [...document.querySelectorAll('#cases .cs')].filter(e => e.style.display !== 'none').length);
  rec('CASE-FILTER', all === 5 && one.n === 1 && two === 1 ? 'PASS' : 'FAIL', `tất cả=${all} · phòng ngủ=${one.n} ("${one.count}") · bàn ăn=${two}`);
  await c.close();

  // ---- 4. lỗ ban page ----
  const lb = await browser.newPage();
  await lb.setViewport({ width: 1440, height: 900 });
  await lb.goto(B + '/lo-ban.html', { waitUntil: 'networkidle2' });
  await sleep(400);
  const lb1 = await lb.evaluate(() => document.getElementById('lb-out').innerText.replace(/\s+/g, ' '));
  await lb.evaluate(() => { const i = document.getElementById('lb-cm'); i.value = 197; i.dispatchEvent(new Event('input', { bubbles: true })); });
  await sleep(300);
  const lb2 = await lb.evaluate(() => ({
    out: document.getElementById('lb-out').innerText.replace(/\s+/g, ' '),
    rows: document.querySelectorAll('#good-rows tr').length,
    active: document.querySelectorAll('#lb-scale .active').length
  }));
  rec('LOBAN-PAGE', lb1.includes('Tài') && lb2.rows === 4 && lb2.active === 1 ? 'PASS' : 'FAIL',
    `274→"${lb1.slice(0, 60)}" · 197→"${lb2.out.slice(0, 60)}" · bảng=${lb2.rows} cung tốt`);
  await lb.screenshot({ path: OUT + 'lo-ban-full.png', fullPage: true });
  await lb.close();

  // ---- 5. wizard 3 bước ----
  const w = await browser.newPage();
  await w.setViewport({ width: 1440, height: 900 });
  await w.goto(B + '/dat-lich.html', { waitUntil: 'networkidle2' });
  await sleep(400);
  // bỏ trống -> phải chặn
  await w.click('#next-1');
  await sleep(200);
  const s1 = await w.evaluate(() => ({
    err: document.getElementById('bk-room-err').textContent,
    onStep1: !document.getElementById('step-1').hidden
  }));
  await w.select('#bk-room', 'Phòng khách');
  await w.click('#next-1');
  await sleep(400);
  const s2 = await w.evaluate(() => !document.getElementById('step-2').hidden);
  await w.type('#bk-area', '32');
  await w.click('#next-2');
  await sleep(500);
  const s3 = await w.evaluate(() => ({
    onStep3: !document.getElementById('step-3').hidden,
    summary: document.getElementById('bk-summary').innerText.replace(/\s+/g, ' ').slice(0, 80),
    bars: [...document.querySelectorAll('.steps-bar div')].map(d => d.dataset.done + '/' + d.dataset.active)
  }));
  // submit thiếu thông tin
  await w.click('#bk-submit');
  await sleep(300);
  const s4 = await w.evaluate(() => document.querySelectorAll('[aria-invalid="true"]').length);
  await w.type('#bk-name', 'Nguyễn Văn An');
  await w.type('#bk-phone', '0901234567');
  await w.click('#bk-submit');
  await sleep(1100);
  const s5 = await w.evaluate(() => ({
    txt: document.getElementById('bk-done').innerText.replace(/\s+/g, ' ').slice(0, 70),
    shown: !document.getElementById('bk-done').hidden,
    formHidden: [...document.querySelectorAll('#book-form .step')].every(e => e.hidden)
  }));
  rec('WIZARD', s1.err.length > 0 && s2 && s3.onStep3 && s4 === 2 && s5.shown && s5.formHidden ? 'PASS' : 'FAIL',
    `bỏ trống bị chặn="${s1.err.slice(0, 40)}" · step2=${s2} · step3=${s3.onStep3} · tóm tắt="${s3.summary}" · lỗi khi thiếu=${s4} · thành công="${s5.txt}" · form ẩn=${s5.formHidden}`);
  await w.screenshot({ path: OUT + 'dat-lich-step3.png' });
  await w.close();

  // ---- 6. tải trang nặng nhất ----
  const perf = await browser.newPage();
  await perf.setViewport({ width: 1440, height: 900 });
  const t0 = Date.now();
  await perf.goto(B + '/trang-chu.html', { waitUntil: 'networkidle2' });
  const ms = Date.now() - t0;
  rec('LOAD', ms < 3500 ? 'PASS' : 'WARN', `${ms}ms localhost`);
  await perf.close();

  rec('CONSOLE-ALL', errors.length === 0 ? 'PASS' : 'FAIL', errors.length ? [...new Set(errors)].slice(0, 5).join(' || ') : 'không có lỗi trên 7 trang');

  fs.writeFileSync(OUT + 'site-check.json', JSON.stringify({ res, errors: [...new Set(errors)] }, null, 2));
  const cnt = res.reduce((a, r) => (a[r.s] = (a[r.s] || 0) + 1, a), {});
  console.log('\nSUMMARY', JSON.stringify(cnt));
  await browser.close();
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
