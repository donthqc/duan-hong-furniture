const puppeteer=require('puppeteer');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const cases=[
 {label:'pwd=abcd (4 ký tự, email lạ)', id:'ke.toan@congtykhac.vn', pwd:'abcd'},
 {label:'pwd=admin123 (email lạ)', id:'boss@evil.com', pwd:'admin123'},
 {label:'pwd=123 (3 ký tự)', id:'boss2@evil.com', pwd:'123'},
 {label:'id=admin, pwd=bất kỳ 8 ký tự', id:'admin', pwd:'whatever99'},
];
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:60000});
for(const c of cases){
  const p=await b.newPage(); await p.setViewport({width:1440,height:900});
  await p.goto('http://127.0.0.1:8099/cms_duan_hong.html',{waitUntil:'domcontentloaded',timeout:60000});
  await sleep(800);
  await p.evaluate((id,pwd)=>{
    document.getElementById('cms-login-identifier').value=id;
    document.getElementById('cms-login-password').value=pwd;
    document.getElementById('cms-login-form').dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));
  },c.id,c.pwd);
  await sleep(2500);
  const r=await p.evaluate(()=>{
    const d=document.getElementById('admin-login-screen');
    const hidden=!d || getComputedStyle(d).display==='none' || d.classList.contains('hidden') || d.offsetParent===null;
    const u=localStorage.getItem('dh_admin_user')||'';
    return {hidden, role:(JSON.parse(u||'{}').role||''), email:(JSON.parse(u||'{}').email||''), body:document.body.innerText.replace(/\s+/g,' ').slice(0,80)};
  });
  console.log(`${r.hidden?'VÀO ĐƯỢC':'BỊ CHẶN'} | ${c.label} | role="${r.role}" | ${r.body}`);
  await p.close();
}
// Also: does CMS let you reach dashboard by setting localStorage manually? (client-side only auth)
const p=await b.newPage();
await p.goto('http://127.0.0.1:8099/cms_duan_hong.html',{waitUntil:'domcontentloaded'});
await sleep(600);
await p.evaluate(()=>{
  localStorage.setItem('dh_admin_user',JSON.stringify({id:999,fullName:'Kẻ Gian',email:'x@y.z',role:'Super Admin',permissions:{manage_users:true,manage_products:true,manage_orders:true,view_reports:true}}));
  localStorage.setItem('dh_admin_token','dh_jwt_'+btoa(JSON.stringify({id:999,role:'Super Admin'})));
  localStorage.setItem('dh_admin_login_at',String(Date.now()));
});
await p.reload({waitUntil:'networkidle2'}); await sleep(2000);
const forged=await p.evaluate(()=>({hasLogin:/Đăng Nhập Ngay/.test(document.body.innerText),dash:/doanh thu|tổng quan|đơn hàng/i.test(document.body.innerText),txt:document.body.innerText.replace(/\s+/g,' ').slice(0,120)}));
console.log('FORGED localStorage ->', JSON.stringify(forged).slice(0,300));
await p.screenshot({path:'C:/Users/DELL/Documents/qa-web-ban-hang/evidence/22-cms-forged-session.png'});
await b.close();})();
