const puppeteer = require('puppeteer');
const B = process.env.DH_WEB || 'http://127.0.0.1:8098';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const out = [];
const rec = (id, status, detail) => { out.push({ id, status, detail }); console.log(`[${status}] ${id} :: ${detail}`); };

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 120000 });

  const newPage = async (url) => {
    const p = await br.newPage();
    await p.setViewport({ width: 1440, height: 900 });
    const errs = [];
    p.on('pageerror', e => errs.push(e.message.slice(0, 90)));
    await p.goto(url, { waitUntil: 'networkidle2' });
    await sleep(350);
    return { p, errs };
  };

  // ---------- 1. TRACKER edge cases ----------
  {
    const { p } = await newPage(B + '/trang-chu.html');
    const set = async (code, phone) => {
      await p.evaluate((c, ph) => {
        document.getElementById('order-code').value = c;
        document.getElementById('order-phone').value = ph;
        document.getElementById('track-btn').click();
      }, code, phone);
      await new Promise(r => setTimeout(r, 800));   // tracker gọi API → chờ kết quả
    };

    await set('dh-801', '5889');
    const lower = await p.evaluate(() => document.getElementById('track-result').innerText);
    rec('C1 lowercase mã đơn', lower.includes('3/5') ? 'PASS' : 'FAIL', `"${lower.replace(/\s+/g,' ').slice(0,50)}"`);

    await set('  DH-801  ', '5889');
    const spaces = await p.evaluate(() => document.getElementById('track-result').innerText);
    rec('C2 khoảng trắng đầu/cuối', spaces.includes('3/5') ? 'PASS' : 'FAIL', `"${spaces.replace(/\s+/g,' ').slice(0,50)}"`);

    await set('DH-801', '588');
    const short = await p.evaluate(() => document.getElementById('track-result').innerText.slice(0, 30));
    rec('C3 thiếu số SĐT', short.includes('Vui lòng') ? 'PASS' : 'FAIL', `"${short}"`);

    // double click
    await p.evaluate(() => { const c = document.getElementById('order-code'); c.value = 'DH-802'; document.getElementById('order-phone').value = '6778'; });
    await p.evaluate(() => { const b = document.getElementById('track-btn'); b.click(); b.click(); b.click(); });
    await sleep(200);
    const dbl = await p.evaluate(() => document.getElementById('track-result').innerText);
    rec('C4 click 3 lần liên tiếp', dbl.includes('4/5') ? 'PASS' : 'FAIL', `"${dbl.replace(/\s+/g,' ').slice(0,50)}"`);

    // XSS via input
    await p.evaluate(() => {
      document.getElementById('order-code').value = '<img src=x onerror=alert(1)>';
      document.getElementById('order-phone').value = '5889';
      document.getElementById('track-btn').click();
    });
    await sleep(200);
    const xss = await p.evaluate(() => ({
      txt: document.getElementById('track-result').innerText.slice(0, 40),
      injected: document.querySelectorAll('#track-result img').length
    }));
    rec('C5 XSS qua ô mã đơn', xss.injected === 0 ? 'PASS' : 'FAIL', `img chèn=${xss.injected} · "${xss.txt}"`);

    // ?ma= reflected
    const { p: p2 } = await newPage(B + '/trang-chu.html?ma=%3Cscript%3Ealert(1)%3C/script%3E');
    const refl = await p2.evaluate(() => ({
      value: document.getElementById('order-code').value,
      scripts: document.querySelectorAll('#order-code script').length,
      hasScriptTag: document.body.innerHTML.includes('<script>alert(1)</script>')
    }));
    rec('C6 ?ma= reflected XSS', refl.hasScriptTag ? 'FAIL' : 'PASS', `value="${refl.value.slice(0, 30)}" · script chèn=${refl.scripts}`);
    await p2.close();
    await p.close();
  }

  // ---------- 2. FORM edge cases ----------
  {
    const { p } = await newPage(B + '/trang-chu.html');
    const trySubmit = async (name, phone) => {
      await p.evaluate((n, ph) => {
        document.getElementById('lead-name').value = n;
        document.getElementById('lead-phone').value = ph;
        document.getElementById('lead-submit').click();
      }, name, phone);
      await sleep(900);
      return p.evaluate(() => ({
        nameErr: document.getElementById('lead-name-err').textContent,
        phoneErr: document.getElementById('lead-phone-err').textContent,
        ok: document.getElementById('lead-result').classList.contains('is-on'),
        disabled: document.getElementById('lead-submit').disabled
      }));
    };

    let r = await trySubmit('   ', '0901234567');
    rec('F1 tên toàn khoảng trắng', r.nameErr ? 'PASS' : 'FAIL', `nameErr="${r.nameErr}"`);

    r = await trySubmit('Nguyễn Văn An', '+84901234567');
    rec('F2 SĐT +84', r.ok ? 'PASS' : 'FAIL', `ok=${r.ok} phoneErr="${r.phoneErr}"`);

    r = await trySubmit('Nguyễn Văn An', '090 123 4567');
    rec('F3 SĐT có khoảng trắng', r.ok ? 'PASS' : 'FAIL', `ok=${r.ok}`);

    r = await trySubmit('Nguyễn Văn An', '09012345678');
    rec('F4 SĐT 11 số', !r.ok && r.phoneErr ? 'PASS' : 'FAIL', `ok=${r.ok} phoneErr="${r.phoneErr}"`);

    r = await trySubmit('Nguyễn Văn An', '0901234567');
    const afterOk = r;
    // double submit ngay sau khi thành công
    await p.evaluate(() => { document.getElementById('lead-name').value = 'A'; document.getElementById('lead-phone').value = '0901234567'; document.getElementById('lead-submit').click(); });
    await sleep(900);
    const f5 = await p.evaluate(() => {
      const out = document.getElementById('lead-result').innerText.replace(/\s+/g, ' ');
      return { txt: out, name: document.getElementById('lead-name').value };
    });
    // sau khi đã nhận mã, gửi lần 2 phải bị chặn (không tạo lead thứ hai)
    rec('F5 submit lần 2 sau khi đã thành công',
      /đã được nhận/i.test(f5.txt) ? 'PASS' : 'FAIL',
      `"${f5.txt.slice(0, 70)}"`);
    await p.close();
  }

  // ---------- 3. ESTIMATOR edge cases ----------
  {
    const { p, errs } = await newPage(B + '/trang-chu.html');
    const setArea = async (v) => {
      await p.evaluate((val) => {
        const a = document.getElementById('est-area');
        a.value = val;
        a.dispatchEvent(new Event('input', { bubbles: true }));
      }, v);
      await sleep(120);
      return p.evaluate(() => ({
        out: document.getElementById('est-result').textContent,
        note: document.getElementById('est-note').textContent
      }));
    };
    let r = await setArea('');
    rec('E1 diện tích rỗng', r.out === '—' ? 'PASS' : 'FAIL', `"${r.out}" · "${r.note.slice(0, 40)}"`);
    r = await setArea('0');
    rec('E2 diện tích 0', r.out === '—' ? 'PASS' : 'FAIL', `"${r.out}"`);
    r = await setArea('-5');
    rec('E3 diện tích âm', r.out === '—' ? 'PASS' : 'FAIL', `"${r.out}"`);
    r = await setArea('121');
    rec('E4 diện tích 121 (>120)', r.out === '—' ? 'PASS' : 'FAIL', `"${r.out}"`);
    r = await setArea('24.5');
    rec('E5 diện tích thập phân', r.out.includes('₫') ? 'PASS' : 'FAIL', `"${r.out}"`);
    rec('E6 lỗi JS khi nhập liệu', errs.length === 0 ? 'PASS' : 'FAIL', errs.join(' | ') || 'không có');
    await p.close();
  }

  // ---------- 4. LOBAN edge cases ----------
  {
    const { p } = await newPage(B + '/lo-ban.html');
    const set = async (v) => {
      await p.evaluate((val) => {
        const i = document.getElementById('lb-cm');
        i.value = val;
        i.dispatchEvent(new Event('input', { bubbles: true }));
      }, v);
      await sleep(120);
      return p.evaluate(() => document.getElementById('lb-out').innerText.replace(/\s+/g, ' ').slice(0, 60));
    };
    let r = await set('0');
    rec('L1 cm=0', r.includes('Nhập kích thước') ? 'PASS' : 'FAIL', `"${r}"`);
    r = await set('-10');
    rec('L2 cm âm', r.includes('Nhập kích thước') ? 'PASS' : 'FAIL', `"${r}"`);
    r = await set('5000');
    rec('L3 cm=5000 (>2000)', r.includes('Nhập kích thước') ? 'PASS' : 'FAIL', `"${r}"`);
    r = await set('274');
    rec('L4 cm=274', r.includes('Tài') ? 'PASS' : 'FAIL', `"${r}"`);
    await p.close();
  }

  // ---------- 5. CATALOG URL state + filter edge ----------
  {
    const { p } = await newPage(B + '/trang-chu.html?he=khongtontai&go=%3Cscript%3E');
    const r = await p.evaluate(() => ({
      empty: !!document.querySelector('[data-testid="catalog-empty"]'),
      count: document.getElementById('catalog-count').textContent,
      url: location.search,
      chips: [...document.querySelectorAll('.chip[aria-pressed="true"]')].map(c => c.dataset.value)
    }));
    rec('K1 ?he/?go rác', r.empty && r.chips.length === 0 ? 'PASS' : 'WARN',
      `empty=${r.empty} · "${r.count}" · chip active=${r.chips.join(',') || 'none'} · url="${r.url}"`);
    await p.close();
  }

  // ---------- 6. WIZARD: mất state khi reload ----------
  {
    const { p } = await newPage(B + '/dat-lich.html');
    await p.select('#bk-room', 'Phòng ngủ');
    await p.click('#next-1'); await sleep(300);
    await p.type('#bk-area', '30');
    await p.click('#next-2'); await sleep(300);
    const step = await p.evaluate(() => !document.getElementById('step-3').hidden);
    await p.reload({ waitUntil: 'networkidle2' }); await sleep(400);
    const afterReload = await p.evaluate(() => ({
      step1: !document.getElementById('step-1').hidden,
      room: document.getElementById('bk-room').value
    }));
    const kept = await p.evaluate(() => ({
      step3: !document.getElementById('step-3').hidden,
      room: document.getElementById('bk-room').value,
      area: document.getElementById('bk-area').value
    }));
    rec('W1 reload giữa wizard', kept.room === 'Phòng ngủ' && kept.area === '30' ? 'PASS' : 'FAIL',
      `trước reload bước 3=${step}; sau reload: room="${kept.room}", area="${kept.area}", ở bước 3=${kept.step3}`);
    await p.close();
  }

  // ---------- 7. PDP option + price injection ----------
  {
    const { p } = await newPage(B + '/pdp.html');
    await p.evaluate(() => { document.querySelectorAll('#opt-config .opt__btn')[2].click(); });
    await sleep(200);
    const r = await p.evaluate(() => document.getElementById('pdp-price').innerText.split('\n')[0]);
    rec('P1 chọn "theo kích thước phòng"', r.includes('Báo giá') ? 'PASS' : 'FAIL', `"${r}"`);
    await p.close();
  }

  const fail = out.filter(r => r.status === 'FAIL').length;
  const warn = out.filter(r => r.status === 'WARN').length;
  console.log(`\nSUMMARY pass=${out.filter(r => r.status === 'PASS').length} fail=${fail} warn=${warn}`);
  await br.close();
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
