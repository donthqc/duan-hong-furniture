const puppeteer = require('puppeteer');
const B = 'http://127.0.0.1:8098';
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 120000 });

  // ---------- 1. Điều hướng trên mobile ----------
  const m = await br.newPage();
  await m.setViewport({ width: 375, height: 812, isMobile: true, hasTouch: true });
  await m.goto(B + '/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(400);
  const nav = await m.evaluate(() => {
    const links = [...document.querySelectorAll('.nav__links a')].filter(a => a.offsetParent);
    const burger = [...document.querySelectorAll('button,[role=button]')].filter(b => /menu|☰|hamburger/i.test(b.className + b.id + b.getAttribute('aria-label')));
    return {
      visibleNavLinks: links.length,
      menuButtons: burger.length,
      anyClickableMenu: !!document.querySelector('[aria-label*="menu" i],[aria-label*="Menu"],#mobile-menu-btn,.hamburger'),
      bodyHasNavText: /Sản phẩm/.test(document.body.innerText)
    };
  });
  console.log('MOBILE NAV:', JSON.stringify(nav));

  // ---------- 2. PDP có nhận ?id không ----------
  const ids = ['sofa-go-do', 'an-gian-tho', 'combo-phong-ngu', 'ban-an-live-edge', 'tu-bep-mdf', 'tu-quan-ao-soi'];
  const pdpTitles = [];
  for (const id of ids) {
    const p = await br.newPage();
    await p.goto(B + '/pdp.html?id=' + id, { waitUntil: 'networkidle2' });
    await sleep(250);
    const t = await p.evaluate(() => document.querySelector('h1')?.innerText.trim().slice(0, 40));
    pdpTitles.push(`${id} → "${t}"`);
    await p.close();
  }
  console.log('PDP ?id:');
  pdpTitles.forEach(t => console.log('  ' + t));

  // ---------- 3. Gallery có đổi nội dung không ----------
  const g = await br.newPage();
  await g.goto(B + '/pdp.html', { waitUntil: 'networkidle2' });
  await sleep(300);
  const before = await g.evaluate(() => document.getElementById('gallery-main').innerText.slice(0, 40));
  await g.evaluate(() => document.querySelectorAll('.gallery__thumbs button')[2].click());
  await sleep(250);
  const after = await g.evaluate(() => ({
    main: document.getElementById('gallery-main').innerText.slice(0, 40),
    current: [...document.querySelectorAll('.gallery__thumbs button')].map(b => b.getAttribute('aria-current')).join(',')
  }));
  console.log('GALLERY: trước="' + before + '" | sau="' + after.main + '" | aria-current=' + after.current);

  // ---------- 4. Nút/khối trông bấm được nhưng không có handler ----------
  const h = await br.newPage();
  await h.goto(B + '/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(300);
  const dead = await h.evaluate(() => {
    const out = [];
    document.querySelectorAll('a[href="#"], a[href=""]').forEach(a => out.push('link rỗng: "' + a.innerText.trim().slice(0, 24) + '"'));
    // phần tử có cursor pointer nhưng không phải link/button và không có onclick
    document.querySelectorAll('*').forEach(el => {
      const s = getComputedStyle(el);
      const tag = el.tagName;
      if (s.cursor === 'pointer' && !['A', 'BUTTON', 'INPUT', 'SELECT', 'SUMMARY'].includes(tag)
          && !el.onclick && !el.closest('a') && !el.closest('button') && el.offsetParent) {
        const t = (el.innerText || '').trim().slice(0, 30);
        if (t && t.length > 2) out.push('cursor pointer, không handler: ' + t);
      }
    });
    return [...new Set(out)].slice(0, 12);
  });
  console.log('DEAD AFFORDANCES:'); dead.forEach(d => console.log('  ' + d));

  // ---------- 5. Chức năng còn thiếu ----------
  const miss = await h.evaluate(() => ({
    searchInput: !!document.querySelector('input[type=search], input[placeholder*="Tìm"], input[placeholder*="tìm"]'),
    reviewForm: !!document.querySelector('#panel-3 form, textarea[name*=review], button[onclick*=danhgia i]'),
    reviewButton: [...document.querySelectorAll('button,a')].some(b => /viết đánh giá/i.test(b.innerText)),
    mobileMenu: !!document.querySelector('[aria-label*="menu" i], #mobile-menu-btn, .hamburger'),
    cmsLink: [...document.querySelectorAll('a')].some(a => /cms|quản trị|admin/i.test(a.innerText)),
    policyPages: [...document.querySelectorAll('a')].filter(a => /chính sách|bảo hành|điều khoản/i.test(a.innerText)).map(a => a.getAttribute('href'))
  }));
  console.log('MISSING FEATURES:', JSON.stringify(miss, null, 0));

  // ---------- 6. Bấm từng nút, xem DOM có đổi không ----------
  const buttons = await h.evaluate(() => [...document.querySelectorAll('button')]
    .filter(b => b.offsetParent)
    .map((b, i) => ({ i, text: (b.innerText || b.id || '').trim().slice(0, 26), id: b.id, cls: String(b.className).slice(0, 24) })));
  const noop = [];
  for (const btn of buttons.slice(0, 20)) {
    const changed = await h.evaluate((i) => {
      const b = [...document.querySelectorAll('button')].filter(x => x.offsetParent)[i];
      if (!b) return null;
      const html = document.body.innerHTML.length;
      b.click();
      return new Promise(r => setTimeout(() => r(document.body.innerHTML.length !== html), 120));
    }, btn.i);
    if (changed === false) noop.push(btn.text || btn.id);
  }
  console.log('NÚT BẤM KHÔNG ĐỔI GÌ (' + noop.length + '):', noop.join(' | '));

  await br.close();
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
