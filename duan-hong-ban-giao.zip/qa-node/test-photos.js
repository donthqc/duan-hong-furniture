const puppeteer = require('puppeteer');
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const WEB = process.env.DH_WEB || 'http://127.0.0.1:8098';   // đổi được khi test gói ZIP ở cổng khác
/* Chạy được cả trong repo gốc (../design) lẫn trong gói bàn giao (../04-website). */
const CANDIDATES = [path.join(__dirname, '..', '04-website'), path.join(__dirname, '..', 'design')];
const SITE = CANDIDATES.find(d => fs.existsSync(d)) || CANDIDATES[0];
const IMG = path.join(SITE, 'assets', 'img');
const ROOT = path.dirname(SITE);
const PHOTO_TOOL = [path.join(SITE, '_tools', 'photos.js'), path.join(ROOT, 'tools', 'photos.js')]
  .find(f => fs.existsSync(f));
let pass = 0, fail = 0;
const ok = (n, c, d = '') => { console.log(`${c ? 'PASS' : 'FAIL'}  ${n}${d ? '  :: ' + d : ''}`); c ? pass++ : fail++; };

/* Ảnh mẫu 1×1 PNG — chỉ để kiểm cơ chế, không phải ảnh thật của xưởng */
const PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  'base64'
);
const FIXTURES = ['hero-workshop.png', 'product-sofa-go-do.png', 'step-1.png'];
const runPhotos = () => {   // photos.js trả mã 2 khi còn thiếu ảnh → bỏ qua mã thoát
  if (!PHOTO_TOOL) return;
  try { execFileSync(process.execPath, [PHOTO_TOOL], { cwd: ROOT, stdio: 'ignore' }); } catch {}
};
function makeFixtures() { FIXTURES.forEach(f => fs.writeFileSync(path.join(IMG, f), PNG)); }
function cleanFixtures() {
  FIXTURES.forEach(f => { try { fs.unlinkSync(path.join(IMG, f)); } catch {} });
  runPhotos();
}

(async () => {
  makeFixtures();
  runPhotos();

  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 90000 });
  const page = await br.newPage();
  await page.setViewport({ width: 1440, height: 900 });

  /* ---- có ảnh: placeholder phải được thay ---- */
  await page.goto(WEB + '/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(1200);

  const hero = await page.evaluate(() => {
    const img = document.querySelector('.hero__media img.ph-img');
    return img ? { src: img.getAttribute('src'), alt: img.alt, w: img.naturalWidth, h: img.naturalHeight, loading: img.loading } : null;
  });
  ok('hero đổi thành <img> thật', !!hero, hero ? hero.src : 'không thấy');
  ok('ảnh tải được (naturalWidth > 0)', hero && hero.w > 0, hero ? `${hero.w}x${hero.h}` : '');
  ok('alt có nghĩa, không phải "VỊ TRÍ ẢNH"', hero && !/VỊ TRÍ ẢNH/.test(hero.alt), hero ? hero.alt.slice(0, 50) : '');
  ok('hero dùng loading=eager (LCP)', hero && hero.loading === 'eager');

  const cards = await page.evaluate(() => {
    const imgs = [...document.querySelectorAll('#catalog img.ph-img')];
    return { n: imgs.length, srcs: imgs.map(i => i.getAttribute('src')), lazy: imgs.every(i => i.loading === 'lazy') };
  });
  ok('card sản phẩm có ảnh thật đổi theo slug', cards.n >= 1, cards.srcs.join(','));
  ok('card dùng lazy loading', cards.lazy);

  const stillPh = await page.evaluate(() => [...document.querySelectorAll('[data-photo]')].map(e => e.getAttribute('data-photo')));
  ok('ô chưa có ảnh vẫn giữ placeholder', stillPh.length > 0, stillPh.slice(0, 4).join(','));

  // ảnh không gây nhảy layout: chiều cao khung ảnh ổn định
  const cls = await page.evaluate(() => {
    const el = document.querySelector('.hero__media');
    return el ? Math.round(el.getBoundingClientRect().height) : 0;
  });
  ok('khung ảnh hero giữ chiều cao', cls > 100, `${cls}px`);

  await page.screenshot({ path: 'C:/Users/DELL/Documents/qa-web-ban-hang/design/shots/photos-with.jpg', fullPage: false });

  /* ---- trang quy-trinh: 1 ảnh thật, 4 placeholder ---- */
  await page.goto(WEB + '/quy-trinh.html', { waitUntil: 'networkidle2' });
  await sleep(900);
  const qt = await page.evaluate(() => ({
    imgs: document.querySelectorAll('img.ph-img').length,
    phs: document.querySelectorAll('[data-photo]').length
  }));
  ok('quy-trinh: 1 ảnh thật + 4 placeholder', qt.imgs === 1 && qt.phs === 4, `img=${qt.imgs} ph=${qt.phs}`);

  /* ---- pdp: ảnh chính theo ?id ---- */
  await page.goto(WEB + '/pdp.html?id=sofa-go-do', { waitUntil: 'networkidle2' });
  await sleep(900);
  const pdp = await page.evaluate(() => {
    const m = document.querySelector('.pdp img.ph-img');
    return {
      tag: m ? m.tagName : null,
      src: m && m.getAttribute('src'),
      alt: m && m.alt,
      focusable: m && m.getAttribute('tabindex'),
      thumb: document.querySelectorAll('.gallery__thumbs img.ph-img').length
    };
  });
  ok('PDP ảnh chính đổi thành ảnh thật theo ?id', pdp.tag === 'IMG' && /product-sofa-go-do/.test(pdp.src || ''), pdp.src || '');
  ok('PDP ảnh chính có alt là tên sản phẩm', !!pdp.alt && !/VỊ TRÍ/.test(pdp.alt), pdp.alt || '');
  ok('PDP thumb chưa có ảnh thì giữ placeholder', pdp.thumb === 0);

  /* ---- xoá ảnh: phải quay lại placeholder, không vỡ ---- */
  await page.goto(WEB + '/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(500);
  const before = await page.evaluate(() => document.querySelectorAll('img.ph-img').length);

  console.log(`\n${'='.repeat(56)}\nẢNH: ${pass} PASS / ${fail} FAIL  (ảnh thật trên trang: ${before})\n${'='.repeat(56)}`);
  await br.close();
  cleanFixtures();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('FATAL', e.message); try { cleanFixtures(); } catch {} process.exit(1); });
