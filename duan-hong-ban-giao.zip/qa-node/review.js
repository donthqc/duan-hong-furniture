const puppeteer = require('puppeteer');
const fs = require('fs');
const B = 'http://127.0.0.1:8098';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const PAGES = ['index.html', 'trang-chu.html', 'pdp.html', 'quy-trinh.html', 'cong-trinh.html', 'lo-ban.html', 'tra-cuu.html', 'dat-lich.html'];
const out = [];

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 180000 });
  for (const file of PAGES) {
    const p = await br.newPage();
    await p.setViewport({ width: 1440, height: 900 });
    const errs = [];
    p.on('pageerror', e => errs.push('pageerror: ' + e.message.slice(0, 100)));
    p.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text().slice(0, 100)); });
    await p.goto(B + '/' + file, { waitUntil: 'networkidle2', timeout: 60000 });
    await sleep(500);

    const a = await p.evaluate(() => {
      const R = {};
      R.title = document.title;
      R.titleLen = document.title.length;
      const md = document.querySelector('meta[name="description"]');
      R.descLen = md ? md.content.length : 0;
      R.canonical = !!document.querySelector('link[rel="canonical"]');
      R.h1 = document.querySelectorAll('h1').length;
      // heading order
      const hs = [...document.querySelectorAll('h1,h2,h3,h4')].map(e => +e.tagName[1]);
      let jump = null;
      for (let i = 1; i < hs.length; i++) if (hs[i] - hs[i - 1] > 1) { jump = `${hs[i - 1]}→${hs[i]}`; break; }
      R.headingJump = jump;
      // duplicate ids
      const ids = [...document.querySelectorAll('[id]')].map(e => e.id);
      R.dupIds = [...new Set(ids.filter((x, i) => ids.indexOf(x) !== i))];
      // broken anchors
      R.badAnchors = [...document.querySelectorAll('a[href^="#"]')].map(a => a.getAttribute('href'))
        .filter(h => h.length > 1 && !document.querySelector(h.replace('#', '#')));
      // generic link text
      const generic = ['xem chi tiết', 'tìm hiểu thêm', 'click here', 'ở đây', 'xem thêm'];
      R.genericLinks = [...document.querySelectorAll('a')].filter(a => generic.includes(a.innerText.trim().toLowerCase())).length;
      // links without text/aria-label
      R.emptyLinks = [...document.querySelectorAll('a')].filter(a => !a.innerText.trim() && !a.getAttribute('aria-label') && a.offsetParent).length;
      // buttons without accessible name
      R.emptyBtns = [...document.querySelectorAll('button')].filter(b => !b.innerText.trim() && !b.getAttribute('aria-label') && b.offsetParent).length;
      // inputs: autocomplete
      R.inputsNoAutocomplete = [...document.querySelectorAll('input[type="text"],input[type="tel"],input[type="email"]')]
        .filter(i => !i.getAttribute('autocomplete')).length;
      // inline styles count
      R.inlineStyles = document.querySelectorAll('[style]').length;
      // hardcoded hex in markup (not css)
      R.hexInDom = (document.documentElement.outerHTML.match(/#[0-9a-f]{6}/gi) || []).length;
      // tab order sanity: positive tabindex
      R.positiveTabindex = document.querySelectorAll('[tabindex]:not([tabindex="0"]):not([tabindex="-1"])').length;
      // touch targets < 40 at desktop (informational)
      R.landmarks = ['header', 'main', 'footer', 'nav'].filter(t => document.querySelector(t)).length;
      // preload/priority of LCP candidates
      R.imgs = document.querySelectorAll('img').length;
      R.lazyImgs = document.querySelectorAll('img[loading="lazy"]').length;
      return R;
    });

    // contrast of small text (<14px)
    const contrast = await p.evaluate(() => {
      const lum = c => {
        const m = (c.match(/\d+(\.\d+)?/g) || ['0', '0', '0']).slice(0, 3).map(Number).map(v => {
          v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
        });
        return 0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2];
      };
      const ratio = (x, y) => { const a = lum(x), b = lum(y); return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05); };
      const bad = [];
      document.querySelectorAll('p,span,li,dd,dt,time,small,a,label').forEach(el => {
        if (!el.offsetParent || el.children.length > 0) return;
        const t = (el.innerText || '').trim();
        if (t.length < 3) return;
        const s = getComputedStyle(el);
        const size = parseFloat(s.fontSize);
        if (size > 14) return;
        let bg = s.backgroundColor, n = el;
        while ((bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent') && n.parentElement) { n = n.parentElement; bg = getComputedStyle(n).backgroundColor; }
        if (bg === 'rgba(0, 0, 0, 0)') return;
        const r = ratio(s.color, bg);
        if (r < 4.5) bad.push(t.slice(0, 26) + ' → ' + r.toFixed(2));
      });
      return [...new Set(bad)].slice(0, 6);
    });

    out.push({ file, ...a, lowContrastSmall: contrast, errs: [...new Set(errs)] });
    await p.close();
  }

  // cross-page link check
  const p = await br.newPage();
  await p.goto(B + '/index.html', { waitUntil: 'networkidle2' });
  const hrefs = await p.evaluate(() => {
    const set = new Set();
    document.querySelectorAll('a[href]').forEach(a => {
      const h = a.getAttribute('href');
      if (h && !h.startsWith('http') && !h.startsWith('tel') && !h.startsWith('mailto') && !h.startsWith('#')) set.add(h);
    });
    return [...set];
  });
  const linkStatus = [];
  for (const h of hrefs) {
    const r = await p.goto(B + '/' + h.split('#')[0], { waitUntil: 'domcontentloaded' }).catch(() => null);
    if (!r || r.status() !== 200) linkStatus.push(`${h} → ${r ? r.status() : 'ERR'}`);
  }
  await p.close();

  console.log('=== PER-PAGE ===');
  for (const r of out) {
    console.log(`\n${r.file}`);
    console.log(`  title=${r.titleLen} desc=${r.descLen} canonical=${r.canonical} h1=${r.h1} landmark=${r.landmarks}/4`);
    console.log(`  headingJump=${r.headingJump || 'ok'} dupIds=${r.dupIds.length ? r.dupIds.join(',') : '0'} badAnchors=${r.badAnchors.length ? r.badAnchors.join(',') : '0'}`);
    console.log(`  genericLinks=${r.genericLinks} emptyLinks=${r.emptyLinks} emptyBtns=${r.emptyBtns} noAutocomplete=${r.inputsNoAutocomplete}`);
    console.log(`  inlineStyles=${r.inlineStyles} hexInDom=${r.hexInDom} positiveTabindex=${r.positiveTabindex} imgs=${r.imgs} lazy=${r.lazyImgs}`);
    console.log(`  lowContrastSmall=${r.lowContrastSmall.length ? r.lowContrastSmall.join(' | ') : 'none'}`);
    if (r.errs.length) console.log(`  ERRORS=${r.errs.join(' | ')}`);
  }
  console.log('\n=== CROSS-PAGE LINKS ===');
  console.log(linkStatus.length ? linkStatus.join('\n') : 'all internal links 200');

  fs.writeFileSync('C:/Users/DELL/Documents/qa-web-ban-hang/design/shots/review.json', JSON.stringify({ out, linkStatus }, null, 2));
  await br.close();
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
