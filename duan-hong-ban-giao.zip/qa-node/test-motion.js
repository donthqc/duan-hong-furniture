/**
 * Kiểm hiệu ứng động trên site đang chạy.
 *   node test-motion.js [http://127.0.0.1:8096]
 *
 * Kiểm cả 3 trạng thái: bật JS, tắt JS, và prefers-reduced-motion.
 */
const puppeteer = require('puppeteer');
const WEB = process.argv[2] || 'http://127.0.0.1:8096';

let pass = 0, fail = 0;
const ok = (n, c, d = '') => { console.log(`${c ? 'PASS' : 'FAIL'}  ${n}${d ? '  :: ' + d : ''}`); c ? pass++ : fail++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 120000 });

  /* ─────────── 1. JS bật: hiệu ứng phải chạy ─────────── */
  let page = await br.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message.slice(0, 90)));

  await page.goto(`${WEB}/trang-chu.html`, { waitUntil: 'networkidle2' });
  await sleep(1400);

  const s1 = await page.evaluate(() => {
    const root = document.documentElement;
    const hero = document.querySelector('h1.anim-up');
    const cs = hero ? getComputedStyle(hero) : null;
    return {
      motionClass: root.classList.contains('motion'),
      hasProgressBar: !!document.getElementById('dh-progress'),
      heroVisible: cs ? parseFloat(cs.opacity) : null,
      heroTransform: cs ? cs.transform : null,
      animCount: document.querySelectorAll('.anim-up').length,
      inCount: document.querySelectorAll('.anim-up.is-in').length,
      counterText: (document.querySelector('[data-count]') || {}).textContent || '',
      bytesLoaded: performance.getEntriesByType('resource')
        .filter(r => /motion\.(css|js)/.test(r.name)).length,
    };
  });

  ok('motion.css + motion.js được tải', s1.bytesLoaded === 2, `số file=${s1.bytesLoaded}`);
  ok('html có class "motion" (JS đã chạy)', s1.motionClass);
  ok('hero đã hiện (opacity=1)', s1.heroVisible === 1, String(s1.heroVisible));
  ok('có phần tử anim-up trên trang', s1.animCount > 0, String(s1.animCount));
  ok('phần tử trong màn hình đã is-in', s1.inCount > 0, `${s1.inCount}/${s1.animCount}`);
  ok('thanh tiến độ đọc trang tồn tại', s1.hasProgressBar);
  ok('bộ đếm số đã chạy (11%)', /11/.test(s1.counterText), s1.counterText);

  /* ─────────── 2. Cuộn xuống: phần tử dưới phải hiện dần ─────────── */
  const before = await page.evaluate(() => document.querySelectorAll('.anim-up.is-in').length);
  await page.evaluate(async () => {
    const step = window.innerHeight * 0.8;
    for (let y = 0; y < document.body.scrollHeight; y += step) {
      window.scrollTo(0, y);
      await new Promise((r) => setTimeout(r, 90));
    }
  });
  await sleep(900);
  const after = await page.evaluate(() => ({
    inCount: document.querySelectorAll('.anim-up.is-in').length,
    total: document.querySelectorAll('.anim-up').length,
    progress: (document.getElementById('dh-progress') || {}).style.width || '',
  }));
  ok('cuộn trang làm hiện thêm phần tử', after.inCount > before, `${before} → ${after.inCount}/${after.total}`);
  ok('thanh tiến độ chạy theo cuộn', parseFloat(after.progress) > 50, after.progress);

  /* ─────────── 3. Không nhảy layout (CLS) ─────────── */
  const cls = await page.evaluate(() => {
    return new Promise((resolve) => {
      let total = 0;
      try {
        new PerformanceObserver((list) => {
          for (const e of list.getEntries()) if (!e.hadRecentInput) total += e.value;
        }).observe({ type: 'layout-shift', buffered: true });
      } catch (e) { return resolve(-1); }
      setTimeout(() => resolve(total), 400);
    });
  });
  ok('layout shift thấp (< 0.1)', cls >= 0 && cls < 0.1, `CLS=${cls === -1 ? 'không đo được' : cls.toFixed(4)}`);

  /* ─────────── 4. Thẻ sản phẩm render từ API có hiệu ứng ─────────── */
  await page.evaluate(() => document.getElementById('san-pham').scrollIntoView({ block: 'center', behavior: 'instant' }));
  await sleep(1200);
  const cards = await page.evaluate(() => {
    const c = [...document.querySelectorAll('#catalog .prod')];
    return {
      n: c.length,
      withAnim: c.filter(x => x.classList.contains('anim-up')).length,
      shown: c.filter(x => x.classList.contains('is-in')).length,
      opacity: c.length ? getComputedStyle(c[0]).opacity : null,
    };
  });
  ok('thẻ sản phẩm có class anim-up', cards.n > 0 && cards.withAnim === cards.n, `${cards.withAnim}/${cards.n}`);
  ok('thẻ sản phẩm đã hiện sau khi render từ API', cards.shown === cards.n && cards.opacity === '1',
    `shown=${cards.shown}/${cards.n} opacity=${cards.opacity}`);

  /* ─────────── 5. Hover: thẻ nhấc lên ─────────── */
  const box = await page.evaluate(() => {
    const el = document.querySelector('#catalog .prod');
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { x: r.x + r.width / 2, y: r.y + r.height / 2 };
  });
  if (box) {
    await page.mouse.move(box.x, box.y);
    await sleep(400);
    const hovered = await page.evaluate(() => {
      const el = document.querySelector('#catalog .prod:hover');
      if (!el) return null;
      const cs = getComputedStyle(el);
      return { translate: cs.translate, scale: cs.scale, shadow: cs.boxShadow };
    });
    const lifted = hovered && ((hovered.translate && hovered.translate !== 'none') ||
                              (hovered.scale && hovered.scale !== 'none'));
    ok('hover thẻ sản phẩm → nhấc lên', !!lifted,
      hovered ? `translate=${hovered.translate} scale=${hovered.scale}` : 'không hover được');
  } else {
    ok('hover thẻ sản phẩm → có transform', false, 'không thấy thẻ');
  }

  ok('không lỗi JS khi chạy hiệu ứng', errs.length === 0, errs.slice(0, 2).join(' | ') || 'sạch');
  await page.close();

  /* ─────────── 6. prefers-reduced-motion: phải tắt sạch ─────────── */
  page = await br.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  await page.emulateMediaFeatures([{ name: 'prefers-reduced-motion', value: 'reduce' }]);
  await page.goto(`${WEB}/trang-chu.html`, { waitUntil: 'networkidle2' });
  await sleep(1200);

  const s3 = await page.evaluate(() => {
    const h1 = document.querySelector('h1.anim-up');
    const cs = h1 ? getComputedStyle(h1) : null;
    const hidden = [...document.querySelectorAll('.anim-up')].filter(e => getComputedStyle(e).opacity === '0').length;
    const counter = document.querySelector('[data-count]');
    return {
      opacity: cs ? cs.opacity : null,
      transition: cs ? cs.transitionDuration : null,
      hiddenCount: hidden,
      counterText: counter ? counter.textContent : '',
      progress: !!document.getElementById('dh-progress'),
      parallax: (document.querySelector('.anim-parallax') || {}).style?.transform || '',
    };
  });
  ok('giảm chuyển động: phần tử hiện ngay (không ẩn)', s3.hiddenCount === 0, `${s3.hiddenCount} phần tử bị ẩn`);
  ok('giảm chuyển động: không có transition', s3.transition === '0s' || s3.transition === null, String(s3.transition));
  ok('giảm chuyển động: bộ đếm hiện số cuối luôn', /11/.test(s3.counterText), s3.counterText);
  ok('giảm chuyển động: không tạo thanh tiến độ', s3.progress === false);
  ok('giảm chuyển động: không parallax', s3.parallax === '', s3.parallax || '(rỗng)');
  await page.close();

  /* ─────────── 7. Tắt JS: nội dung vẫn đọc được ─────────── */
  page = await br.newPage();
  await page.setJavaScriptEnabled(false);
  await page.goto(`${WEB}/trang-chu.html`, { waitUntil: 'domcontentloaded' });
  await sleep(400);
  const s4 = await page.evaluate(() => {
    const h1 = document.querySelector('h1');
    const cs = h1 ? getComputedStyle(h1) : null;
    return {
      h1Text: h1 ? h1.textContent.trim().slice(0, 40) : '',
      opacity: cs ? cs.opacity : null,
      hidden: [...document.querySelectorAll('.anim-up')].filter(e => getComputedStyle(e).opacity === '0').length,
    };
  });
  ok('tắt JS: h1 vẫn có chữ', s4.h1Text.length > 5, s4.h1Text);
  ok('tắt JS: không phần tử nào bị ẩn', s4.hidden === 0, `${s4.hidden} bị ẩn`);
  ok('tắt JS: h1 opacity = 1', s4.opacity === '1', String(s4.opacity));
  await page.close();

  await br.close();
  console.log(`\n${'='.repeat(56)}\nMOTION: ${pass} PASS / ${fail} FAIL\n${'='.repeat(56)}`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('FATAL', e.message); process.exit(1); });
