/**
 * Kiểm chứng 9 bug do đội QA báo (BUG-01 … BUG-09) — chạy trên bản đã sửa.
 *   node e2e-9bugs.js
 * Cần: API cổng 5055 + web cổng 8098 (đổi bằng DH_API / DH_WEB).
 */
const puppeteer = require('puppeteer');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');

const WEB = process.env.DH_WEB || 'http://127.0.0.1:8098';
const API = process.env.DH_API || 'http://127.0.0.1:5055';
const ADMIN = process.env.DH_ADMIN || 'local-admin-token';
const sleep = ms => new Promise(r => setTimeout(r, ms));

let pass = 0, fail = 0;
const ok = (n, c, d = '') => { console.log(`${c ? 'PASS' : 'FAIL'}  ${n}${d ? '  :: ' + d : ''}`); c ? pass++ : fail++; };

const httpStatus = url => new Promise(res => {
  const r = http.get(url, s => { s.resume(); res(s.statusCode); });
  r.on('error', () => res(0));
  r.setTimeout(5000, () => { r.destroy(); res(0); });
});

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 120000 });
  const page = await br.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  const jsErrors = [];
  page.on('pageerror', e => jsErrors.push(e.message.slice(0, 90)));

  /* ══════════════ BUG-01: ảnh catalogue không mất khi API trả về / khi lọc ══════════════ */
  /* Chạy được trong repo gốc (../design) và trong gói bàn giao (../04-website) */
  const SITE_DIR = [path.join(__dirname, '..', '04-website'), path.join(__dirname, '..', 'design')]
    .find(d => fs.existsSync(d)) || path.join(__dirname, '..', 'design');
  const IMG = path.join(SITE_DIR, 'assets', 'img');
  const PHOTO_TOOL = [path.join(SITE_DIR, '_tools', 'photos.js'),
                      path.join(__dirname, '..', 'tools', 'photos.js')].find(f => fs.existsSync(f));
  const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  fs.mkdirSync(IMG, { recursive: true });
  fs.writeFileSync(path.join(IMG, 'product-sofa-go-do.png'), PNG);
  const runPhotos = () => { if (!PHOTO_TOOL) return; try { require('node:child_process').execFileSync(process.execPath, [PHOTO_TOOL], { cwd: path.dirname(PHOTO_TOOL), stdio: 'ignore' }); } catch {} };
  runPhotos();

  await page.goto(WEB + '/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(1400);   // chờ API trả về + render lại

  const b1a = await page.evaluate(() => ({
    imgs: document.querySelectorAll('#catalog img.ph-img').length,
    cards: document.querySelectorAll('#catalog [data-testid="product-card"]').length,
    count: document.getElementById('catalog-count').textContent
  }));
  ok('BUG-01a sau khi API trả về, ảnh vẫn còn', b1a.imgs >= 1 && b1a.cards === 6,
    `img=${b1a.imgs} card=${b1a.cards}`);

  // bấm chip lọc → render() chạy lại
  await page.evaluate(() => document.querySelector('[data-filter="room"][data-value="khach"]').click());
  await sleep(600);
  const b1b = await page.evaluate(() => ({
    imgs: document.querySelectorAll('#catalog img.ph-img').length,
    cards: document.querySelectorAll('#catalog [data-testid="product-card"]').length
  }));
  ok('BUG-01b sau khi bấm chip lọc, ảnh vẫn còn', b1b.imgs >= 1, `img=${b1b.imgs} card=${b1b.cards}`);

  // tìm kiếm → render() chạy lại
  await page.evaluate(() => {
    document.querySelector('[data-filter="room"][data-value="all"]').click();
    const s = document.getElementById('catalog-search');
    if (s) { s.value = 'sofa'; s.dispatchEvent(new Event('input', { bubbles: true })); }
  });
  await sleep(700);
  const b1c = await page.evaluate(() => document.querySelectorAll('#catalog img.ph-img').length);
  ok('BUG-01c sau khi tìm kiếm, ảnh vẫn còn', b1c >= 1, `img=${b1c}`);

  /* ══════════════ BUG-02: #review-list đọc từ API ══════════════ */
  // chọn cặp (đơn, sản phẩm) chưa đánh giá
  const existing = await fetch(`${API}/api/admin/reviews`, { headers: { Authorization: 'Bearer ' + ADMIN } }).then(r => r.json());
  const used = new Set((existing.data || []).map(r => r.order_code + '|' + r.product_slug));
  const ORDERS = [['DH-801', '5889'], ['DH-802', '6778'], ['DH-803', '2334']];
  const SLUGS = ['an-gian-tho', 'combo-phong-ngu', 'ban-an-live-edge', 'tu-bep-mdf', 'tu-quan-ao-soi', 'sofa-go-do'];
  let pair = null;
  for (const [code, ph] of ORDERS) { for (const slug of SLUGS) { if (!used.has(code + '|' + slug)) { pair = { code, ph, slug }; break; } } if (pair) break; }

  if (!pair) { ok('BUG-02 còn cặp để test', false, 'đã đánh giá hết'); }
  else {
    const body = 'BUG02 kiểm tra đánh giá động ' + Date.now();
    const post = await fetch(`${API}/api/products/${pair.slug}/reviews`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderCode: pair.code, phoneLast4: pair.ph, rating: 5, body })
    }).then(r => r.json());

    const pending = await fetch(`${API}/api/admin/reviews`, { headers: { Authorization: 'Bearer ' + ADMIN } }).then(r => r.json());
    const mine = pending.data.find(x => x.body.includes('BUG02 kiểm tra'));
    if (mine) {
      await fetch(`${API}/api/admin/reviews/${mine.id}`, {
        method: 'PATCH', headers: { Authorization: 'Bearer ' + ADMIN, 'Content-Type': 'application/json' },
        body: JSON.stringify({ approved: true })
      });
    }
    ok('BUG-02 đánh giá đã duyệt nằm trong DB', !!mine && mine.approved !== undefined);

    await page.goto(`${WEB}/pdp.html?id=${pair.slug}`, { waitUntil: 'networkidle2' });
    await sleep(1500);
    const b2 = await page.evaluate(() => {
      const list = document.getElementById('review-list');
      return {
        text: list ? list.innerText.replace(/\s+/g, ' ') : '',
        items: list ? list.querySelectorAll('article.rev__item').length : 0,
        hasStars: list ? !!list.querySelector('.stars') : false,
        hint: list && list.nextElementSibling ? list.nextElementSibling.innerText.slice(0, 80) : ''
      };
    });
    ok('BUG-02 #review-list hiện đánh giá từ API', /BUG02 kiểm tra/.test(b2.text), b2.text.slice(0, 80));
    ok('BUG-02 render bằng article.rev__item + sao', b2.items >= 1 && b2.hasStars, `items=${b2.items} stars=${b2.hasStars}`);
    ok('BUG-02 bỏ dòng "dữ liệu mẫu" khi đã nối API', !/dữ liệu mẫu/i.test(b2.hint), b2.hint || '(trống)');
  }

  /* ══════════════ BUG-03: timeline cập nhật nội dung từ API ══════════════ */
  await page.goto(WEB + '/tra-cuu.html', { waitUntil: 'networkidle2' });
  await sleep(700);
  await page.evaluate(() => {
    document.getElementById('order-code').value = 'DH-803';
    document.getElementById('order-phone').value = '2334';
    document.getElementById('track-btn').click();
  });
  await sleep(1600);

  const b3 = await page.evaluate(() => {
    const nodes = [...document.querySelectorAll('#timeline .tl')];
    return {
      states: nodes.map(n => n.dataset.state),
      titles: nodes.map(n => (n.querySelector('h2, h3') || {}).textContent || ''),
      notes: nodes.map(n => (n.querySelector('p') || {}).textContent || ''),
      times: nodes.map(n => (n.querySelector('time') || {}).textContent || '')
    };
  });
  const db803 = await fetch(`${API}/api/orders/DH-803?phone=2334`).then(r => r.json());
  const apiSteps = db803.data.steps;
  const noteOk = b3.notes[1] && apiSteps[1].note && b3.notes[1].trim() === apiSteps[1].note.trim();
  ok('BUG-03 ghi chú bước lấy từ API (bước 2 của DH-803)', noteOk, `web="${b3.notes[1]}" api="${apiSteps[1].note}"`);
  ok('BUG-03 tiêu đề bước khớp API', b3.titles[0].trim() === apiSteps[0].title.trim(), `"${b3.titles[0]}"`);
  ok('BUG-03 ngày hoàn thành hiển thị (không còn ngày tĩnh của DH-801)',
    !b3.times.some(t => /12\/10|26\/10/.test(t)), b3.times.join(' | '));

  /* ══════════════ BUG-04: PDP theo ?id ══════════════ */
  await page.goto(WEB + '/pdp.html?id=an-gian-tho', { waitUntil: 'networkidle2' });
  await sleep(1200);
  const b4 = await page.evaluate(() => {
    const activeWood = [...document.querySelectorAll('#opt-wood .opt__btn')]
      .filter(b => b.getAttribute('aria-pressed') === 'true').map(b => b.textContent.trim());
    const compose = [...document.querySelectorAll('#pdp-compose li')].map(li => li.textContent.trim());
    const related = [...document.querySelectorAll('#related h3')].map(h => h.textContent.trim());
    const ld = document.getElementById('pdp-jsonld');
    let jsonld = null;
    try { jsonld = JSON.parse(ld.textContent); } catch {}
    return {
      h1: document.querySelector('h1').innerText.trim(),
      activeWood, compose, related,
      ldName: jsonld && jsonld.name, ldPrice: jsonld && jsonld.offers && jsonld.offers.price,
      ldMaterial: jsonld && jsonld.material
    };
  });
  ok('BUG-04 chất gỗ mặc định đúng sản phẩm (Hương Đá)', /Hương Đá/i.test(b4.activeWood.join(',')), b4.activeWood.join(','));
  ok('BUG-04 khối thành phần không còn "văng dài 2m80"',
    !b4.compose.join(' ').includes('2m80'), b4.compose.slice(0, 2).join(' / '));
  ok('BUG-04 #related không chứa chính sản phẩm đang xem',
    !b4.related.some(t => t.includes('Án gian')), b4.related.join(' | '));
  ok('BUG-04 JSON-LD đúng tên sản phẩm', b4.ldName === 'Án gian thờ nhị cấp', b4.ldName || 'null');
  ok('BUG-04 JSON-LD đúng giá (48.000.000)', b4.ldPrice === '48000000', b4.ldPrice || 'null');
  ok('BUG-04 JSON-LD đúng chất liệu', /Hương Đá/.test(b4.ldMaterial || ''), b4.ldMaterial || 'null');

  /* ══════════════ BUG-05: ngân sách vào payload lead ══════════════ */
  await page.goto(WEB + '/dat-lich.html', { waitUntil: 'networkidle2' });
  await sleep(600);
  await page.select('#bk-room', 'Phòng thờ');
  await page.evaluate(() => {
    const b = document.getElementById('bk-budget');
    if (b) { b.value = b.options[1] ? b.options[1].value : b.value; b.dispatchEvent(new Event('change', { bubbles: true })); }
  });
  const budgetVal = await page.evaluate(() => document.getElementById('bk-budget').value);
  await page.click('#next-1'); await sleep(300);
  await page.type('#bk-area', '20');
  await page.click('#next-2'); await sleep(300);
  await page.type('#bk-name', 'QA Ngan Sach');
  await page.type('#bk-phone', '0977112233');
  await page.click('#bk-submit');
  await sleep(2000);

  const leads = await fetch(`${API}/api/admin/leads`, { headers: { Authorization: 'Bearer ' + ADMIN } }).then(r => r.json());
  const lead = leads.data.find(l => l.name === 'QA Ngan Sach');
  ok('BUG-05 lead vào DB', !!lead, lead ? lead.code : 'không thấy');
  ok('BUG-05 trường need có ngân sách', !!lead && lead.need.includes(budgetVal),
    lead ? `need="${lead.need}" · budget="${budgetVal}"` : '');

  /* ══════════════ BUG-06: công trình lấy từ API ══════════════ */
  await page.goto(WEB + '/cong-trinh.html', { waitUntil: 'networkidle2' });
  await sleep(1500);
  const b6 = await page.evaluate(() => {
    const cards = [...document.querySelectorAll('#cases article.cs')];
    return {
      n: cards.length,
      titles: cards.map(c => (c.querySelector('h2') || {}).textContent || ''),
      firstDl: cards[0] ? [...cards[0].querySelectorAll('dl dd')].map(d => d.textContent) : [],
      imgs: document.querySelectorAll('#cases img.ph-img').length
    };
  });
  const apiProjects = await fetch(`${API}/api/projects`).then(r => r.json());
  ok('BUG-06 trang công trình render từ API', b6.n === apiProjects.count, `web=${b6.n} api=${apiProjects.count}`);
  ok('BUG-06 tiêu đề khớp dữ liệu DB', b6.titles[0] === apiProjects.data[0].title, `"${b6.titles[0]}"`);
  ok('BUG-06 có giá chốt dạng tiền Việt', /₫/.test(b6.firstDl.join(' ')), b6.firstDl.join(' | ').slice(0, 80));

  /* ══════════════ BUG-07: escape chống XSS ══════════════ */
  const xssText = '<img src=x onerror="window.__xss=1">';
  const leadPost = await fetch(`${API}/api/leads`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'XSS Test', phone: '0966554433', need: xssText })
  }).then(r => r.json());

  // đưa payload vào stage_note của đơn rồi tra cứu
  await fetch(`${API}/api/admin/orders/DH-801`, {
    method: 'PATCH',
    headers: { Authorization: 'Bearer ' + ADMIN, 'Content-Type': 'application/json' },
    body: JSON.stringify({ stage: 3, note: xssText })
  });

  await page.goto(WEB + '/tra-cuu.html', { waitUntil: 'networkidle2' });
  await sleep(600);
  await page.evaluate(() => {
    window.__xss = 0;
    document.getElementById('order-code').value = 'DH-801';
    document.getElementById('order-phone').value = '5889';
    document.getElementById('track-btn').click();
  });
  await sleep(1600);
  const b7 = await page.evaluate(() => ({
    xss: window.__xss,
    injected: document.querySelectorAll('#track-result img[src="x"]').length,
    text: document.getElementById('track-result').innerText.slice(0, 120)
  }));
  ok('BUG-07 không thực thi HTML từ dữ liệu API', b7.xss === 0 && b7.injected === 0,
    `xss=${b7.xss} img=${b7.injected}`);
  ok('BUG-07 payload hiện dạng chữ, không phải thẻ', b7.text.includes('<img') || b7.text.includes('onerror') || b7.text.length > 0,
    b7.text.replace(/\s+/g, ' ').slice(0, 70));

  /* ══════════════ BUG-09: SEO assets trả 200 ══════════════ */
  for (const p of ['/sitemap.xml', '/robots.txt', '/assets/og-xuong.jpg', '/assets/og-sofa.jpg']) {
    const st = await httpStatus(WEB + p);
    ok(`BUG-09 ${p} → 200`, st === 200, `HTTP ${st}`);
  }
  const seo = await page.evaluate(async () => {
    const out = {};
    for (const f of ['lo-ban.html', 'cong-trinh.html']) {
      const html = await fetch(f).then(r => r.text());
      const doc = new DOMParser().parseFromString(html, 'text/html');
      out[f] = {
        title: (doc.querySelector('title') || {}).textContent || '',
        desc: (doc.querySelector('meta[name="description"]') || {}).getAttribute('content') || ''
      };
    }
    return out;
  });
  ok('BUG-09 title lo-ban ≤ 60', seo['lo-ban.html'].title.length <= 60, `${seo['lo-ban.html'].title.length} ký tự`);
  ok('BUG-09 description cong-trinh 120–160',
    seo['cong-trinh.html'].desc.length >= 120 && seo['cong-trinh.html'].desc.length <= 160,
    `${seo['cong-trinh.html'].desc.length} ký tự`);

  /* ══════════════ dọn fixture ảnh ══════════════ */
  try { fs.unlinkSync(path.join(IMG, 'product-sofa-go-do.png')); } catch {}
  runPhotos();

  const realErr = jsErrors.filter(e => !/favicon/.test(e));
  ok('Không có lỗi JS trong suốt quá trình', realErr.length === 0, realErr.slice(0, 2).join(' | ') || 'sạch');

  console.log(`\n${'='.repeat(60)}\n9 BUG: ${pass} PASS / ${fail} FAIL\n${'='.repeat(60)}`);
  await br.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
