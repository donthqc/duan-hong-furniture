const puppeteer = require('puppeteer');
const fs = require('fs');
const OUT = 'C:/Users/DELL/Documents/qa-web-ban-hang/design/shots/';
fs.mkdirSync(OUT, { recursive: true });
const B = 'http://127.0.0.1:8098';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const res = [];
const rec = (id, s, d) => { res.push({ id, s, d }); console.log(`[${s}] ${id} :: ${d}`); };

const lum = c => {
  const m = (c.match(/\d+(\.\d+)?/g) || ['0','0','0']).slice(0,3).map(Number).map(v => { v/=255; return v<=0.03928? v/12.92 : Math.pow((v+0.055)/1.055,2.4); });
  return 0.2126*m[0]+0.7152*m[1]+0.0722*m[2];
};
const ratio = (a,b) => { const l1=lum(a), l2=lum(b); return +(((Math.max(l1,l2)+0.05)/(Math.min(l1,l2)+0.05)).toFixed(2)); };

(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 180000 });
  const errors = [];
  const mk = async (w, h, mobile=false) => {
    const p = await browser.newPage();
    await p.setViewport({ width: w, height: h, isMobile: mobile, hasTouch: mobile, deviceScaleFactor: 1 });
    p.on('pageerror', e => errors.push('pageerror: ' + e.message.slice(0, 140)));
    p.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/i.test(m.text())) errors.push('console: ' + m.text().slice(0, 140)); });
    // ghi rõ URL tài nguyên trả >=400 để không phải đoán "Failed to load resource" là gì
    // (bỏ qua 404 của /api/orders: đây là ca âm cố ý — tra cứu sai 4 số điện thoại)
    p.on('response', r => { if (r.status() >= 400 && !/\/api\/orders\//.test(r.url())) errors.push('HTTP ' + r.status() + ' ' + r.url().slice(0, 140)); });
    return p;
  };

  // ---------- HOME 1440 ----------
  const p = await mk(1440, 900);
  const t0 = Date.now();
  await p.goto(B + '/trang-chu.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await sleep(900);
  const loadMs = Date.now() - t0;
  await p.screenshot({ path: OUT + 'home-1440.png' });
  await p.screenshot({ path: OUT + 'home-1440-full.png', fullPage: true });

  const hero = await p.evaluate(() => ({
    h1: document.querySelector('h1')?.innerText.replace(/\s+/g, ' '),
    ctaInView: (() => { const b = document.querySelector('[data-testid="hero-cta-primary"]'); const r = b.getBoundingClientRect(); return r.top < innerHeight && r.bottom > 0; })(),
    cards: document.querySelectorAll('#catalog [data-testid="product-card"]').length,
    h1count: document.querySelectorAll('h1').length,
    lang: document.documentElement.lang
  }));
  rec('H1', hero.h1 && hero.ctaInView ? 'PASS' : 'FAIL', `h1="${hero.h1}" · CTA trong màn hình đầu=${hero.ctaInView} · ${hero.cards} thẻ SP · lang=${hero.lang}`);

  // ---------- Lọc catalogue + URL state ----------
  await p.click('[data-filter="room"][data-value="ngu"]');
  await sleep(400);
  const f1 = await p.evaluate(() => ({
    n: document.querySelectorAll('#catalog [data-testid="product-card"]').length,
    url: location.search,
    count: document.getElementById('catalog-count').textContent
  }));
  await p.click('[data-filter="wood"][data-value="mdf"]');
  await sleep(400);
  const f2 = await p.evaluate(() => ({
    n: document.querySelectorAll('#catalog [data-testid="product-card"]').length,
    url: location.search,
    empty: !!document.querySelector('[data-testid="catalog-empty"]')
  }));
  rec('FILTER', f1.n === 2 && f2.empty ? 'PASS' : 'FAIL', `ngu→${f1.n} thẻ, url="${f1.url}" | +mdf→${f2.n} thẻ, empty state=${f2.empty}, url="${f2.url}"`);

  // deep link
  const pDeep = await mk(1440, 900);
  await pDeep.goto(B + '/trang-chu.html?he=tho&go=huong-da', { waitUntil: 'networkidle2' });
  await sleep(600);
  const deep = await pDeep.evaluate(() => ({
    n: document.querySelectorAll('#catalog [data-testid="product-card"]').length,
    pressed: [...document.querySelectorAll('.chip[aria-pressed="true"]')].map(c => c.dataset.value)
  }));
  rec('DEEPLINK', deep.n === 1 ? 'PASS' : 'FAIL', `?he=tho&go=huong-da → ${deep.n} thẻ, chip active=${deep.pressed.join(',')}`);
  await pDeep.close();

  // ---------- Estimator ----------
  await p.evaluate(() => { const a = document.getElementById('est-area'); a.value = 30; a.dispatchEvent(new Event('input', { bubbles: true })); });
  await sleep(200);
  const e1 = await p.evaluate(() => document.getElementById('est-result').textContent);
  await p.select('#est-wood', 'go-do');
  await sleep(200);
  const e2 = await p.evaluate(() => document.getElementById('est-result').textContent);
  rec('ESTIMATOR', e1.includes('₫') && e2 !== e1 ? 'PASS' : 'FAIL', `30m² sồi Nga: ${e1} | gõ đỏ: ${e2}`);

  // ---------- Tracker ----------
  await p.type('#order-code', 'DH-801');
  await p.type('#order-phone', '0000');
  await p.click('#track-btn');
  await sleep(300);
  const t1 = await p.evaluate(() => document.getElementById('track-result').innerText.replace(/\s+/g, ' ').slice(0, 80));
  await p.evaluate(() => { document.getElementById('order-phone').value = '5889'; });
  await p.click('#track-btn');
  await sleep(300);
  const t2 = await p.evaluate(() => ({
    txt: document.getElementById('track-result').innerText.replace(/\s+/g, ' ').slice(0, 100),
    steps: [...document.querySelectorAll('#timeline .tl')].map(e => e.dataset.state),
    url: location.search
  }));
  rec('TRACKER', t1.includes('Không tìm thấy') && t2.txt.includes('3/5') ? 'PASS' : 'FAIL',
     `sai SĐT→"${t1}" | đúng→"${t2.txt}" | timeline=${t2.steps.join('>')} | url=${t2.url}`);

  // ---------- Form validation ----------
  await p.evaluate(() => { document.getElementById('lead-name').value = ''; document.getElementById('lead-phone').value = '123'; });
  await p.click('#lead-submit');
  await sleep(400);
  const v1 = await p.evaluate(() => ({
    nameErr: document.getElementById('lead-name-err').textContent,
    phoneErr: document.getElementById('lead-phone-err').textContent,
    invalid: document.querySelectorAll('[aria-invalid="true"]').length,
    focused: document.activeElement.id
  }));
  await p.evaluate(() => { document.getElementById('lead-name').value = 'Nguyễn Văn An'; document.getElementById('lead-phone').value = '0901234567'; });
  await p.click('#lead-submit');
  await sleep(1200);
  const v2 = await p.evaluate(() => ({
    txt: document.getElementById('lead-result').innerText.replace(/\s+/g, ' ').slice(0, 60),
    shown: document.getElementById('lead-result').classList.contains('is-on'),
    cleared: document.getElementById('lead-name').value === ''
  }));
  rec('FORM', v1.invalid === 2 && v2.shown ? 'PASS' : 'FAIL',
     `rỗng→${v1.invalid} lỗi, focus=${v1.focused}, nameErr="${v1.nameErr.slice(0,40)}" | hợp lệ→"${v2.txt}"`);

  // ---------- Contrast ----------
  const contrast = await p.evaluate(() => {
    const pick = sel => {
      const e = document.querySelector(sel); if (!e) return null;
      const s = getComputedStyle(e); let bg = s.backgroundColor, n = e;
      while ((bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent') && n.parentElement) { n = n.parentElement; bg = getComputedStyle(n).backgroundColor; }
      return { fg: s.color, bg, size: parseFloat(s.fontSize) };
    };
    return {
      heroLead: pick('.hero__lead'), heroProof: pick('.hero__proof span'),
      body: pick('.sec-head p'), commitP: pick('.commit__item p'),
      chip: pick('.chip'), btnPrimary: pick('.btn--primary'), price: pick('#pdp-price, .prod__price')
    };
  });
  const lows = [];
  for (const k in contrast) {
    if (!contrast[k]) continue;
    const r = ratio(contrast[k].fg, contrast[k].bg);
    if (r < 4.5) lows.push(`${k}=${r}:1`);
  }
  rec('CONTRAST', lows.length === 0 ? 'PASS' : 'FAIL', lows.length ? 'dưới 4.5:1 → ' + lows.join(', ') : 'toàn bộ text ≥ 4.5:1');

  // ---------- Overflow @ 4 widths ----------
  for (const w of [375, 768, 1024, 1440]) {
    const q = await mk(w, 900, w < 700);
    await q.goto(B + '/trang-chu.html', { waitUntil: 'networkidle2', timeout: 60000 });
    await sleep(500);
    const o = await q.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    rec('OVERFLOW-' + w, o.sw <= o.cw + 1 ? 'PASS' : 'FAIL', `${o.sw} vs ${o.cw}`);
    if (w === 375) await q.screenshot({ path: OUT + 'home-375.png', fullPage: false });
    if (w === 768) await q.screenshot({ path: OUT + 'home-768.png' });
    await q.close();
  }

  // ---------- PDP ----------
  const d = await mk(1440, 900);
  await d.goto(B + '/pdp.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await sleep(700);
  await d.screenshot({ path: OUT + 'pdp-1440.png' });
  await d.screenshot({ path: OUT + 'pdp-1440-full.png', fullPage: true });
  const d0 = await d.evaluate(() => ({
    price: document.getElementById('pdp-price').innerText.split('\n')[0],
    notes: document.getElementById('pdp-price-note').textContent,
    h1: document.querySelectorAll('h1').length
  }));
  // change config to "Bộ 3 món"
  await d.evaluate(() => [...document.querySelectorAll('#opt-config .opt__btn')][1].click());
  await sleep(200);
  const d1 = await d.evaluate(() => document.getElementById('pdp-price').innerText.split('\n')[0]);
  rec('PDP-VARIANT', d0.price.includes('74.500.000') && d1.includes('Báo giá') ? 'PASS' : 'FAIL', `mặc định="${d0.price}" → bộ 3 món="${d1}" (h1=${d0.h1})`);

  // loban
  await d.evaluate(() => { const i = document.getElementById('lb-cm'); i.value = 280; i.dispatchEvent(new Event('input', { bubbles: true })); });
  await sleep(200);
  const lb = await d.evaluate(() => document.getElementById('lb-out').innerText.replace(/\s+/g, ' '));
  rec('PDP-LOBAN', lb.length > 10 ? 'PASS' : 'FAIL', `280cm → ${lb.slice(0, 90)}`);

  // tabs keyboard
  await d.focus('#tab-1');
  await d.keyboard.press('ArrowRight');
  await sleep(200);
  const tabState = await d.evaluate(() => ({
    sel: document.querySelector('[role="tab"][aria-selected="true"]').id,
    visible: [...document.querySelectorAll('[role="tabpanel"]')].filter(p => !p.hidden).map(p => p.id)
  }));
  rec('PDP-TABS', tabState.sel === 'tab-2' && tabState.visible[0] === 'panel-2' ? 'PASS' : 'FAIL', `ArrowRight → ${tabState.sel}, panel=${tabState.visible.join(',')}`);

  const dOv = await d.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  rec('PDP-OVERFLOW', dOv.sw <= dOv.cw + 1 ? 'PASS' : 'FAIL', `${dOv.sw} vs ${dOv.cw}`);

  // ---------- a11y basics ----------
  const a11y = await d.evaluate(() => ({
    imgsNoAlt: [...document.images].filter(i => !i.hasAttribute('alt')).length,
    inputsNoLabel: [...document.querySelectorAll('input,select,textarea')].filter(i => {
      if (i.type === 'hidden') return false;
      return !(i.id && document.querySelector(`label[for="${i.id}"]`)) && !i.getAttribute('aria-label');
    }).length,
    headings: [...document.querySelectorAll('h1,h2,h3')].map(h => h.tagName).join(''),
    landmarks: ['header','main','footer','nav'].filter(t => document.querySelector(t)).length
  }));
  rec('A11Y', a11y.imgsNoAlt === 0 && a11y.inputsNoLabel === 0 && a11y.landmarks === 4 ? 'PASS' : 'FAIL',
     `ảnh thiếu alt=${a11y.imgsNoAlt}, input thiếu label=${a11y.inputsNoLabel}, landmarks=${a11y.landmarks}/4`);

  // ---------- tap targets mobile ----------
  const m = await mk(375, 812, true);
  await m.goto(B + '/trang-chu.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await sleep(500);
  const taps = await m.evaluate(() => {
    const els = [...document.querySelectorAll('a,button,input,select')].filter(e => e.offsetParent);
    const small = els.filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && (r.height < 40); });
    return { total: els.length, small: small.length, samples: small.slice(0, 4).map(e => (e.innerText || e.tagName).slice(0, 22)) };
  });
  rec('TAP-375', taps.small === 0 ? 'PASS' : 'FAIL', `${taps.small}/${taps.total} phần tử < 40px: ${taps.samples.join(' | ')}`);

  // ---------- total page weight ----------
  const sizes = await p.evaluate(async () => {
    const r = performance.getEntriesByType('resource').map(x => ({ n: x.name.split('/').pop(), s: x.transferSize || 0 }));
    return r.sort((a, b) => b.s - a.s).slice(0, 5);
  });
  rec('WEIGHT', sizes.reduce((a, c) => a + c.s, 0) < 900000 ? 'PASS' : 'WARN',
     'top: ' + sizes.map(x => `${x.n}=${Math.round(x.s/1024)}KB`).join(', '));

  rec('CONSOLE', errors.length === 0 ? 'PASS' : 'FAIL', errors.length ? [...new Set(errors)].slice(0, 4).join(' || ') : 'không có lỗi');
  rec('LOAD', loadMs < 2500 ? 'PASS' : 'WARN', `${loadMs}ms (localhost, chưa tính mạng 4G)`);

  fs.writeFileSync(OUT + 'results.json', JSON.stringify({ res, errors: [...new Set(errors)] }, null, 2));
  const c = res.reduce((a, r) => (a[r.s] = (a[r.s] || 0) + 1, a), {});
  console.log('\nSUMMARY', JSON.stringify(c));
  await browser.close();
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
