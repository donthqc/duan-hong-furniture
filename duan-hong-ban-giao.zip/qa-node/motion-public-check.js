// Kiểm tra bản xem trước công khai mà không ép cấu hình API.
const puppeteer = require('puppeteer');
(async()=>{
 const b=await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:180000});
 const p=await b.newPage(); const errors=[]; p.on('pageerror',e=>errors.push(e.message));
 const r=await p.goto('https://democrat-fold-bedrooms-drink.trycloudflare.com/trang-chu.html',{waitUntil:'networkidle2',timeout:60000});
 await new Promise(x=>setTimeout(x,2000));
 const d=await p.evaluate(()=>({motion:!!window.DH_MOTION,hero:getComputedStyle(document.querySelector('h1')).opacity,apiBase:window.DH_API?.base,catalog:document.querySelector('#catalog-count')?.textContent,banner:!!document.querySelector('#dh-demo-banner')}));
 console.log(JSON.stringify({http:r.status(),...d,errors})); await b.close();
 if(r.status()!==200 || !d.motion || d.hero!=='1'||errors.length) process.exitCode=1;
})().catch(e=>{console.error(e.message);process.exitCode=1});
