const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const OUT = 'C:\\Users\\DELL\\Documents\\qa-web-ban-hang\\evidence';
fs.mkdirSync(OUT, { recursive: true });
const BASE = 'http://127.0.0.1:8099';
const results = [];
function rec(id, title, status, detail) {
  results.push({ id, title, status, detail });
  console.log(`[${status}] ${id} ${title} :: ${detail}`);
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage']
  });
  const page = await browser.newPage();
  const consoleErrors = [];
  page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 200)); });
  page.on('pageerror', e => consoleErrors.push('pageerror: ' + e.message.slice(0, 200)));
  page.on('requestfailed', r => consoleErrors.push('reqfail: ' + r.url().slice(0, 120)));
  await page.setViewport({ width: 1440, height: 900 });

  // ---------- Home page ----------
  const t0 = Date.now();
  const resp = await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(1200);
  const loadMs = Date.now() - t0;
  await page.screenshot({ path: path.join(OUT, '01-home.png'), fullPage: false });

  const home = await page.evaluate(() => ({
    title: document.title,
    lang: document.documentElement.lang,
    viewport: !!document.querySelector('meta[name=viewport]'),
    h1: [...document.querySelectorAll('h1')].map(e => e.innerText.trim()),
    headings: [...document.querySelectorAll('h1,h2')].slice(0, 12).map(e => e.tagName + ':' + e.innerText.trim().slice(0, 50)),
    imgs: document.images.length,
    brokenImgs: [...document.images].filter(i => i.complete && i.naturalWidth === 0).map(i => i.src.slice(0, 100)),
    noAlt: [...document.images].filter(i => !i.alt || !i.alt.trim()).length,
    links: document.querySelectorAll('a[href]').length,
    extLinks: [...document.querySelectorAll('a[href^=http]')].map(a => a.href).filter(h => !h.includes('127.0.0.1')).slice(0, 8),
    bodyText: document.body.innerText.slice(0, 300),
    docHeight: document.documentElement.scrollHeight
  }));
  rec('TC-A01', 'Trang chủ hiển thị đủ thành phần', resp.status() === 200 && home.h1.length > 0 ? 'PASS' : 'FAIL', `status=${resp.status()} load=${loadMs}ms imgs=${home.imgs} broken=${home.brokenImgs.length} h1=${JSON.stringify(home.h1)}`);
  rec('TC-L08a', 'Alt text ảnh', home.noAlt === 0 ? 'PASS' : 'FAIL', `${home.noAlt}/${home.imgs} ảnh thiếu alt`);
  rec('TC-C06a', 'Meta SEO trang chủ', (home.title.length > 10 ? 'PASS' : 'FAIL'), `title="${home.title}" lang="${home.lang}" viewport=${home.viewport}`);
  if (home.brokenImgs.length) rec('TC-A01b', 'Ảnh bị vỡ', 'FAIL', home.brokenImgs.slice(0, 5).join(' | '));

  // horizontal scroll at mobile
  const mobile = await browser.newPage();
  await mobile.setViewport({ width: 375, height: 812, isMobile: true, hasTouch: true });
  await mobile.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(800);
  const mob = await mobile.evaluate(() => ({
    scrollW: document.documentElement.scrollWidth,
    clientW: document.documentElement.clientWidth,
    smallTaps: [...document.querySelectorAll('a,button')].filter(e => {
      const r = e.getBoundingClientRect();
      return r.width > 0 && (r.width < 32 || r.height < 32);
    }).length,
    stickyBars: [...document.querySelectorAll('*')].filter(e => {
      const s = getComputedStyle(e);
      return s.position === 'fixed' && e.getBoundingClientRect().height > 50;
    }).length
  }));
  await mobile.screenshot({ path: path.join(OUT, '02-home-mobile.png') });
  rec('TC-L07', 'Responsive 375px không tràn ngang', mob.scrollW <= mob.clientW + 2 ? 'PASS' : 'FAIL', `scrollW=${mob.scrollW} clientW=${mob.clientW} tapTarget<32px=${mob.smallTaps} fixedBars=${mob.stickyBars}`);

  // 768 / 1024
  for (const w of [768, 1024]) {
    const p2 = await browser.newPage();
    await p2.setViewport({ width: w, height: 900 });
    await p2.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 45000 });
    await sleep(500);
    const o = await p2.evaluate(() => ({ s: document.documentElement.scrollWidth, c: document.documentElement.clientWidth }));
    rec('TC-L07-' + w, `Responsive ${w}px`, o.s <= o.c + 2 ? 'PASS' : 'FAIL', `scrollW=${o.s} clientW=${o.c}`);
    await p2.close();
  }

  // ---------- Navigation / links ----------
  const nav = await page.evaluate(() => [...document.querySelectorAll('a[href]')]
    .map(a => ({ text: a.innerText.trim().slice(0, 40), href: a.getAttribute('href') }))
    .filter(x => x.href && !x.href.startsWith('#') && !x.href.startsWith('javascript'))
    .slice(0, 60));
  const internal = nav.filter(n => !n.href.startsWith('http'));
  const checked = [];
  for (const n of internal.slice(0, 25)) {
    try {
      const u = new URL(n.href, BASE).href;
      const r = await page.evaluate(async (url) => {
        try { const x = await fetch(url, { method: 'GET' }); return x.status; } catch (e) { return 'ERR'; }
      }, u);
      checked.push(`${r} ${n.href}`);
    } catch (e) { checked.push('ERR ' + n.href); }
  }
  const bad = checked.filter(c => !c.startsWith('200') && !c.startsWith('30'));
  rec('TC-A04', 'Link nội bộ không chết', bad.length === 0 ? 'PASS' : 'FAIL', `${bad.length}/${checked.length} lỗi: ${bad.slice(0, 6).join(' | ')}`);

  // ---------- Product listing / search ----------
  await page.goto(BASE + '/product.html', { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(1500);
  await page.screenshot({ path: path.join(OUT, '03-product.png'), fullPage: false });
  const plp = await page.evaluate(() => ({
    title: document.title,
    cards: document.querySelectorAll('[data-product-id], .product-card').length,
    text: document.body.innerText.slice(0, 400),
    searchInput: !!document.querySelector('input[type=search], input[placeholder*=Tìm], input[placeholder*=tìm]'),
    error: document.body.innerText.includes('localhost') ? 'HAS_LOCALHOST_TEXT' : ''
  }));
  rec('TC-B/PLP', 'Trang sản phẩm tải được', plp.cards > 0 || plp.text.length > 100 ? 'PASS' : 'FAIL', `cards=${plp.cards} search=${plp.searchInput}`);

  // search behaviour
  const si = await page.$('input[type=search], input[placeholder*=Tìm], input[placeholder*=tìm]');
  if (si) {
    await si.click({ clickCount: 3 });
    await si.type('sofa', { delay: 40 });
    await page.keyboard.press('Enter');
    await sleep(1500);
    const after = await page.evaluate(() => ({ n: document.querySelectorAll('[data-product-id], .product-card').length, t: document.body.innerText.slice(0, 200) }));
    rec('TC-B01', 'Tìm kiếm "sofa"', after.n > 0 ? 'PASS' : 'FAIL', `cards=${after.n}`);
    await page.screenshot({ path: path.join(OUT, '04-search-sofa.png') });

    await si.click({ clickCount: 3 });
    await si.type('xyzabc123', { delay: 20 });
    await page.keyboard.press('Enter');
    await sleep(1200);
    const empty = await page.evaluate(() => ({ n: document.querySelectorAll('[data-product-id], .product-card').length, t: document.body.innerText.toLowerCase() }));
    rec('TC-B04', 'Tìm không kết quả → empty state', empty.n === 0 && (empty.t.includes('không tìm') || empty.t.includes('không có')) ? 'PASS' : (empty.n === 0 ? 'WARN' : 'FAIL'), `cards=${empty.n} hasEmptyMsg=${empty.t.includes('không tìm') || empty.t.includes('không có')}`);
    await page.screenshot({ path: path.join(OUT, '05-search-empty.png') });
  }

  // ---------- Product detail ----------
  const firstCard = await page.$('a[href*="product-detail"], a[href*="?id="], [data-product-id] a');
  if (firstCard) {
    await firstCard.click();
    await sleep(1800);
    const pdp = await page.evaluate(() => ({
      url: location.href, title: document.title,
      h1: [...document.querySelectorAll('h1')].map(e => e.innerText.trim()),
      price: (document.body.innerText.match(/[\d\.]{7,}\s*(đ|₫|VND)/) || [''])[0],
      canonical: (document.querySelector('link[rel=canonical]') || {}).href || '',
      og: !!document.querySelector('meta[property="og:image"]'),
      addBtn: !!([...document.querySelectorAll('button')].find(b => /giỏ|mua/i.test(b.innerText)))
    }));
    rec('TC-C01', 'PDP hiển thị thông tin', pdp.h1.length > 0 && pdp.price ? 'PASS' : 'FAIL', `url=${pdp.url.slice(-60)} h1=${JSON.stringify(pdp.h1)} price=${pdp.price} addBtn=${pdp.addBtn} og=${pdp.og}`);
    rec('TC-C06', 'PDP canonical/OG', pdp.canonical ? 'PASS' : 'FAIL', `canonical="${pdp.canonical}"`);
    await page.screenshot({ path: path.join(OUT, '06-pdp.png'), fullPage: false });

    // add to cart
    const addBtn = await page.$$('button');
    let clicked = false;
    for (const b of addBtn) {
      const txt = await page.evaluate(el => el.innerText, b);
      if (/thêm vào giỏ|mua ngay/i.test(txt)) { await b.click(); clicked = true; break; }
    }
    await sleep(1500);
    const cartState = await page.evaluate(() => ({
      ls: Object.keys(localStorage).filter(k => /cart|gio/i.test(k)).map(k => k + '=' + localStorage.getItem(k).slice(0, 80)),
      body: document.body.innerText.slice(0, 200)
    }));
    rec('TC-D01', 'Thêm vào giỏ (khách)', clicked && cartState.ls.length > 0 ? 'PASS' : (clicked ? 'WARN' : 'FAIL'), `clicked=${clicked} ls=${cartState.ls.join(' ; ').slice(0, 160)}`);
    await page.screenshot({ path: path.join(OUT, '07-add-to-cart.png') });
  } else {
    rec('TC-C01', 'PDP mở được từ danh sách', 'BLOCKED', 'Không tìm thấy link tới trang chi tiết');
  }

  // ---------- CMS login ----------
  const cms = await browser.newPage();
  const cmsErr = [];
  cms.on('console', m => { if (m.type() === 'error') cmsErr.push(m.text().slice(0, 160)); });
  await cms.setViewport({ width: 1440, height: 900 });
  await cms.goto(BASE + '/cms_duan_hong.html', { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(1200);
  await cms.screenshot({ path: path.join(OUT, '08-cms-login.png') });
  const cmsBefore = await cms.evaluate(() => ({
    loginVisible: !!document.getElementById('admin-login-screen') && !document.getElementById('admin-login-screen').classList.contains('hidden'),
    pwdPrefill: (document.getElementById('cms-login-password') || {}).value,
    demoHints: document.body.innerText.match(/admin123|demo/gi),
    anyLocalStorage: Object.keys(localStorage).length
  }));
  rec('TC-J01a', 'CMS yêu cầu đăng nhập', cmsBefore.loginVisible ? 'PASS' : 'FAIL', `loginScreen=${cmsBefore.loginVisible} pwdPrefill="${cmsBefore.pwdPrefill}"`);
  rec('TC-E-warn', 'Mật khẩu mặc định điền sẵn', cmsBefore.pwdPrefill ? 'FAIL' : 'PASS', `value="${cmsBefore.pwdPrefill}"`);

  // try BAD credentials -> should be rejected
  await cms.evaluate(() => {
    document.getElementById('cms-login-identifier').value = 'attacker' + Math.random().toString(36).slice(2, 6) + '@evil.com';
    document.getElementById('cms-login-password').value = 'zzz9';
  });
  await cms.evaluate(() => document.getElementById('cms-login-form').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true })));
  await sleep(3000);
  const badLogin = await cms.evaluate(() => ({
    loginVisible: !!document.getElementById('admin-login-screen') && !document.getElementById('admin-login-screen').classList.contains('hidden'),
    token: localStorage.getItem('dh_cms_token') || localStorage.getItem('cms_token') || JSON.stringify(Object.keys(localStorage).filter(k => /token|auth|user/i.test(k))),
    dashVisible: !!document.querySelector('#admin-dashboard, #cms-dashboard, main')
  }));
  await cms.screenshot({ path: path.join(OUT, '09-cms-badlogin.png') });
  rec('TC-E-bypass', 'CMS chặn sai mật khẩu', badLogin.loginVisible ? 'PASS' : 'FAIL', `loginScreenAfter=${badLogin.loginVisible} keys=${badLogin.token}`);

  // reload -> does session persist / can we reach admin without login?
  await cms.reload({ waitUntil: 'networkidle2' });
  await sleep(1500);
  const afterReload = await cms.evaluate(() => ({
    loginVisible: !!document.getElementById('admin-login-screen') && !document.getElementById('admin-login-screen').classList.contains('hidden')
  }));
  rec('TC-E-session', 'Session sau reload', afterReload.loginVisible ? 'PASS' : 'FAIL', `loginScreen=${afterReload.loginVisible}`);

  // ---------- Form validation on home (lead form) ----------
  await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 45000 });
  await sleep(1000);
  const forms = await page.evaluate(() => [...document.querySelectorAll('form')].map((f, i) => ({
    i, id: f.id, inputs: [...f.querySelectorAll('input,textarea,select')].map(x => x.name || x.id || x.type)
  })));
  const leadForm = forms.find(f => f.inputs.some(n => /phone|tel|sdt/i.test(n)));
  if (leadForm) {
    await page.evaluate(() => {
      const f = [...document.querySelectorAll('form')].find(f => [...f.querySelectorAll('input,textarea,select')].some(x => /phone|tel|sdt/i.test(x.name || x.id || x.type)));
      f.querySelectorAll('input,textarea').forEach(el => { el.value = ''; });
    });
    const submitBtn = await page.evaluate(() => {
      const f = [...document.querySelectorAll('form')].find(f => [...f.querySelectorAll('input,textarea,select')].some(x => /phone|tel|sdt/i.test(x.name || x.id || x.type)));
      const b = f.querySelector('button[type=submit], button');
      if (b) { b.click(); return b.innerText; }
      return null;
    });
    await sleep(1200);
    const vres = await page.evaluate(() => {
      const inv = [...document.querySelectorAll('input')].filter(i => i.required && !i.value).length;
      return { bodyHasError: /vui lòng|bắt buộc|không hợp lệ/i.test(document.body.innerText), invalidRequired: inv };
    });
    rec('TC-F09', 'Validate form thiếu dữ liệu', vres.bodyHasError || vres.invalidRequired > 0 ? 'PASS' : 'FAIL', `submit="${submitBtn}" errorMsg=${vres.bodyHasError}`);
  } else {
    rec('TC-F09', 'Form đặt lịch/liên hệ', 'BLOCKED', 'Không tìm thấy form có input SĐT');
  }

  // ---------- console errors summary ----------
  rec('TC-L02-err', 'Console error khi duyệt site', consoleErrors.length === 0 ? 'PASS' : 'FAIL', `${consoleErrors.length} lỗi: ${[...new Set(consoleErrors)].slice(0, 6).join(' | ')}`);

  fs.writeFileSync('C:\\Users\\DELL\\Documents\\qa-web-ban-hang\\evidence\\results.json', JSON.stringify({ results, consoleErrors: [...new Set(consoleErrors)], cmsErr: [...new Set(cmsErr)] }, null, 2));
  console.log('\n=== SUMMARY ===');
  const counts = results.reduce((a, r) => (a[r.status] = (a[r.status] || 0) + 1, a), {});
  console.log(JSON.stringify(counts));
  await browser.close();
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
