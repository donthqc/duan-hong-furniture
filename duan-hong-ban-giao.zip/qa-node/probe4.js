const puppeteer=require('puppeteer');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:60000});
const p=await b.newPage(); await p.setViewport({width:1440,height:900});
// 1. 404 resource on which page
const bad=[]; p.on('response',r=>{if(r.status()>=400) bad.push(r.status()+' '+r.url());});
await p.goto('http://127.0.0.1:8099/index.html',{waitUntil:'networkidle2',timeout:60000});
await sleep(1500);
console.log('404s on home:', JSON.stringify([...new Set(bad)].slice(0,8)));
// 2. admin.html direct access without login
const p2=await b.newPage(); await p2.setViewport({width:1440,height:900});
await p2.goto('http://127.0.0.1:8099/admin.html',{waitUntil:'networkidle2',timeout:60000});
await sleep(1500);
const adm=await p2.evaluate(()=>({title:document.title,txt:document.body.innerText.replace(/\s+/g,' ').slice(0,200),hasLogin:/đăng nhập/i.test(document.body.innerText),gotData:/doanh thu|đơn hàng|khách hàng/i.test(document.body.innerText),ls:Object.keys(localStorage)}));
console.log('ADMIN direct:',JSON.stringify(adm).slice(0,400));
await p2.screenshot({path:'C:/Users/DELL/Documents/qa-web-ban-hang/evidence/20-admin-direct.png'});
// 3. CMS: which password work? test "1" (len 1)
const p3=await b.newPage(); await p3.setViewport({width:1440,height:900});
await p3.evaluateOnNewDocument(()=>localStorage.clear());
await p3.goto('http://127.0.0.1:8099/cms_duan_hong.html',{waitUntil:'networkidle2',timeout:60000});
await sleep(1200);
await p3.evaluate(()=>{document.getElementById('cms-login-identifier').value='ceo@congtykhac.vn'; document.getElementById('cms-login-password').value='1'; document.getElementById('cms-login-form').dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));});
await sleep(3000);
const r=await p3.evaluate(()=>({hidden:(()=>{const d=document.getElementById('admin-login-screen');return getComputedStyle(d).display==='none'||d.classList.contains('hidden');})(),txt:document.body.innerText.replace(/\s+/g,' ').slice(0,150),role:(localStorage.getItem('dh_admin_user')||'').slice(0,140)}));
console.log('CMS pwd="1":',JSON.stringify(r));
await p3.screenshot({path:'C:/Users/DELL/Documents/qa-web-ban-hang/evidence/21-cms-pwd1.png',fullPage:false});
await b.close();})();
