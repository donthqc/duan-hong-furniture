const puppeteer=require('puppeteer');
const OUT='C:/Users/DELL/Documents/qa-web-ban-hang/evidence/';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:180000});
const p=await b.newPage(); await p.setViewport({width:1440,height:900});
await p.goto('http://127.0.0.1:8099/product.html',{waitUntil:'networkidle2',timeout:60000});
await sleep(1000);
await p.evaluate(()=>document.getElementById('btn-add-cart').click());
await sleep(1200);
// click the actual header cart button
const clicked=await p.evaluate(()=>{const bs=[...document.querySelectorAll('button')].filter(x=>(x.getAttribute('onclick')||'').includes('toggleCartDrawer')); if(bs[0]){bs[0].click();return true;} return false;});
await sleep(1200);
const state=await p.evaluate(()=>{
  const d=document.getElementById('cart-drawer');
  const cs=getComputedStyle(d); const r=d.getBoundingClientRect();
  return {clicked:true,cls:d.className,transform:cs.transform,display:cs.display,right:r.right,width:r.width,left:r.left,visible:r.left<window.innerWidth-10, items:document.querySelectorAll('#cart-items-list>*').length};
});
console.log('DRAWER STATE:',JSON.stringify(state));
await p.screenshot({path:OUT+'15-cart-click.png'});

// checkout modal: empty submit (validation)
await p.evaluate(()=>{const b=[...document.querySelectorAll('button')].find(x=>/ĐẶT CỌC MỘC/i.test(x.innerText)); if(b) b.click();});
await sleep(1200);
const before=await p.evaluate(()=>({modalText:document.body.innerText.slice(-700)}));
await p.screenshot({path:OUT+'16-checkout-modal.png'});
const submit=await p.evaluate(()=>{const f=[...document.querySelectorAll('form')].find(x=>/checkout|dat-coc|order/i.test(x.id||x.className)); const btn=f?[...f.querySelectorAll('button')].find(x=>/xác nhận|gửi|đặt cọc|hoàn tất/i.test(x.innerText)):null; if(btn){btn.click();return btn.innerText.trim();} return null;});
await sleep(1500);
const after=await p.evaluate(()=>({
  required:[...document.querySelectorAll('#checkout input[required], [id*=checkout] input[required]')].map(i=>i.id||i.name),
  emptyStillModal:!!document.querySelector('[id*=checkout]:not(.hidden)'),
  msg:(document.body.innerText.match(/vui lòng[^.\n]{0,60}|bắt buộc[^.\n]{0,40}|không hợp lệ[^.\n]{0,40}/i)||[])[0]||'',
  text:document.body.innerText.slice(-300)
}));
console.log('CHECKOUT SUBMIT:',submit,'| required:',JSON.stringify(after.required),'| msg:',after.msg);
console.log('TAIL:',after.text.replace(/\s+/g,' ').slice(-200));
await p.screenshot({path:OUT+'17-checkout-empty-submit.png'});
await b.close();})();
