const puppeteer=require('puppeteer');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:180000});
const p=await b.newPage(); await p.setViewport({width:1440,height:900});
// 1. where is add-to-cart on PDP
await p.goto('http://127.0.0.1:8099/product.html',{waitUntil:'networkidle2',timeout:60000});
await sleep(1500);
const btns=await p.evaluate(()=>[...document.querySelectorAll('button,a.btn,[role=button]')].map(x=>({t:x.innerText.trim().replace(/\s+/g,' ').slice(0,40),id:x.id,cls:String(x.className).slice(0,50)})).filter(x=>x.t));
console.log('PDP BUTTONS:'); console.log(JSON.stringify(btns.slice(0,25),null,0));
// 2. checkout flow on PDP
const add=await p.evaluate(()=>{const x=[...document.querySelectorAll('button')].find(y=>/thêm vào giỏ|mua ngay|đặt mua/i.test(y.innerText)); if(x){x.click();return x.innerText.trim();} return null;});
await sleep(1500);
console.log('ADD CLICKED:',add);
const after=await p.evaluate(()=>({ls:Object.entries(localStorage).filter(([k])=>/cart|gio/i.test(k)).map(([k,v])=>k+'='+v.slice(0,100)),badge:(document.getElementById('header-cart-badge')||{}).innerText,url:location.href}));
console.log('AFTER ADD:',JSON.stringify(after));
await p.screenshot({path:'C:/Users/DELL/Documents/qa-web-ban-hang/evidence/probe-pdp-after-add.png'});
// 3. cart drawer open?
const cartBtn=await p.evaluate(()=>{const c=[...document.querySelectorAll('button,a')].filter(x=>/giỏ/i.test(x.innerText)||x.getAttribute('onclick')?.includes('Cart')); return c.map(x=>x.getAttribute('onclick')||x.innerText.trim()).slice(0,8);});
console.log('CART CONTROLS:',JSON.stringify(cartBtn));
await b.close();})();
