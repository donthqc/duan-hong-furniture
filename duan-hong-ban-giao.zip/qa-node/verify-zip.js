/* Kiểm tra bản ZIP đã giải nén có chạy thật không — độc lập với thư mục gốc */
const puppeteer = require('puppeteer');
const http = require('node:http');

/* python -m http.server đóng socket kiểu làm undici (fetch) assert → dùng http.request */
const httpGet = (url) => new Promise((resolve) => {
  const req = http.get(url, (res) => { res.resume(); resolve(res.statusCode); });
  req.on('error', () => resolve(0));
  req.setTimeout(5000, () => { req.destroy(); resolve(0); });
});
const sleep = ms => new Promise(r => setTimeout(r, ms));
/* Mặc định trùng các bộ test khác; đổi bằng DH_WEB / DH_API nếu chạy cổng khác. */
const WEB = process.env.DH_WEB || 'http://127.0.0.1:8098';
const API = process.env.DH_API || 'http://127.0.0.1:5055';
let pass = 0, fail = 0;
const ok = (n, c, d = '') => { console.log(`${c ? 'PASS' : 'FAIL'}  ${n}${d ? '  :: ' + d : ''}`); c ? pass++ : fail++; };

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 90000 });
  const page = await br.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  const errs = [];
  page.on('pageerror', e => errs.push(e.message.slice(0, 100)));
  page.on('requestfailed', r => { if (!r.url().includes(':5055') && !r.url().includes(API) && !r.url().includes('favicon')) errs.push('fail ' + r.url().slice(-40)); });

  // 1. Trang design system mở được
  const r1 = await page.goto(WEB + '/index.html', { waitUntil: 'networkidle2' });
  ok('index.html mở được (200)', r1.status() === 200, 'HTTP ' + r1.status());

  // 2. Cả 8 trang đều 200
  const pages = ['index', 'trang-chu', 'pdp', 'quy-trinh', 'cong-trinh', 'lo-ban', 'tra-cuu', 'dat-lich'];
  let bad = [];
  for (const p of pages) {
    const code = await httpGet(`${WEB}/${p}.html`);
    if (code !== 200) bad.push(`${p}(${code})`);
  }
  ok('8/8 trang trả 200', bad.length === 0, bad.join(',') || 'đủ 8');

  // 3. API trong gói chạy, có dữ liệu
  const h = await fetch(API + '/api/health').then(r => r.json()).catch(() => null);
  ok('API trong ZIP chạy', h && h.status === 'UP', h ? h.service : 'không kết nối');
  const prod = await fetch(API + '/api/products').then(r => r.json());
  ok('API có 6 sản phẩm (dữ liệu tự seed)', prod.count === 6, `count=${prod.count}`);

  // 4. Website gọi được API: đổi base sang 5056 rồi tải catalogue
  await page.evaluateOnNewDocument(api => localStorage.setItem('dh_api_base', api), API);
  await page.goto(WEB + '/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(1200);
  const cat = await page.evaluate(() => ({
    cards: document.querySelectorAll('#catalog [data-testid="product-card"]').length,
    count: document.getElementById('catalog-count').textContent,
    apiBase: window.DH_API.base
  }));
  ok('catalogue lấy từ API của gói ZIP', cat.cards === 6 && !cat.count.includes('dữ liệu mẫu'), cat.count);
  ok('DH_API trỏ đúng máy chủ', cat.apiBase === API, cat.apiBase);

  // 5. Gửi lead vào DB của gói ZIP
  await page.evaluate(() => document.querySelector('#lead-form').scrollIntoView({ block: 'center', behavior: 'instant' }));
  await sleep(300);
  await page.type('#lead-name', 'QA Tu ZIP');
  await page.type('#lead-phone', '0987654321');
  await page.click('#lead-submit');
  await sleep(1800);
  const res = await page.evaluate(() => document.getElementById('lead-result').innerText.replace(/\s+/g, ' '));
  const code = (res.match(/LH-[A-Z0-9]+/) || [])[0];
  ok('gửi lead từ gói ZIP → có mã', !!code, code || res.slice(0, 60));

  const leads = await fetch(API + '/api/admin/leads', { headers: { Authorization: 'Bearer local-admin-token' } }).then(r => r.json());
  ok('lead vào database của gói ZIP', leads.data.some(l => l.code === code), `tổng ${leads.data.length} lead`);

  // 6. Tra cứu tiến độ
  await page.evaluate(() => document.getElementById('tien-do').scrollIntoView({ block: 'center', behavior: 'instant' }));
  await sleep(200);
  await page.type('#order-code', 'DH-801');
  await page.type('#order-phone', '5889');
  await page.click('#track-btn');
  await sleep(1200);
  const tr = await page.evaluate(() => document.getElementById('track-result').innerText.replace(/\s+/g, ' '));
  ok('tra cứu đơn từ API của gói ZIP', /\/5/.test(tr) && /DH-801/.test(tr), tr.slice(0, 70));

  // 7. Ảnh: chưa có ảnh thật thì phải là placeholder
  const ph = await page.evaluate(() => ({
    imgs: document.querySelectorAll('img.ph-img').length,
    phos: document.querySelectorAll('[data-photo]').length
  }));
  ok('chưa có ảnh → giữ placeholder (đúng như bàn giao)', ph.imgs === 0 && ph.phos > 0, `img=${ph.imgs} ph=${ph.phos}`);

  ok('không có lỗi JS khi chạy từ ZIP', errs.length === 0, errs.slice(0, 2).join(' | ') || 'sạch');

  console.log(`\n${'='.repeat(52)}\nKIỂM TRA GÓI ZIP: ${pass} PASS / ${fail} FAIL\n${'='.repeat(52)}`);
  await br.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
