const puppeteer = require('puppeteer');
const WEB = process.env.DH_WEB || 'http://127.0.0.1:8098';
const PAGES = ['trang-chu.html','pdp.html','quy-trinh.html','cong-trinh.html','lo-ban.html','tra-cuu.html','dat-lich.html','index.html'];
(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'] });
  for (const f of PAGES) {
    const p = await br.newPage();
    await p.setViewport({ width: 375, height: 800, isMobile: true, hasTouch: true });
    await p.goto(WEB + '/' + f, { waitUntil: 'networkidle2' });
    await new Promise(r => setTimeout(r, 500));
    const bad = await p.evaluate(() => {
      const out = [];
      for (const el of document.querySelectorAll('a,button,input,select,textarea,[role=button]')) {
        const r = el.getBoundingClientRect();
        if (r.width === 0 && r.height === 0) continue;
        if (r.height < 40 || r.width < 40) {
          out.push({
            tag: el.tagName.toLowerCase(),
            text: (el.innerText || el.value || el.getAttribute('aria-label') || '').trim().slice(0, 45),
            cls: (el.className || '').toString().slice(0, 50),
            href: el.getAttribute('href') || '',
            w: Math.round(r.width), h: Math.round(r.height),
            top: Math.round(r.top + scrollY)
          });
        }
      }
      return out;
    });
    if (bad.length) console.log(f, JSON.stringify(bad, null, 1));
    await p.close();
  }
  await br.close();
})();
