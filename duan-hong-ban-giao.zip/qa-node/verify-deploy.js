/**
 * Kiểm tra deployment đang chạy thật (LAN hoặc domain).
 *   node verify-deploy.js http://192.168.0.107:8098 http://192.168.0.107:5055
 */
const puppeteer = require('puppeteer');

const WEB = process.argv[2] || 'http://127.0.0.1:8098';
const API = process.argv[3] || 'http://127.0.0.1:5055';
let pass = 0, fail = 0;
const ok = (n, c, d = '') => { console.log(`${c ? 'PASS' : 'FAIL'}  ${n}${d ? '  :: ' + d : ''}`); c ? pass++ : fail++; };

/* Dùng fetch để hỗ trợ cả http và https (LAN và tunnel) */
const get = async (url) => {
  try {
    const r = await fetch(url, { headers: { 'User-Agent': 'duanhong-verify/1.0' } });
    return { code: r.status, body: await r.text() };
  } catch (e) {
    return { code: 0, body: e.code || e.message };
  }
};

(async () => {
  console.log(`Web : ${WEB}\nAPI : ${API}\n`);

  /* 1. API công khai */
  let r = await get(`${API}/api/health`);
  let j = null; try { j = JSON.parse(r.body); } catch {}
  ok('API /api/health → UP', r.code === 200 && j && j.status === 'UP', `HTTP ${r.code}`);

  r = await get(`${API}/api/products`);
  try { j = JSON.parse(r.body); } catch { j = null; }
  ok('API /api/products trả 6 sản phẩm', r.code === 200 && j && j.count === 6, `count=${j && j.count}`);

  /* 2. Endpoint quản trị phải bị khoá khi không token */
  r = await get(`${API}/api/admin/leads`);
  ok('admin không token bị chặn', r.code === 401 || r.code === 503, `HTTP ${r.code}`);

  /* 3. OTP/ZNS đã xoá → 404 */
  const post = async (url, body) => {
    try {
      const r = await fetch(url, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      return r.status;
    } catch { return 0; }
  };
  ok('/api/otp/request đã bị xoá (404)', (await post(`${API}/api/otp/request`, { phone: '0378914207' })) === 404);

  /* 4. 8 trang trả 200 từ host đang deploy */
  const pages = ['index', 'trang-chu', 'pdp', 'quy-trinh', 'cong-trinh', 'lo-ban', 'tra-cuu', 'dat-lich'];
  const bad = [];
  for (const p of pages) {
    const x = await get(`${WEB}/${p}.html`);
    if (x.code !== 200) bad.push(`${p}(${x.code})`);
  }
  ok('8/8 trang trả 200', bad.length === 0, bad.join(',') || 'đủ 8');

  /* 5. Tài nguyên SEO */
  for (const p of ['/sitemap.xml', '/robots.txt', '/assets/og-xuong.jpg', '/assets/og-sofa.jpg']) {
    const x = await get(WEB + p);
    ok(`${p} → 200`, x.code === 200, `HTTP ${x.code}`);
  }

  /* 6. Trình duyệt thật: catalogue lấy từ API của host này */
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 120000 });
  const page = await br.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  const errs = [];
  page.on('pageerror', (e) => errs.push(e.message.slice(0, 80)));

  await page.evaluateOnNewDocument((api) => localStorage.setItem('dh_api_base', api), API);
  await page.goto(`${WEB}/trang-chu.html`, { waitUntil: 'networkidle2', timeout: 45000 });
  await new Promise((r) => setTimeout(r, 1500));

  const cat = await page.evaluate(() => ({
    cards: document.querySelectorAll('#catalog [data-testid="product-card"]').length,
    count: (document.getElementById('catalog-count') || {}).textContent || '',
    banner: !!document.getElementById('dh-demo-banner'),
    apiBase: window.DH_API && window.DH_API.base,
  }));
  ok('catalogue 6 thẻ', cat.cards === 6, `cards=${cat.cards}`);
  ok('KHÔNG ở chế độ demo (API sống)', !cat.count.includes('dữ liệu mẫu') && !cat.banner, cat.count.slice(0, 50));
  ok('trang gọi đúng API của host', cat.apiBase === API, cat.apiBase);

  /* 7. Gửi lead thật vào DB của host đang deploy */
  await page.evaluate(() => document.querySelector('#lead-form').scrollIntoView({ block: 'center', behavior: 'instant' }));
  await new Promise((r) => setTimeout(r, 300));
  const stamp = 'Deploy Test ' + Date.now().toString().slice(-6);
  await page.type('#lead-name', stamp);
  await page.type('#lead-phone', '0912345678');
  await page.click('#lead-submit');
  await new Promise((r) => setTimeout(r, 2200));
  const res = await page.evaluate(() => document.getElementById('lead-result').innerText.replace(/\s+/g, ' '));
  const code = (res.match(/LH-[A-Z0-9]+/) || [])[0];
  ok('gửi form đặt lịch → có mã', !!code, code || res.slice(0, 60));

  ok('không lỗi JS', errs.length === 0, errs.slice(0, 2).join(' | ') || 'sạch');

  await br.close();
  console.log(`\n${'='.repeat(52)}\nDEPLOY: ${pass} PASS / ${fail} FAIL\n${'='.repeat(52)}`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('FATAL', e.message); process.exit(1); });
