const puppeteer=require('puppeteer');
const fs=require('fs');
const OUT='C:/Users/DELL/Documents/qa-web-ban-hang/evidence/';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const res=[]; const rec=(id,t,s,d)=>{res.push({id,t,s,d});console.log(`[${s}] ${id} | ${t} :: ${d}`);};
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:180000});
const p=await b.newPage(); await p.setViewport({width:1440,height:900});
const errs=[]; p.on('pageerror',e=>errs.push(e.message.slice(0,150)));

// PDP: variant -> price -> add -> buy now
await p.goto('http://127.0.0.1:8099/product.html',{waitUntil:'networkidle2',timeout:60000});
await sleep(1200);
const p0=await p.evaluate(()=>({price:(document.body.innerText.match(/74\.500\.000 đ|88\.000\.000 đ/g)||[])}));
// choose variant 10 món
const v=await p.evaluate(()=>{const x=[...document.querySelectorAll('.variant-btn')].find(y=>/10 Món/.test(y.innerText)); if(x){x.click();return x.innerText.trim();} return null;});
await sleep(1000);
const p1=await p.evaluate(()=>({txt:document.body.innerText.match(/[\d\.]{8,} đ/g)?.slice(0,3), variantActive:[...document.querySelectorAll('.variant-btn')].filter(x=>/border-wood-900|active|ring/.test(x.className)).map(x=>x.innerText.trim()).slice(0,3)}));
rec('TC-C02','Chọn biến thể cập nhật giá',v&&p1.txt?'PASS':'FAIL',`chọn "${v}" -> giá ${p1.txt?.join(' / ')}`);
await p.screenshot({path:OUT+'12-pdp-variant.png'});

// qty +
const q=await p.evaluate(()=>{const bs=[...document.querySelectorAll('button')]; const plus=bs.find(x=>x.innerText.trim()==='+'); if(plus){plus.click();plus.click();} return true;});
await sleep(600);
const qv=await p.evaluate(()=>{const els=[...document.querySelectorAll('input[type=number],input[value]')].map(i=>i.value);return els.slice(0,4);});
rec('TC-D05','Tăng số lượng trên PDP',qv.length?'PASS':'WARN',`giá trị input: ${JSON.stringify(qv)}`);

// add to cart
await p.evaluate(()=>document.getElementById('btn-add-cart').click());
await sleep(1500);
const c=await p.evaluate(()=>({cart:JSON.parse(localStorage.getItem('dh_cart')||'[]'),badge:(document.getElementById('header-cart-badge')||{}).innerText}));
rec('TC-D01','Thêm vào giỏ',c.cart.length>0?'PASS':'FAIL',`${c.cart.length} item, qty=${c.cart[0]?.qty}, badge=${c.badge}`);
// open drawer
await p.evaluate(()=>{ if(typeof toggleCartDrawer==='function') toggleCartDrawer(); });
await sleep(1000);
await p.screenshot({path:OUT+'13-cart-drawer.png'});
const d=await p.evaluate(()=>({
  subtotal:(document.getElementById('cart-subtotal')||{}).innerText,
  deposit:(document.getElementById('cart-deposit-amount')||{}).innerText,
  items:document.querySelectorAll('#cart-items-list > *').length,
  drawerVisible:(()=>{const el=document.getElementById('cart-drawer'); const r=el.getBoundingClientRect(); return r.x < window.innerWidth && r.width>0;})()
}));
rec('TC-D02','Giỏ hiển thị & tính tổng + cọc 30%',d.items>0?'PASS':'FAIL',`items=${d.items} subtotal="${d.subtotal}" cọc="${d.deposit}" drawerVisible=${d.drawerVisible}`);
// qty change in cart
await p.evaluate(()=>{ if(typeof updateCartQty==='function') updateCartQty(0,1); });
await sleep(800);
const d2=await p.evaluate(()=>({subtotal:(document.getElementById('cart-subtotal')||{}).innerText,deposit:(document.getElementById('cart-deposit-amount')||{}).innerText,cart:JSON.parse(localStorage.getItem('dh_cart')||'[]')}));
rec('TC-D02b','Tăng số lượng trong giỏ cập nhật tổng',d2.subtotal!==d.subtotal?'PASS':'FAIL',`${d.subtotal} -> ${d2.subtotal}, qty=${d2.cart[0]?.qty}, cọc=${d2.deposit}`);
// max qty abuse
await p.evaluate(()=>{const c=JSON.parse(localStorage.getItem('dh_cart')||'[]'); c[0].qty=999999; localStorage.setItem('dh_cart',JSON.stringify(c)); if(typeof renderCart==='function') renderCart();});
await sleep(800);
const d3=await p.evaluate(()=>({subtotal:(document.getElementById('cart-subtotal')||{}).innerText,cart:JSON.parse(localStorage.getItem('dh_cart')||'[]')}));
rec('TC-D04','Chặn số lượng vượt tồn kho',d3.cart[0]?.qty<=4?'PASS':'FAIL',`đặt qty=999999 -> giữ ${d3.cart[0]?.qty} (tồn kho 4), tổng=${d3.subtotal}`);
// checkout
const ck=await p.evaluate(()=>{const bs=[...document.querySelectorAll('button')].filter(x=>/thanh toán|đặt cọc|đặt hàng|checkout/i.test(x.innerText)); if(bs[0]){bs[0].click();return bs[0].innerText.trim();} return null;});
await sleep(1500);
await p.screenshot({path:OUT+'14-checkout.png'});
const ckState=await p.evaluate(()=>({
  modal:!!document.querySelector('[id*=checkout]:not(.hidden), #checkout-modal:not(.hidden)'),
  visibleText:(document.body.innerText.match(/Thanh toán|Đặt cọc|Chuyển khoản|VietQR|COD/i)||[]).slice(0,4),
  forms:[...document.querySelectorAll('form')].map(f=>f.id||f.getAttribute('onsubmit')).slice(0,5)
}));
rec('TC-F01','Nút đặt hàng/thanh toán',ck?'PASS':'BLOCKED',`nút="${ck}" modal=${ckState.modal} text=${JSON.stringify(ckState.visibleText)}`);
await b.close();
fs.writeFileSync(OUT+'flow-results.json',JSON.stringify({res,errs},null,2));
})();
