const puppeteer = require('puppeteer');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const scrollTo = async (page, sel) => {
  await page.evaluate(s => {
    const el = document.querySelector(s);
    if (el) el.scrollIntoView({ block: 'center', behavior: 'instant' });
  }, sel);
  await sleep(250);
};
const WEB = process.env.DH_WEB || 'http://127.0.0.1:8098';
const API = process.env.DH_API || 'http://127.0.0.1:5055';
let pass = 0, fail = 0;
const ok = (name, cond, detail = '') => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? '  :: ' + detail : ''}`);
  cond ? pass++ : fail++;
};

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'], protocolTimeout: 120000 });
  const page = await br.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  const errs = [];
  const badUrls = [];
  page.on('requestfailed', r => badUrls.push('FAILED ' + r.url().slice(0, 90)));
  page.on('response', r => { if (r.status() >= 400) badUrls.push(r.status() + ' ' + r.url().slice(0, 90)); });
  page.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0, 120)); });
  page.on('pageerror', e => errs.push('pageerror: ' + e.message.slice(0, 120)));

  /* ---------- 1. Catalogue lấy từ API ---------- */
  await page.goto(WEB + '/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(900);
  const cat = await page.evaluate(() => ({
    cards: document.querySelectorAll('#catalog [data-testid="product-card"]').length,
    count: document.getElementById('catalog-count').textContent,
    banner: !!document.getElementById('dh-demo-banner')
  }));
  ok('catalogue render 6 thẻ', cat.cards === 6, `cards=${cat.cards}`);
  ok('dòng đếm KHÔNG còn "dữ liệu mẫu" (đang dùng API)', !cat.count.includes('dữ liệu mẫu'), cat.count);
  ok('không hiện banner demo khi API sống', !cat.banner);

  /* ---------- 2. Lead thật: gửi form ---------- */
  await scrollTo(page, '#lead-form');
  await page.type('#lead-name', 'QA End-to-end');
  await page.type('#lead-phone', '0901234567');
  await page.type('#lead-note', 'Bàn ăn 6 người, phòng 4x5m');
  await page.click('#lead-submit');
  await sleep(1500);
  const lead = await page.evaluate(() => document.getElementById('lead-result').innerText.replace(/\s+/g, ' '));
  const leadCode = (lead.match(/LH-[A-Z0-9]+/) || [])[0] || '';
  ok('form gửi thật → có mã LH-', !!leadCode, lead.slice(0, 80));

  const leadInDb = await fetch(`${API}/api/admin/leads`, { headers: { Authorization: 'Bearer local-admin-token' } })
    .then(r => r.json());
  const found = leadInDb.data.find(l => l.code === leadCode);
  ok('lead đã vào database', !!found, found ? `${found.name} · ${found.phone}` : 'không thấy');

  /* ---------- 3. Tra cứu tiến độ qua API ---------- */
  await scrollTo(page, '#tien-do');
  await page.type('#order-code', 'DH-802');
  await page.type('#order-phone', '6778');
  await page.click('#track-btn');
  await sleep(1200);
  const track = await page.evaluate(() => ({
    txt: document.getElementById('track-result').innerText.replace(/\s+/g, ' '),
    steps: [...document.querySelectorAll('#timeline .tl')].map(e => e.dataset.state)
  }));
  ok('tracker lấy dữ liệu từ API (DH-802 bước 4)', track.txt.includes('4/5'), track.txt.slice(0, 90));
  ok('timeline cập nhật theo API', track.steps.join(',').includes('now'), track.steps.join(','));

  await page.evaluate(() => { document.getElementById('order-phone').value = '0000'; });
  await page.click('#track-btn');
  await sleep(900);
  const bad = await page.evaluate(() => document.getElementById('track-result').innerText);
  ok('sai 4 số bị API từ chối', /Không tìm thấy/i.test(bad), bad.slice(0, 60));

  /* ---------- 4. Đánh giá: gửi → chờ duyệt → duyệt → hiện ---------- */
  // tìm cặp (mã đơn, sản phẩm) chưa có đánh giá để test không phụ thuộc dữ liệu cũ
  const existing = await fetch(`${API}/api/admin/reviews`, { headers: { Authorization: 'Bearer local-admin-token' } }).then(r => r.json());
  const used = new Set((existing.data || []).map(r => r.order_code + '|' + r.product_slug));
  const ORDERS_T = [['DH-801', '5889'], ['DH-802', '6778'], ['DH-803', '2334']];
  const SLUGS = ['sofa-go-do', 'an-gian-tho', 'combo-phong-ngu', 'ban-an-live-edge', 'tu-bep-mdf', 'tu-quan-ao-soi'];
  let pair = null;
  for (const [code, ph] of ORDERS_T) for (const slug of SLUGS) {
    if (!used.has(code + '|' + slug)) { pair = { code, ph, slug }; break; }
    if (pair) break;
  }
  if (!pair) { ok('còn cặp đơn/sản phẩm để test đánh giá', false, 'đã đánh giá hết 18 cặp — reset DB'); }

  const slug = pair ? pair.slug : 'an-gian-tho';
  await page.goto(WEB + '/pdp.html?id=' + slug, { waitUntil: 'networkidle2' });
  await sleep(700);
  const title = await page.evaluate(() => document.querySelector('h1').innerText);
  ok('PDP đúng sản phẩm theo ?id', title.length > 3, title);

  const reviewsBefore = await fetch(`${API}/api/products/${slug}/reviews`).then(x => x.json()).then(r => r.count);
  await page.evaluate(() => document.querySelector('[role=tab][aria-controls=panel-3]').click());
  await sleep(200);
  await page.click('#btn-write-review');
  await sleep(150);
  await page.type('#rv-code', pair ? pair.code : 'DH-803');
  await page.type('#rv-phone', pair ? pair.ph : '2334');
  await page.type('#rv-body', 'Combo phòng ngủ đóng chắc, đúng số đo đã chốt.');
  await page.click('#review-form button[type=submit]');
  await sleep(2000);
  const rvMsg = await page.evaluate(() => document.getElementById('review-msg').innerText);
  ok('gửi đánh giá → chờ duyệt', /duyệt/i.test(rvMsg), rvMsg.slice(0, 70));

  const pending = await fetch(`${API}/api/admin/reviews`, { headers: { Authorization: 'Bearer local-admin-token' } })
    .then(r => r.json());
  const mine = pending.data.find(x => x.body.includes('Combo phòng ngủ đóng chắc'));
  ok('đánh giá nằm trong DB ở trạng thái chờ', !!mine && mine.approved === 0);

  if (mine) {
    await fetch(`${API}/api/admin/reviews/${mine.id}`, {
      method: 'PATCH',
      headers: { Authorization: 'Bearer local-admin-token', 'Content-Type': 'application/json' },
      body: JSON.stringify({ approved: true })
    });
  }
  const after = await fetch(`${API}/api/products/${slug}/reviews`).then(r => r.json());
  ok('sau khi duyệt, review hiện công khai', after.count === reviewsBefore + 1, `${reviewsBefore} → ${after.count}`);

  /* ---------- 5. Wizard gửi lead thật ---------- */
  await page.goto(WEB + '/dat-lich.html', { waitUntil: 'networkidle2' });
  await sleep(500);
  await page.select('#bk-room', 'Phòng thờ');
  await page.click('#next-1'); await sleep(300);
  await page.type('#bk-area', '20');
  await page.click('#next-2'); await sleep(300);
  await page.type('#bk-name', 'QA Wizard');
  await page.type('#bk-phone', '0912345678');
  await page.click('#bk-submit');
  await sleep(1600);
  const wiz = await page.evaluate(() => ({
    done: !document.getElementById('bk-done').hidden,
    msg: document.getElementById('bk-done-msg').innerText
  }));
  ok('wizard gửi thật → trạng thái hoàn tất', wiz.done, wiz.msg.slice(0, 60));

  const leads2 = await fetch(`${API}/api/admin/leads`, { headers: { Authorization: 'Bearer local-admin-token' } }).then(r => r.json());
  ok('lead từ wizard vào DB', leads2.data.some(l => l.name === 'QA Wizard'), `tổng lead=${leads2.data.length}`);

  /* ---------- 6. API tắt → banner demo, không báo thành công giả ---------- */
  await page.setRequestInterception(true);
  page.on('request', r => {
    if (r.url().startsWith(API)) return r.abort();   // chặn đúng cổng API đang test
    r.continue();
  });
  await page.goto(WEB + '/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(900);
  await scrollTo(page, '#lead-form');
  await page.type('#lead-name', 'QA Offline');
  await page.type('#lead-phone', '0909999999');
  await page.click('#lead-submit');
  await sleep(1200);
  const offline = await page.evaluate(() => ({
    msg: document.getElementById('lead-result').innerText.replace(/\s+/g, ' '),
    banner: !!document.getElementById('dh-demo-banner')
  }));
  ok('API tắt: hiện banner demo', offline.banner);
  ok('API tắt: KHÔNG báo đã nhận thành công', !/Đã nhận yêu cầu/.test(offline.msg), offline.msg.slice(0, 70));

  const realBad = badUrls.filter(u => !u.includes(API) && !u.includes('favicon'));
  ok('không có request lỗi (bỏ qua API bị chặn có chủ đích)', realBad.length === 0,
     realBad.slice(0, 3).join(' | ') || 'sạch');

  console.log(`\n${'='.repeat(58)}\nE2E: ${pass} PASS / ${fail} FAIL\n${'='.repeat(58)}`);
  await br.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('FATAL', e.message); process.exit(1); });
