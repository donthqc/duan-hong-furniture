const puppeteer = require('puppeteer');
const sleep = ms => new Promise(r => setTimeout(r, ms));

const lum = (c) => {
  const m = c.match(/\d+(\.\d+)?/g) || ['0', '0', '0'];
  const [r, g, b] = m.slice(0, 3).map(Number).map(v => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};
const ratio = (a, b) => {
  const l1 = lum(a), l2 = lum(b);
  return ((Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05)).toFixed(2);
};

(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'] });
  const p = await br.newPage();
  await p.setViewport({ width: 1440, height: 900 });
  await p.goto('file:///C:/Users/DELL/Documents/qa-web-ban-hang/prototype/trang-chu-moi.html', { waitUntil: 'networkidle0' });
  await sleep(600);

  const r = await p.evaluate(() => {
    const out = { overflow: 0, overlaps: [], h1: '', btnH: 0, sections: 0 };
    const els = [...document.querySelectorAll('h1,h2,h3,p,li,dd,dt,.btn,input,label,time')].filter(e => e.offsetParent);
    els.forEach(e => {
      const pr = e.parentElement.getBoundingClientRect(), er = e.getBoundingClientRect();
      if (er.width > pr.width + 2) out.overflow++;
    });
    const boxes = els.map(e => ({ e, r: e.getBoundingClientRect() })).filter(o => o.r.width > 20 && o.r.height > 8);
    for (let i = 0; i < boxes.length; i++) {
      for (let j = i + 1; j < boxes.length; j++) {
        const a = boxes[i].r, c = boxes[j].r;
        if (a.right - c.left > 4 && c.right - a.left > 4 && a.bottom - c.top > 4 && c.bottom - a.top > 4) {
          if (!boxes[i].e.contains(boxes[j].e) && !boxes[j].e.contains(boxes[i].e)) {
            out.overlaps.push((boxes[i].e.innerText || boxes[i].e.tagName).slice(0, 28) + ' <> ' + (boxes[j].e.innerText || boxes[j].e.tagName).slice(0, 28));
          }
        }
      }
    }
    out.overlaps = out.overlaps.slice(0, 5);
    out.h1 = getComputedStyle(document.querySelector('h1')).fontSize;
    out.btnH = document.querySelector('.btn').getBoundingClientRect().height;
    out.sections = document.querySelectorAll('section').length;
    return out;
  });
  console.log('STRUCT:', JSON.stringify(r));

  const pairs = await p.evaluate(() => {
    const pick = (sel) => {
      const e = document.querySelector(sel);
      if (!e) return null;
      const s = getComputedStyle(e);
      let bg = s.backgroundColor, n = e;
      while ((bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent') && n.parentElement) {
        n = n.parentElement; bg = getComputedStyle(n).backgroundColor;
      }
      while (bg === 'rgba(0, 0, 0, 0)' ) { bg = 'rgb(250,246,240)'; break; }
      return { fg: s.color, bg };
    };
    return {
      heroP: pick('.hero p'),
      cardP: pick('.card p'),
      secHeadP: pick('.sec-head p'),
      btnPrimary: pick('.btn-primary'),
      smallHint: pick('.hint'),
      footerText: pick('footer p')
    };
  });
  for (const k in pairs) {
    if (!pairs[k]) continue;
    console.log('CONTRAST', k, ratio(pairs[k].fg, pairs[k].bg) + ':1', JSON.stringify(pairs[k]));
  }
  await br.close();
})();
