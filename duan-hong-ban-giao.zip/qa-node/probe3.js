const puppeteer=require('puppeteer');
const OUT='C:/Users/DELL/Documents/qa-web-ban-hang/evidence/';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:180000});
const p=await b.newPage(); await p.setViewport({width:1440,height:900});
const logs=[]; p.on('console',m=>logs.push(m.type()+': '+m.text().slice(0,120))); p.on('pageerror',e=>logs.push('pageerror: '+e.message.slice(0,120)));
await p.goto('http://127.0.0.1:8099/product.html',{waitUntil:'networkidle2',timeout:60000});
await sleep(800);
await p.evaluate(()=>document.getElementById('btn-add-cart').click());
await sleep(1000);
// reopen drawer the way the UI does
await p.evaluate(()=>{const bs=[...document.querySelectorAll('button')].find(x=>(x.getAttribute('onclick')||'').includes('toggleCartDrawer')); bs.click();});
await sleep(400);
console.log('AFTER 1 CLICK:', await p.evaluate(()=>document.getElementById('cart-drawer').className.includes('translate-x-full')));
await p.evaluate(()=>toggleCartDrawer()); await sleep(400);
await p.evaluate(()=>toggleCartDrawer()); await sleep(600);
const st=await p.evaluate(()=>({cls:document.getElementById('cart-drawer').className.slice(-40), left:document.getElementById('cart-drawer').getBoundingClientRect().left}));
console.log('AFTER 3 CALLS:', JSON.stringify(st));
// submit empty checkout
await p.evaluate(()=>{const btn=[...document.querySelectorAll('button')].find(x=>/XÁC NHẬN ĐẶT ĐƠN/i.test(x.innerText)); if(btn) btn.click();});
await sleep(1200);
const v=await p.evaluate(()=>({
  activeId:document.activeElement?document.activeElement.id:'',
  invalid:[...document.querySelectorAll('input:invalid')].map(i=>i.id),
  valMsg:[...document.querySelectorAll('input')].map(i=>i.id+':'+i.validationMessage).filter(s=>!s.endsWith(':')),
  stillModal:!!document.querySelector('[id*=checkout]:not(.hidden)'),
  msg:(document.body.innerText.match(/vui lòng[^.\n]{0,60}/i)||[])[0]||''
}));
console.log('EMPTY SUBMIT:',JSON.stringify(v));
await p.screenshot({path:OUT+'18-checkout-validation.png'});
// fill valid -> submit -> where does it go
await p.evaluate(()=>{
  const set=(id,val)=>{const e=document.getElementById(id); if(e){e.value=val; e.dispatchEvent(new Event('input',{bubbles:true}));}};
  set('order-customer-name','QA Automation');
  set('order-customer-phone','0900000000');
  set('order-customer-address','Số 1 Nguyễn Du, TP Hưng Yên');
});
await p.evaluate(()=>{const btn=[...document.querySelectorAll('button')].find(x=>/XÁC NHẬN ĐẶT ĐƠN/i.test(x.innerText)); if(btn) btn.click();});
await sleep(2500);
const done=await p.evaluate(()=>({ls:Object.keys(localStorage), orders:(localStorage.getItem('dh_orders')||localStorage.getItem('dh_leads')||'').slice(0,200), txt:document.body.innerText.slice(-300)}));
console.log('AFTER VALID SUBMIT keys:',done.ls.join(','),'\norders:',done.orders,'\ntxt:',done.txt.replace(/\s+/g,' ').slice(-150));
console.log('LOGS:',[...new Set(logs)].slice(0,6).join(' || '));
await p.screenshot({path:OUT+'19-order-success.png'});
await b.close();})();
