const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const OUT = 'C:\\Users\\DELL\\Documents\\qa-web-ban-hang\\evidence';
fs.mkdirSync(OUT, { recursive: true });
const BASE = 'http://127.0.0.1:8099';
const results = [];
const rec = (id, title, status, detail) => {
  results.push({ id, title, status, detail });
  console.log(`[${status}] ${id} | ${title} :: ${detail}`);
};
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new', protocolTimeout: 180000,
    args: ['--no-sandbox', '--disable-dev-shm-usage']
  });
  const errors = [];
  const newPage = async (w = 1440, h = 900) => {
    const p = await browser.newPage();
    await p.setViewport({ width: w, height: h });
    p.on('console', m => { if (m.type() === 'error') errors.push('[console] ' + m.text().slice(0, 160)); });
    p.on('pageerror', e => errors.push('[pageerror] ' + e.message.slice(0, 160)));
    p.on('requestfailed', r => {
      const u = r.url();
      if (!/localhost:5000|telegram|google|vietqr|unsplash|fonts/.test(u)) errors.push('[reqfail] ' + u.slice(0, 120));
    });
    return p;
  };

  // ================= HOME =================
  const page = await newPage();
  const t0 = Date.now();
  const resp = await page.goto(BASE + '/index.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await sleep(1200);
  const loadMs = Date.now() - t0;
  await page.screenshot({ path: path.join(OUT, '01-home-desktop.png'), fullPage: false });

  const home = await page.evaluate(() => ({
    title: document.title,
    h1: [...document.querySelectorAll('h1')].map(e => e.innerText.trim().replace(/\s+/g, ' ')),
    cards: document.querySelectorAll('#products-grid > *').length,
    imgs: document.images.length,
    broken: [...document.images].filter(i => i.complete && i.naturalWidth === 0).map(i => i.src.slice(0, 90)),
    noAlt: [...document.images].filter(i => !i.alt.trim()).length,
    sections: [...document.querySelectorAll('section[id]')].map(s => s.id),
    canonical: (document.querySelector('link[rel=canonical]') || {}).href || '',
    ogImage: (document.querySelector('meta[property="og:image"]') || {}).content || '',
    ldjson: document.querySelectorAll('script[type="application/ld+json"]').length,
    cartBadge: (document.getElementById('header-cart-badge') || {}).innerText
  }));
  rec('TC-A01', 'Trang chủ tải & đủ khối nội dung', resp.status() === 200 && home.cards > 0 ? 'PASS' : 'FAIL',
    `HTTP ${resp.status()}, ${loadMs}ms, ${home.cards} thẻ SP, ${home.imgs} ảnh, sections=${home.sections.length}`);
  rec('TC-C06a', 'SEO on-page trang chủ', home.title && home.canonical && home.ldjson > 0 ? 'PASS' : 'FAIL',
    `title=${home.title.length} ký tự, canonical=${home.canonical ? 'có' : 'THIẾU'}, og:image=${home.ogImage ? 'có' : 'THIẾU'}, JSON-LD=${home.ldjson}`);
  rec('TC-L08a', 'Alt text ảnh', home.noAlt === 0 ? 'PASS' : 'FAIL', `${home.noAlt}/${home.imgs} ảnh thiếu alt`);
  if (home.broken.length) rec('TC-A01b', 'Ảnh vỡ', 'FAIL', home.broken.slice(0, 4).join(' | '));

  // --- links (node-side, no page fetch) ---
  const links = await page.evaluate(() => [...document.querySelectorAll('a[href]')]
    .map(a => a.getAttribute('href'))
    .filter(h => h && !h.startsWith('#') && !h.startsWith('javascript') && !h.startsWith('tel') && !h.startsWith('mailto') && !h.startsWith('http')));
  const uniq = [...new Set(links)];
  const http = require('http');
  const headStatus = (url) => new Promise((resolve) => {
    const req = http.request(url, { method: 'GET', timeout: 8000 }, (res) => {
      res.resume();
      resolve(res.statusCode);
    });
    req.on('timeout', () => { req.destroy(); resolve('TIMEOUT'); });
    req.on('error', () => resolve('ERR'));
    req.end();
  });
  let bad = [];
  for (const href of uniq) {
    const url = BASE + '/' + href.replace(/^\.?\//, '');
    const st = await headStatus(url);
    if (st === 'ERR' || st === 'TIMEOUT' || st >= 400) bad.push(st + ' ' + href);
  }
  rec('TC-A04', 'Link nội bộ không chết', bad.length === 0 ? 'PASS' : 'FAIL', `${uniq.length} link kiểm tra, lỗi: ${bad.join(' | ') || 'không'}`);

  // --- responsive ---
  for (const w of [375, 768, 1024, 1440]) {
    const pg = await newPage(w, 900);
    await pg.goto(BASE + '/index.html', { waitUntil: 'networkidle2', timeout: 60000 });
    await sleep(700);
    const o = await pg.evaluate(() => ({
      sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth,
      overflowers: [...document.querySelectorAll('*')].filter(e => e.getBoundingClientRect().right > document.documentElement.clientWidth + 3)
        .map(e => (e.tagName + '.' + String(e.className).slice(0, 40))).slice(0, 3)
    }));
    rec('TC-L07-' + w, `Responsive ${w}px`, o.sw <= o.cw + 2 ? 'PASS' : 'FAIL', `scrollW=${o.sw} vs ${o.cw}${o.overflowers.length ? ' tràn: ' + o.overflowers.join(', ') : ''}`);
    if (w === 375) await pg.screenshot({ path: path.join(OUT, '02-home-mobile375.png') });
    await pg.close();
  }

  // ================= SEARCH =================
  const searchSel = 'input[placeholder*="Tìm"], input[placeholder*="tìm"], input[type=search]';
  const hasSearch = await page.$(searchSel);
  if (hasSearch) {
    await hasSearch.click({ clickCount: 3 });
    await hasSearch.type('sofa', { delay: 30 });
    await page.keyboard.press('Enter');
    await sleep(1500);
    const s1 = await page.evaluate(() => ({
      cards: document.querySelectorAll('#products-grid > *').length,
      visible: [...document.querySelectorAll('#products-grid > *')].filter(e => e.offsetParent).length,
      txt: document.body.innerText.toLowerCase().slice(0, 1500)
    }));
    rec('TC-B01', 'Tìm "sofa" có kết quả', s1.visible > 0 ? 'PASS' : 'FAIL', `${s1.visible}/${s1.cards} thẻ hiển thị`);
    await page.screenshot({ path: path.join(OUT, '03-search-sofa.png') });

    await hasSearch.click({ clickCount: 3 });
    await hasSearch.type('khongcospnay123', { delay: 20 });
    await page.keyboard.press('Enter');
    await sleep(1200);
    const s2 = await page.evaluate(() => ({
      visible: [...document.querySelectorAll('#products-grid > *')].filter(e => e.offsetParent).length,
      hasEmptyMsg: /không tìm thấy|không có sản phẩm|0 sản phẩm/i.test(document.body.innerText)
    }));
    rec('TC-B04', 'Tìm không kết quả', s2.visible === 0 && s2.hasEmptyMsg ? 'PASS' : (s2.visible === 0 ? 'WARN' : 'FAIL'),
      `visible=${s2.visible}, thông báo rỗng=${s2.hasEmptyMsg}`);
    await page.screenshot({ path: path.join(OUT, '04-search-empty.png') });
  }

  // ================= CART (drawer) =================
  await page.goto(BASE + '/index.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await sleep(1000);
  const addBtn = await page.evaluateHandle(() => {
    const b = [...document.querySelectorAll('button')].find(x => /thêm vào giỏ|mua ngay/i.test(x.innerText));
    return b || null;
  });
  const addOk = await page.evaluate(el => !!el, addBtn);
  if (addOk) {
    await addBtn.click();
    await sleep(1200);
    const c1 = await page.evaluate(() => ({
      badge: (document.getElementById('header-cart-badge') || {}).innerText,
      ls: (localStorage.getItem('dh_cart') || localStorage.getItem('cart') || '').slice(0, 120),
      keys: Object.keys(localStorage)
    }));
    rec('TC-D01', 'Thêm sản phẩm vào giỏ (guest)', parseInt(c1.badge || '0') > 0 ? 'PASS' : 'FAIL', `badge=${c1.badge}, localStorage keys=${c1.keys.join(',')}`);
    // open drawer
    await page.evaluate(() => { const b = document.querySelector('[onclick*="toggleCartDrawer"], [onclick*="openCart"]'); if (b) b.click(); });
    await sleep(1000);
    await page.screenshot({ path: path.join(OUT, '05-cart-drawer.png') });
    const c2 = await page.evaluate(() => ({
      drawerOpen: (() => { const d = document.getElementById('cart-drawer'); return d && !d.classList.contains('translate-x-full') && getComputedStyle(d).transform !== 'none' || (d && d.offsetParent !== null); })(),
      items: document.querySelectorAll('#cart-items-list > *').length,
      subtotal: (document.getElementById('cart-subtotal') || {}).innerText,
      deposit: (document.getElementById('cart-deposit-amount') || {}).innerText,
      text: (document.getElementById('cart-drawer') || {}).innerText?.slice(0, 300)
    }));
    rec('TC-D02', 'Giỏ hàng hiển thị & tính tiền', c2.items > 0 ? 'PASS' : 'FAIL', `items=${c2.items}, subtotal="${c2.subtotal}", cọc 30%="${c2.deposit}"`);
    // quantity +
    await page.evaluate(() => { const b = document.querySelector('#cart-items-list button[onclick*="updateCartQty"]'); if (b) b.click(); });
    await sleep(900);
    const c3 = await page.evaluate(() => ({
      subtotal: (document.getElementById('cart-subtotal') || {}).innerText,
      badge: (document.getElementById('header-cart-badge') || {}).innerText
    }));
    rec('TC-D02b', 'Tăng số lượng cập nhật tổng tiền', c3.subtotal !== c2.subtotal ? 'PASS' : 'FAIL', `trước="${c2.subtotal}" sau="${c3.subtotal}" badge=${c3.badge}`);

    // checkout modal
    const checkout = await page.evaluate(() => {
      const b = [...document.querySelectorAll('button, a')].find(x => /đặt hàng|thanh toán|đặt cọc|checkout/i.test(x.innerText));
      if (b) { b.click(); return b.innerText.trim().slice(0, 40); }
      return null;
    });
    await sleep(1200);
    await page.screenshot({ path: path.join(OUT, '06-checkout.png') });
    const ck = await page.evaluate(() => ({
      modal: !!document.querySelector('[id*=checkout][class*=fixed], #checkout-modal, [id*=checkout]'),
      text: document.body.innerText.slice(-500)
    }));
    rec('TC-F01', 'Luồng đặt hàng/thanh toán tồn tại', checkout ? 'PASS' : 'BLOCKED', `nút="${checkout}", modal=${ck.modal}`);
  } else {
    rec('TC-D01', 'Thêm vào giỏ', 'BLOCKED', 'Không tìm thấy nút thêm giỏ trên trang chủ');
  }

  // ================= PDP =================
  const pdp = await newPage();
  await pdp.goto(BASE + '/product.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await sleep(1500);
  await pdp.screenshot({ path: path.join(OUT, '07-pdp.png') });
  const pd = await pdp.evaluate(() => ({
    title: document.title,
    h1: [...document.querySelectorAll('h1')].map(e => e.innerText.trim()),
    price: (document.body.innerText.match(/[\d\.]{9,}\s*đ/) || [''])[0],
    allPrice: [...new Set((document.body.innerText.match(/[\d\.]{8,}\s*đ/g) || []))].slice(0, 5),
    canonical: (document.querySelector('link[rel=canonical]') || {}).href || '',
    og: !!(document.querySelector('meta[property="og:image"]')),
    ldjson: document.querySelectorAll('script[type="application/ld+json"]').length,
    tabs: [...document.querySelectorAll('button')].map(b => b.innerText.trim()).filter(t => t.length > 2 && t.length < 30).slice(0, 15)
  }));
  rec('TC-C01', 'PDP hiển thị đúng thông tin', pd.h1.length > 0 && pd.allPrice.length > 0 ? 'PASS' : 'FAIL', `h1="${pd.h1[0]?.slice(0, 50)}", giá=${pd.allPrice.join(' / ')}`);
  rec('TC-C05', 'Giá khuyến mãi + giá gốc', pd.allPrice.length >= 2 ? 'PASS' : 'FAIL', `${pd.allPrice.join(' | ')}`);
  rec('TC-C06', 'SEO metadata PDP', pd.canonical && pd.og && pd.ldjson > 0 ? 'PASS' : 'FAIL', `canonical=${pd.canonical ? 'có' : 'THIẾU'} og=${pd.og} JSON-LD=${pd.ldjson}`);

  // variant selection presence
  const variants = await pdp.evaluate(() => ({
    sizeBtns: [...document.querySelectorAll('button')].filter(b => /^(1m[0-9]|2m[0-9]|[0-9]+m[0-9]+|\d{2,3}cm)$/i.test(b.innerText.trim())).length,
    stock: /còn\s*\d+|hết hàng/i.test(document.body.innerText),
    qtyInput: !!document.querySelector('input[type=number], input[name*=qty], input[id*=qty]')
  }));
  rec('TC-C02', 'Chọn biến thể (kích thước/gỗ)', variants.sizeBtns > 0 ? 'PASS' : 'WARN', `${variants.sizeBtns} nút biến thể, tồn kho hiển thị=${variants.stock}, ô số lượng=${variants.qtyInput}`);

  // reviews
  const rev = await pdp.evaluate(() => ({
    reviewSection: /đánh giá/i.test(document.body.innerText),
    form: [...document.querySelectorAll('form')].length,
    textareas: document.querySelectorAll('textarea').length
  }));
  rec('TC-I03', 'Khu vực đánh giá sản phẩm', rev.reviewSection ? 'PASS' : 'FAIL', `có mục đánh giá=${rev.reviewSection}, form=${rev.form}, textarea=${rev.textareas}`);

  // ================= LOGIN PAGE =================
  const lp = await newPage();
  await lp.goto(BASE + '/login.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await sleep(1200);
  await lp.screenshot({ path: path.join(OUT, '08-login.png') });
  const lg = await lp.evaluate(() => ({
    inputs: [...document.querySelectorAll('input')].map(i => ({ type: i.type, name: i.name || i.id, autocomplete: i.autocomplete, required: i.required })),
    hasForgot: /quên mật khẩu/i.test(document.body.innerText),
    hasRegister: /đăng ký/i.test(document.body.innerText),
    captcha: /captcha|recaptcha/i.test(document.body.innerText),
    storePwd: [...document.querySelectorAll('script')].some(s => /localStorage\.setItem\([^)]*password/i.test(s.textContent))
  }));
  rec('TC-E01', 'Trang đăng nhập có đủ thành phần', lg.inputs.length >= 2 ? 'PASS' : 'FAIL', `${lg.inputs.length} input, quên MK=${lg.hasForgot}, đăng ký=${lg.hasRegister}, captcha=${lg.captcha}`);

  // login with bogus creds
  await lp.evaluate(() => {
    const ins = [...document.querySelectorAll('input')];
    const email = ins.find(i => i.type === 'text' || i.type === 'email');
    const pwd = ins.find(i => i.type === 'password');
    if (email) email.value = 'attacker@evil.com';
    if (pwd) pwd.value = 'zzzz9';
    const f = document.querySelector('form');
    if (f) f.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
  });
  await sleep(2000);
  const lgAfter = await lp.evaluate(() => ({
    url: location.href,
    keys: Object.keys(localStorage),
    token: JSON.stringify(Object.entries(localStorage).filter(([k]) => /token|auth|user/i.test(k)).map(([k, v]) => k + '=' + String(v).slice(0, 60))),
    text: document.body.innerText.toLowerCase()
  }));
  rec('TC-E04', 'Đăng nhập sai bị chặn', lgAfter.text.includes('sai') || lgAfter.text.includes('không đúng') || lgAfter.url.includes('login') ? 'PASS' : 'FAIL',
    `url=${lgAfter.url.slice(-40)}, ls=${lgAfter.token}`);
  await lp.screenshot({ path: path.join(OUT, '09-login-fail.png') });

  // ================= CMS =================
  const cms = await newPage();
  await cms.goto(BASE + '/cms_duan_hong.html', { waitUntil: 'networkidle2', timeout: 60000 });
  await sleep(1500);
  await cms.screenshot({ path: path.join(OUT, '10-cms-login.png') });
  const cmsBefore = await cms.evaluate(() => ({
    loginScreen: (() => { const d = document.getElementById('admin-login-screen'); return d ? getComputedStyle(d).display !== 'none' && !d.classList.contains('hidden') : null; })(),
    prefillPwd: (document.getElementById('cms-login-password') || {}).value || '',
    prefillId: (document.getElementById('cms-login-identifier') || {}).value || ''
  }));
  rec('TC-J01', 'CMS có màn hình đăng nhập', cmsBefore.loginScreen ? 'PASS' : 'FAIL', `loginScreen=${cmsBefore.loginScreen}`);
  rec('TC-E-warn', 'Không prefill mật khẩu', cmsBefore.prefillPwd ? 'FAIL' : 'PASS', `password field value="${cmsBefore.prefillPwd}"`);

  // BAD creds attempt
  const attacker = 'attacker' + Date.now().toString().slice(-4) + '@evil.com';
  await cms.evaluate((id) => {
    document.getElementById('cms-login-identifier').value = id;
    document.getElementById('cms-login-password').value = 'abc9';
    document.getElementById('cms-login-form').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
  }, attacker);
  await sleep(3500);
  await cms.screenshot({ path: path.join(OUT, '11-cms-after-badlogin.png') });
  const cmsAfter = await cms.evaluate(() => ({
    loginScreenHidden: (() => { const d = document.getElementById('admin-login-screen'); return d ? (getComputedStyle(d).display === 'none' || d.classList.contains('hidden')) : null; })(),
    bodySnippet: document.body.innerText.replace(/\s+/g, ' ').slice(0, 260),
    lsKeys: Object.keys(localStorage),
    role: localStorage.getItem('dh_cms_user') || localStorage.getItem('dh_current_user') || localStorage.getItem('cms_user') || ''
  }));
  rec('TC-E-bypass', 'CMS chặn đăng nhập sai (auth thật)', cmsAfter.loginScreenHidden ? 'FAIL' : 'PASS',
    `sau khi nhập mật khẩu sai "abc9" với email lạ: loginScreenHidden=${cmsAfter.loginScreenHidden}; ls=${cmsAfter.lsKeys.slice(0, 5).join(',')}`);
  if (cmsAfter.loginScreenHidden) rec('TC-E-bypass2', 'CHIẾM QUYỀN CMS', 'FAIL', `Vào được dashboard với tài khoản không tồn tại. Nội dung: ${cmsAfter.bodySnippet.slice(0, 120)}`);

  // ================= CONSOLE =================
  const uniqErr = [...new Set(errors)];
  rec('TC-L02', 'Console/network error khi duyệt site', uniqErr.length === 0 ? 'PASS' : 'FAIL', `${uniqErr.length} lỗi: ${uniqErr.slice(0, 5).join(' || ')}`);

  fs.writeFileSync(path.join(OUT, 'ui-results.json'), JSON.stringify({ results, errors: uniqErr }, null, 2));
  const counts = results.reduce((a, r) => (a[r.status] = (a[r.status] || 0) + 1, a), {});
  console.log('\n=== SUMMARY ===', JSON.stringify(counts));
  await browser.close();
})().catch(e => { console.error('FATAL:', e.message); process.exit(1); });
