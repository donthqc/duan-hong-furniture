const fs = require('fs'), path = require('path');
const p = require('puppeteer');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const ROOT = 'C:/Users/DELL/Documents/qa-web-ban-hang';
const IMG = path.join(ROOT, 'design', 'assets', 'img');
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const fx = ['hero-workshop.png', 'product-sofa-go-do.png'];

const runPhotos = () => { try { require('child_process').execFileSync(process.execPath, [path.join(ROOT, 'tools', 'photos.js')], { cwd: ROOT, stdio: 'ignore' }); } catch (e) {} };

fx.forEach(f => fs.writeFileSync(path.join(IMG, f), PNG));
runPhotos();

(async () => {
  const br = await p.launch({ headless: 'new', args: ['--no-sandbox'] });
  const pg = await br.newPage();
  await pg.setViewport({ width: 1440, height: 900 });
  await pg.goto('http://127.0.0.1:8098/trang-chu.html', { waitUntil: 'networkidle2' });
  await sleep(1200);
  await pg.screenshot({ path: path.join(ROOT, 'design', 'shots', 'anh-hero-that.jpg'), type: 'jpeg', quality: 80 });
  await pg.evaluate(() => document.querySelector('#catalog').scrollIntoView({ block: 'center', behavior: 'instant' }));
  await sleep(700);
  await pg.screenshot({ path: path.join(ROOT, 'design', 'shots', 'anh-card-that.jpg'), type: 'jpeg', quality: 80 });
  console.log('chup xong');
  await br.close();
  fx.forEach(f => { try { fs.unlinkSync(path.join(IMG, f)); } catch (e) {} });
  runPhotos();
})();
