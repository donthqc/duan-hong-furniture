// Kiểm thử giao diện động: không sửa dữ liệu và không cấu hình API giả.
const puppeteer = require('puppeteer');
const url = process.argv[2] || 'http://127.0.0.1:8096';
const sleep = n => new Promise(r => setTimeout(r, n));
(async () => {
  const browser = await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:180000});
  let failures = 0;
  for (const width of [375, 1440]) {
    const page = await browser.newPage();
    await page.setViewport({width,height:900});
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    for (const name of ['trang-chu','pdp','quy-trinh','cong-trinh','lo-ban','tra-cuu','dat-lich','index']) {
      const response = await page.goto(url+'/'+name+'.html', {waitUntil:'networkidle2',timeout:45000});
      await sleep(400);
      const result = await page.evaluate(() => ({
        overflow: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1,
        css: [...document.querySelectorAll('link[rel=stylesheet]')].some(e => e.getAttribute('href') === 'motion.css'),
        js: Boolean(window.DH_MOTION),
        titleVisible: !!document.querySelector('h1') && getComputedStyle(document.querySelector('h1')).opacity !== '0',
      }));
      const ok = [200, 304].includes(response.status()) && result.css && result.js && !result.overflow && result.titleVisible;
      if(!ok) failures++;
      console.log(`${ok?'PASS':'FAIL'} ${width} ${name} ${JSON.stringify(result)} HTTP ${response.status()}`);
    }
    if(errors.length) {failures++; console.log('FAIL pageerror',JSON.stringify(errors));}
    await page.close();
  }
  const reduced = await browser.newPage();
  await reduced.emulateMediaFeatures([{name:'prefers-reduced-motion',value:'reduce'}]);
  await reduced.goto(url+'/trang-chu.html',{waitUntil:'networkidle2'});
  await reduced.evaluate(()=>document.querySelector('#catalog .prod').scrollIntoView({behavior:'instant',block:'center'}));
  await reduced.hover('#catalog .prod');
  await sleep(200);
  const translate = await reduced.$eval('#catalog .prod', e=>getComputedStyle(e).translate);
  if(translate !== 'none') {failures++; console.log('FAIL reduced hover',translate);} else console.log('PASS reduced hover',translate);
  await reduced.close();
  await browser.close();
  console.log('KẾT QUẢ: '+failures+' lỗi');
  process.exitCode = failures ? 1 : 0;
})().catch(e=>{console.error('FATAL',e);process.exitCode=1;});
