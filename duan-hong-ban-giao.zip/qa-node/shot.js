const puppeteer=require('puppeteer');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const OUT='C:/Users/DELL/Documents/qa-web-ban-hang/prototype/';
(async()=>{
const b=await puppeteer.launch({headless:'new',args:['--no-sandbox'],protocolTimeout:120000});
const errs=[];
// desktop
const p=await b.newPage(); await p.setViewport({width:1440,height:900,deviceScaleFactor:1});
p.on('pageerror',e=>errs.push('pageerror: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text().slice(0,120));});
await p.goto('file:///C:/Users/DELL/Documents/qa-web-ban-hang/prototype/trang-chu-moi.html',{waitUntil:'networkidle0'});
await sleep(900);
await p.screenshot({path:OUT+'shot-desktop-hero.png'});
await p.screenshot({path:OUT+'shot-desktop-full.png',fullPage:true});
// lo ban test
const r1=await p.evaluate(()=>{document.getElementById('chieu-dai').value=280;tinhLoBan();return document.getElementById('kq-loban').innerText.replace(/\s+/g,' ');});
const r2=await p.evaluate(()=>{document.getElementById('chieu-dai').value=283;tinhLoBan();return document.getElementById('kq-loban').innerText.replace(/\s+/g,' ');});
console.log('LOBAN 280:',r1);
console.log('LOBAN 283:',r2);
// tracker test
const t1=await p.evaluate(()=>{document.getElementById('ma-don').value='DH-801';document.getElementById('sdt4').value='5889';traCuu();return document.getElementById('kq').innerText.replace(/\s+/g,' ');});
const t2=await p.evaluate(()=>{document.getElementById('sdt4').value='0000';traCuu();return document.getElementById('kq').innerText.replace(/\s+/g,' ');});
console.log('TRACK ok:',t1);
console.log('TRACK wrong phone:',t2);
// form validation
const f1=await p.evaluate(()=>{document.getElementById('ten').value='A';document.getElementById('sdt').value='123';guiYeuCau({preventDefault(){},target:{reset(){}}});return document.getElementById('kq-form').innerText.replace(/\s+/g,' ');});
console.log('FORM invalid:',f1);
const f2=await p.evaluate(()=>{document.getElementById('ten').value='Nguyễn Văn A';document.getElementById('sdt').value='0901234567';guiYeuCau({preventDefault(){},target:{reset(){}}});return document.getElementById('kq-form').innerText.replace(/\s+/g,' ');});
console.log('FORM valid:',f2);
// overflow check
for(const w of [390,768,1024,1440]){
  const q=await b.newPage(); await q.setViewport({width:w,height:900});
  await q.goto('file:///C:/Users/DELL/Documents/qa-web-ban-hang/prototype/trang-chu-moi.html',{waitUntil:'networkidle0'});
  await sleep(400);
  const o=await q.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth}));
  console.log(`OVERFLOW ${w}px:`,o.sw,'vs',o.cw, o.sw<=o.cw+1?'OK':'TRÀN');
  if(w===390) await q.screenshot({path:OUT+'shot-mobile.png'});
  await q.close();
}
console.log('ERRORS:',errs.length?errs:'none');
await b.close();})();
