const puppeteer = require('puppeteer');
(async () => {
  const br = await puppeteer.launch({ headless: 'new', args: ['--no-sandbox'] });
  const p = await br.newPage();
  await p.setViewport({ width: 375, height: 800, isMobile: true, hasTouch: true });
  await p.goto('http://127.0.0.1:8098/trang-chu.html', { waitUntil: 'networkidle2' });
  await new Promise(r => setTimeout(r, 500));
  const info = await p.evaluate(() => [...document.querySelectorAll('a[href^="tel:"]')].map((a, i) => {
    const r = a.getBoundingClientRect();
    const cs = getComputedStyle(a);
    const sec = a.closest('section,footer,header,div[class]');
    return {
      i, text: a.innerText.trim().slice(0, 30),
      w: Math.round(r.width), h: Math.round(r.height),
      top: Math.round(r.top + scrollY),
      inline: cs.display, pad: cs.padding, lh: cs.lineHeight, fs: cs.fontSize,
      parent: sec ? (sec.tagName.toLowerCase() + '.' + (sec.className || '').toString().slice(0, 40)) : ''
    };
  }));
  console.log(JSON.stringify(info, null, 1));
  console.log('page height:', await p.evaluate(() => document.body.scrollHeight));
  await br.close();
})();
