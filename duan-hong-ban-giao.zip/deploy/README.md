# Triển khai lên máy chủ thật

Thư mục này chứa cấu hình để đưa website + backend lên VPS Ubuntu. **Chưa có gì được chạy tự động trên máy bạn** — đây là bộ file để bạn mang lên server.

## Có gì

| File | Dùng để |
|---|---|
| `.env.example` | Mẫu biến môi trường → copy thành `/etc/duanhong/api.env` |
| `duanhong-api.service` | systemd unit → backend tự chạy lại khi crash/reboot |
| `nginx-duanhong.conf` | Nginx: phục vụ web tĩnh + proxy API, SSL, HSTS, CSP, rate limit |
| `deploy.sh` | Script cài đặt một lần: kiểm tra Node, copy code, tạo DB, bật service, smoke test |

## Trước khi chạy — 4 việc phải tự làm

1. **Trỏ DNS**: bản ghi `A` cho `duanhong.vn`, `www`, `api` về IP máy chủ.
2. **Cài Node ≥ 22.5**:
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
   apt install -y nodejs
   node -v   # phải ≥ v22.5.0
   ```
3. **Sinh 2 chuỗi bí mật**:
   ```bash
   openssl rand -hex 32   # → ADMIN_TOKEN
   openssl rand -hex 16   # → PHONE_SALT
   ```
4. **Sửa `/etc/duanhong/api.env`** — script sẽ tự tạo từ mẫu rồi **dừng lại** để bạn điền. Điền xong chạy lại script.

## Chạy

```bash
# lần đầu
sudo ./deploy.sh                 # sẽ dừng ở bước cấu hình để bạn điền env
sudo nano /etc/duanhong/api.env  # điền ADMIN_TOKEN, PHONE_SALT, DB_PATH
sudo ./deploy.sh                 # chạy lại → cài đặt hoàn tất

# cập nhật code sau này
sudo ./deploy.sh --keep-data     # giữ nguyên lead & đơn
```

Không dùng `--keep-data` thì script **sao lưu** DB cũ thành `.bak-<ngày>` rồi nạp lại dữ liệu mẫu.

## Script làm gì (8 bước)

1. Chặn nếu Node < 22.5, in hướng dẫn nâng cấp
2. Tạo `/var/www/duanhong` + `/var/lib/duanhong`, set quyền `www-data`
3. Copy website tĩnh (bỏ `_build`, `_tools`, `*.py`, `shots`)
4. Kiểm `api.env` — thiếu thì tạo từ mẫu rồi **dừng**, không đoán giá trị
5. Sao lưu DB cũ → reset dữ liệu mẫu (hoặc giữ nếu `--keep-data`)
6. Cài `duanhong-api.service`, `systemctl restart`, kiểm đang chạy
7. Smoke test: `/api/health` phải `UP`, `/api/products` phải > 0 sản phẩm
8. Copy Nginx config, `nginx -t`, reload

Nếu bước 6 hoặc 7 fail, script in log `journalctl` và **thoát với mã lỗi** — không báo "xong" khi chưa chạy được.

## SSL

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d duanhong.vn -d www.duanhong.vn -d api.duanhong.vn
```

Certbot sẽ tự sửa block `listen 80` và thêm chứng chỉ. Sau đó kiểm:

```bash
curl -I https://duanhong.vn/
curl -s https://api.duanhong.vn/api/health
curl -I https://duanhong.vn/sitemap.xml
curl -I https://duanhong.vn/assets/og-xuong.jpg
```

## Sao lưu

Database là một file SQLite. Cron hằng ngày:

```bash
sudo crontab -e
# 2h sáng mỗi ngày, giữ 14 bản
0 2 * * * sqlite3 /var/lib/duanhong/duanhong.db ".backup '/var/backups/duanhong-$(date +\%F).db'" && find /var/backups -name 'duanhong-*.db' -mtime +14 -delete
```

Nếu chưa có `sqlite3` CLI: `apt install -y sqlite3`.

## Kiểm tra sau khi lên

```bash
systemctl status duanhong-api
journalctl -u duanhong-api -n 50 --no-pager
sudo nginx -t
tail -f /var/log/nginx/duanhong.error.log
```

## Những gì script KHÔNG làm (và không nên tự động hoá)

- **Không** cấp SSL (cần domain đã trỏ DNS — certbot sẽ fail nếu chưa trỏ xong)
- **Không** điền `ADMIN_TOKEN`/`PHONE_SALT` hộ bạn — bịa giá trị bí mật là thảm hoạ
- **Không** thêm ảnh thật — bạn nói sẽ thêm sau, xem `04-website/HUONG-DAN-THEM-ANH.md`
- **Không** gửi Zalo ZNS — chưa nối, và cần tài khoản Zalo OA của xưởng

## Nếu dùng Cloudflare Pages / static host thay VPS

Website tĩnh (`04-website/`) chạy được trên Cloudflare Pages, Netlify, Vercel mà không cần Nginx. Khi đó:
- Bỏ block `location`, chỉ upload thư mục `04-website/`
- Backend vẫn phải chạy trên VPS (hoặc Fly.io/Render) vì cần SQLite ghi được
- Sửa `ALLOWED_ORIGINS` cho đúng domain Pages
- `api.js` sẽ gọi `https://api.duanhong.vn` — trỏ subdomain đó về VPS
