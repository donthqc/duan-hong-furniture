#!/usr/bin/env bash
# ==========================================================================
# Triển khai website xưởng mộc Duân Hồng lên VPS Ubuntu.
#
#   sudo ./deploy.sh              # cài đặt / cập nhật
#   sudo ./deploy.sh --keep-data  # giữ nguyên lead & đơn đang có
#
# Script này KHÔNG tự chạy: đọc hết rồi mới chạy.
# ==========================================================================
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WEB_ROOT="/var/www/duanhong"
DATA_DIR="/var/lib/duanhong"
API_USER="www-data"
NODE_MIN_MAJOR=22
NODE_MIN_MINOR=5
KEEP_DATA=0

for arg in "$@"; do
  case "$arg" in
    --keep-data) KEEP_DATA=1 ;;
    -h|--help) sed -n '2,12p' "$0"; exit 0 ;;
  esac
done

say() { printf '\n\033[1;33m▸ %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

[[ $EUID -eq 0 ]] || die "Phải chạy bằng sudo: sudo ./deploy.sh"

# ───────────────────────── 1. Kiểm tra Node ≥ 22.5 ─────────────────────────
say "Kiểm tra Node.js"
command -v node >/dev/null || die "Chưa cài Node.js. Cài bằng: curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && apt install -y nodejs"
NODE_V="$(node -v)"
MAJ="$(echo "$NODE_V" | sed 's/^v//' | cut -d. -f1)"
MIN="$(echo "$NODE_V" | sed 's/^v//' | cut -d. -f2)"
echo "  Node $NODE_V"
if (( MAJ < NODE_MIN_MAJOR )) || { (( MAJ == NODE_MIN_MAJOR )) && (( MIN < NODE_MIN_MINOR )); }; then
  die "Cần Node ≥ ${NODE_MIN_MAJOR}.${NODE_MIN_MINOR} (node:sqlite). Đang có $NODE_V.
     Cài bản mới:  curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && apt install -y nodejs
     Hoặc dùng nvm:  nvm install 22 && nvm use 22"
fi
echo "  ✓ Node đủ điều kiện"

# ───────────────────────── 2. Thư mục & quyền ─────────────────────────
say "Chuẩn bị thư mục"
mkdir -p "$WEB_ROOT" "$DATA_DIR"
chown -R "$API_USER:$API_USER" "$DATA_DIR"
chmod 750 "$DATA_DIR"
echo "  web:  $WEB_ROOT"
echo "  data: $DATA_DIR"

# ───────────────────────── 3. Copy mã nguồn ─────────────────────────
say "Copy website tĩnh"
rsync -a --delete \
  --exclude='_build' --exclude='_tools' --exclude='*.py' --exclude='shots' \
  "$SRC/04-website/" "$WEB_ROOT/04-website/"
chown -R root:root "$WEB_ROOT/04-website"
find "$WEB_ROOT/04-website" -type d -exec chmod 755 {} \;
find "$WEB_ROOT/04-website" -type f -exec chmod 644 {} \;

say "Copy backend"
rsync -a --delete \
  --exclude='node_modules' --exclude='data' \
  "$SRC/05-backend-database/" "$WEB_ROOT/05-backend-database/"
chown -R "$API_USER:$API_USER" "$WEB_ROOT/05-backend-database"
echo "  ✓ $WEB_ROOT"

# ───────────────────────── 4. Biến môi trường ─────────────────────────
say "Kiểm tra cấu hình môi trường"
ENV_FILE="/etc/duanhong/api.env"
if [[ ! -f "$ENV_FILE" ]]; then
  mkdir -p /etc/duanhong
  cp "$SRC/deploy/.env.example" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  chown root:root "$ENV_FILE"
  echo "  Đã tạo $ENV_FILE từ mẫu."
  echo "  ⚠  PHẢI sửa 3 giá trị sau rồi chạy lại script:"
  echo "       ADMIN_TOKEN   →  openssl rand -hex 32"
  echo "       PHONE_SALT    →  openssl rand -hex 16"
  echo "       ALLOWED_ORIGINS, DB_PATH"
  die "Dừng lại để bạn điền cấu hình. Sửa xong chạy lại: sudo ./deploy.sh"
fi
chmod 600 "$ENV_FILE"

# shellcheck disable=SC1090
set -a; source "$ENV_FILE"; set +a

[[ "${ADMIN_TOKEN:-}" == THAY_BANG* ]] && die "ADMIN_TOKEN còn là giá trị mẫu trong $ENV_FILE"
[[ "${PHONE_SALT:-}"  == THAY_BANG* ]] && die "PHONE_SALT còn là giá trị mẫu trong $ENV_FILE"

[[ "${NODE_ENV:-}" == "production" ]] || echo "  ⚠ NODE_ENV chưa phải production → rate limit sẽ nới rộng"
echo "  ✓ Cấu hình hợp lệ"

# ───────────────────────── 5. Database ─────────────────────────
say "Chuẩn bị database"
cd "$WEB_ROOT/05-backend-database"
if [[ $KEEP_DATA -eq 1 && -f "${DB_PATH:-}" ]]; then
  echo "  --keep-data: giữ nguyên $(du -h "$DB_PATH" | cut -f1) dữ liệu hiện có"
else
  if [[ -f "${DB_PATH:-}" ]]; then
    BACKUP="${DB_PATH}.bak-$(date +%Y%m%d-%H%M%S)"
    cp "$DB_PATH" "$BACKUP"
    echo "  Đã sao lưu: $BACKUP"
  fi
  echo "  Xoá dữ liệu test và nạp lại mẫu…"
  sudo -u "$API_USER" DB_PATH="$DB_PATH" node src/reset.js --yes
fi
chown -R "$API_USER:$API_USER" "$DATA_DIR"

# ───────────────────────── 6. systemd ─────────────────────────
say "Cài dịch vụ systemd"
cp "$SRC/deploy/duanhong-api.service" /etc/systemd/system/duanhong-api.service
systemctl daemon-reload
systemctl enable duanhong-api >/dev/null 2>&1
systemctl restart duanhong-api
sleep 2
if systemctl is-active --quiet duanhong-api; then
  echo "  ✓ duanhong-api đang chạy"
else
  journalctl -u duanhong-api -n 30 --no-pager
  die "Dịch vụ không khởi động được — xem log ở trên"
fi

# ───────────────────────── 7. Smoke test ─────────────────────────
say "Smoke test API"
HEALTH="$(curl -fsS --max-time 5 "http://127.0.0.1:${PORT:-5055}/api/health" || true)"
if echo "$HEALTH" | grep -q '"status":"UP"'; then
  echo "  ✓ /api/health: $HEALTH"
else
  die "Health check thất bại. Log: journalctl -u duanhong-api -n 50"
fi

PROD_COUNT="$(curl -fsS "http://127.0.0.1:${PORT:-5055}/api/products" | grep -o '"count":[0-9]*' | cut -d: -f2 || echo 0)"
echo "  ✓ /api/products: $PROD_COUNT sản phẩm"
(( PROD_COUNT > 0 )) || die "API trả 0 sản phẩm — kiểm tra DB_PATH và quyền ghi"

# ───────────────────────── 8. Nginx ─────────────────────────
say "Cấu hình Nginx"
if command -v nginx >/dev/null; then
  cp "$SRC/deploy/nginx-duanhong.conf" /etc/nginx/sites-available/duanhong
  ln -sf /etc/nginx/sites-available/duanhong /etc/nginx/sites-enabled/duanhong
  nginx -t || die "Cấu hình Nginx sai — không reload"
  systemctl reload nginx
  echo "  ✓ Nginx đã reload"
  echo "  Nhắc: chạy certbot nếu chưa có SSL:"
  echo "    sudo certbot --nginx -d duanhong.vn -d www.duanhong.vn -d api.duanhong.vn"
else
  echo "  Nginx chưa cài — bỏ qua bước này"
fi

# ───────────────────────── 9. Tổng kết ─────────────────────────
say "HOÀN TẤT"
cat <<EOF
  Website : $WEB_ROOT/04-website
  Backend : http://127.0.0.1:${PORT:-5055}
  Database: ${DB_PATH:-?}
  Log     : journalctl -u duanhong-api -f

  Kiểm tra sau khi trỏ domain:
    curl -I https://duanhong.vn/
    curl -s https://api.duanhong.vn/api/health
    curl -I https://duanhong.vn/sitemap.xml

  Nhắc lại việc chưa làm được tự động:
    - Trỏ DNS A record cho duanhong.vn / www / api về IP máy này
    - Chạy certbot để lấy SSL
    - Thêm ảnh thật vào $WEB_ROOT/04-website/assets/img (xem HUONG-DAN-THEM-ANH.md)
EOF
