# KẾ HOẠCH PHÁT TRIỂN WEBSITE DUÂN HỒNG

**Phiên bản:** 1.0  
**Định hướng:** Xưởng mộc may đo minh bạch  
**Mục tiêu:** biến website từ bản giới thiệu có API thành kênh tạo và quản lý khách hàng thực tế.

---

## 0. Nguyên tắc chung

1. Ưu tiên tạo lead thật trước khi mở rộng tính năng.
2. Không dùng số liệu, ảnh, đánh giá hoặc cam kết chưa được xưởng xác nhận.
3. Không đưa dữ liệu khách thật lên link preview hoặc frontend công khai.
4. Mọi tính năng có dữ liệu động phải có bốn trạng thái: đang tải, rỗng, lỗi, thành công.
5. Mỗi giai đoạn chỉ được coi là hoàn tất khi có kiểm thử và bằng chứng.
6. Không triển khai production nếu chưa có sao lưu và phương án khôi phục.
7. Giữ cấu trúc tinh gọn: HTML/CSS/JS thuần, `node:http`, SQLite ở giai đoạn đầu.
8. Không tích hợp lại Zalo/ZNS/OTP nếu chưa có yêu cầu mới bằng văn bản.

---

## Tóm tắt lộ trình

| Giai đoạn | Mục tiêu | Đầu ra chính | Điều kiện chuyển tiếp |
|---|---|---|---|
| 0 | Chốt phạm vi và dữ liệu thật | Spec nghiệp vụ, danh sách nội dung | Chủ xưởng duyệt |
| 1 | Ổn định nền tảng | Bản frontend/backend sạch, test baseline | Không còn lỗi chặn |
| 2 | Thu lead thật | Form → API → Google Sheets | Ghi và đọc lại thành công |
| 3 | Bổ sung nội dung bán hàng | Ảnh thật, sản phẩm, công trình | Nội dung được duyệt |
| 4 | Đưa lên production | Domain, HTTPS, VPS, backup | Smoke test production pass |
| 5 | Quản lý vận hành | Màn hình admin/lead/CMS tối thiểu | Phân quyền và audit pass |
| 6 | SEO và đo chuyển đổi | SEO địa phương, analytics sự kiện | Không lộ PII, đo đúng |
| 7 | Tối ưu dài hạn | CRM, báo giá, tiến độ nâng cao | Có dữ liệu vận hành đủ |

---

# GIAI ĐOẠN 0 — CHỐT PHẠM VI VÀ DỮ LIỆU

## Mục tiêu
Không xây tính năng dựa trên dữ liệu đoán hoặc nội dung chưa được xưởng xác nhận.

## Việc cần làm

### 0.1 Chốt thông tin doanh nghiệp
- Tên thương hiệu, tên pháp lý nếu công khai.
- Địa chỉ xưởng, khu vực nhận thi công.
- Hotline, email, giờ làm việc.
- Chính sách cọc, giao hàng, lắp đặt.
- Thời gian sản xuất và bảo hành thực tế.
- Người phụ trách nhận lead và thời gian phản hồi mục tiêu.

### 0.2 Chốt catalogue
Tạo bảng nội bộ cho từng sản phẩm:
- Tên sản phẩm và slug.
- Nhóm phòng.
- Loại gỗ.
- Kích thước chuẩn và phạm vi may đo.
- Giá tham khảo hoặc quy tắc báo giá.
- Thời gian làm.
- Ảnh cần có.
- Trạng thái: được phép công khai / cần xác nhận / chưa công khai.

### 0.3 Chốt công trình
Mỗi công trình cần:
- Tên hoặc mã công trình không lộ địa chỉ khách.
- Khu vực ở mức đủ dùng, không công khai thông tin riêng tư.
- Hạng mục.
- Vật liệu và quy cách.
- Ảnh được khách/xưởng cho phép sử dụng.
- Thời gian hoàn thiện.
- Giá chỉ công khai khi được duyệt.

## Đầu ra
- `SPEC-NGHIEP-VU.md`.
- Bảng catalogue nội bộ.
- Danh sách ảnh cần chụp.
- Bảng quyền sử dụng ảnh.
- Quyết định nội dung nào chưa được phép công khai.

## Tiêu chí nghiệm thu
- Chủ xưởng duyệt bằng văn bản.
- Không còn số liệu placeholder trong nội dung công khai.
- Mỗi cam kết về giá, thời gian, bảo hành có nguồn xác nhận.

---

# GIAI ĐOẠN 1 — ỔN ĐỊNH NỀN TẢNG VÀ CHỐT BẢN BASELINE

## Mục tiêu
Có một bản mã nguồn sạch, chạy lặp lại được trước khi nối dịch vụ bên ngoài.

## Việc cần làm

### 1.1 Quản lý mã nguồn
- Chốt repository và nhánh production.
- Tách `design/`, `server/`, `qa-node/`, `deploy/` rõ ràng.
- Không commit `.env`, token, database thật, ảnh khách chưa được phép.
- Xoá/đánh dấu dữ liệu demo rõ ràng.
- Ghi phiên bản Node yêu cầu.

### 1.2 Kiểm thử baseline
Chạy từ database tạm và cổng riêng:
- Kiểm tra cú pháp toàn bộ JS.
- API health, sản phẩm, công trình, lead, đơn hàng, review.
- E2E form và tracker.
- 8 trang ở 375px và 1440px.
- Không tràn ngang, không lỗi console.
- Kiểm tra reduced motion.
- Kiểm tra gói ZIP sau khi giải nén.

### 1.3 Rà soát dữ liệu và bảo mật
- Endpoint admin fail closed khi thiếu token.
- Rate limit cho form, tracker và review.
- Không trả số điện thoại đầy đủ trong API công khai.
- Prepared statements cho toàn bộ SQL.
- Xác nhận CORS chỉ cho origin cần thiết.
- Xác nhận body-size limit.
- Kiểm tra XSS bằng nội dung HTML trong tên, nhu cầu, đánh giá.

## Đầu ra
- Báo cáo baseline.
- Log test có timestamp.
- Checklist release.
- Bản ZIP baseline đã kiểm tra.

## Tiêu chí nghiệm thu
- Không có lỗi chặn trong các bộ test hiện có.
- Không dùng database khách thật để test.
- Có lệnh khởi động và lệnh test được ghi rõ.

---

# GIAI ĐOẠN 2 — THU LEAD VÀ ĐỒNG BỘ GOOGLE SHEETS

## Mục tiêu
Mỗi form hợp lệ tạo ra một lead có thể truy vết, không mất khi Google Sheets lỗi.

## Kiến trúc đề xuất

```text
Form website
    ↓ HTTPS
Backend POST /api/leads
    ↓
SQLite: bản ghi chính (source of truth)
    ↓ hàng đợi/trạng thái đồng bộ
Google Sheets: bảng làm việc của xưởng
```

Không đặt Google credential trong frontend. Backend là nơi duy nhất gọi Google Sheets API.

## 2.1 Chuẩn bị Google Sheet
Tạo sheet `Khách hàng` với các cột:
- Thời gian gửi.
- Mã yêu cầu.
- Họ và tên.
- Số điện thoại.
- Khu vực / địa chỉ.
- Nhu cầu / nội dung.
- Nguồn.
- Trạng thái xử lý.
- Người phụ trách.
- Ghi chú.
- Thời gian liên hệ gần nhất.

Định dạng số điện thoại là văn bản; cố định hàng tiêu đề; bật bộ lọc; không công khai sheet.

## 2.2 Thiết kế đồng bộ
Bổ sung bảng hoặc cột nội bộ:
- `sheets_sync_status`: `pending`, `sent`, `failed`.
- `sheets_row_id` hoặc mã dòng nếu API trả về.
- `sheets_last_error`.
- `sheets_synced_at`.
- `sync_attempts`.

Không sửa trạng thái lead thành `sent` trước khi Google trả kết quả thành công.

## 2.3 Luồng gửi
1. Validate tên, điện thoại, nhu cầu ở server.
2. Tạo mã lead và lưu SQLite trong transaction.
3. Trả kết quả thành công cho frontend khi bản ghi nội bộ đã lưu.
4. Worker gửi bản ghi sang Sheets.
5. Nếu thất bại, retry có giới hạn và ghi lỗi.
6. Không tạo dòng trùng khi retry; dùng mã yêu cầu làm khóa idempotency.
7. Cho phép quản trị bấm đồng bộ lại các bản ghi failed.

## 2.4 Bảo mật và riêng tư
- Chỉ xin Google scope cần cho Sheets.
- Token OAuth ở server, không commit và không gửi qua chat.
- Hạn chế quyền chia sẻ sheet.
- Không gửi mật khẩu, token hoặc dữ liệu không cần thiết vào Sheet.
- Có thông báo riêng tư ngắn dưới form.
- Xác định thời hạn lưu và người được phép xem.

## 2.5 Kiểm thử bắt buộc
- Form hợp lệ → SQLite có row → Sheet có đúng một dòng.
- Double click → không tạo hai lead.
- Google lỗi → SQLite vẫn giữ lead, trạng thái `failed`.
- Retry → không nhân bản dòng.
- Tên/nhu cầu chứa HTML → không XSS.
- Số điện thoại sai → không ghi.
- Thiếu credential → backend báo lỗi vận hành, không báo thành công giả.
- Không đưa dữ liệu test lên Sheet production.

## Đầu ra
- Google Sheet riêng tư.
- Module tích hợp Sheets ở backend.
- Log đồng bộ và retry.
- Test integration dùng Sheet/test account hoặc mock rõ ràng.
- Hướng dẫn xử lý lead cho xưởng.

## Tiêu chí nghiệm thu
- 10 lần gửi hợp lệ tạo đúng 10 mã và 10 dòng, không trùng.
- 1 lần cố ý làm Google lỗi vẫn giữ được lead trong SQLite.
- Đọc lại SQLite và Sheet để đối chiếu, không chỉ dựa vào HTTP 200.

---

# GIAI ĐOẠN 3 — ẢNH THẬT VÀ NỘI DUNG BÁN HÀNG

## Mục tiêu
Tăng niềm tin bằng bằng chứng thật, không tăng bằng hiệu ứng hoặc lời hứa.

## 3.1 Shot list ảnh sản phẩm
Mỗi sản phẩm tối thiểu:
- Ảnh toàn cảnh.
- Ảnh góc nghiêng cho thấy tỷ lệ.
- Ảnh cận vân gỗ.
- Ảnh mộng, cạnh, hoàn thiện bề mặt.
- Ảnh có kích thước hoặc người đứng cạnh để tham chiếu tỷ lệ khi phù hợp.

## 3.2 Shot list ảnh công trình
- Không gian trước khi thi công nếu được phép.
- Đo đạc hoặc bản vẽ đã ẩn thông tin riêng tư.
- Giai đoạn dựng thô.
- Giai đoạn hoàn thiện.
- Ảnh bàn giao.

## 3.3 Nội dung trang
- Tên và mô tả không phóng đại.
- Vật liệu và quy cách.
- Giá tham khảo kèm điều kiện.
- Thời gian dự kiến, không cam kết tuyệt đối nếu chưa chốt.
- Chính sách bảo hành được xác nhận.
- CTA rõ: `Đặt lịch`, `Nhận báo giá`, `Gọi xưởng`.

## 3.4 Quy trình duyệt
1. Người chụp nộp ảnh gốc.
2. Xưởng xác nhận ảnh đúng sản phẩm/công trình.
3. Kiểm tra đã che thông tin khách.
4. Ghi quyền sử dụng.
5. Tối ưu kích thước và alt text.
6. Đưa lên staging.
7. Chủ xưởng duyệt trước khi production.

## Tiêu chí nghiệm thu
- Không còn nhãn ảnh thật ở ô chưa có ảnh.
- Ảnh thật không gây layout shift đáng kể.
- Mobile không vỡ ảnh hoặc tràn ngang.
- Mỗi ảnh có alt mô tả đúng, không bịa.

---

# GIAI ĐOẠN 4 — DEPLOY PRODUCTION

## Mục tiêu
Website chạy ổn định trên domain thật, có HTTPS và có thể khôi phục dữ liệu.

## 4.1 Chuẩn bị hạ tầng
- VPS Linux hoặc nền tảng đã chọn.
- Domain và DNS.
- Node đúng phiên bản.
- Nginx reverse proxy.
- Process manager/systemd.
- Firewall chỉ mở 80/443 và SSH giới hạn.
- SSL tự động gia hạn.

## 4.2 Biến môi trường
Cấu hình riêng trên server:
- `PORT`.
- `ADMIN_TOKEN` hoặc cơ chế admin mạnh hơn.
- `PHONE_SALT`.
- `ALLOWED_ORIGINS` chỉ gồm domain thật.
- Google OAuth/Sheets credential.

Không đưa các giá trị này vào Git, frontend, ảnh chụp hoặc tài liệu công khai.

## 4.3 Database và backup
- Thư mục database không nằm trong web root.
- WAL/checkpoint theo cấu hình.
- Backup tự động hàng ngày.
- Giữ nhiều phiên bản backup.
- Backup được mã hóa và lưu ngoài VPS.
- Thử restore vào DB tạm hàng tuần.
- Không dùng `reset` trên production.

## 4.4 Smoke test production
- Trang chủ và 7 trang còn lại trả 200.
- HTTPS và redirect HTTP hoạt động.
- API health không lộ bí mật.
- Form test nội bộ tạo lead test, sau đó xóa/đánh dấu theo quy trình.
- Đọc lại row trong DB và Sheet.
- Chặn API thử nghiệm không làm frontend báo thành công giả.
- Không có lỗi console và không tràn ngang.

## Tiêu chí nghiệm thu
- Có URL domain thật.
- Có ảnh chụp cấu hình HTTPS, không lộ secret.
- Có log triển khai và smoke test.
- Có bản backup và bằng chứng restore thành công.
- Được chủ xưởng duyệt mở nhận lead thật.

---

# GIAI ĐOẠN 5 — ADMIN VÀ VẬN HÀNH LEAD

## Mục tiêu
Chủ xưởng xử lý lead mà không phải sửa trực tiếp trong database hoặc Google Sheet.

## MVP admin
- Đăng nhập bảo mật.
- Danh sách lead có phân trang.
- Lọc theo trạng thái/ngày/nguồn.
- Xem chi tiết lead.
- Ghi chú nội bộ.
- Đổi trạng thái.
- Gán người phụ trách.
- Nút gọi điện nhưng không tự động gửi tin.
- Nút đồng bộ lại Google Sheets.
- Audit log cho thay đổi quan trọng.

## Phân quyền
- Chủ xưởng: xem và cập nhật toàn bộ.
- Nhân viên tư vấn: chỉ xem lead được phân công hoặc phạm vi được cấp.
- Kỹ thuật: không mặc định xem số điện thoại đầy đủ.
- Không dùng một token chung lâu dài cho mọi người nếu có phương án tốt hơn.

## Tiêu chí nghiệm thu
- Người chưa đăng nhập không xem được lead.
- Người không đủ quyền không sửa được trạng thái.
- Mọi cập nhật có người thực hiện và thời gian.
- Không lộ PII trong log hoặc URL.

---

# GIAI ĐOẠN 6 — SEO ĐỊA PHƯƠNG VÀ ĐO CHUYỂN ĐỔI

## Mục tiêu
Thu hút đúng khách ở khu vực phục vụ và biết kênh nào tạo lead.

## SEO kỹ thuật
- Title/description/canonical cho 8 trang.
- Sitemap và robots đúng domain production.
- Một `h1` có ý nghĩa mỗi trang.
- Open Graph có ảnh thật khi đủ điều kiện.
- Schema `LocalBusiness`, `Product` hoặc `Article` chỉ dùng dữ liệu có thật.
- Tối ưu ảnh WebP/AVIF khi phù hợp.
- LCP và CLS đo trên production, không chỉ localhost.

## Nội dung
- Chọn 5–10 chủ đề có nhu cầu thật.
- Mỗi bài có câu hỏi, quy trình, ảnh hoặc ví dụ xác thực.
- Không viết hàng loạt bài SEO rỗng.
- Tạo Google Business Profile và đồng bộ thông tin NAP.

## Đo chuyển đổi
Các sự kiện nên đo:
- `click_hotline`.
- `submit_lead_success`.
- `book_visit`.
- `view_product`.
- `use_loban`.
- `track_order`.

Không gửi họ tên hoặc số điện thoại vào công cụ analytics. Dùng mã sự kiện ẩn danh.

## Tiêu chí nghiệm thu
- Có báo cáo tháng: lượt truy cập, cuộc gọi, form, lịch hẹn, nguồn lead.
- Đối chiếu được event với lead nhưng không lộ PII.
- Có banner/chính sách phù hợp nếu dùng cookie hoặc công cụ theo dõi cần đồng ý.

---

# GIAI ĐOẠN 7 — MỞ RỘNG DÀI HẠN

Chỉ thực hiện khi các giai đoạn 2–6 vận hành ổn định và có dữ liệu thực tế.

## 7.1 CRM riêng
- Thay Google Sheets bằng giao diện dữ liệu chính thức.
- Lịch sử liên hệ.
- Nhắc gọi lại.
- Phân loại nhu cầu.
- Báo cáo tỷ lệ chuyển đổi.

## 7.2 Báo giá
- Form kích thước.
- Chọn vật liệu/quy cách.
- Khoảng giá, không tự hứa giá chốt.
- Tạo PDF để nhân viên kiểm tra và gửi thủ công.

## 7.3 Theo dõi đơn hàng nâng cao
- Mã đơn và quyền truy cập an toàn.
- Ảnh từng bước đã được phép chia sẻ.
- Ghi chú sản xuất.
- Lịch giao/lắp đặt.
- Không hiển thị thông tin đơn của người khác.

## 7.4 Nội dung video
- Video ngắn theo quy trình.
- Video giải thích vật liệu.
- Video bàn giao nếu được phép.
- Phụ đề và thumbnail nhẹ để không ảnh hưởng tốc độ tải.

---

# BẢNG ƯU TIÊN THỰC HIỆN

## P0 — Không được trì hoãn
- Chốt dữ liệu doanh nghiệp và chính sách.
- Không lộ secret/PII.
- Form không báo thành công giả khi API lỗi.
- Backup và restore trước khi nhận dữ liệu thật.
- HTTPS và quyền admin.

## P1 — Làm ngay sau P0
- Đồng bộ Google Sheets.
- Ảnh thật và nội dung sản phẩm.
- Deploy domain thật.
- Quy trình tiếp nhận và gọi lại lead.

## P2 — Tăng trưởng
- Admin quản lý lead.
- SEO địa phương.
- Đo chuyển đổi.
- Trang công trình chi tiết.

## P3 — Khi đã có dữ liệu
- CRM riêng.
- Báo giá tự động có kiểm duyệt.
- Theo dõi đơn hàng nâng cao.
- Video và nội dung chuyên sâu.

---

# CHECKLIST CHUYỂN GIAI ĐOẠN

Mỗi lần chuyển giai đoạn phải có:

- [ ] Phạm vi và người chịu trách nhiệm.
- [ ] Dữ liệu đầu vào đã được xác nhận.
- [ ] Bằng chứng test pass.
- [ ] Bằng chứng đọc lại dữ liệu sau thao tác ghi.
- [ ] Bằng chứng bảo mật không lộ secret/PII.
- [ ] Kế hoạch rollback.
- [ ] Tài liệu hướng dẫn người vận hành.
- [ ] Chủ xưởng duyệt.

# ĐỀ XUẤT BƯỚC TIẾP THEO

Thực hiện **Giai đoạn 0 và 2 song song ở mức chuẩn bị**:

1. Chủ xưởng chốt cột dữ liệu và quyền xem Google Sheet.
2. Tạo Google Sheet riêng tư.
3. Cấu hình OAuth/Sheets ở backend, không đưa credential vào frontend.
4. Chạy test bằng database tạm và Sheet thử nghiệm.
5. Đọc lại SQLite và Sheet để xác nhận không mất hoặc trùng lead.
6. Chỉ sau đó mới gắn Sheet production và mở nhận khách thật.
