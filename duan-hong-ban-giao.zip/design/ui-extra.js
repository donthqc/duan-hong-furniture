/* ==========================================================================
   Duân Hồng — phần bổ sung: menu mobile, PDP theo ?id, gallery, tìm kiếm.
   Giữ nguyên API cũ; chỉ thêm hàm mới vào window.DH.
   ========================================================================== */
(function () {
  "use strict";
  var DH = window.DH;
  if (!DH) return;

  /* ---------------- 1. Menu mobile (tự sinh, không cần sửa 8 trang) ------- */
  function initMobileNav() {
    var nav = document.querySelector(".nav");
    var links = document.querySelector(".nav__links");
    if (!nav || !links || document.getElementById("mnav-btn")) return;

    var btn = document.createElement("button");
    btn.id = "mnav-btn";
    btn.className = "mnav-btn";
    btn.type = "button";
    btn.setAttribute("aria-label", "Mở menu");
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-controls", "mnav-panel");
    btn.innerHTML = '<span class="mnav-bar"></span><span class="mnav-bar"></span><span class="mnav-bar"></span>';

    var panel = document.createElement("div");
    panel.id = "mnav-panel";
    panel.className = "mnav-panel";
    panel.hidden = true;
    panel.innerHTML =
      '<nav aria-label="Điều hướng trên điện thoại">' +
      Array.prototype.map.call(links.querySelectorAll("a"), function (a) {
        return '<a href="' + a.getAttribute("href") + '">' + a.textContent.trim() + "</a>";
      }).join("") +
      "</nav>" +
      '<a class="btn btn--primary btn--block" href="dat-lich.html">Đặt thợ đo tại nhà</a>';

    nav.appendChild(btn);
    document.body.appendChild(panel);

    function setOpen(open) {
      panel.hidden = !open;
      btn.setAttribute("aria-expanded", String(open));
      btn.setAttribute("aria-label", open ? "Đóng menu" : "Mở menu");
      document.body.classList.toggle("mnav-open", open);
    }

    btn.addEventListener("click", function () {
      setOpen(panel.hidden);
    });
    panel.addEventListener("click", function (e) {
      if (e.target.closest("a")) setOpen(false);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !panel.hidden) {
        setOpen(false);
        btn.focus();
      }
    });
    // đổi lên desktop thì đóng panel để không kẹt trạng thái
    window.addEventListener("resize", function () {
      if (window.innerWidth > 960 && !panel.hidden) setOpen(false);
    });
  }

  /* ---------------- 2. PDP render theo ?id ------------------------------- */
  var PDP_EXTRA = {
    "sofa-go-do": {
      wood: "go-do",
      composeTitle: "Bộ 5 món gồm những gì",
      compose: ["01 văng dài 2m80 — mặt nguyên tấm dày 12cm", "01 văng ngắn 1m90", "01 bàn trà nguyên khối", "01 ghế đơn chân quỳ", "01 đôn kẹp"],

      configs: [
        { label: "Bộ 5 món (tiêu chuẩn)", price: 74500000, note: "Bộ 5 món · giá tại xưởng, đã gồm công đục và sơn PU" },
        { label: "Bộ 3 món", price: null, note: "Bộ 3 món · cần đo để báo giá chính xác" },
        { label: "Theo kích thước phòng", price: null, note: "Làm theo kích thước phòng · báo giá sau khi đo" }
      ],
      desc: "Bộ sofa 5 món gỗ Gõ Đỏ Pachy cho phòng khách, đóng theo kích thước phòng và cung Lỗ Ban. Gia chủ kiểm tra phôi mộc và ký tên trước khi sơn PU."
    },
    "an-gian-tho": {
      wood: "huong-da",
      composeTitle: "Cấu tạo án gian",
      compose: ["Khung 2 cấp, cao 2m17 tính cả bệ", "Vách hậu ván 2cm chạm kênh bong", "Sập thờ mặt liền, có ngăn kéo hai bên", "Bệ đế liền khối, chân quỳ chạm nổi"],

      configs: [
        { label: "Cao 2m17 · 2 cấp", price: 48000000, note: "Quy cách tiêu chuẩn · gỗ Hương Đá chọn thớ" },
        { label: "Theo kích thước bàn thờ", price: null, note: "Đo theo hiện trạng · báo giá sau khi đo" }
      ],
      desc: "Án gian thờ nhị cấp gỗ Hương Đá, chạm kênh bong, đo theo khoảng lọt lòng của phòng thờ. Số đo được ghi vào phiếu bảo hành 5 năm."
    },
    "combo-phong-ngu": {
      wood: "soi-nga",
      composeTitle: "Combo gồm những gì",
      compose: ["01 giường 1m8 kéo ngăn", "02 tủ đầu giường", "01 tủ quần áo 4 cánh", "01 bàn trang điểm kèm ghế"],

      configs: [
        { label: "Combo 4 món (tiêu chuẩn)", price: 36900000, note: "4 món · Sồi Nga nhập khẩu, đã gồm công đục và sơn PU" },
        { label: "Thêm món / đổi kích thước", price: null, note: "Điều chỉnh theo nhu cầu · báo giá sau khi đo" }
      ],
      desc: "Combo phòng ngủ 4 món gỗ Sồi Nga: giường 1m8, tủ 4 cánh kịch trần, 2 tab đầu giường và bàn phấn. Đóng theo chiều cao trần thực tế."
    },
    "ban-an-live-edge": {
      wood: "go-do",
      composeTitle: "Cấu tạo bàn",
      compose: ["Mặt bàn nguyên tấm dày 6–8cm, giữ nguyên đường viền tự nhiên", "Chân thép hộp sơn tĩnh điện hoặc chân gỗ theo chọn", "Gia cố thanh xương chống cong vênh mặt bàn"],

      configs: [
        { label: "Dài 2m20 · 8 ghế", price: 38000000, note: "Mặt nguyên tấm · gỗ Gõ Đỏ, cạnh tự nhiên" },
        { label: "Theo kích thước phòng ăn", price: null, note: "Chốt số ghế và chiều dài sau khi đo" }
      ],
      desc: "Bàn ăn live-edge giữ nguyên cạnh tự nhiên của tấm gỗ, mặt dày 12cm. Chiều dài chốt theo phòng ăn và số người dùng."
    },
    "tu-bep-mdf": {
      wood: "mdf",
      composeTitle: "Cấu tạo tủ bếp",
      compose: ["Thùng tủ MDF chống ẩm phủ melamine", "Cánh Acrylic bóng gương", "Phụ kiện giảm chấn, ray hộp", "Mặt bếp đá hoặc inox theo chọn"],

      configs: [
        { label: "Theo mét dài", price: null, note: "Báo giá theo mét dài sau khi đo" }
      ],
      desc: "Tủ bếp cánh phẳng MDF lõi xanh chống ẩm An Cường, ray giảm chấn. Giá tính theo mét dài và cấu hình khoang."
    },
    "tu-quan-ao-soi": {
      wood: "soi-nga",
      composeTitle: "Cấu tạo tủ",
      compose: ["Thùng tủ sồi Nga ghép tấm, khung hậu 8mm", "Cánh phẳng hoặc cánh kính theo chọn", "Ray giảm chấn, thanh treo inox, kệ điều chỉnh được"],

      configs: [
        { label: "Cao kịch trần", price: null, note: "Đo chiều cao trần thực tế · báo giá sau khi đo" }
      ],
      desc: "Tủ quần áo 4 cánh kịch trần gỗ Sồi Nga, chia khoang theo nhu cầu sử dụng. Có thể đặt trong combo Tổ Ấm hoặc làm lẻ."
    }
  };

  function initPdp() {
    if (document.body.dataset.page !== "pdp") return;
    var id = new URLSearchParams(location.search).get("id") || "sofa-go-do";
    var p = (DH.PRODUCTS || []).filter(function (x) { return x.id === id; })[0];
    if (!p) return;
    var extra = PDP_EXTRA[id] || null;

    // tiêu đề, tag, breadcrumb
    var h1 = document.querySelector("h1");
    if (h1) h1.textContent = p.name;
    var tag = document.querySelector(".pdp__tag");
    if (tag) tag.textContent = p.tag + " · " + DH.WOOD_LABEL[p.wood];
    var crumb = document.querySelector('.crumbs li[aria-current="page"]');
    if (crumb) crumb.textContent = p.name;

    // giá
    var priceEl = document.getElementById("pdp-price");
    var noteEl = document.getElementById("pdp-price-note");
    if (priceEl) {
      priceEl.firstChild.textContent = p.price ? DH.vnd(p.price) : "Báo giá theo kích thước";
    }
    if (noteEl) noteEl.textContent = p.priceNote;

    // dòng quy cách dưới giá (nếu có)
    var specEl = document.getElementById("pdp-spec");
    if (specEl) specEl.textContent = p.spec;

    // danh sách quy cách
    var box = document.getElementById("opt-config");
    if (box && extra) {
      box.innerHTML = extra.configs.map(function (c, i) {
        return '<button class="opt__btn" aria-pressed="' + (i === 0) + '" data-price="' +
          (c.price || "") + '" data-note="' + c.note + '">' + c.label + "</button>";
      }).join("");
    }

    // mô tả ngắn trong tab 1
    var descEl = document.getElementById("pdp-desc");
    if (descEl && extra) descEl.textContent = extra.desc;

    /* BUG-04: chất gỗ mặc định đúng sản phẩm */
    if (extra && extra.wood && window.DH && DH.WOOD_LABEL) {
      var wRow = document.getElementById("opt-wood");
      if (wRow) {
        Array.prototype.forEach.call(wRow.querySelectorAll(".opt__btn"), function (b) {
          b.setAttribute("aria-pressed", String(b.getAttribute("data-wood") === extra.wood));
        });
      }
    }

    /* BUG-04: khối thành phần đúng sản phẩm */
    if (extra && extra.compose) {
      var ct = document.getElementById("pdp-compose-title");
      var cu = document.getElementById("pdp-compose");
      if (ct) ct.textContent = extra.composeTitle || "Cấu tạo";
      if (cu) {
        cu.textContent = "";
        extra.compose.forEach(function (line) {
          var li = document.createElement("li");
          li.textContent = line;
          cu.appendChild(li);
        });
      }
    }

    /* BUG-04: JSON-LD khớp sản phẩm đang xem */
    var ld = document.getElementById("pdp-jsonld");
    if (ld) {
      ld.textContent = JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Product",
        name: p.name,
        description: (extra && extra.desc) || p.spec,
        brand: { "@type": "Brand", name: "Đồ Gỗ Nội Thất Duân Hồng" },
        material: DH.WOOD_LABEL[p.wood] || p.wood,
        offers: {
          "@type": "Offer",
          priceCurrency: "VND",
          price: p.price ? String(p.price) : "",
          availability: "https://schema.org/MadeToOrder"
        }
      });
    }

    /* BUG-04: canonical theo đúng sản phẩm */
    var can = document.querySelector('link[rel="canonical"]');
    if (can) can.setAttribute("href", "https://duanhong.vn/pdp/" + id);

    // ảnh chính + thumbnail theo sản phẩm
    var gm = document.getElementById("gallery-main");
    if (gm) { gm.textContent = "VỊ TRÍ ẢNH: " + p.name; gm.setAttribute("data-photo", "product-" + p.id); if (DH.initPhotos) DH.initPhotos(); }
    Array.prototype.forEach.call(document.querySelectorAll(".gallery__thumbs button"), function (b) {
      var label = b.getAttribute("data-label") || b.textContent.trim();
      b.setAttribute("data-label", label);
      b.setAttribute("aria-label", "Xem ảnh: " + label);
    });

    // meta
    document.title = p.name + " — Đồ Gỗ Nội Thất Duân Hồng";
    var md = document.querySelector('meta[name="description"]');
    if (md) md.setAttribute("content", p.name + " · " + p.spec + " · " + (p.price ? DH.vnd(p.price) : "Báo giá theo kích thước") + ". Đặt thợ đo miễn phí trong 30km.");
    var canon = document.querySelector('link[rel="canonical"]');
    if (canon) canon.setAttribute("href", "https://duanhong.vn/pdp/" + id);
  }


  /* ---------------- 2b. Đánh giá đã duyệt từ API (BUG-02) --------------- */
  function initReviews() {
    var list = document.getElementById("review-list");
    if (!list || !window.DH_API) return;

    var slug = new URLSearchParams(location.search).get("id") || "sofa-go-do";
    var hint = list.nextElementSibling;   // dòng ghi chú dưới danh sách

    DH_API.get("/api/products/" + encodeURIComponent(slug) + "/reviews").then(function (r) {
      if (!r.ok || !r.data || !Array.isArray(r.data.data)) return;   // giữ nguyên mẫu nếu API lỗi
      var items = r.data.data;

      if (!items.length) {
        list.textContent = "";
        var empty = document.createElement("p");
        empty.className = "hint";
        empty.textContent = "Chưa có đánh giá nào cho mẫu này. Đánh giá chỉ hiện sau khi xưởng duyệt.";
        list.appendChild(empty);
      } else {
        list.textContent = "";
        items.forEach(function (rv) {
          var art = document.createElement("article");
          art.className = "rev__item";

          var head = document.createElement("div");
          head.className = "rev__head";

          var name = document.createElement("span");
          name.className = "rev__name";
          name.textContent = rv.author;

          var ver = document.createElement("span");
          ver.className = "verified";
          ver.textContent = "Đã mua tại xưởng";

          var meta = document.createElement("span");
          meta.className = "rev__meta";
          meta.textContent = rv.date;

          head.appendChild(name); head.appendChild(ver); head.appendChild(meta);

          var stars = document.createElement("div");
          stars.className = "stars";
          stars.setAttribute("aria-label", rv.rating + " trên 5 sao");
          stars.textContent = "★".repeat(rv.rating) + "☆".repeat(5 - rv.rating);

          var body = document.createElement("p");
          body.className = "rev__body";
          body.textContent = rv.body;                 // chống XSS

          art.appendChild(head); art.appendChild(stars); art.appendChild(body);
          list.appendChild(art);
        });
      }

      if (hint && hint.classList.contains("hint")) {
        var n = items.length;
        var avg = r.data.average || 0;
        hint.textContent = n
          ? n + " đánh giá · trung bình " + avg + "/5 · chỉ gồm khách có mã đơn đã bàn giao."
          : "Chưa có đánh giá nào được duyệt.";
      }
    });
  }

  /* ---------------- 3. Gallery đổi ảnh chính ----------------------------- */
  function initGallery() {
    let main = document.getElementById("gallery-main");
    if (!main) return;
    var thumbs = document.querySelectorAll(".gallery__thumbs button");
    Array.prototype.forEach.call(thumbs, function (b) {
      b.addEventListener("click", function () {
        Array.prototype.forEach.call(thumbs, function (x) { x.setAttribute("aria-current", String(x === b)); });
        var label = b.getAttribute("data-label") || b.textContent.trim();
        var subject = main.getAttribute("data-subject") || document.querySelector("h1").textContent;
        var inner = b.querySelector("[data-photo]");
        var key = b.getAttribute("data-photo") || (inner && inner.getAttribute("data-photo"));
        var cur = document.getElementById("gallery-main") || main;   // ô có thể đã bị thay bằng <img>

        var withPhoto = function (entry) {
          var img = document.createElement("img");
          img.id = "gallery-main";
          img.className = "ph-img gallery__main";
          img.src = entry.src;
          img.alt = label + " — " + subject;
          img.loading = "lazy";
          img.decoding = "async";
          img.setAttribute("data-subject", subject);
          cur.replaceWith(img);
          main = img;
        };

        var placeholder = function () {
          var d = document.createElement("div");
          d.id = "gallery-main";
          d.className = "ph gallery__main";
          d.setAttribute("data-subject", subject);
          d.setAttribute("aria-live", "polite");
          d.textContent = "VỊ TRÍ ẢNH: " + label + " — " + subject;
          if (key) d.setAttribute("data-photo", key);
          cur.replaceWith(d);
          main = d;
        };

        if (!key) return placeholder();
        loadManifest().then(function (m) {
          // ảnh phụ (-2, -3, -4) phải có đúng file; chỉ ảnh chính mới lùi về ảnh đại diện
          var base = key.replace(/-\d+$/, "");
          var isFirstView = base === key || /-1$/.test(key);
          var entry = m[key] || (isFirstView ? m[base] : null);
          if (entry && entry.src) withPhoto(entry);
          else placeholder();
        });
      });
    });
  }

  /* ---------------- 4. Tìm kiếm trong catalogue -------------------------- */
  function initCatalogSearch() {
    var input = document.getElementById("catalog-search");
    if (!input) return;
    var t = null;
    function apply() {
      var q = input.value.trim().toLowerCase();
      var url = new URLSearchParams(location.search);
      if (q) url.set("q", q); else url.delete("q");
      history.replaceState(null, "", url.toString() ? "?" + url.toString() : location.pathname);
      document.dispatchEvent(new CustomEvent("dh:catalogsearch", { detail: { q: q } }));
    }
    input.addEventListener("input", function () {
      clearTimeout(t);
      t = setTimeout(apply, 200);
    });
    var initial = new URLSearchParams(location.search).get("q");
    if (initial) { input.value = initial; apply(); }
  }

  /* ---------------- 5. Viết đánh giá (cần mã đơn) ------------------------ */
  function initReviewForm() {
    var open = document.getElementById("btn-write-review");
    var form = document.getElementById("review-form");
    if (!open || !form) return;
    var list = document.getElementById("review-list");
    var out = document.getElementById("review-msg");

    open.addEventListener("click", function () {
      form.hidden = !form.hidden;
      if (!form.hidden) document.getElementById("rv-code").focus();
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var code = document.getElementById("rv-code").value.trim().toUpperCase();
      var phone = document.getElementById("rv-phone").value.trim();
      var body = document.getElementById("rv-body").value.trim();
      var rating = document.getElementById("rv-rating").value;
      out.textContent = "";

      // gửi thật lên API; không có API thì báo lỗi, không giả thành công
      if (!window.DH_API) {
        out.className = "hint bad";
        out.textContent = "Chưa kết nối máy chủ nên đánh giá chưa được gửi.";
        return;
      }

      var slug = new URLSearchParams(location.search).get("id") || "sofa-go-do";
      var submitBtn = form.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.textContent = "Đang gửi…";

      DH_API.post("/api/products/" + encodeURIComponent(slug) + "/reviews", {
        orderCode: code,
        phoneLast4: phone,
        rating: Number(rating),
        body: body
      }).then(function (r) {
        submitBtn.disabled = false;
        submitBtn.textContent = "Gửi đánh giá";

        if (r.status === 0) {
          if (window.DH_API) DH_API.banner();
          out.className = "hint bad";
          out.textContent = "Không gửi được, kiểm tra kết nối và thử lại.";
          return;
        }
        if (!r.ok) {
          out.className = "hint bad";
          out.textContent = (r.data && r.data.message) || "Chưa gửi được đánh giá.";
          document.getElementById("rv-code").focus();
          return;
        }

        form.reset();
        form.hidden = true;
        out.className = "hint ok";
        out.textContent = "Đã gửi đánh giá. Xưởng sẽ duyệt trước khi hiển thị công khai.";
      });
    });
  }

  DH.initMobileNav = initMobileNav;
  DH.initPdp = initPdp;
  DH.initGallery = initGallery;
  DH.initCatalogSearch = initCatalogSearch;

  /* ---------------- 6. Thay ô placeholder bằng ảnh thật ---------------- */
  var photoManifest = null;

  function loadManifest() {
    if (photoManifest) return Promise.resolve(photoManifest);
    return fetch("assets/img/manifest.json", { cache: "no-cache" })
      .then(function (r) { return r.ok ? r.json() : {}; })
      .then(function (m) { photoManifest = m || {}; return photoManifest; })
      .catch(function () { photoManifest = {}; return photoManifest; });
  }

  function swap(ph, entry, key) {
    var img = document.createElement("img");
    img.src = entry.src;
    img.alt = ph.getAttribute("data-alt") || ph.textContent.replace(/^VỊ TRÍ ẢNH:\s*/, "").trim() || key;
    img.loading = ph.getAttribute("data-eager") === "1" ? "eager" : "lazy";
    img.decoding = "async";
    if (ph.getAttribute("data-eager") === "1") img.setAttribute("fetchpriority", "high");
    if (entry.width) img.width = entry.width;
    if (entry.height) img.height = entry.height;
    img.className = "ph-img";
    // giữ id/lớp của ô gốc để JS gallery + CSS vẫn hoạt động
    if (ph.id) img.id = ph.id;
    if (ph.className) img.className = "ph-img " + ph.className.replace(/ph/g, "").trim();
    ph.replaceWith(img);
  }

  function initPhotos() {
    var nodes = document.querySelectorAll("[data-photo]");
    if (!nodes.length) return;
    loadManifest().then(function (m) {
      Array.prototype.forEach.call(document.querySelectorAll("[data-photo]"), function (ph) {
        var key = ph.getAttribute("data-photo");
        var entry = m[key] || m[key + "-1"];
        if (entry && entry.src) swap(ph, entry, key);
      });
    });
  }

  /* ---------------- 7. Ảnh cập nhật của đơn (nếu API có) --------------- */
  function renderStepPhoto(step) {
    if (!step || !step.photo_url) return "";
    return '<img class="ph-img" src="' + step.photo_url + '" alt="Ảnh cập nhật bước ' +
      step.step + ': ' + step.title + '" loading="lazy" decoding="async" style="border-radius:8px;margin-top:8px">';
  }

  DH.initReviewForm = initReviewForm;
  DH.initPhotos = initPhotos;

  /* ---------------- 8. Trang Công trình lấy dữ liệu từ API (BUG-06) ----- */
  function initProjects() {
    var grid = document.getElementById("cases");
    if (!grid || !window.DH_API) return;

    var WOOD = (window.DH && DH.WOOD_LABEL) || {};
    var esc = function (v) {
      return String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;")
        .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    };
    var vnd = function (n) { return Number(n).toLocaleString("vi-VN") + " ₫"; };

    DH_API.get("/api/projects").then(function (r) {
      if (!r.ok || !r.data || !Array.isArray(r.data.data) || !r.data.data.length) return;

      grid.textContent = "";
      r.data.data.forEach(function (cs, i) {
        var art = document.createElement("article");
        art.className = "cs anim-up";
        art.setAttribute("data-room", cs.room || "");
        art.setAttribute("data-testid", "project-card");

        var media = document.createElement("div");
        media.className = "ph";
        media.setAttribute("data-photo", "project-" + (i + 1));
        media.textContent = "VỊ TRÍ ẢNH: " + (cs.title || "công trình");
        art.appendChild(media);

        var body = document.createElement("div");
        body.className = "cs__body";

        var top = document.createElement("div");
        top.className = "cs__top";
        var h2 = document.createElement("h2");
        h2.textContent = cs.title || "";
        var place = document.createElement("span");
        place.className = "cs__place";
        place.textContent = [cs.place, cs.quote ? "" : ""].filter(Boolean).join(" · ") +
          (cs.status === "in_progress" ? " · đang thi công" : "");
        top.appendChild(h2); top.appendChild(place);
        body.appendChild(top);

        var dl = document.createElement("dl");
        var rows = [
          ["Diện tích phòng", cs.area_m2 ? cs.area_m2 + " m²" : "—"],
          ["Quy cách", cs.spec || "—"],
          ["Chất gỗ", WOOD[cs.wood] || cs.wood || "—"],
          ["Thời gian", cs.days ? cs.days + " ngày" : "—"],
          ["Giá chốt", cs.price ? vnd(cs.price) : "Báo giá sau khi đo"]
        ];
        rows.forEach(function (row) {
          var dt = document.createElement("dt");
          dt.textContent = row[0];
          var dd = document.createElement("dd");
          dd.textContent = row[1];
          dl.appendChild(dt); dl.appendChild(dd);
        });
        body.appendChild(dl);

        if (cs.status === "in_progress") {
          var note = document.createElement("p");
          note.className = "cs__quote";
          note.textContent = "Đang thi công tại xưởng — ảnh và số đo cập nhật mỗi lần chuyển bước.";
          body.appendChild(note);
        }

        art.appendChild(body);
        grid.appendChild(art);
      });

      if (window.DH && DH.initPhotos) DH.initPhotos();   // ảnh project-N nếu đã có
      if (window.DH_MOTION && DH_MOTION.observe) DH_MOTION.observe(grid);
    });
  }

  DH.initReviews = initReviews;
  DH.initProjects = initProjects;
  DH.renderStepPhoto = renderStepPhoto;
})();
