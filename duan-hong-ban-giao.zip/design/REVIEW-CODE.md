# CODE REVIEW — `design/` (frontend tôi đã viết)

Ngày 07/11/2026 · Phạm vi: 8 HTML + `design-tokens.css` + `ui.js` + 3 script build
Phương pháp: đọc code + `node --check` + grep cấu trúc + 23 test hành vi bằng Puppeteer + audit DOM/contrast/heading
Kết quả: **3 lỗi Must Fix (đã sửa), 2 Should Fix (đã sửa), 6 điểm để lại có lý do.**

---

## 1. Must Fix — đã sửa

### M1. Thước Lỗ Ban nhận giá trị ngoài miền hợp lệ
- **Vị trí:** `ui.js` → `DH.loban(cm)`
- **Tái hiện:** mở `/lo-ban.html`, nhập `5000` → kết quả `Cung xấu — Hại · 128 thước + 33.6cm`
- **Vấn đề:** input khai `max="2000"`, nội dung hướng dẫn ghi "1 đến 2000cm", nhưng hàm không chặn trên. Người dùng gõ tay vẫn qua được (thuộc tính `max` của HTML không chặn khi JS đọc trực tiếp).
- **Sửa:** thêm `const LOBAN_MAX = 2000;` và `if (!cm || cm <= 0 || cm > LOBAN_MAX) return null;` — một chỗ chặn cho cả trang `/lo-ban` và khối Lỗ Ban trong PDP.
- **Sau sửa:** `5000` → "Nhập kích thước từ 1 đến 2000cm."

### M2. Wizard 3 bước mất toàn bộ dữ liệu khi reload
- **Vị trí:** `dat-lich.html` (script cuối trang)
- **Tái hiện:** chọn "Phòng ngủ" → bước 2 nhập 30 m² → bước 3 → F5 → quay về bước 1, mất sạch.
- **Vấn đề:** form nhiều bước nhưng state chỉ nằm trong DOM. Người dùng lỡ tay reload là nhập lại từ đầu — đúng loại ma sát làm rơi lead.
- **Sửa:** lưu nháp vào `sessionStorage` (`dh_datlich_draft`) mỗi lần đổi bước/đổi trường; khôi phục khi tải lại, mở đúng bước đang làm; xoá nháp sau khi gửi thành công và khi bấm "Đặt lịch khác".
- **Sau sửa:** reload giữa bước 3 → vẫn ở bước 3, `room="Phòng ngủ"`, `area="30"`.

### M3. CSS trùng lặp giữa token và từng trang
- **Vị trí:** `.panel` khai lại ở 4 file (`dat-lich`, `lo-ban`, `pdp`, `tra-cuu`); `.timeline/.tl` khai 2 lần (`trang-chu`, `tra-cuu`); `.chip` khai ở cả `design-tokens.css` và `trang-chu.html`.
- **Rủi ro:** sửa một chỗ, ba chỗ kia lệch. Đây đúng là lỗi đã xảy ra ở vòng trước (5 trang mới thiếu style `.chip`).
- **Sửa:** đưa `.panel`, `.timeline`, `.tl`, `.chip` vào `design-tokens.css`; xoá định nghĩa trùng trong 5 trang.
- **Kiểm chứng:** sau khi xoá, `site-check` vẫn 19/19 PASS và ảnh chụp không đổi bố cục.

---

## 2. Should Fix — đã sửa

### S1. Bộ test của chính tôi báo sai 3 lần
- **Vị trí:** `qa-node/code-review.js`
- **Vấn đề:** assertion chỉ đọc 40 ký tự đầu của `#track-result`, trong khi "3/5" nằm ở dòng thứ ba → báo FAIL cho 3 case thực chất PASS (mã lowercase, khoảng trắng đầu/cuối, click 3 lần).
- **Sửa:** đọc toàn bộ `innerText`. Đây là bài học: test sai còn tệ hơn không test, vì nó tạo niềm tin giả.

### S2. Nhánh lỗi của tracker không dọn kết quả cũ
- Tracker ghi đè `innerHTML` mỗi lần tra nên không rò rỉ trạng thái cũ — đã kiểm, giữ nguyên.

---

## 3. Điểm để lại (không sửa) — và vì sao

| # | Vấn đề | Vị trí | Vì sao để lại |
|---|---|---|---|
| R1 | `var` dùng ở script trang (`dat-lich`, `pdp`) trong khi `ui.js` dùng `const/let` | `dat-lich.html`, `pdp.html` | Không sai chức năng, phạm vi hàm đã đóng. Đổi chỉ để đẹp → rủi ro sửa nhầm cao hơn lợi ích |
| R2 | Render bằng `innerHTML` với dữ liệu | `ui.js` (catalogue, tracker), `pdp.html` | Dữ liệu hiện là hằng số trong file nên an toàn. **Khi nối API thật phải đổi sang `textContent`/DOM API hoặc escape** — đã ghi vào checklist handoff |
| R3 | 3 script build trùng phần shell; `OUT` hardcode tuyệt đối; `build_pages2/3` import `build_pages` nên chạy là sinh lại `quy-trinh.html` | `build_pages*.py` | Chỉ là công cụ nội bộ, chạy đúng. Nên tách `shell.py` + nhận `OUT` từ argv khi bàn giao cho dev |
| R4 | `<time>` không có `datetime` | nhiều trang | Ảnh hưởng SEO ngữ nghĩa ở mức thấp; ngày đang là chuỗi hiển thị |
| R5 | Không có CSP; toàn bộ script inline | mọi trang | Bản thật nên tách `app.js` và bật CSP có hash |
| R6 | Form ghi "đồng ý được liên hệ" nhưng không có checkbox đồng ý riêng | `trang-chu.html`, `dat-lich.html` | Cần BA/pháp lý xác nhận theo Nghị định 13/2023/NĐ-CP về dữ liệu cá nhân — không tự thêm |

---

## 4. Những gì đã kiểm và đạt

**Tĩnh**

| Kiểm | Kết quả |
|---|---|
| `node --check ui.js` | exit 0 |
| `innerHTML` có nội suy biến người dùng | 0 chỗ nguy hiểm: mã đơn chỉ được chèn sau khi khớp bảng `ORDERS`; `?ma=` đưa vào `value` của input (không render HTML) |
| `tabindex` dương | 0 |
| `id` trùng | 0 |
| Link/button không có tên | 0 |
| Link chết nội bộ | 0 (một số 304 do cache) |

**Hành vi (23 case, sau sửa: 22 PASS · 1 WARN)**

| Nhóm | Kết quả |
|---|---|
| Tracker | lowercase `dh-801` ✓ · khoảng trắng đầu/cuối ✓ · thiếu 4 số SĐT → chặn ✓ · click 3 lần liên tiếp ✓ · chèn `<img onerror>` qua ô mã đơn → không render ✓ · `?ma=<script>` → không phản chiếu ✓ |
| Form | tên toàn khoảng trắng → chặn ✓ · `+84901234567` ✓ · `090 123 4567` ✓ · 11 số → chặn ✓ · gửi 2 lần → WARN (demo, production phải chặn theo session) |
| Dự toán | rỗng / 0 / âm / 121 → "—" + hướng dẫn ✓ · 24,5 → ra khoảng giá ✓ · 0 lỗi JS |
| Lỗ Ban | 0 / âm / 5000 → chặn ✓ · 274 → Tài ✓ |
| Catalogue | `?he=khongtontai&go=<script>` → empty state + 0 chip active, không lỗi ✓ |
| PDP | chọn "theo kích thước phòng" → "Báo giá sau khi đo" ✓ |
| Wizard | reload giữa bước 3 → giữ nguyên dữ liệu ✓ |

**Giao diện (8 trang)**: 19/19 PASS của `site-check` (200, 1 `h1`, 4 landmark, 0 alt thiếu, 0 label thiếu, không tràn ngang 4 breakpoint, 0 tap target < 40px, 0 lỗi console); `review` báo 0 lỗi contrast chữ nhỏ, 0 nhảy bậc heading.

---

## 5. Ghi chú về một finding bị loại

Vision đọc ảnh `dat-lich-step3.png` và báo có lỗi chính tả "Thợ cá". Kiểm bằng `grep -rn "Thợ cá" *.html` → **0 kết quả**; nguồn có 11 chỗ "Thợ cả" viết đúng. Kết luận: OCR của model đọc sai, không phải lỗi sản phẩm. Đã loại bỏ khỏi báo cáo thay vì "sửa" theo nó.

---

## 6. Việc nên làm tiếp (theo thứ tự)

1. Nối API thật → đổi mọi `innerHTML` có dữ liệu động sang `textContent`/DOM API (R2).
2. Tách `app.js` khỏi HTML + CSP (R5).
3. Tách `shell.py`, `OUT` lấy từ argv để dev build được trên máy khác (R3).
4. Thêm checkbox đồng ý xử lý dữ liệu cá nhân sau khi pháp lý xác nhận (R6).
5. Thay số liệu demo ("128 đánh giá", "86 bộ") bằng dữ liệu CMS hoặc bỏ.

---

# VÒNG 2 — sau phản hồi "vài chức năng chưa hoạt động"

Ngày 07/11/2026 · Audit bằng `completeness-audit.js` (bấm thử từng nút, so sánh DOM trước/sau).

## Lỗi chức năng thật đã tìm ra và sửa

| # | Mức | Vấn đề | Bằng chứng trước khi sửa | Cách sửa | Bằng chứng sau |
|---|---|---|---|---|---|
| N1 | Critical | **Mobile không có menu**: 6 link điều hướng bị ẩn ở ≤960px nhưng không có nút hamburger → điện thoại không đi đâu được ngoài cuộn | `visibleNavLinks: 0, menuButtons: 0` | `ui-extra.js` tự sinh nút hamburger + panel từ `.nav__links` (không phải sửa 8 file), Esc để đóng, khoá cuộn nền, đổi lên desktop tự đóng | `menuButtons: 1`, panel 7 link, `aria-expanded=true`, Esc đóng đúng |
| N2 | Critical | **PDP bỏ qua `?id`**: cả 6 sản phẩm đều hiện sofa, nên mọi link từ catalogue đều mở sai sản phẩm | 6/6 URL `?id=...` đều trả `"Sofa gõ đỏ chân quỳ"` | `initPdp()` đọc `?id`, render tên/tag/giá/quy cách/mô tả/meta + 6 bộ dữ liệu quy cách riêng | 6/6 đúng tên: Án gian thờ, Combo phòng ngủ, Bàn ăn live-edge, Tủ bếp, Tủ quần áo |
| N3 | High | **Thumbnail gallery không đổi ảnh chính**: chỉ đổi `aria-current`, nhìn như nút chết | trước/sau đều `"VỊ TRÍ ẢNH: sofa tại nhà khách…"` | `initGallery()` cập nhật ảnh chính theo `data-label`, thêm `aria-live` | bấm "Mộng ghép" → `"VỊ TRÍ ẢNH: Mộng ghép — Sofa gõ đỏ…"` |
| N4 | High | **3 link footer rỗng `href="#"`** (Bảo hành, Cọc, Vận chuyển) | `link rỗng: "Bảo hành 5 năm"` ×3 | trỏ về `quy-trinh.html#bao-hanh|#thanh-toan|#van-chuyen` (id có thật) | 0 link rỗng |
| N5 | High | **Không có tìm kiếm** dù catalogue 6 sản phẩm | `searchInput: false` | thêm ô search + debounce 200ms, lọc theo tên/quy cách/chất gỗ/hệ phòng, state `?q=` | `searchInput: true` |
| N6 | Medium | **Không viết được đánh giá** dù có tab "Đánh giá" và 2 review mẫu | `reviewForm: false, reviewButton: false` | form yêu cầu mã đơn + 4 số cuối (đúng luật "chỉ khách đã mua"), chèn review bằng `textContent` (không render HTML) | sai đơn → chặn; đúng DH-801/5889 → thêm review thứ 3, trạng thái "chờ duyệt" |
| N7 | Medium | **Nhãn placeholder sai sự thật**: thẻ sản phẩm ghi "ẢNH THẬT" trong khi là ô trống | 2 chỗ trong `ui.js` + `trang-chu.html` | đổi thành "VỊ TRÍ ẢNH" | 0 chuỗi "ẢNH THẬT" trong toàn bộ source |

## Kiểm chứng lại toàn bộ (không regression)

| Bộ kiểm | Kết quả |
|---|---|
| `site-check.js` (8 trang) | **19/19 PASS**, 0 lỗi console, 0 tràn ngang, 0 tap target < 40px |
| `code-review.js` (hành vi) | **23/23 PASS**, 1 WARN (form cho gửi lại — demo) |
| `review.js` (metadata/a11y) | 8/8 trang: contrast OK, heading OK, 0 anchor gãy, 0 id trùng |
| Lọc theo từng chip (đo độc lập) | Phòng ngủ 6→2 · Hương Đá 6→1 · Óc Chó 6→0 · Sồi Nga 6→2 · Tủ bếp 6→1 |
| Menu mobile | mở 7 link, `aria-expanded=true`, Esc đóng, không chồng header |

## Ghi chú

- Mục "NÚT BẤM KHÔNG ĐỔI GÌ (5 chip)" trong audit là **dương tính giả**: audit bấm tuần tự trên cùng một trang nên trạng thái lọc cộng dồn; test lại từng chip trên trang sạch thì tất cả đều lọc đúng (bảng trên).
- `reviewForm/reviewButton: false` trong audit là do audit chạy trên trang chủ — form đánh giá nằm ở PDP, kiểm riêng thì có và hoạt động.


---

## VÒNG 3 — Cơ chế ảnh + nối API

### Đã sửa
- **A1 — 17 ô ảnh không có đường thay**: thêm `data-photo` cho hero, 5 công đoạn, 5 công trình, 5 ảnh sản phẩm, 2 ô cập nhật; `querySelectorAll("[data-photo]")` + `manifest.json` do `tools/photos.js` sinh. Không sửa HTML khi thêm ảnh.
- **A2 — nhãn "ẢNH XƯỞNG THẬT" trên ô trống** ở hero: đổi thành "VỊ TRÍ ẢNH: ảnh xưởng — …".
- **A3 — thay ảnh làm mất `id`/lớp của ô gốc**: `img` mới giữ `id` và class (bỏ `ph`) để gallery và CSS vẫn trỏ đúng.
- **A4 — gallery sau khi có ảnh thật vẫn ghi chữ vào `<img>`**: viết lại `initGallery` để đổi `src` khi ô là `img`, và tạo lại khung `VỊ TRÍ ẢNH` khi ảnh phụ chưa có.
- **A5 — ảnh phụ lấy nhầm ảnh đại diện**: chỉ ảnh chính (`-1` hoặc không hậu tố) mới lùi về ảnh đại diện; `-2/-3/-4` phải có file thật.
- **A6 — hero dùng `loading=lazy`**: thêm `data-eager="1"` → `eager` + `fetchpriority=high`.
- **A7 — wizard cho quay lại bước 3 sau khi đã gửi**: `form.dataset.done` chặn `show()` sau khi thành công; nút "đặt lịch khác" xoá cờ.
- **A8 — `req.destroy()` làm client mất response 413**: đọc cạn stream rồi mới trả lỗi.
- **A9 — seed sản phẩm lệch cột** (`active` nhận giá trị `sort`): insert tường minh 11 cột.
- **A10 — form đánh giá vẫn dùng dữ liệu local** (báo "đã gửi" mà không gửi): gọi `POST /api/products/:slug/reviews`.
- **A11 — rate limit dev chặn test**: `RATE_LEAD/RATE_REVIEW/RATE_TRACK` cấu hình được, production giữ 5/10/30.

### Kiểm chứng
- `server/test/api.test.js` → **46/46 PASS**
- `qa-node/e2e-api.js` → **17/17 PASS** (lead vào DB thật, review qua duyệt, wizard, API tắt thì không báo thành công giả)
- `qa-node/site-check.js` → **19/19 PASS**
- `qa-node/code-review.js` → **23 PASS / 1 WARN**
- `qa-node/test-photos.js` → **12/12 PASS** (tự tạo fixture, kiểm xong tự dọn)
