# REVIEW BẢN THIẾT KẾ — WEBSITE XƯỞNG MỘC DUÂN HỒNG

Ngày: 07/11/2026 · Phạm vi: 8 file HTML trong `design/` (7 trang + trang design system)
Phương pháp: audit tự động bằng Puppeteer (DOM, contrast, heading, link, keyboard) + review ảnh chụp + đối chiếu tài liệu gốc trong file .zip.
Kết quả: **2 lỗi Must Fix đã sửa, 4 Should Fix đã sửa, 3 điểm còn lại chấp nhận có lý do.**

---

## 1. Must Fix (đã sửa xong)

| # | Vấn đề | Bằng chứng | Đã sửa |
|---|---|---|---|
| M1 | **Chữ nhỏ dưới ngưỡng tương phản** — nhãn eyebrow và meta dùng #c8823b / #b8873f trên nền ivory chỉ đạt **2,93–3,19:1** (chuẩn AA cần 4,5:1) | audit: "BẢY TRANG → 2.93", "PHÒNG KHÁCH · GÕ ĐỎ → 3.19", "★★★★★ → 2.99" | Thêm token `--color-amber-text: #8a5b22` (**5,46:1**), áp cho eyebrow, `card__meta`, `prod__tag`, `pdp__tag`, `stars`, `step-num`; badge vàng đổi sang chữ `wood-900`; thanh cung Lỗ Ban đổi sang `wood-900`. Kết quả: **8/8 trang `lowContrastSmall = none`** |
| M2 | **Nhảy bậc heading 2 → 4** ở 5 trang (footer dùng `h4`, timeline dùng `h4` sau `h2`) | audit: `headingJump=2→4` trên trang-chu, cong-trinh, lo-ban, tra-cuu, dat-lich | Footer và timeline đổi `h4` → `h3`. Kết quả: **8/8 trang `headingJump = ok`** |

## 2. Should Fix (đã sửa)

| # | Vấn đề | Đã sửa |
|---|---|---|
| S1 | `index.html` thiếu meta description, canonical, và chỉ có 1/4 landmark | Thêm description (131 ký tự), canonical, `<header>` có `<nav>`, `<footer>` → **4/4 landmark** |
| S2 | Chữ trong ô placeholder ảnh có tương phản không đo được (nền gradient ⇒ `backgroundColor` trong suốt) | Thêm `background-color:#54382a` làm nền dự phòng + chữ `#f0e2d2` (6,0:1). Giờ cả người và công cụ đo đều đọc đúng |
| S3 | `.chip`, rule vùng chạm chỉ nằm ở trang chủ, 5 trang mới bị lỗi | Đưa `.chip`, `.empty`, rule touch-target vào `design-tokens.css` dùng chung |
| S4 | Wizard cuộn qua mất thanh tiến độ; gửi xong vẫn còn form | Thanh bước `position: sticky`; sau khi gửi ẩn toàn bộ step, hiện card "Đã nhận lịch hẹn" + nút "Đặt lịch khác" |

## 3. Could Improve (chưa sửa, có lý do)

| # | Vấn đề | Đo được | Vì sao để lại |
|---|---|---|---|
| C1 | **Inline style còn nhiều** (PDP 52 chỗ, index 36 chỗ, trang chủ 26 chỗ) | `inlineStyles` trong audit | Phần lớn là viền bảng spec và khoảng cách một lần dùng. Refactor hết sẽ thành 40+ class dùng một lần — đổi lại lợi ích thấp hơn chi phí đọc code |
| C2 | **Chưa có `<img>` nào** — toàn bộ ảnh là div placeholder | `imgs=0` trên cả 8 trang | Đúng theo nguyên tắc "không giả ảnh thật". Khi có ảnh thật phải thêm `width/height`, `loading=lazy` cho dưới màn hình đầu, `fetchpriority=high` cho LCP |
| C3 | **Font tải từ Google** (render-blocking tiềm ẩn) | Lighthouse chưa chạy được (không có Chrome build chính thức) | Bản thật phải self-host subset tiếng Việt. Prototype chấp nhận để chạy được ngay khi mở file |

## 4. Đã kiểm và đạt (không cần sửa)

| Hạng mục | Kết quả |
|---|---|
| 7 trang + design system | HTTP 200, đúng 1 `<h1>`/trang, 4 landmark, 0 ảnh thiếu `alt`, 0 input thiếu `<label for>` |
| Responsive | 375 / 768 / 1024 / 1440 — `scrollWidth = clientWidth` ở cả 8 trang |
| Vùng chạm | 0 phần tử tương tác < 40px ở 375px (45 phần tử trên trang chủ) |
| Bàn phím | Tab qua 22–25 điểm dừng/trang, **0 điểm dừng không có focus ring** |
| Link nội bộ | Tất cả trả 200 (một số 304 do cache) — không có link chết, không có anchor gãy |
| ID trùng | 0 trên cả 8 trang |
| `tabindex` dương | 0 — thứ tự tab theo DOM, không nhảy cóc |
| Link/button không có tên | 0 |
| Text chung chung ("Xem chi tiết", "Tìm hiểu thêm") | 0 |
| Console | 0 lỗi trên 8 trang |
| Chức năng | Lọc catalogue (kèm deep link), lọc công trình, dự toán, tra cứu (đúng/sai SĐT), Lỗ Ban, wizard 3 bước + trạng thái hoàn tất — chạy đúng |

## 5. Review nội dung (đối chiếu file .zip)

| Điểm | Trạng thái |
|---|---|
| Hotline 0378.914.207 | Nhất quán 100% (đã bỏ số 0988.686.868 lẫn trong CMS) |
| Địa chỉ, giờ mở cửa | Nhất quán giữa topbar, footer, JSON-LD |
| Giá 36,9tr / 74,5tr / 48tr / 38tr | Khớp dữ liệu gốc trong repo |
| Bảo hành 5 năm, cọc 30/70, 30km, độ ẩm 11% | Khớp SKILL và USER_GUIDE |
| Thời gian làm | Ghi rõ "45 ngày sấy + 15–25 ngày gia công" — đúng cả hai tài liệu vốn mâu thuẫn |
| Số đo Lỗ Ban | **Không** hiển thị cung cho 2m80 (vì thước 38,8 cho ra cung Bệnh); công cụ ghi rõ chỉ tính thước 38,8 |
| Số liệu không kiểm chứng | Đã bỏ "từ 1994", "1.200+ khách", "148 lượt thích". Còn lại "128 đánh giá / 86 bộ đã bàn giao" lấy từ mock data của repo — **phải thay bằng số thật trước khi lên production** |

## 6. Ba rủi ro còn lại trước khi coi là xong

1. **Ảnh.** Bản thiết kế này sống bằng ảnh xưởng thật. Chưa có ảnh thì mọi trang vẫn là khung sườn đúng nhưng chưa thuyết phục.
2. **Backend.** Tracker và form đang chạy trên dữ liệu mẫu trong `ui.js`. Nối API thật phải sửa trước lỗi bảo mật `GET /api/orders` (đã ghi trong báo cáo QA) — nếu không, siết quyền xong mới nối.
3. **Số liệu xã hội.** "128 đánh giá / 86 bộ" hiện là dữ liệu mẫu; hiển thị số không có thật trên site bán đồ 74 triệu là rủi ro niềm tin, cần lấy từ CMS hoặc bỏ.

---

## Tổng kết

Bản thiết kế đã sạch về mặt kỹ thuật (a11y, responsive, link, console) và không còn lỗi tương phản. Cái còn thiếu không phải là code mà là **tư liệu thật từ xưởng**: ảnh, số đánh giá thật, và xác nhận loại thước Lỗ Ban.
