/* ==========================================================================
   Client API cho website Duân Hồng.
   Nguyên tắc: nếu API không chạy, KHÔNG giả lập thành công — hiện chế độ demo
   và nói rõ dữ liệu không được lưu. Tránh lừa người dùng và tránh mất lead.
   ========================================================================== */
window.DH_API = (function () {
  "use strict";

  /* Cùng origin (serve.js proxy /api) → để rỗng, gọi tương đối "/api/..." */
  var SAME_ORIGIN = location.protocol === "http:" || location.protocol === "https:";
  var DEFAULT_BASE = (location.hostname === "127.0.0.1" || location.hostname === "localhost")
    ? (location.port === "8096" ? "" : "http://127.0.0.1:5055")
    : "https://api.duanhong.vn";

  var base = (function () {
    try { return localStorage.getItem("dh_api_base") || DEFAULT_BASE; }
    catch (e) { return DEFAULT_BASE; }
  })();

  var state = { online: null, checkedAt: 0 };

  function url(path) { return base ? base.replace(/\/$/, "") + path : path; }

  async function request(method, path, body) {
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, 6000);
    try {
      var res = await fetch(url(path), {
        method: method,
        headers: body ? { "Content-Type": "application/json" } : undefined,
        body: body ? JSON.stringify(body) : undefined,
        signal: ctrl.signal,
        credentials: "omit"
      });
      var data = null;
      try { data = await res.json(); } catch (e) {}
      return { ok: res.ok, status: res.status, data: data };
    } catch (err) {
      return { ok: false, status: 0, data: null, error: err.name === "AbortError" ? "timeout" : "network" };
    } finally {
      clearTimeout(timer);
    }
  }

  async function health(force) {
    var now = Date.now();
    if (!force && state.online !== null && now - state.checkedAt < 15000) return state.online;
    var r = await request("GET", "/api/health");
    state.online = r.ok;
    state.checkedAt = now;
    return state.online;
  }

  /* Thanh trạng thái nhỏ, chỉ hiện khi API không chạy */
  function banner() {
    if (document.getElementById("dh-demo-banner")) return;
    var b = document.createElement("div");
    b.id = "dh-demo-banner";
    b.setAttribute("role", "status");
    b.style.cssText =
      "position:fixed;left:0;right:0;bottom:0;z-index:90;background:#7a3a1e;color:#fff;" +
      "font:600 12.5px/1.5 var(--font-sans);padding:9px 14px;text-align:center;";
    b.innerHTML = 'Chế độ demo: chưa kết nối máy chủ nên dữ liệu <b>không được lưu</b>. ' +
      'Chạy <code style="font-family:monospace">npm start</code> trong thư mục <code style="font-family:monospace">server/</code> để bật.';
    document.body.appendChild(b);
  }

  return {
    base: base,
    url: url,
    health: health,
    banner: banner,
    get: function (p) { return request("GET", p); },
    post: function (p, b) { return request("POST", p, b); },
    patch: function (p, b) { return request("PATCH", p, b); },
    setBase: function (b) {
      base = b.replace(/\/$/, "");
      try { localStorage.setItem("dh_api_base", base); } catch (e) {}
      state.online = null;
    }
  };
})();
