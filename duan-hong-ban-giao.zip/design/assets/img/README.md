# Thư mục ảnh — cách thêm ảnh thật

Chỉ cần **thả file đúng tên** vào thư mục này rồi chạy một lệnh. Không sửa HTML, không sửa JS.

```bash
node tools/photos.js
```

Lệnh này quét thư mục, sinh `manifest.json` và báo còn thiếu ảnh nào. Tải lại trang là ảnh hiện ra.

## Tên file phải đúng (đuôi `.webp` / `.jpg` / `.png` đều được)

**Trang chủ**
- `hero-workshop` — ảnh lớn đầu trang: thợ cả đang ghép mộng tại xưởng. Tỉ lệ 4:3, rộng ≥ 1600px, ngang 1200×900 cũng đủ.

**5 công đoạn (trang Quy trình)**
- `step-1` — thợ cả đo phòng tại nhà khách
- `step-2` — phôi trong lò sấy / đồng hồ độ ẩm
- `step-3` — ghép mộng âm dương, đục tay
- `step-4` — khách ký tên lên gầm bàn
- `step-5` — phun PU / xe xưởng giao lắp
- Tỉ lệ 5:4.

**5 công trình (trang Công trình)**
- `project-1` … `project-5` — ảnh bàn giao thật. Tỉ lệ 16:9.

**6 sản phẩm (ảnh đại diện)**
- `product-sofa-go-do`
- `product-an-gian-tho`
- `product-combo-phong-ngu`
- `product-ban-an-live-edge`
- `product-tu-bep-mdf`
- `product-tu-quan-ao-soi`
- Tỉ lệ 4:3.

**Ảnh phụ cho trang sản phẩm (tuỳ chọn)**
- `product-<slug>-2`, `-3`, `-4` — mỗi ảnh ứng với một thumbnail. Tên `-1` là ảnh "Toàn cảnh" (nếu không có thì dùng ảnh đại diện).
- Ảnh phụ **không** tự lấy ảnh đại diện thay thế: chưa có file thì ô đó vẫn ghi "VỊ TRÍ ẢNH", để không ai tưởng là ảnh thật của góc khác.

**Trang tra cứu**
- `order-latest` — ảnh cập nhật mới nhất từ xưởng. Tỉ lệ 16:9.

## Quy ước nên theo

- **Chụp ngang**, không dùng ảnh dọc cho hero/công trình (sẽ bị cắt).
- Nén còn **≤ 300 KB/ảnh**; ưu tiên `.webp`. Hero có thể tới 400 KB.
- Tên file **không dấu, không khoảng trắng**, chữ thường.
- Ảnh có người: xin phép khách trước khi đăng (quy định tại Nghị định 13/2023/NĐ-CP về dữ liệu cá nhân).

## Ảnh cho từng bước của một đơn (trang Tra cứu)

Ảnh tiến độ đơn không dùng thư mục này. Đó là `photo_url` trong bảng `order_steps`,
cập nhật qua API quản trị (xem `server/README.md`). Nếu `photo_url` rỗng thì bước đó chỉ hiện chữ.

## Kiểm tra nhanh

```bash
node tools/photos.js --check    # chỉ báo cáo, không ghi manifest
```

Kết quả mẫu:

```
Đã có       : 3/18 ảnh bắt buộc (17%)
  ✓ hero-workshop, step-1, product-sofa-go-do
  ✗ thiếu: step-2, step-3, ...
```
