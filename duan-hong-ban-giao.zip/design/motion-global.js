"use strict";
/* Tăng cường có điều kiện; không thay thế bộ điều khiển hay dữ liệu sẵn có. */
(function () {
  if (window.DH_GLOBAL_MOTION) return;
  var reduce = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
  var fine = window.matchMedia ? window.matchMedia("(hover: hover) and (pointer: fine) and (min-width: 961px)") : { matches: false };
  var groups = ".catalog,.cases,.cases-grid,.commit,.combo,.steps,.policy,.rev,.grid-pages,#related,[data-dmg-stagger]";
  var states = new WeakMap(), counts = new WeakSet(), activeCounts = new Set();
  var frame = 0, bar, hero, tilt = null;
  var observer = null, revealObserver = null, animations = new Set();

  function visible(el) { return !!(el.getClientRects().length) && getComputedStyle(el).visibility !== "hidden"; }
  function animate(el, index) {
    /* Không ghi đè transform/opacity của hệ reveal cũ. */
    if (el.matches(".anim-up,.anim-mask,.anim-zoom,.reveal")) {
      if (el.matches(".anim-up:not(.is-in)")) {
        if (reduce.matches) { el.classList.add("is-in"); return; }
        el.style.setProperty("--i", String(Math.min(index, 8)));
        if (revealObserver) revealObserver.observe(el);
        else el.classList.add("is-in");
      }
      return;
    }
    if (reduce.matches || !el.animate) return;
    var animation = el.animate([{ opacity: 0.65 }, { opacity: 1 }], {
      duration: 420, delay: Math.min(index, 8) * 60, easing: "ease-out"
    });
    animations.add(animation);
    animation.finished.then(function () { animations.delete(animation); }, function () { animations.delete(animation); });
  }
  function scanGroup(group) {
    var index = 0;
    Array.prototype.forEach.call(group.children, function (el) {
      var shown = visible(el), previous = states.get(el);
      states.set(el, shown);
      if (!shown) return;
      if (previous !== true) animate(el, index);
      index++;
    });
  }
  function scan(root) {
    if (root.nodeType !== 1 && root !== document) return;
    if (root.matches && root.matches(groups)) scanGroup(root);
    if (root.querySelectorAll) root.querySelectorAll(groups).forEach(scanGroup);
    if (root.matches && root.matches("[data-dmg-count]")) watchCount(root);
    if (root.querySelectorAll) root.querySelectorAll("[data-dmg-count]").forEach(watchCount);
  }
  /* Bộ đếm riêng chỉ nhận opt-in, không đụng [data-count] của motion.js. */
  function watchCount(el) {
    if (counts.has(el) || el.children.length) return;
    var raw = el.getAttribute("data-dmg-count");
    if (!raw || !/^-?\d+(?:\.\d+)?$/.test(raw)) return;
    var value = Number(raw);
    if (!Number.isFinite(value) || Math.abs(value) > 1000000000000) return;
    counts.add(el);
    if (reduce.matches || !observer) return;
    observer.observe(el);
  }
  function runCount(el) {
    var original = el.textContent, raw = el.getAttribute("data-dmg-count"), value = Number(raw);
    var precision = (raw.split(".")[1] || "").length;
    if (precision > 6) return;
    var prefix = el.getAttribute("data-dmg-prefix") || "", suffix = el.getAttribute("data-dmg-suffix") || "";
    var label = el.getAttribute("aria-label"), start = performance.now();
    if (label === null) el.setAttribute("aria-label", original);
    var record = { el: el, original: original, label: label, id: 0 };
    activeCounts.add(record);
    function finish() {
      el.textContent = original;
      if (label === null) el.removeAttribute("aria-label");
      activeCounts.delete(record);
    }
    record.finish = finish;
    function tick(now) {
      if (reduce.matches || !el.isConnected) { finish(); return; }
      var p = Math.min(1, Math.max(0, (now - start) / 1000));
      if (p >= 1) { finish(); return; }
      el.textContent = prefix + (value * (1 - Math.pow(1 - p, 3))).toLocaleString("vi-VN", { minimumFractionDigits: precision, maximumFractionDigits: precision }) + suffix;
      record.id = requestAnimationFrame(tick);
    }
    record.id = requestAnimationFrame(tick);
  }
  function update() {
    frame = 0;
    var max = document.documentElement.scrollHeight - window.innerHeight;
    var progress = max > 0 ? Math.max(0, Math.min(1, window.scrollY / max)) : 0;
    if (bar) bar.style.transform = "scaleX(" + progress + ")";
    if (hero) hero.style.setProperty("--dmg-parallax", (reduce.matches ? 0 : Math.min(18, Math.max(0, window.scrollY * 0.06))) + "px");
  }
  function queueUpdate() { if (!frame) frame = requestAnimationFrame(update); }
  function resetTilt() {
    if (!tilt) return;
    tilt.classList.remove("dmg-tilt");
    tilt.style.removeProperty("--dmg-rx"); tilt.style.removeProperty("--dmg-ry"); tilt = null;
  }
  function init() {
    if (!document.body) return;
    bar = document.createElement("div"); bar.className = "dmg-progress"; bar.setAttribute("aria-hidden", "true"); document.body.appendChild(bar);
    hero = document.querySelector(".hero__media.anim-parallax");
    var heroSection = document.querySelector(".hero");
    if (heroSection && heroSection.querySelector(".hero__inner")) {
      var ambient = document.createElement("span"); ambient.className = "dmg-ambient"; ambient.setAttribute("aria-hidden", "true"); heroSection.prepend(ambient);
      var content = heroSection.querySelector(".hero__inner > div");
      if (content) Array.prototype.forEach.call(content.children, animate);
    }
    if ("IntersectionObserver" in window) {
      observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) { if (entry.isIntersecting) { observer.unobserve(entry.target); runCount(entry.target); } });
      }, { threshold: 0.5 });
      revealObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) { if (entry.isIntersecting) { entry.target.classList.add("is-in"); revealObserver.unobserve(entry.target); } });
      }, { threshold: 0.1 });
    }
    document.documentElement.classList.add("dmg-ready");
    scan(document);
    window.addEventListener("scroll", queueUpdate, { passive: true });
    window.addEventListener("resize", queueUpdate, { passive: true });
    queueUpdate();
    if ("MutationObserver" in window) new MutationObserver(function (changes) {
      var dirty = new Set();
      changes.forEach(function (change) {
        if (change.type === "childList") {
          change.addedNodes.forEach(function (node) { if (node.nodeType === 1 && !node.classList.contains("dmg-ripple")) scan(node); });
          if (change.target.matches && change.target.matches(groups)) dirty.add(change.target);
        } else if (change.target.parentElement && change.target.parentElement.matches(groups)) dirty.add(change.target.parentElement);
      });
      dirty.forEach(scanGroup);
    }).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["hidden", "style"] });
    document.addEventListener("click", function (event) {
      var button = event.target.closest && event.target.closest(".btn");
      if (!button || reduce.matches || button.disabled || event.detail === 0) return;
      var rect = button.getBoundingClientRect(), diameter = Math.max(rect.width, rect.height) * 2;
      var wave = document.createElement("span"); wave.className = "dmg-ripple"; wave.setAttribute("aria-hidden", "true");
      wave.style.width = wave.style.height = diameter + "px"; wave.style.left = (event.clientX - rect.left) + "px"; wave.style.top = (event.clientY - rect.top) + "px";
      button.appendChild(wave); wave.addEventListener("animationend", function () { wave.remove(); }, { once: true });
      window.setTimeout(function () { wave.remove(); }, 1000);
    });
    document.addEventListener("pointermove", function (event) {
      if (event.pointerType !== "mouse" || reduce.matches || !fine.matches) return;
      var card = event.target.closest && event.target.closest(".prod,.cs,.case");
      if (!card) { resetTilt(); return; }
      if (tilt !== card) { resetTilt(); tilt = card; card.classList.add("dmg-tilt"); }
      var r = card.getBoundingClientRect(); if (!r.width || !r.height) return;
      var x = Math.max(-1, Math.min(1, (event.clientX - r.left) / r.width * 2 - 1));
      var y = Math.max(-1, Math.min(1, (event.clientY - r.top) / r.height * 2 - 1));
      card.style.setProperty("--dmg-rx", (-y * 3).toFixed(2) + "deg"); card.style.setProperty("--dmg-ry", (x * 3).toFixed(2) + "deg");
    }, { passive: true });
    document.addEventListener("pointerout", function (event) { if (tilt && (!event.relatedTarget || !tilt.contains(event.relatedTarget))) resetTilt(); });
    function preferenceChanged() {
      if (reduce.matches) { resetTilt(); animations.forEach(function (a) { a.cancel(); }); activeCounts.forEach(function (c) { cancelAnimationFrame(c.id); c.finish(); }); }
      queueUpdate();
    }
    if (reduce.addEventListener) reduce.addEventListener("change", preferenceChanged);
    else if (reduce.addListener) reduce.addListener(preferenceChanged);
  }
  window.DH_GLOBAL_MOTION = { refresh: function (root) { scan(root || document); queueUpdate(); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true }); else init();
})();