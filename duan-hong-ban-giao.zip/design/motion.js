"use strict";
/* ==========================================================================
   MOTION — Điều khiển hiệu ứng bằng IntersectionObserver + 3D Tilt + Magnetic + Ripple.
   Tham khảo các hiệu ứng hiện đại:
   - 3D Hover Tilt Cards (perspective 900px, xoay theo góc toạ độ chuột)
   - Magnetic Buttons (hút nhẹ theo chuột tạo lực tương tác cao cấp)
   - Liquid Ripple Effect (gợn sóng ánh vàng hổ phách khi click)
   - Spotlight Lighting (ánh sáng đèn rọi theo chuột nhẹ nhàng)
   - Sticky Frosted Glass Header (kính mờ co giãn khi cuộn)
   Tất cả đều là progressive enhancement: không có JS thì nội dung vẫn hiện bình thường.
   ========================================================================== */
(function () {
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var hasIO = "IntersectionObserver" in window;
  var isDesktop = window.matchMedia && window.matchMedia("(hover: hover) and (pointer: fine)").matches;

  /* ─────────────── 1. Gắn nhịp (--i) cho các phần tử cùng nhóm ───────── */
  function stagger() {
    var groups = document.querySelectorAll("[data-stagger]");
    Array.prototype.forEach.call(groups, function (g) {
      var kids = g.querySelectorAll(":scope > .anim-up, :scope > * > .anim-up, .anim-mask, .anim-zoom");
      Array.prototype.forEach.call(kids, function (el, i) {
        if (!el.style.getPropertyValue("--i")) el.style.setProperty("--i", String(i));
      });
    });

    // Timeline: đánh số từng bước
    Array.prototype.forEach.call(document.querySelectorAll(".timeline .tl"), function (el, i) {
      if (!el.style.getPropertyValue("--i")) el.style.setProperty("--i", String(i));
    });
  }

  /* ─────────────── 2. Hiện khi cuộn tới ──────────────────────────────── */
  function reveal() {
    var sel = ".anim-up, .anim-mask, .anim-zoom, .timeline";
    var items = document.querySelectorAll(sel);
    if (!items.length) return;

    if (reduce || !hasIO) {
      Array.prototype.forEach.call(items, function (el) { el.classList.add("is-in"); });
      return;
    }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        en.target.classList.add("is-in");
        io.unobserve(en.target);
      });
    }, { rootMargin: "0px 0px -4% 0px", threshold: 0.08 });

    Array.prototype.forEach.call(items, function (el) { io.observe(el); });
  }

  /* ─────────────── 3. Đếm số ─────────────────────────────────────────── */
  function counters() {
    var nodes = document.querySelectorAll("[data-count]");
    if (!nodes.length) return;

    function run(el) {
      var target = parseFloat(el.getAttribute("data-count"));
      if (isNaN(target)) return;
      var decimals = parseInt(el.getAttribute("data-decimals") || "0", 10);
      var suffix = el.getAttribute("data-suffix") || "";
      var prefix = el.getAttribute("data-prefix") || "";

      if (reduce) { el.textContent = prefix + target.toFixed(decimals) + suffix; return; }

      var dur = 1100, t0 = performance.now();
      function tick(now) {
        var p = Math.min((now - t0) / dur, 1);
        var eased = 1 - Math.pow(1 - p, 3);
        var val = target * eased;
        el.textContent = prefix +
          (decimals ? val.toFixed(decimals) : Math.round(val).toLocaleString("vi-VN")) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    }

    if (!hasIO || reduce) { Array.prototype.forEach.call(nodes, run); return; }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        run(en.target);
        io.unobserve(en.target);
      });
    }, { threshold: 0.5 });
    Array.prototype.forEach.call(nodes, function (el) { io.observe(el); });
  }

  /* ─────────────── 4. Parallax rất nhẹ cho ảnh hero ──────────────────── */
  function parallax() {
    var el = document.querySelector(".hero__media.anim-parallax");
    if (!el || reduce) return;
    var ticking = false;
    function onScroll() {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        var shift = Math.min(window.scrollY * 0.06, 26);
        el.style.transform = "translate3d(0," + shift.toFixed(1) + "px,0)";
        ticking = false;
      });
    }
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* ─────────────── 5. Thanh tiến độ đọc trang ────────────────────────── */
  function progressBar() {
    if (reduce) return;
    if (document.getElementById("dh-progress")) return;
    var bar = document.createElement("div");
    bar.id = "dh-progress";
    bar.setAttribute("aria-hidden", "true");
    bar.style.cssText =
      "position:fixed;top:0;left:0;height:3px;width:100%;z-index:200;background:var(--color-amber,#c8823b);" +
      "transform:scaleX(0);transform-origin:left;pointer-events:none;transition:transform 0.1s linear";
    document.body.appendChild(bar);

    var ticking = false;
    function update() {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        var h = document.documentElement.scrollHeight - window.innerHeight;
        var p = h > 0 ? (window.scrollY / h) * 100 : 0;
        bar.style.transform = "scaleX(" + (Math.min(Math.max(p, 0), 100) / 100).toFixed(3) + ")";
        ticking = false;
      });
    }
    window.addEventListener("scroll", update, { passive: true });
    update();
  }

  /* ─────────────── 6. Header cuộn kính mờ ─────────────────────────────── */
  function stickyHeader() {
    var header = document.querySelector(".site-header");
    if (!header) return;
    var ticking = false;
    function onScroll() {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        header.classList.toggle("is-scrolled", window.scrollY > 15);
        ticking = false;
      });
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  /* ─────────────── 7. Hiệu ứng 3D Card Tilt theo toạ độ chuột ─────────── */
  function init3DTilt() {
    if (reduce || !isDesktop) return;
    var cards = document.querySelectorAll(".prod, .case, .commit__item, .card");
    Array.prototype.forEach.call(cards, function (card) {
      if (card.dataset.tiltBound) return;
      card.dataset.tiltBound = "1";

      card.addEventListener("mousemove", function (e) {
        var rect = card.getBoundingClientRect();
        var x = e.clientX - rect.left;
        var y = e.clientY - rect.top;
        var centerX = rect.width / 2;
        var centerY = rect.height / 2;
        var rotateX = ((y - centerY) / centerY) * -7;
        var rotateY = ((x - centerX) / centerX) * 7;
        card.style.transform = "perspective(900px) rotateX(" + rotateX.toFixed(2) + "deg) rotateY(" + rotateY.toFixed(2) + "deg) scale3d(1.02, 1.02, 1.02)";
      });

      card.addEventListener("mouseleave", function () {
        card.style.transform = "perspective(900px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)";
        card.style.transition = "transform 0.45s cubic-bezier(0.16, 1, 0.3, 1)";
      });

      card.addEventListener("mouseenter", function () {
        card.style.transition = "none";
      });
    });
  }

  /* ─────────────── 8. Nút nam châm hút nhẹ (Magnetic Buttons) ────────── */
  function initMagneticButtons() {
    if (reduce || !isDesktop) return;
    var btns = document.querySelectorAll(".nav .btn, .hero__cta .btn, #bk-submit, #lead-submit");
    Array.prototype.forEach.call(btns, function (btn) {
      if (btn.dataset.magneticBound) return;
      btn.dataset.magneticBound = "1";

      btn.addEventListener("mousemove", function (e) {
        var rect = btn.getBoundingClientRect();
        var x = e.clientX - rect.left - rect.width / 2;
        var y = e.clientY - rect.top - rect.height / 2;
        btn.style.transform = "translate3d(" + (x * 0.22).toFixed(1) + "px, " + (y * 0.22).toFixed(1) + "px, 0) scale(1.03)";
      });

      btn.addEventListener("mouseleave", function () {
        btn.style.transform = "translate3d(0, 0, 0) scale(1)";
        btn.style.transition = "transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)";
      });

      btn.addEventListener("mouseenter", function () {
        btn.style.transition = "none";
      });
    });
  }

  /* ─────────────── 9. Gợn sóng ánh kim khi click (Ripple Effect) ─────── */
  function initRippleEffect() {
    if (reduce) return;
    var btns = document.querySelectorAll(".btn");
    Array.prototype.forEach.call(btns, function (btn) {
      if (btn.dataset.rippleBound) return;
      btn.dataset.rippleBound = "1";

      btn.addEventListener("click", function (e) {
        var rect = btn.getBoundingClientRect();
        var x = e.clientX - rect.left;
        var y = e.clientY - rect.top;
        var ripple = document.createElement("span");
        ripple.className = "btn-ripple";
        ripple.style.left = x + "px";
        ripple.style.top = y + "px";
        btn.appendChild(ripple);
        setTimeout(function () { ripple.remove(); }, 600);
      });
    });
  }

  /* ─────────────── 10. Showroom Spotlight Lighting ───────────────────── */
  function initSpotlight() {
    if (reduce || !isDesktop) return;
    if (document.getElementById("dh-spotlight")) return;
    var spot = document.createElement("div");
    spot.id = "dh-spotlight";
    spot.setAttribute("aria-hidden", "true");
    document.body.appendChild(spot);

    var ticking = false;
    window.addEventListener("mousemove", function (e) {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () {
        spot.style.transform = "translate3d(" + (e.clientX - 250) + "px, " + (e.clientY - 250) + "px, 0)";
        ticking = false;
      });
    }, { passive: true });
  }

  /* ─────────────── 11. Đánh dấu phần tử mới render từ API ─────────────── */
  function observeDynamic(root) {
    if (!root || !hasIO || reduce) {
      if (root) Array.prototype.forEach.call(root.querySelectorAll(".anim-up"), function (e) { e.classList.add("is-in"); });
      return;
    }
    Array.prototype.forEach.call(root.querySelectorAll(".anim-up:not(.is-in)"), function (el, i) {
      el.style.setProperty("--i", String(i));
      ioDynamic.observe(el);
    });
    init3DTilt();
  }
  var ioDynamic = hasIO ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      en.target.classList.add("is-in");
      ioDynamic.unobserve(en.target);
    });
  }, { threshold: 0.08 }) : null;

  /* ─────────────── khởi động toàn bộ ─────────────────────────────────── */
  function init() {
    document.documentElement.classList.add("motion");
    stagger();
    reveal();
    counters();
    parallax();
    progressBar();
    stickyHeader();
    init3DTilt();
    initMagneticButtons();
    initRippleEffect();
    initSpotlight();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.DH_MOTION = { refresh: init, observe: observeDynamic, reduced: reduce };
})();
