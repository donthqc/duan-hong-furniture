/*
 * Tích hợp: nạp motion-components.css sau kiểu riêng trang và motion.css;
 * nạp motion-components.js sau ui.js, ui-extra.js, motion.js và mã khởi tạo trang.
 * Lớp này chỉ quan sát trạng thái sẵn có, không thay thế logic của trang.
 * Gallery phụ thuộc #gallery-main và .gallery__thumbs; ô ảnh được thay bất đồng bộ.
 * Lightbox dùng dialog gốc (không hỗ trợ thì không tạo nút); chỉ phóng to ảnh
 * hiện tại hoặc văn bản thay ảnh, không có điều hướng ảnh bên trong hộp thoại.
 * Chuyển tab/bước chỉ có hiệu ứng vào vì trang ẩn ngay nội dung cũ. Menu đóng
 * ngay theo thuộc tính hidden sẵn có; chỉ hiệu ứng mở được áp dụng. Thanh tiến độ
 * dựa trên data-state, không suy diễn trạng thái đơn. Rung lỗi dựa vào aria-invalid
 * hoặc sự kiện invalid; form novalidate không đánh dấu lỗi sẽ không có hiệu ứng.
 * Tùy chọn giảm chuyển động tắt hiệu ứng của lớp này, không thay đổi các lệnh
 * cuộn mượt đang có trong mã trang hoặc tính năng của motion.js.
 */
(function () {
  'use strict';
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  function animate(el, name) {
    if (!el || reduce.matches) return;
    el.classList.remove(name);
    void el.offsetWidth;
    el.classList.add(name);
  }
  function observe(el, options, callback) {
    if (el && window.MutationObserver) new MutationObserver(callback).observe(el, options);
  }
  function gallery() {
    var initial = document.getElementById('gallery-main');
    var thumbs = document.querySelector('.gallery__thumbs');
    if (!initial || !thumbs) return;
    var host = initial.parentElement;
    var last = initial;
    var trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'mc-gallery-open';
    trigger.textContent = 'Phóng to ảnh';
    trigger.setAttribute('aria-label', 'Phóng to ảnh sản phẩm');
    thumbs.insertAdjacentElement('afterend', trigger);
    var dialog = document.createElement('dialog');
    if (typeof dialog.showModal === 'function') {
      dialog.className = 'mc-lightbox';
      dialog.setAttribute('aria-label', 'Ảnh sản phẩm phóng to');
      var close = document.createElement('button');
      close.type = 'button'; close.className = 'mc-lightbox-close';
      close.textContent = 'Đóng'; close.setAttribute('aria-label', 'Đóng ảnh phóng to');
      var content = document.createElement('div'); content.className = 'mc-lightbox-content';
      dialog.append(close, content); document.body.appendChild(dialog);
      trigger.addEventListener('click', function () {
        var main = document.getElementById('gallery-main');
        if (!main) return;
        content.replaceChildren();
        if (main.tagName === 'IMG') {
          var image = document.createElement('img'); image.src = main.currentSrc || main.src;
          image.alt = main.alt; content.appendChild(image);
        } else {
          var text = document.createElement('p'); text.textContent = main.textContent; content.appendChild(text);
        }
        dialog.showModal(); close.focus();
      });
      host.addEventListener('click', function (event) {
        var main = document.getElementById('gallery-main');
        if (main && main.tagName === 'IMG' && (event.target === main || main.contains(event.target))) trigger.click();
      });
      function dismiss() { dialog.close(); trigger.focus(); }
      close.addEventListener('click', dismiss);
      dialog.addEventListener('cancel', function (event) { event.preventDefault(); dismiss(); });
      dialog.addEventListener('close', function () { trigger.focus(); });
    } else trigger.remove();
    observe(host, { childList: true }, function () {
      var current = document.getElementById('gallery-main');
      if (!current || current === last) return;
      var previous = last; last = current;
      if (reduce.matches || !previous.getBoundingClientRect) return;
      var rect = current.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      var ghost = previous.cloneNode(true);
      ghost.removeAttribute('id'); ghost.setAttribute('aria-hidden', 'true');
      ghost.classList.add('mc-gallery-ghost');
      Object.assign(ghost.style, { left: rect.left + 'px', top: rect.top + 'px', width: rect.width + 'px', height: rect.height + 'px' });
      document.body.appendChild(ghost);
      ghost.addEventListener('animationend', function () { ghost.remove(); }, { once: true });
      setTimeout(function () { ghost.remove(); }, 450);
    });
  }
  function tabs() {
    document.querySelectorAll('[role="tablist"]').forEach(function (list) {
      var indicator = document.createElement('span'); indicator.className = 'mc-tab-indicator';
      indicator.setAttribute('aria-hidden', 'true'); list.classList.add('mc-tabs'); list.appendChild(indicator);
      function update() {
        var active = list.querySelector('[role="tab"][aria-selected="true"]');
        if (!active) return;
        var lr = list.getBoundingClientRect(), ar = active.getBoundingClientRect();
        indicator.style.transform = 'translate(' + (ar.left - lr.left + list.scrollLeft) + 'px,' + (ar.bottom - lr.top - 2) + 'px) scaleX(' + ar.width + ')';
      }
      observe(list, { subtree: true, attributes: true, attributeFilter: ['aria-selected'] }, update);
      list.addEventListener('scroll', update, { passive: true });
      window.addEventListener('resize', update);
      if (window.ResizeObserver) new ResizeObserver(update).observe(list);
      update();
    });
    document.querySelectorAll('[role="tabpanel"]').forEach(function (panel) {
      observe(panel, { attributes: true, attributeFilter: ['hidden'] }, function () {
        if (!panel.hidden) animate(panel, 'mc-enter');
      });
    });
  }
  function wizard() {
    document.querySelectorAll('#book-form .step, #bk-done').forEach(function (step) {
      observe(step, { attributes: true, attributeFilter: ['hidden'] }, function () {
        if (!step.hidden) animate(step, 'mc-enter');
      });
    });
    document.querySelectorAll('.steps-bar > div').forEach(function (item) {
      observe(item, { attributes: true, attributeFilter: ['data-done'] }, function () {
        if (item.dataset.done === '1') animate(item, 'mc-tick');
      });
    });
  }
  function dynamicEffects() {
    var scale = document.getElementById('lb-scale');
    observe(scale, { childList: true, subtree: true }, function () {
      animate(scale.querySelector('.active'), 'mc-highlight');
    });
    var result = document.getElementById('est-result');
    observe(result, { childList: true, characterData: true, subtree: true }, function () { animate(result, 'mc-flash'); });
    document.querySelectorAll('.timeline').forEach(function (timeline) {
      function progress() {
        var items = Array.from(timeline.querySelectorAll('.tl'));
        var current = items.findIndex(function (item) { return item.dataset.state === 'now'; });
        if (current < 0) current = items.reduce(function (last, item, i) { return item.dataset.state === 'done' ? i : last; }, -1);
        var first = items[0], last = items[current];
        var height = first && last ? Math.max(0, last.offsetTop - first.offsetTop) : 0;
        timeline.style.setProperty('--mc-progress', String(height));
        timeline.classList.add('mc-timeline');
      }
      observe(timeline, { subtree: true, attributes: true, childList: true, attributeFilter: ['data-state'] }, progress);
      window.addEventListener('resize', progress); progress();
    });
    observe(document.body, { subtree: true, attributes: true, attributeFilter: ['aria-invalid'] }, function (records) {
      records.forEach(function (record) {
        if (record.target.getAttribute('aria-invalid') === 'true') animate(record.target, 'mc-shake');
      });
    });
    document.addEventListener('invalid', function (event) { animate(event.target, 'mc-shake'); }, true);
  }
  function mobileMenu() {
    var btn = document.getElementById('mnav-btn'), panel = document.getElementById('mnav-panel');
    if (!btn || !panel) return;
    panel.querySelectorAll('nav a, .btn').forEach(function (link, i) { link.style.setProperty('--mc-index', i); });
  }
  function backToTop() {
    var button = document.createElement('button'); button.type = 'button';
    button.className = 'mc-top'; button.textContent = '↑';
    button.setAttribute('aria-label', 'Về đầu trang'); button.hidden = true;
    document.body.appendChild(button);
    function update() { button.hidden = window.scrollY < 400; }
    window.addEventListener('scroll', update, { passive: true }); update();
    button.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reduce.matches ? 'auto' : 'smooth' });
    });
  }
  function init() { gallery(); tabs(); wizard(); dynamicEffects(); mobileMenu(); backToTop(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
}());
