/* ==========================================================================
   Duân Hồng — UI logic dùng chung cho trang chủ và PDP.
   Nguyên tắc: không hardcode text trong JS khi có thể render từ dữ liệu;
   mọi state quan trọng phản ánh được ra URL; mọi control có data-testid.
   ========================================================================== */
window.DH = (function () {
  "use strict";

  /* ---------------- Dữ liệu catalogue (nguồn: mock data của repo) ---------- */
  const PRODUCTS = [
    {
      id: "sofa-go-do", tag: "Phòng khách", room: "khach", wood: "go-do",
      name: "Sofa gõ đỏ chân quỳ",
      spec: "Văng 2m80 + văng 1m90 + bàn trà + ghế đơn + đôn kẹp",
      price: 74500000, priceNote: "Bộ 5 món · Gõ Đỏ Pachy Nam Phi"
    },
    {
      id: "an-gian-tho", tag: "Phòng thờ", room: "tho", wood: "huong-da",
      name: "Án gian thờ nhị cấp",
      spec: "Cao 2m17 · 2 cấp · chạm kênh bong",
      price: 48000000, priceNote: "Gỗ Hương Đá chọn thớ"
    },
    {
      id: "combo-phong-ngu", tag: "Phòng ngủ", room: "ngu", wood: "soi-nga",
      name: "Combo phòng ngủ Tổ Ấm",
      spec: "Giường 1m8×2m · tủ 4 cánh · 2 tab · bàn phấn",
      price: 36900000, priceNote: "4 món · Sồi Nga nhập khẩu"
    },
    {
      id: "ban-an-live-edge", tag: "Phòng khách", room: "khach", wood: "go-do",
      name: "Bàn ăn live-edge",
      spec: "Dài 2m20 · mặt nguyên tấm · kèm 8 ghế",
      price: 38000000, priceNote: "Gỗ Gõ Đỏ · cạnh tự nhiên"
    },
    {
      id: "tu-bep-mdf", tag: "Tủ bếp", room: "bep", wood: "mdf",
      name: "Tủ bếp cánh phẳng",
      spec: "Thiết kế theo mét dài · ray giảm chấn",
      price: null, priceNote: "Báo giá theo mét dài sau khi đo"
    },
    {
      id: "tu-quan-ao-soi", tag: "Phòng ngủ", room: "ngu", wood: "soi-nga",
      name: "Tủ quần áo 4 cánh kịch trần",
      spec: "Cao kịch trần · chia khoang theo yêu cầu",
      price: null, priceNote: "Nằm trong combo Tổ Ấm hoặc làm lẻ"
    }
  ];

  const ROOM_LABEL = { khach: "Phòng khách", ngu: "Phòng ngủ", tho: "Phòng thờ", bep: "Tủ bếp" };

  /* BUG-07: escape mọi chuỗi đến từ API trước khi đưa vào innerHTML */
  const esc = (s) => String(s === null || s === undefined ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

  const WOOD_LABEL = { "go-do": "Gõ Đỏ", "huong-da": "Hương Đá", "oc-cho": "Óc Chó", "soi-nga": "Sồi Nga", mdf: "MDF An Cường" };

  const vnd = (n) => n.toLocaleString("vi-VN") + " ₫";

  /* ---------------- Catalogue + lọc (state qua URL) ------------------------ */
  function initCatalog() {
    const grid = document.getElementById("catalog");
    if (!grid) return;
    const countEl = document.getElementById("catalog-count");
    const chips = Array.from(document.querySelectorAll(".chip[data-filter]"));
    const state = { room: "all", wood: "all", q: "" };

    let DATA = PRODUCTS;                 // fallback khi API offline
    let usingApi = false;

    const params = new URLSearchParams(location.search);
    if (params.get("he")) state.room = params.get("he");
    if (params.get("go")) state.wood = params.get("go");
    if (params.get("q")) state.q = params.get("q").toLowerCase();

    function syncChips() {
      chips.forEach((c) => {
        const k = c.dataset.filter;
        c.setAttribute("aria-pressed", String(state[k] === c.dataset.value));
      });
    }

    function render() {
      const list = DATA.filter((p) => {
        if (state.room !== "all" && p.room !== state.room) return false;
        if (state.wood !== "all" && p.wood !== state.wood) return false;
        if (state.q) {
          const hay = (p.name + " " + p.spec + " " + (WOOD_LABEL[p.wood] || "") + " " + p.tag).toLowerCase();
          if (hay.indexOf(state.q) === -1) return false;
        }
        return true;
      });
      if (!list.length) {
        grid.innerHTML = `<div class="empty" data-testid="catalog-empty">
          <p style="font-weight:600;color:#2b1a0f;margin-bottom:6px">Chưa có mẫu đúng bộ lọc này</p>
          <p style="font-size:13.5px">Xưởng nhận làm theo yêu cầu. Gọi 0378.914.207 để thợ cả tư vấn quy cách phù hợp.</p>
        </div>`;
      } else {
        grid.innerHTML = list.map((p) => `
          <article class="prod anim-up" data-testid="product-card" data-id="${p.id}">
            <div class="ph" aria-hidden="true" data-photo="product-${esc(p.id)}">VỊ TRÍ ẢNH: ${esc(p.name)}</div>
            <div class="prod__body">
              <span class="prod__tag">${esc(p.tag)} · ${esc(WOOD_LABEL[p.wood] || p.wood)}</span>
              <h3 class="prod__name"><a href="pdp.html?id=${encodeURIComponent(p.id)}">${esc(p.name)}</a></h3>
              <p class="prod__spec">${esc(p.spec)}</p>
              <div class="prod__price">
                ${p.price ? vnd(p.price) : "Báo giá theo kích thước"}
                <small>${esc(p.priceNote)}</small>
              </div>
            </div>
          </article>`).join("");
      }
      // BUG-01: grid vừa bị ghi đè bằng innerHTML → phải thay lại ảnh thật
      if (window.DH && DH.initPhotos) DH.initPhotos();
      // hiệu ứng: quan sát các thẻ vừa render
      if (window.DH_MOTION && DH_MOTION.observe) DH_MOTION.observe(grid);

      countEl.textContent = (state.q
        ? `Tìm "${state.q}": ${list.length} / ${DATA.length} sản phẩm`
        : `Đang hiển thị ${list.length} / ${DATA.length} sản phẩm`) + (usingApi ? "" : " · dữ liệu mẫu");
      syncChips();
      const q = new URLSearchParams();
      if (state.room !== "all") q.set("he", state.room);
      if (state.wood !== "all") q.set("go", state.wood);
      if (state.q) q.set("q", state.q);
      const qs = q.toString();
      history.replaceState(null, "", qs ? `?${qs}` : location.pathname);
    }

    chips.forEach((chip) => {
      chip.addEventListener("click", () => {
        state[chip.dataset.filter] = chip.dataset.value;
        render();
      });
    });

    // ô tìm kiếm (nếu trang có) — ui-extra.js phát sự kiện sau debounce
    document.addEventListener("dh:catalogsearch", (e) => {
      state.q = (e.detail && e.detail.q) || "";
      render();
    });

    render();

    // nâng cấp lên dữ liệu thật nếu API sống
    if (window.DH_API) {
      DH_API.get("/api/products").then((r) => {
        if (r.ok && r.data && Array.isArray(r.data.data) && r.data.data.length) {
          DATA = r.data.data;
          usingApi = true;
          render();
        } else if (r.status !== 0) {
          console.warn("[catalog] API trả lỗi", r.status);
        } else {
          DH_API.banner();
        }
      });
    }
  }

  /* ---------------- Dự toán ngân sách -------------------------------------- */
  function initEstimator() {
    const area = document.getElementById("est-area");
    if (!area) return;
    const room = document.getElementById("est-room");
    const wood = document.getElementById("est-wood");
    const out = document.getElementById("est-result");
    const note = document.getElementById("est-note");

    // đơn giá tham khảo / m2 theo hệ phòng (triệu đồng), và hệ số chất gỗ
    const RATE = { khach: 2.4, ngu: 2.0, tho: 2.9, bep: 3.4 };
    const MULT = { "soi-nga": 1.0, "huong-da": 1.25, "go-do": 1.55, "oc-cho": 1.65, mdf: 0.72 };

    function calc() {
      const a = parseFloat(area.value);
      if (!a || a < 6 || a > 120) {
        out.textContent = "—";
        note.textContent = "Nhập diện tích từ 6 đến 120 m² để xem khoảng giá.";
        return;
      }
      const base = a * RATE[room.value] * MULT[wood.value] * 1e6;
      const low = Math.round((base * 0.85) / 5e5) * 5e5;
      const high = Math.round((base * 1.15) / 5e5) * 5e5;
      out.textContent = `${vnd(low)} – ${vnd(high)}`;
      note.textContent = `${ROOM_LABEL[room.value]} ${a} m² · ${WOOD_LABEL[wood.value]} · đã gồm công đục, sơn PU và vận chuyển trong 30km.`;
    }
    [area, room, wood].forEach((el) => el.addEventListener("input", calc));
    calc();
  }

  /* ---------------- Tra cứu tiến độ --------------------------------------- */
  const ORDERS = {
    "DH-801": { phone: "5889", name: "Anh Hoàng Nam", product: "Sofa gõ đỏ chân quỳ · 2m80", step: 3 },
    "DH-802": { phone: "6778", name: "Bác Trọng Cường", product: "Án gian thờ nhị cấp 2m17", step: 4 },
    "DH-803": { phone: "2334", name: "Chị Minh Tuyết", product: "Combo phòng ngủ sồi Nga", step: 2 }
  };
  const STEP_NAMES = ["Chốt kích thước", "Sấy phôi", "Ghép mộng & đục chạm", "Gia chủ ký mộc", "Sơn PU & bàn giao"];

  function initTracker() {
    const btn = document.getElementById("track-btn");
    if (!btn) return;
    const code = document.getElementById("order-code");
    const phone = document.getElementById("order-phone");
    const box = document.getElementById("track-result");

    // prefill từ URL (?ma=DH-801) — state tái lập được, không chứa SĐT
    const ma = new URLSearchParams(location.search).get("ma");
    if (ma) code.value = ma.toUpperCase();

    function paint(step) {
      document.querySelectorAll("#timeline .tl").forEach((el, i) => {
        el.dataset.state = i + 1 < step ? "done" : (i + 1 === step ? "now" : "");
      });
    }

    /* BUG-03: đổ nội dung thật của từng bước (ghi chú, ngày, ảnh) vào timeline */
    function paintSteps(steps) {
      if (!Array.isArray(steps) || !steps.length) return;
      const nodes = document.querySelectorAll("#timeline .tl");
      steps.forEach((st, i) => {
        const el = nodes[st.step - 1];
        if (!el) return;
        const h = el.querySelector("h2, h3");
        if (h && st.title) h.textContent = st.title;

        let p = el.querySelector("p");
        if (st.note) {
          if (!p) { p = document.createElement("p"); el.appendChild(p); }
          p.textContent = st.note;                       // textContent, không innerHTML
        } else if (p) {
          p.remove();
        }

        let t = el.querySelector("time");
        if (st.done_at) {
          if (!t) { t = document.createElement("time"); el.appendChild(t); }
          const d = new Date(st.done_at + "T00:00:00");
          t.dateTime = st.done_at;
          t.textContent = isNaN(d) ? st.done_at : d.toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" });
        } else if (t && st.step === steps[steps.length - 1].step) {
          t.textContent = "Đang thực hiện";
        } else if (t) {
          t.textContent = "Chưa tới bước này";
        }

        // ảnh tiến độ của bước (nếu xưởng đã đăng)
        if (window.DH && DH.renderStepPhoto && st.photo_url) {
          const old = el.querySelector(".ph-img");
          if (old) old.remove();
          el.insertAdjacentHTML("beforeend", DH.renderStepPhoto(st));
        }
      });
    }

    btn.addEventListener("click", () => {
      const c = (code.value || "").trim().toUpperCase();
      const p = (phone.value || "").trim();
      box.className = "result is-on";

      if (!c || p.length !== 4) {
        box.innerHTML = `<span class="bad">Vui lòng nhập mã đơn và đủ 4 số cuối điện thoại.</span>`;
        (c ? phone : code).focus();
        return;
      }
      // 1) thử API thật trước
      if (window.DH_API) {
        box.innerHTML = '<span class="hint">Đang tra…</span>';
        DH_API.get(`/api/orders/${encodeURIComponent(c)}?phone=${encodeURIComponent(p)}`).then((r) => {
          if (r.ok && r.data && r.data.data) {
            const d = r.data.data;
            paint(d.stage);
            paintSteps(d.steps);
            box.className = "result is-on";
            box.innerHTML = `
              <div class="hint" style="margin:0 0 4px">Đơn ${esc(d.code)} · ${esc(d.customerName)}</div>
              <div style="font-family:var(--font-serif);font-size:17px;margin-bottom:6px">${esc(d.productName)}</div>
              <div>Đang ở bước <strong>${Number(d.stage)}/5 — ${esc(d.stageName)}</strong></div>
              ${d.stageNote ? `<div class="hint">${esc(d.stageNote)}</div>` : ""}
              <div class="hint">Cập nhật ${esc(String(d.updatedAt).slice(0, 10))} · ảnh chụp tại xưởng</div>`;
            history.replaceState(null, "", `?ma=${c}#tien-do`);
            return;
          }
          if (r.status === 0) {
            DH_API.banner();
            box.className = "result is-on";
            box.innerHTML = '<span class="bad">Không kết nối được máy chủ tra cứu.</span>' +
              '<p class="hint" style="margin-top:6px">Gọi <a href="tel:+84378914207" style="font-weight:600;color:#2b1a0f">0378.914.207</a> để được đọc tiến độ.</p>';
            return;
          }
          box.className = "result is-on";
          box.innerHTML = `<span class="bad">${esc((r.data && r.data.message) || "Không tìm thấy đơn khớp mã và số điện thoại.")}</span>
            <p class="hint" style="margin-top:6px">Kiểm tra lại mã đơn trong tin nhắn xác nhận, hoặc gọi <a href="tel:+84378914207" style="font-weight:600;color:#2b1a0f">0378.914.207</a>.</p>`;
        });
        return;
      }

      const o = ORDERS[c];
      if (!o || o.phone !== p) {
        box.innerHTML = `<span class="bad">Không tìm thấy đơn khớp mã và số điện thoại.</span>
          <p class="hint" style="margin-top:6px">Kiểm tra lại mã đơn trong tin nhắn xác nhận, hoặc gọi <a href="tel:+84378914207" style="font-weight:600;color:#2b1a0f">0378.914.207</a>.</p>`;
        return;
      }
      paint(o.step);
      box.innerHTML = `
        <div class="hint" style="margin:0 0 4px">Đơn ${c} · ${o.name}</div>
        <div style="font-family:var(--font-serif);font-size:17px;margin-bottom:6px">${o.product}</div>
        <div>Đang ở bước <strong>${o.step}/5 — ${STEP_NAMES[o.step - 1]}</strong></div>
        <div class="hint">Thợ cả cập nhật ảnh tại xưởng mỗi lần chuyển bước.</div>`;
      history.replaceState(null, "", `?ma=${c}#tien-do`);
    });

    phone.addEventListener("keydown", (e) => { if (e.key === "Enter") btn.click(); });
    code.addEventListener("keydown", (e) => { if (e.key === "Enter") btn.click(); });
  }

  /* ---------------- Form đặt lịch ----------------------------------------- */
  function initLeadForm() {
    const form = document.getElementById("lead-form");
    if (!form) return;
    const name = document.getElementById("lead-name");
    const phone = document.getElementById("lead-phone");
    const nameErr = document.getElementById("lead-name-err");
    const phoneErr = document.getElementById("lead-phone-err");
    const btn = document.getElementById("lead-submit");
    const out = document.getElementById("lead-result");

    const vnPhone = (v) => /^0\d{9}$/.test(v.replace(/[^0-9]/g, "")) || /^84\d{9}$/.test(v.replace(/[^0-9]/g, ""));

    function clear(el, errEl) {
      el.removeAttribute("aria-invalid");
      errEl.textContent = "";
    }

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      let ok = true;
      clear(name, nameErr); clear(phone, phoneErr);

      if (name.value.trim().length < 2) {
        nameErr.textContent = "Vui lòng nhập họ tên (ít nhất 2 ký tự).";
        name.setAttribute("aria-invalid", "true");
        ok = false;
      }
      if (!vnPhone(phone.value)) {
        phoneErr.textContent = "Số điện thoại chưa đúng. Ví dụ: 0901234567.";
        phone.setAttribute("aria-invalid", "true");
        ok = false;
      }
      if (!ok) {
        out.className = "result";
        (name.getAttribute("aria-invalid") ? name : phone).focus();
        return;
      }

      if (form.dataset.sent === "1") {
        out.className = "result is-on";
        out.innerHTML = '<span class="ok"><strong>Yêu cầu trước đã được nhận.</strong></span>' +
          '<p class="hint" style="margin-top:4px">Nếu cần gửi thêm, gọi <a href="tel:+84378914207" style="font-weight:600">0378.914.207</a> hoặc tải lại trang.</p>';
        return;
      }

      const label = btn.textContent;
      btn.disabled = true;
      btn.textContent = "Đang gửi…";

      const done = (html) => {
        btn.disabled = false;
        btn.textContent = label;
        out.className = "result is-on";
        out.innerHTML = html;
      };

      if (!window.DH_API) {
        return done(`<span class="bad"><strong>Chưa kết nối máy chủ.</strong></span>
          <p class="hint" style="margin-top:4px">Yêu cầu chưa được gửi. Gọi <a href="tel:+84378914207" style="font-weight:600">0378.914.207</a> để đặt lịch ngay.</p>`);
      }

      DH_API.post("/api/leads", {
        name: name.value.trim(),
        phone: phone.value.trim(),
        area: (function () {
          const p = (document.getElementById("lead-area") || {}).value || "";
          const a = ((document.getElementById("lead-address") || {}).value || "").trim();
          return a ? `${a}, ${p}` : p;
        })(),
        need: (document.getElementById("lead-note") || {}).value || ""
      }).then((r) => {
        if (r.ok && r.data && r.data.success) {
          const code = r.data.data && r.data.data.code;
          done(`<span class="ok"><strong>Đã nhận yêu cầu${code ? " · " + code : ""}.</strong></span>
            <p class="hint" style="margin-top:4px">Thợ cả sẽ gọi lại trong 15 phút (giờ hành chính). Mã này dùng để đối chiếu khi cần.</p>`);
          form.dataset.sent = "1";
          form.reset();
          return;
        }
        if (r.status === 429) {
          return done(`<span class="bad"><strong>Bạn đã gửi nhiều yêu cầu.</strong></span>
            <p class="hint" style="margin-top:4px">Vui lòng gọi <a href="tel:+84378914207" style="font-weight:600">0378.914.207</a> để được phục vụ ngay.</p>`);
        }
        if (r.status === 0) {
          DH_API.banner();
          return done(`<span class="bad"><strong>Không gửi được.</strong></span>
            <p class="hint" style="margin-top:4px">Kiểm tra kết nối rồi thử lại, hoặc gọi <a href="tel:+84378914207" style="font-weight:600">0378.914.207</a>.</p>`);
        }
        done(`<span class="bad"><strong>Chưa gửi được.</strong></span>
          <p class="hint" style="margin-top:4px">${(r.data && r.data.message) || "Vui lòng thử lại."}</p>`);
      });
    });
  }

  /* ---------------- Reveal on scroll + header shrink ---------------------- */
  function initReveal() {
    const items = document.querySelectorAll(".reveal");
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || !("IntersectionObserver" in window)) {
      items.forEach((el) => el.classList.add("is-in"));
    } else {
      const io = new IntersectionObserver((entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); }
        });
      }, { rootMargin: "0px 0px -60px 0px", threshold: 0.1 });
      items.forEach((el) => io.observe(el));
    }

    const header = document.getElementById("site-header");
    if (header) {
      const onScroll = () => header.classList.toggle("is-scrolled", window.scrollY > 8);
      window.addEventListener("scroll", onScroll, { passive: true });
      onScroll();
    }
  }

  /* ---------------- Thước Lỗ Ban 38,8cm ---------------------------------- */
  const CUNG_388 = [
    { name: "Tài", good: true, desc: "Tiền tài, của cải" },
    { name: "Bệnh", good: false, desc: "Ốm đau, bệnh tật" },
    { name: "Ly", good: false, desc: "Chia ly, mất mát" },
    { name: "Nghĩa", good: true, desc: "Tình nghĩa, êm ấm" },
    { name: "Quan", good: true, desc: "Công danh, thăng tiến" },
    { name: "Kiếp", good: false, desc: "Tai ương" },
    { name: "Hại", good: false, desc: "Tổn hại, thị phi" },
    { name: "Bản", good: true, desc: "Gốc rễ, bền vững" }
  ];
  const LOBAN_MAX = 2000;   // khớp với max của input và nội dung hướng dẫn

  function loban(cm) {
    const RULER = 38.8, SEG = RULER / 8;
    if (!cm || cm <= 0 || cm > LOBAN_MAX) return null;
    const cycles = Math.floor(cm / RULER);
    const rest = cm - cycles * RULER;
    let idx = Math.floor(rest / SEG);
    if (idx > 7) idx = 7;
    const cung = CUNG_388[idx];
    const nearest = CUNG_388
      .map((c, i) => ({ ...c, cm: +(cycles * RULER + i * SEG + SEG / 2).toFixed(1) }))
      .filter((c) => c.good && Math.abs(c.cm - cm) <= 24 && c.cm !== cm)
      .sort((a, b) => Math.abs(a.cm - cm) - Math.abs(b.cm - cm))[0];
    return { cung, cycles, rest: +rest.toFixed(1), offset: +(rest - idx * SEG).toFixed(1), nearest, idx, ruler: RULER };
  }

  return { initCatalog, initEstimator, initTracker, initLeadForm, initReveal, loban, PRODUCTS, vnd, WOOD_LABEL, ROOM_LABEL };
})();
