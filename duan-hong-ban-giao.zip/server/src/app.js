"use strict";
/**
 * Router API. Không dùng framework — node:http thuần.
 * Nguyên tắc:
 *  - khong bao gio noi chuoi SQL (prepared statement ở db.js)
 *  - validate mọi input, giới hạn kích thước body
 *  - rate limit theo IP cho endpoint ghi
 *  - không trả stack trace, không trả PII khi sai mã đơn
 */
const crypto = require("node:crypto");
const { all, get, run, phoneHash, last4, STEP_TITLES } = require("./db");
const sheets = require("./sheets");

const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "";
const DEV_ORIGINS = "http://127.0.0.1:8096,http://localhost:8096,http://127.0.0.1:8098,http://localhost:8098,http://127.0.0.1:8099,http://localhost:8099";
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || DEV_ORIGINS)
  .split(",").map((s) => s.trim()).filter(Boolean);

const MAX_BODY = 32 * 1024;
// dev/test mở rộng để không tự chặn khi thử; production giữ chặt
const IS_PROD = process.env.NODE_ENV === "production";
const RATE = {
  lead: Number(process.env.RATE_LEAD || (IS_PROD ? 5 : 200)),
  review: Number(process.env.RATE_REVIEW || (IS_PROD ? 10 : 200)),
  track: Number(process.env.RATE_TRACK || (IS_PROD ? 30 : 600)),
};
const VN_PHONE = /^(0\d{9}|84\d{9})$/;
/* Cửa sổ chống gửi trùng (double submit): cùng số điện thoại + cùng họ tên
   trong khoảng này được coi là một yêu cầu, trả lại mã cũ thay vì tạo lead mới. */
const LEAD_DEDUPE_MINUTES = Math.min(
  Math.max(Number(process.env.LEAD_DEDUPE_MINUTES) || 15, 1),
  1440
);
const normalizeName = (s) =>
  String(s).normalize("NFC").toLowerCase().replace(/\s+/g, " ").trim();

/* ---------------------------- rate limiting ----------------------------- */
const buckets = new Map();
function rateLimit(key, limit, windowMs) {
  const now = Date.now();
  const arr = (buckets.get(key) || []).filter((t) => now - t < windowMs);
  if (arr.length >= limit) {
    buckets.set(key, arr);
    return { ok: false, retryAfter: Math.ceil((windowMs - (now - arr[0])) / 1000) };
  }
  arr.push(now);
  buckets.set(key, arr);
  if (buckets.size > 5000) buckets.clear();
  return { ok: true };
}

/* ------------------------------- helpers -------------------------------- */
const json = (res, status, payload, extraHeaders = {}) => {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    ...extraHeaders,
  });
  res.end(body);
};

const securityHeaders = (res, origin) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Cross-Origin-Resource-Policy", "same-site");
  res.setHeader("Cache-Control", "no-store");
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,PATCH,OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization");
    res.setHeader("Access-Control-Max-Age", "600");
    res.setHeader("Vary", "Origin");
  }
};

function readBody(req, res) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooBig = false;
    const chunks = [];

    const fail = (code, msg) => {
      // không destroy socket: phải để tầng trên còn gửi được response
      if (res && !res.writableEnded) res.setHeader("Connection", "close");
      reject(Object.assign(new Error(msg), { status: code }));
    };

    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        if (!tooBig) {
          tooBig = true;
          chunks.length = 0;      // ngừng tích buffer
          fail(413, "PAYLOAD_TOO_LARGE");
        }
        return;                    // vẫn đọc tiếp cho cạn stream
      }
      if (!tooBig) chunks.push(c);
    });

    req.on("end", () => {
      if (tooBig) return;          // đã reject ở trên
      if (!chunks.length) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8"));
        if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
          return reject(Object.assign(new Error("INVALID_BODY"), { status: 400 }));
        }
        resolve(parsed);
      } catch {
        reject(Object.assign(new Error("INVALID_JSON"), { status: 400 }));
      }
    });

    req.on("aborted", () => reject(Object.assign(new Error("ABORTED"), { status: 400 })));
    req.on("error", () => reject(Object.assign(new Error("READ_ERROR"), { status: 400 })));
  });
}

const clientIp = (req) =>
  (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress || "unknown";

function requireAdmin(req, res) {
  if (!ADMIN_TOKEN) {
    json(res, 503, { success: false, message: "Chưa cấu hình ADMIN_TOKEN trên máy chủ." });
    return false;
  }
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  const a = Buffer.from(token);
  const b = Buffer.from(ADMIN_TOKEN);
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!ok) {
    json(res, 401, { success: false, message: "Không có quyền truy cập." });
    return false;
  }
  return true;
}

const mapProduct = (p) => ({
  id: p.slug,
  numericId: p.id,
  name: p.name,
  tag: p.tag,
  room: p.room,
  wood: p.wood,
  spec: p.spec,
  price: p.price,
  priceNote: p.price_note,
  description: p.description,
});

/* -------------------------------- routes -------------------------------- */
async function handle(req, res) {
  const origin = req.headers.origin;
  securityHeaders(res, origin);

  if (req.method === "OPTIONS") {
    res.writeHead(origin && ALLOWED_ORIGINS.includes(origin) ? 204 : 403);
    return res.end();
  }

  const url = new URL(req.url, "http://localhost");
  const path = url.pathname.replace(/\/+$/, "") || "/";
  const ip = clientIp(req);

  if (req.method === "GET" && path === "/api/health") {
    return json(res, 200, {
      success: true,
      status: "UP",
      service: "duanhong-api",
      version: "1.0.0",
      time: new Date().toISOString(),
    });
  }

  /* ---------- products ---------- */
  if (req.method === "GET" && path === "/api/products") {
    const room = url.searchParams.get("room");
    const wood = url.searchParams.get("wood");
    const q = (url.searchParams.get("q") || "").trim();
    let sql = "SELECT * FROM products WHERE active = 1";
    const params = [];
    if (room && room !== "all") { sql += " AND room = ?"; params.push(room); }
    if (wood && wood !== "all") { sql += " AND wood = ?"; params.push(wood); }
    if (q) { sql += " AND (name LIKE ? OR spec LIKE ?)"; params.push(`%${q}%`, `%${q}%`); }
    sql += " ORDER BY sort, id";
    const rows = all(sql, params);
    return json(res, 200, { success: true, count: rows.length, data: rows.map(mapProduct) });
  }

  const mProduct = path.match(/^\/api\/products\/([a-z0-9-]+)$/);
  if (req.method === "GET" && mProduct) {
    const p = get("SELECT * FROM products WHERE slug = ? AND active = 1", [mProduct[1]]);
    if (!p) return json(res, 404, { success: false, message: "Không tìm thấy sản phẩm." });
    return json(res, 200, { success: true, data: mapProduct(p) });
  }

  /* ---------- reviews ---------- */
  const mRev = path.match(/^\/api\/products\/([a-z0-9-]+)\/reviews$/);
  if (req.method === "GET" && mRev) {
    const rows = all(
      "SELECT author_label, rating, body, created_at FROM reviews WHERE product_slug = ? AND approved = 1 ORDER BY created_at DESC",
      [mRev[1]]
    );
    const avg = rows.length ? rows.reduce((s, r) => s + r.rating, 0) / rows.length : 0;
    return json(res, 200, {
      success: true,
      count: rows.length,
      average: Number(avg.toFixed(1)),
      data: rows.map((r) => ({ author: r.author_label, rating: r.rating, body: r.body, date: r.created_at.slice(0, 10) })),
    });
  }

  if (req.method === "POST" && mRev) {
    const rl = rateLimit("rev:" + ip, RATE.review, 60 * 60 * 1000);
    if (!rl.ok) return json(res, 429, { success: false, message: "Gửi quá nhiều đánh giá, thử lại sau." }, { "Retry-After": String(rl.retryAfter) });

    const body = await readBody(req, res);
    const orderCode = String(body.orderCode || "").trim().toUpperCase();
    const phone4 = String(body.phoneLast4 || "").replace(/\D/g, "");
    const rating = Number(body.rating);
    const text = String(body.body || "").trim();
    const slug = mRev[1];

    if (!orderCode || phone4.length !== 4) {
      return json(res, 400, { success: false, message: "Cần mã đơn và 4 số cuối điện thoại đặt hàng." });
    }
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
      return json(res, 400, { success: false, message: "Số sao phải từ 1 đến 5." });
    }
    if (text.length < 10 || text.length > 1000) {
      return json(res, 400, { success: false, message: "Nội dung phải từ 10 đến 1000 ký tự." });
    }

    const order = get("SELECT * FROM orders WHERE code = ?", [orderCode]);
    if (!order || order.phone_last4 !== phone4) {
      return json(res, 404, { success: false, message: "Không tìm thấy đơn khớp mã và số điện thoại." });
    }
    if (!get("SELECT id FROM products WHERE slug = ?", [slug])) {
      return json(res, 404, { success: false, message: "Không tìm thấy sản phẩm." });
    }
    if (get("SELECT id FROM reviews WHERE order_code = ? AND product_slug = ?", [orderCode, slug])) {
      return json(res, 409, { success: false, message: "Đơn này đã đánh giá sản phẩm này rồi." });
    }

    run("INSERT INTO reviews (product_slug,order_code,author_label,rating,body,approved) VALUES (?,?,?,?,?,0)",
      [slug, orderCode, order.customer_name + " · khách đã mua", rating, text]);
    return json(res, 201, { success: true, message: "Đã gửi đánh giá, chờ xưởng duyệt.", data: { approved: false } });
  }


  /* ---------- projects ---------- */
  if (req.method === "GET" && path === "/api/projects") {
    const room = url.searchParams.get("room");
    const rows = (room && room !== "all")
      ? all("SELECT * FROM projects WHERE room = ? ORDER BY sort", [room])
      : all("SELECT * FROM projects ORDER BY sort");
    return json(res, 200, { success: true, count: rows.length, data: rows });
  }

  /* ---------- leads ---------- */
  if (req.method === "POST" && path === "/api/leads") {
    const rl = rateLimit("lead:" + ip, RATE.lead, 60 * 60 * 1000);
    if (!rl.ok) return json(res, 429, { success: false, message: "Bạn đã gửi nhiều yêu cầu. Vui lòng gọi 0378.914.207." }, { "Retry-After": String(rl.retryAfter) });

    const body = await readBody(req, res);
    const name = String(body.name || "").trim();
    const phone = String(body.phone || "").replace(/[^\d+]/g, "");
    const area = String(body.area || "").trim().slice(0, 120);
    const need = String(body.need || "").trim().slice(0, 800);

    if (name.length < 2 || name.length > 80) {
      return json(res, 400, { success: false, message: "Vui lòng nhập họ tên từ 2 đến 80 ký tự." });
    }
    if (!VN_PHONE.test(phone.replace(/^\+/, ""))) {
      return json(res, 400, { success: false, message: "Số điện thoại chưa đúng định dạng Việt Nam." });
    }

    /* Chống double submit: cùng số điện thoại + cùng họ tên trong 15 phút
       thì trả lại mã cũ, không tạo lead thứ hai và không thêm dòng Sheet thứ hai. */
    const hash = phoneHash(phone);
    const recent = all(
      `SELECT id, code, name, sheets_status
         FROM leads
        WHERE phone_hash = ? AND created_at >= datetime('now', ?)
        ORDER BY id DESC LIMIT 5`,
      [hash, "-" + LEAD_DEDUPE_MINUTES + " minutes"]
    );
    const dup = recent.find((row) => normalizeName(row.name) === normalizeName(name));
    if (dup) {
      // Lead đã có mà chưa đồng bộ được thì nhân cơ hội gửi lại, vẫn không tạo bản ghi mới.
      if (dup.sheets_status !== "sent") sheets.notifyLeadCreated(dup);
      return json(res, 200, {
        success: true,
        duplicate: true,
        message: "Yêu cầu này đã được ghi nhận trước đó. Thợ cả sẽ gọi lại trong 15 phút giờ hành chính.",
        data: { code: dup.code, duplicate: true },
      });
    }

    const code = "LH-" + Date.now().toString(36).toUpperCase().slice(-6);
    const inserted = run("INSERT INTO leads (code,name,phone,phone_hash,area,need,source) VALUES (?,?,?,?,?,?,?)",
      [code, name, phone, hash, area, need, "website"]);

    // Đồng bộ Sheet chạy nền: lỗi Google không được làm hỏng response của form.
    const savedLead = get("SELECT * FROM leads WHERE id = ?", [Number(inserted.lastInsertRowid)]);
    if (savedLead) sheets.notifyLeadCreated(savedLead);

    return json(res, 201, {
      success: true,
      message: "Đã nhận yêu cầu. Thợ cả sẽ gọi lại trong 15 phút giờ hành chính.",
      data: { code },
    });
  }

  /* ---------- order tracking ---------- */
  const mOrder = path.match(/^\/api\/orders\/([A-Za-z0-9-]{3,24})$/);
  if (req.method === "GET" && mOrder) {
    const rl = rateLimit("track:" + ip, RATE.track, 10 * 60 * 1000);
    if (!rl.ok) return json(res, 429, { success: false, message: "Tra cứu quá nhiều lần, thử lại sau." }, { "Retry-After": String(rl.retryAfter) });

    const code = mOrder[1].toUpperCase();
    const phone4 = (url.searchParams.get("phone") || "").replace(/\D/g, "");
    if (phone4.length !== 4) {
      return json(res, 400, { success: false, message: "Cần 4 số cuối số điện thoại đặt hàng." });
    }
    const order = get("SELECT * FROM orders WHERE code = ?", [code]);
    // so sánh hằng thời gian, và trả cùng một thông báo cho "không có đơn" và "sai số"
    const ok = !!order && crypto.timingSafeEqual(Buffer.from(order.phone_last4), Buffer.from(phone4));
    if (!ok) {
      return json(res, 404, { success: false, message: "Không tìm thấy đơn khớp mã và số điện thoại." });
    }
    const steps = all("SELECT step,title,note,photo_url,done_at FROM order_steps WHERE order_id = ? ORDER BY step", [order.id]);
    return json(res, 200, {
      success: true,
      data: {
        code: order.code,
        customerName: order.customer_name,
        productName: order.product_name,
        stage: order.stage,
        stageName: STEP_TITLES[order.stage - 1],
        stageNote: order.stage_note,
        updatedAt: order.updated_at,
        steps,
      },
    });
  }

  /* ---------- admin ---------- */
  if (path.startsWith("/api/admin/")) {
    if (!requireAdmin(req, res)) return;

    if (req.method === "GET" && path === "/api/admin/leads") {
      const status = url.searchParams.get("status");
      const rows = status
        ? all("SELECT * FROM leads WHERE status = ? ORDER BY created_at DESC LIMIT 200", [status])
        : all("SELECT * FROM leads ORDER BY created_at DESC LIMIT 200");
      return json(res, 200, { success: true, count: rows.length, data: rows });
    }

    if (req.method === "PATCH" && path === "/api/admin/leads/") return json(res, 404, { success: false });

    const mLead = path.match(/^\/api\/admin\/leads\/(\d+)$/);
    if (req.method === "PATCH" && mLead) {
      const body = await readBody(req, res);
      const status = String(body.status || "");
      const allowed = ["new", "called", "measured", "quoted", "won", "lost"];
      if (!allowed.includes(status)) return json(res, 400, { success: false, message: "Trạng thái không hợp lệ." });
      run("UPDATE leads SET status = ? WHERE id = ?", [status, Number(mLead[1])]);
      return json(res, 200, { success: true });
    }

    /* ---------- đồng bộ Google Sheets (quản trị) ---------- */
    if (req.method === "GET" && path === "/api/admin/sheets/status") {
      return json(res, 200, { success: true, data: sheets.getStatus() });
    }

    if (req.method === "POST" && path === "/api/admin/sheets/resync") {
      const body = await readBody(req, res);
      const leadId = body.leadId ? Number(body.leadId) : null;
      if (body.leadId && (!Number.isInteger(leadId) || leadId <= 0)) {
        return json(res, 400, { success: false, message: "leadId không hợp lệ." });
      }
      const result = sheets.resync({
        leadId,
        status: String(body.status || "failed"),
        limit: body.limit,
        force: body.force === true,
      });
      return json(res, 200, { success: true, data: result });
    }

    const mStage = path.match(/^\/api\/admin\/orders\/([A-Za-z0-9-]+)$/);
    if (req.method === "PATCH" && mStage) {
      const body = await readBody(req, res);
      const stage = Number(body.stage);
      if (!Number.isInteger(stage) || stage < 1 || stage > 5) {
        return json(res, 400, { success: false, message: "Bước phải từ 1 đến 5." });
      }
      const order = get("SELECT * FROM orders WHERE code = ?", [mStage[1].toUpperCase()]);
      if (!order) return json(res, 404, { success: false, message: "Không tìm thấy đơn." });
      const nextNote = String(body.note || order.stage_note).slice(0, 300);
      run("UPDATE orders SET stage = ?, stage_note = ?, updated_at = datetime('now') WHERE id = ?",
        [stage, nextNote, order.id]);
      run("UPDATE order_steps SET done_at = COALESCE(done_at, date('now')), note = ? WHERE order_id = ? AND step = ?",
        [String(body.note || "").slice(0, 300), order.id, stage]);
      return json(res, 200, { success: true, data: { code: order.code, stage } });
    }

    const mRevApprove = path.match(/^\/api\/admin\/reviews\/(\d+)$/);
    if (req.method === "PATCH" && mRevApprove) {
      const body = await readBody(req, res);
      const approved = body.approved === false ? 0 : 1;
      run("UPDATE reviews SET approved = ? WHERE id = ?", [approved, Number(mRevApprove[1])]);
      return json(res, 200, { success: true });
    }

    if (req.method === "GET" && path === "/api/admin/reviews") {
      const rows = all("SELECT * FROM reviews ORDER BY approved, created_at DESC LIMIT 200");
      return json(res, 200, { success: true, count: rows.length, data: rows });
    }

    return json(res, 404, { success: false, message: "Endpoint quản trị không tồn tại." });
  }

  return json(res, 404, { success: false, message: "Không tìm thấy endpoint." });
}

module.exports = { handle, ALLOWED_ORIGINS };
