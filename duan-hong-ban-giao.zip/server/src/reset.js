"use strict";
/**
 * Xoá sạch dữ liệu test và nạp lại dữ liệu mẫu.
 *
 *   npm run reset                    # dùng DB mặc định
 *   DB_PATH=/var/lib/duanhong/duanhong.db node src/reset.js
 *   npm run reset -- --yes           # không hỏi xác nhận (dùng trong script deploy)
 *
 * CẢNH BÁO: lệnh này xoá toàn bộ lead, đơn, đánh giá hiện có.
 */
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");

const DB_PATH = process.env.DB_PATH || path.join(__dirname, "..", "data", "duanhong.db");
const YES = process.argv.includes("--yes") || process.argv.includes("-y");

function ask(q) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(q, (a) => { rl.close(); resolve(a.trim().toLowerCase()); });
  });
}

(async () => {
  console.log("DB sẽ xoá : " + DB_PATH);

  if (fs.existsSync(DB_PATH)) {
    const st = fs.statSync(DB_PATH);
    console.log("Kích thước: " + (st.size / 1024).toFixed(0) + " KB");
  } else {
    console.log("Chưa có file DB — sẽ tạo mới.");
  }

  if (!YES) {
    const a = await ask("Xoá toàn bộ lead / đơn / đánh giá và nạp lại dữ liệu mẫu? (gõ 'xoa' để tiếp tục): ");
    if (a !== "xoa") {
      console.log("Đã huỷ. Không có gì bị thay đổi.");
      process.exit(0);
    }
  }

  // WAL/SHM phải xoá cùng, nếu không SQLite sẽ dựng lại dữ liệu cũ
  for (const f of [DB_PATH, DB_PATH + "-wal", DB_PATH + "-shm"]) {
    try { fs.unlinkSync(f); console.log("đã xoá  " + f); } catch (e) { if (e.code !== "ENOENT") throw e; }
  }

  // nạp lại: require db.js sẽ tự tạo schema + seed
  const { all } = require("./db");
  const counts = {
    products: all("SELECT COUNT(*) c FROM products")[0].c,
    projects: all("SELECT COUNT(*) c FROM projects")[0].c,
    orders: all("SELECT COUNT(*) c FROM orders")[0].c,
    leads: all("SELECT COUNT(*) c FROM leads")[0].c,
    reviews: all("SELECT COUNT(*) c FROM reviews")[0].c,
  };

  console.log("\nĐã nạp lại dữ liệu mẫu:");
  for (const [k, v] of Object.entries(counts)) console.log("  " + k.padEnd(10) + v);

  if (counts.leads !== 0) {
    console.log("\nCẢNH BÁO: bảng leads không rỗng sau khi reset — kiểm tra lại DB_PATH.");
    process.exit(1);
  }
  console.log("\nXong. Chạy 'npm start' để khởi động máy chủ.");
})();
