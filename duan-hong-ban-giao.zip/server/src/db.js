"use strict";
/**
 * Lớp dữ liệu: SQLite qua node:sqlite (built-in, không cần npm install).
 * - Tạo schema nếu chưa có
 * - Seed dữ liệu mẫu lần đầu
 * - Chỉ dùng prepared statement (không nối chuỗi SQL)
 */
/* BUG-08: node:sqlite chỉ có từ Node 22.5. Nếu chạy Node 18/20 thì thử better-sqlite3,
   nếu không có cả hai thì báo lỗi tiếng Việt rõ ràng thay vì crash khó hiểu. */
let DatabaseSync;
try {
  ({ DatabaseSync } = require("node:sqlite"));
} catch (err) {
  try {
    const Better = require("better-sqlite3");
    // adapter tối thiểu để phần còn lại của db.js không phải đổi
    DatabaseSync = class {
      constructor(file) { this._db = new Better(file); }
      exec(sql) { this._db.exec(sql); }
      prepare(sql) {
        const st = this._db.prepare(sql);
        return {
          run: (...a) => st.run(...a),
          get: (...a) => st.get(...a),
          all: (...a) => st.all(...a),
        };
      }
      close() { this._db.close(); }
    };
    console.warn("[db] Đang dùng better-sqlite3 (Node " + process.versions.node + " < 22.5).");
  } catch (err2) {
    const line = "=".repeat(66);
    console.error(line);
    console.error("  KHÔNG CHẠY ĐƯỢC: backend cần SQLite nhưng máy chưa có module phù hợp");
    console.error(`  Node hiện tại: ${process.versions.node}`);
    console.error("");
    console.error("  Cách 1 (khuyến nghị): nâng Node lên >= 22.5");
    console.error("    https://nodejs.org/en/download  ·  hoặc:  nvm install 22 && nvm use 22");
    console.error("");
    console.error("  Cách 2: giữ Node cũ và cài better-sqlite3");
    console.error("    npm install better-sqlite3");
    console.error(line);
    process.exit(1);
  }
}
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const DB_PATH = process.env.DB_PATH || path.join(__dirname, "..", "data", "duanhong.db");
const PHONE_SALT = process.env.PHONE_SALT || "duanhong-local-salt-change-me";

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new DatabaseSync(DB_PATH);
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");

const SCHEMA = `
CREATE TABLE IF NOT EXISTS products (
  id          INTEGER PRIMARY KEY,
  slug        TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  tag         TEXT NOT NULL,
  room        TEXT NOT NULL CHECK (room IN ('khach','ngu','tho','bep')),
  wood        TEXT NOT NULL,
  spec        TEXT NOT NULL,
  price       INTEGER,
  price_note  TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  active      INTEGER NOT NULL DEFAULT 1,
  sort        INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS projects (
  id       INTEGER PRIMARY KEY,
  title    TEXT NOT NULL,
  place    TEXT NOT NULL,
  room     TEXT NOT NULL,
  area_m2  INTEGER,
  spec     TEXT NOT NULL,
  wood     TEXT NOT NULL,
  days     INTEGER,
  price    INTEGER,
  quote    TEXT NOT NULL DEFAULT '',
  status   TEXT NOT NULL DEFAULT 'done' CHECK (status IN ('done','in_progress')),
  sort     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS orders (
  id            INTEGER PRIMARY KEY,
  code          TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  phone_last4   TEXT NOT NULL,
  phone_hash    TEXT NOT NULL,
  product_name  TEXT NOT NULL,
  stage         INTEGER NOT NULL DEFAULT 1 CHECK (stage BETWEEN 1 AND 5),
  stage_note    TEXT NOT NULL DEFAULT '',
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_steps (
  id        INTEGER PRIMARY KEY,
  order_id  INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  step      INTEGER NOT NULL CHECK (step BETWEEN 1 AND 5),
  title     TEXT NOT NULL,
  note      TEXT NOT NULL DEFAULT '',
  photo_url TEXT NOT NULL DEFAULT '',
  done_at   TEXT,
  UNIQUE (order_id, step)
);

CREATE TABLE IF NOT EXISTS leads (
  id         INTEGER PRIMARY KEY,
  code       TEXT NOT NULL UNIQUE,
  name       TEXT NOT NULL,
  phone      TEXT NOT NULL,
  phone_hash TEXT NOT NULL,
  area       TEXT NOT NULL DEFAULT '',
  need       TEXT NOT NULL DEFAULT '',
  source     TEXT NOT NULL DEFAULT 'website',
  status     TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','called','measured','quoted','won','lost')),
  note       TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  /* Trạng thái đồng bộ Google Sheets (Giai đoạn 2). Cột này cũng được
     bổ sung bằng migration idempotent cho database đã có sẵn. */
  sheets_status    TEXT NOT NULL DEFAULT 'pending',
  sheets_row       INTEGER,
  sheets_error     TEXT NOT NULL DEFAULT '',
  sheets_synced_at TEXT,
  sync_attempts    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS reviews (
  id           INTEGER PRIMARY KEY,
  product_slug TEXT NOT NULL,
  order_code   TEXT NOT NULL,
  author_label TEXT NOT NULL,
  rating       INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  body         TEXT NOT NULL,
  approved     INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_products_slug   ON products(slug);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status, sort);
CREATE INDEX IF NOT EXISTS idx_orders_code     ON orders(code);
CREATE INDEX IF NOT EXISTS idx_leads_created   ON leads(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_slug, approved);
CREATE UNIQUE INDEX IF NOT EXISTS idx_reviews_unique ON reviews(order_code, product_slug);

`;

db.exec(SCHEMA);

/* ---------------------- MIGRATION IDEMPOTENT (Giai đoạn 2) ---------------
 * Database cũ đang có lead thật: chỉ ALTER TABLE khi cột còn thiếu, không
 * xoá bảng, không nạp lại dữ liệu. Chạy lại bao nhiêu lần cũng an toàn.
 * PRAGMA table_info không nhận tham số nên tên bảng ở đây là hằng trong mã.
 */
const LEAD_SHEETS_COLUMNS = [
  ["sheets_status", "TEXT NOT NULL DEFAULT 'pending'"],
  ["sheets_row", "INTEGER"],
  ["sheets_error", "TEXT NOT NULL DEFAULT ''"],
  ["sheets_synced_at", "TEXT"],
  ["sync_attempts", "INTEGER NOT NULL DEFAULT 0"],
];

function migrateLeadsSheets() {
  const existing = new Set(db.prepare("PRAGMA table_info(leads)").all().map((c) => c.name));
  const added = [];
  for (const [name, ddl] of LEAD_SHEETS_COLUMNS) {
    if (existing.has(name)) continue;
    db.exec(`ALTER TABLE leads ADD COLUMN ${name} ${ddl}`);
    added.push(name);
  }
  db.exec("CREATE INDEX IF NOT EXISTS idx_leads_sheets ON leads(sheets_status)");
  // Truy vấn chống gửi trùng tra theo phone_hash
  db.exec("CREATE INDEX IF NOT EXISTS idx_leads_phone_hash ON leads(phone_hash)");
  return added;
}

const addedLeadColumns = migrateLeadsSheets();
if (addedLeadColumns.length) {
  console.log("[db] migration leads: đã thêm cột " + addedLeadColumns.join(", "));
}

const phoneHash = (phone) =>
  crypto.createHash("sha256").update(String(phone).replace(/\D/g, "") + PHONE_SALT).digest("hex");

const last4 = (phone) => String(phone).replace(/\D/g, "").slice(-4);



/* ------------------------------- SEED ---------------------------------- */
const PRODUCTS = [
  ["sofa-go-do", "Sofa gõ đỏ chân quỳ", "Phòng khách", "khach", "go-do",
   "Văng 2m80 + văng 1m90 + bàn trà + ghế đơn + đôn kẹp", 74500000,
   "Bộ 5 món · Gõ Đỏ Pachy Nam Phi",
   "Bộ sofa 5 món gỗ Gõ Đỏ Pachy cho phòng khách, đóng theo kích thước phòng và cung Lỗ Ban. Gia chủ kiểm tra phôi mộc và ký tên trước khi sơn PU.", 1],
  ["an-gian-tho", "Án gian thờ nhị cấp", "Phòng thờ", "tho", "huong-da",
   "Cao 2m17 · 2 cấp · chạm kênh bong", 48000000, "Gỗ Hương Đá chọn thớ",
   "Án gian thờ nhị cấp gỗ Hương Đá, chạm kênh bong, đo theo khoảng lọt lòng của phòng thờ. Số đo được ghi vào phiếu bảo hành 5 năm.", 2],
  ["combo-phong-ngu", "Combo phòng ngủ Tổ Ấm", "Phòng ngủ", "ngu", "soi-nga",
   "Giường 1m8×2m · tủ 4 cánh · 2 tab · bàn phấn", 36900000, "4 món · Sồi Nga nhập khẩu",
   "Combo phòng ngủ 4 món gỗ Sồi Nga: giường 1m8, tủ 4 cánh kịch trần, 2 tab đầu giường và bàn phấn. Đóng theo chiều cao trần thực tế.", 3],
  ["ban-an-live-edge", "Bàn ăn live-edge", "Phòng khách", "khach", "go-do",
   "Dài 2m20 · mặt nguyên tấm · kèm 8 ghế", 38000000, "Gỗ Gõ Đỏ · cạnh tự nhiên",
   "Bàn ăn live-edge giữ nguyên cạnh tự nhiên của tấm gỗ, mặt dày 12cm. Chiều dài chốt theo phòng ăn và số người dùng.", 4],
  ["tu-bep-mdf", "Tủ bếp cánh phẳng", "Tủ bếp", "bep", "mdf",
   "Thiết kế theo mét dài · ray giảm chấn", null, "Báo giá theo mét dài sau khi đo",
   "Tủ bếp cánh phẳng MDF lõi xanh chống ẩm An Cường, ray giảm chấn. Giá tính theo mét dài và cấu hình khoang.", 5],
  ["tu-quan-ao-soi", "Tủ quần áo 4 cánh kịch trần", "Phòng ngủ", "ngu", "soi-nga",
   "Cao kịch trần · chia khoang theo yêu cầu", null, "Nằm trong combo Tổ Ấm hoặc làm lẻ",
   "Tủ quần áo 4 cánh kịch trần gỗ Sồi Nga, chia khoang theo nhu cầu sử dụng. Có thể đặt trong combo Tổ Ấm hoặc làm lẻ.", 6],
];

const PROJECTS = [
  ["Bộ sofa gõ đỏ chân quỳ 5 món", "Mỹ Hào · đơn DH-801", "khach", 45, "Văng 2m80 + 1m90", "Gõ Đỏ Pachy", 62, 74500000,
   "Tôi về xưởng ký tên lên gầm bàn trước khi sơn. Bàn đo đúng 2m74, giao lắp đủ 5 món trong một buổi.", "done"],
  ["Án gian thờ nhị cấp", "TP. Hưng Yên · đơn DH-802", "tho", 18, "Cao 2m17 · 2 cấp", "Hương Đá", 48, 48000000,
   "Thợ đo tận nhà, giải thích rõ từng cung. Phần mộc thô tôi được xem trước khi vào sơn.", "done"],
  ["Combo phòng ngủ sồi Nga 4 món", "Thị trấn Bần · đơn DH-803", "ngu", 22, "Giường 1m8 · tủ 4 cánh · 2 tab · bàn phấn", "Sồi Nga", 41, 36900000,
   "Đóng kịch trần nên phải đo rất kỹ. Xưởng đo lại 2 lần mới cắt phôi.", "done"],
  ["Bàn ăn live-edge 8 ghế", "Văn Giang · đơn DH-804", "bep", 26, "Dài 2m20 · mặt nguyên tấm", "Gõ Đỏ", 56, 38000000,
   "Giữ cạnh tự nhiên nên vân gỗ là điểm nhấn của cả phòng ăn.", "done"],
  ["Phòng khách gỗ óc chó", "TP. Hưng Yên · đơn DH-805", "khach", 54, "Sofa góc + bàn trà + 2 ghế đơn", "Óc Chó Bắc Mỹ FAS", null, null,
   "Công trình này đang ở bước 3/5. Theo dõi tiến độ thật tại trang tra cứu.", "in_progress"],
];

const STEP_TITLES = [
  "Chốt kích thước & cung Lỗ Ban",
  "Sấy phôi chân không",
  "Ghép mộng & đục chạm",
  "Gia chủ ký mộc thô",
  "Sơn PU & bàn giao",
];

const ORDERS = [
  ["DH-801", "Anh Hoàng Nam", "0912445889", "Sofa gõ đỏ chân quỳ · 2m74", 3, "Đang ghép mộng mặt bàn, dự kiến xong 09/11"],
  ["DH-802", "Bác Trọng Cường", "0904556778", "Án gian thờ nhị cấp 2m17", 4, "Đã ký mộc 05/11, chuyển sang phun PU"],
  ["DH-803", "Chị Minh Tuyết", "0983112334", "Combo phòng ngủ sồi Nga", 2, "Phôi đang trong lò, độ ẩm 14% ngày 07/11"],
];

function seed() {
  const n = db.prepare("SELECT COUNT(*) AS c FROM products").get().c;
  if (n > 0) return;

  const insP = db.prepare(`INSERT INTO products
    (slug,name,tag,room,wood,spec,price,price_note,description,active,sort)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
  PRODUCTS.forEach((p, i) => {
    const [slug, name, tag, room, wood, spec, price, priceNote, description] = p;
    insP.run(slug, name, tag, room, wood, spec, price, priceNote, description, 1, i + 1);
  });

  const insPr = db.prepare(`INSERT INTO projects
    (title,place,room,area_m2,spec,wood,days,price,quote,status,sort)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
  PROJECTS.forEach((p, i) => insPr.run(...p, i + 1));

  const insO = db.prepare(`INSERT INTO orders
    (code,customer_name,phone_last4,phone_hash,product_name,stage,stage_note)
    VALUES (?,?,?,?,?,?,?)`);
  const insS = db.prepare(`INSERT INTO order_steps (order_id,step,title,note,photo_url,done_at)
    VALUES (?,?,?,?,?,?)`);
  for (const [code, name, phone, product, stage, note] of ORDERS) {
    const r = insO.run(code, name, last4(phone), phoneHash(phone), product, stage, note);
    for (let s = 1; s <= 5; s++) {
      const done = s < stage ? "2026-11-0" + (s + 3) : null;
      insS.run(r.lastInsertRowid, s, STEP_TITLES[s - 1], s === stage ? note : "", "", done);
    }
  }

  const insR = db.prepare(`INSERT INTO reviews
    (product_slug,order_code,author_label,rating,body,approved) VALUES (?,?,?,?,?,?)`);
  insR.run("sofa-go-do", "DH-801", "Anh Hoàng Nam · Mỹ Hào", 5,
    "Tôi về xưởng ký tên lên gầm bàn trước khi sơn. Bàn đo đúng 2m74 rơi cung đỏ theo yêu cầu, giao lắp đủ 5 món trong một buổi.", 1);
  insR.run("sofa-go-do", "DH-802", "Bác Trọng Cường · TP. Hưng Yên", 5,
    "Thợ đo tận nhà và giải thích rõ từng cung. Phần mộc thô tôi được xem trước khi vào sơn.", 1);

  console.log("[db] đã seed dữ liệu mẫu");
}

seed();

/* ------------------------------ Helpers -------------------------------- */
const all = (sql, params = []) => db.prepare(sql).all(...params);
const get = (sql, params = []) => db.prepare(sql).get(...params);
const run = (sql, params = []) => db.prepare(sql).run(...params);

module.exports = { db, all, get, run, phoneHash, last4, DB_PATH, STEP_TITLES };
