"use strict";
/** Điểm vào duy nhất của module đồng bộ Google Sheets. */
module.exports = {
  ...require("./sync"),
  queue: require("./queue"),
  client: require("./client"),
  config: require("./config"),
};
