"use strict";
/**
 * Đồng bộ lead từ SQLite sang Google Sheets.
 *
 * Hợp đồng quan trọng:
 *  - SQLite là nguồn sự thật. Google lỗi thì lead vẫn còn, chỉ đổi trạng thái.
 *  - Chỉ ghi `sent` SAU KHI Google xác nhận thành công.
 *  - Mã lead (`code`) là khoá idempotency: trước khi thêm dòng, tìm lại mã trong Sheet.
 *    Nhờ vậy append lỗi giữa đường rồi retry vẫn không sinh dòng thứ hai.
 *  - Cột H..K (trạng thái xử lý, người phụ trách, ghi chú, lần liên hệ) là của xưởng:
 *    khi cập nhật lại một dòng đã có, chỉ ghi A..G để không đè lên ghi chú tay.
 */
const { all, get, run } = require("../db");
const { loadConfig, publicSummary } = require("./config");
const { GoogleSheetsClient } = require("./client");
const queue = require("./queue");

/** Tiêu đề cột của tab "Khách hàng" — dùng cho tài liệu và test đối chiếu. */
const SHEET_HEADERS = [
  "Thời gian gửi",
  "Mã yêu cầu",
  "Họ và tên",
  "Số điện thoại",
  "Khu vực / địa chỉ",
  "Nhu cầu / nội dung",
  "Nguồn",
  "Trạng thái xử lý",
  "Người phụ trách",
  "Ghi chú",
  "Thời gian liên hệ gần nhất",
];

const LEAD_STATUS_VN = {
  new: "Mới nhận",
  called: "Đã liên hệ",
  measured: "Đang tư vấn",
  quoted: "Đang tư vấn",
  won: "Đã chốt",
  lost: "Chưa có nhu cầu",
};

const MAX_ERROR_LEN = 500;

let cachedConfig = null;
let cachedClient = null;
let warnedMissing = false;

function getConfigSafe() {
  if (cachedConfig) return cachedConfig;
  try {
    const cfg = loadConfig();
    if (!cfg.enabled) {
      cachedConfig = {
        cfg: null,
        error: Object.assign(new Error("Đồng bộ Google Sheets đang tắt (SHEETS_SYNC=off)."), {
          code: "SHEETS_NOT_CONFIGURED",
          missing: ["SHEETS_SYNC"],
        }),
      };
    } else {
      cachedConfig = { cfg, error: null };
    }
  } catch (err) {
    cachedConfig = { cfg: null, error: err };
  }
  if (!cachedConfig.cfg && !warnedMissing) {
    warnedMissing = true;
    console.error("[sheets] " + cachedConfig.error.message);
  }
  return cachedConfig;
}

function getClient(cfg) {
  if (!cachedClient) cachedClient = new GoogleSheetsClient(cfg);
  return cachedClient;
}

/** Chỉ dùng trong test: xoá cấu hình/client đã cache. */
function resetForTest() {
  cachedConfig = null;
  cachedClient = null;
  warnedMissing = false;
  queue.clear();
}

/** created_at của SQLite là UTC ("YYYY-MM-DD HH:MM:SS"); Sheet hiển thị giờ Việt Nam. */
function formatVnTime(sqliteUtc) {
  const raw = String(sqliteUtc || "").trim();
  const d = new Date(raw.replace(" ", "T") + "Z");
  if (Number.isNaN(d.getTime())) return raw;
  const vn = new Date(d.getTime() + 7 * 3600 * 1000);
  const p = (n) => String(n).padStart(2, "0");
  return `${p(vn.getUTCDate())}/${p(vn.getUTCMonth() + 1)}/${vn.getUTCFullYear()} ${p(vn.getUTCHours())}:${p(vn.getUTCMinutes())}`;
}

/** Dòng đúng 11 ô theo thứ tự cột A..K. */
function buildRow(lead) {
  return [
    formatVnTime(lead.created_at),
    String(lead.code || ""),
    String(lead.name || ""),
    String(lead.phone || ""),
    String(lead.area || ""),
    String(lead.need || ""),
    String(lead.source || "website"),
    LEAD_STATUS_VN[lead.status] || String(lead.status || "Mới nhận"),
    "", // Người phụ trách — xưởng tự điền
    String(lead.note || ""),
    "", // Thời gian liên hệ gần nhất — xưởng tự điền
  ];
}

function markFailed(leadId, message) {
  const msg = String(message || "Lỗi không xác định").slice(0, MAX_ERROR_LEN);
  run("UPDATE leads SET sheets_status = 'failed', sheets_error = ? WHERE id = ?", [msg, leadId]);
  return msg;
}

/**
 * Đồng bộ một lead theo id. An toàn khi gọi lặp lại nhiều lần.
 * @returns {Promise<{ok:boolean, row?:number, skipped?:boolean, error?:string, attempts?:number}>}
 */
async function syncLeadById(leadId) {
  const lead = get("SELECT * FROM leads WHERE id = ?", [Number(leadId)]);
  if (!lead) return { ok: false, error: "LEAD_NOT_FOUND" };
  if (lead.sheets_status === "sent" && lead.sheets_row) {
    return { ok: true, skipped: true, row: lead.sheets_row };
  }

  const { cfg, error } = getConfigSafe();
  if (!cfg) {
    const msg = markFailed(lead.id, "Chưa cấu hình Google Sheets: " + error.message);
    return { ok: false, error: msg, configured: false };
  }

  const client = getClient(cfg);
  const values = buildRow(lead);

  try {
    let row = lead.sheets_row ? Number(lead.sheets_row) : null;
    if (cfg.mode === "apps-script") {
      row = await client.syncAppsScript(lead, values);
    } else if (row) {
      await client.updateRow(row, values.slice(0, 7));
    } else {
      const existing = await client.findRowByCode(lead.code);
      if (existing) {
        row = existing;
        await client.updateRow(row, values.slice(0, 7));
      } else {
        row = await client.appendRow(values);
      }
    }

    run(
      `UPDATE leads
          SET sheets_status = 'sent',
              sheets_row = ?,
              sheets_error = '',
              sheets_synced_at = datetime('now'),
              sync_attempts = sync_attempts + 1
        WHERE id = ?`,
      [row, lead.id]
    );
    console.log(`[sheets] ${lead.code} → dòng ${row} (đã đồng bộ)`);
    return { ok: true, row };
  } catch (err) {
    const msg = markFailed(lead.id, (err && err.message) || err);
    const current = get("SELECT sync_attempts FROM leads WHERE id = ?", [lead.id]);
    const attempts = (current ? current.sync_attempts : 0) + 1;
    run("UPDATE leads SET sync_attempts = sync_attempts + 1 WHERE id = ?", [lead.id]);
    console.error(`[sheets] ${lead.code} lỗi lần ${attempts}: ${msg}`);

    if (cfg.enabled && attempts < cfg.maxAttempts) {
      const delay = cfg.retryBaseMs * Math.pow(2, attempts - 1);
      const queued = queue.enqueue(lead.id, delay);
      if (queued) console.warn(`[sheets] ${lead.code} sẽ thử lại sau ${delay}ms (lần ${attempts + 1}/${cfg.maxAttempts})`);
    } else {
      console.error(`[sheets] ${lead.code} dừng thử lại sau ${attempts} lần — chờ quản trị đồng bộ lại.`);
    }
    return { ok: false, error: msg, attempts };
  }
}

/**
 * Gọi sau khi đã lưu lead vào SQLite. Không bao giờ ném lỗi,
 * để lỗi Google không làm hỏng response của form.
 */
function notifyLeadCreated(lead) {
  try {
    if (!lead || !lead.id) return;
    const { cfg } = getConfigSafe();
    if (!cfg) {
      markFailed(lead.id, getConfigSafe().error.message);
      return;
    }
    queue.enqueue(lead.id, 0);
  } catch (err) {
    console.error("[sheets] không xếp được lead vào hàng đợi:", (err && err.message) || err);
  }
}

/** Trạng thái cấu hình + số đếm theo trạng thái đồng bộ. Không chứa secret. */
function getStatus() {
  const { cfg, error } = getConfigSafe();
  const counts = {};
  for (const r of all("SELECT sheets_status AS s, COUNT(*) AS c FROM leads GROUP BY sheets_status")) {
    counts[r.s] = r.c;
  }
  const summary = publicSummary(cfg);
  return {
    ...summary,
    configured: !!cfg,
    reason: cfg ? "" : error.message,
    missing: cfg ? [] : error.missing || [],
    queue: {
      pending: queue.pendingCount(),
      running: queue.runningCount(),
      maxAttempts: cfg ? cfg.maxAttempts : null,
      retryBaseMs: cfg ? cfg.retryBaseMs : null,
    },
    counts,
    headers: SHEET_HEADERS,
  };
}

/**
 * Đồng bộ lại lead lỗi (hoặc theo id cụ thể). Không động lead đã `sent`
 * trừ khi force = true.
 */
function resync({ leadId = null, status = "failed", limit = 50, force = false } = {}) {
  const { cfg } = getConfigSafe();
  const max = Math.min(Math.max(Number(limit) || 50, 1), 200);
  const queuedIds = [];

  if (leadId) {
    const lead = get("SELECT id, sheets_status FROM leads WHERE id = ?", [Number(leadId)]);
    if (!lead) return { queued: 0, configured: !!cfg, reason: "LEAD_NOT_FOUND", ids: [] };
    if (lead.sheets_status === "sent" && !force) {
      return { queued: 0, configured: !!cfg, reason: "ALREADY_SENT", ids: [] };
    }
    run("UPDATE leads SET sheets_status = 'pending', sheets_error = '' WHERE id = ?", [lead.id]);
    queue.enqueue(lead.id, 0);
    // Lead đã có job đang chờ/đang chạy vẫn được tính là đã xếp hàng.
    if (queue.isQueued(lead.id)) queuedIds.push(lead.id);
    return {
      queued: queuedIds.length,
      configured: !!cfg,
      reason: cfg ? "" : getConfigSafe().error.message,
      ids: queuedIds,
    };
  }

  const allowed = ["pending", "failed"];
  const target = allowed.includes(status) ? status : "failed";
  const rows = all(
    "SELECT id FROM leads WHERE sheets_status = ? ORDER BY id ASC LIMIT ?",
    [target, max]
  );
  for (const r of rows) {
    run("UPDATE leads SET sheets_status = 'pending', sheets_error = '' WHERE id = ?", [r.id]);
    queue.enqueue(r.id, 0);
    if (queue.isQueued(r.id)) queuedIds.push(r.id);
  }
  return {
    queued: queuedIds.length,
    configured: !!cfg,
    reason: cfg ? "" : getConfigSafe().error.message,
    ids: queuedIds,
  };
}

/**
 * Khởi động lại khi server bật: tiếp tục các lead `pending` chưa gửi xong.
 */
function resumePending(limit = 50) {
  const { cfg } = getConfigSafe();
  if (!cfg) return { resumed: 0, configured: false };
  const rows = all(
    "SELECT id FROM leads WHERE sheets_status = 'pending' ORDER BY id ASC LIMIT ?",
    [Math.min(Math.max(Number(limit) || 50, 1), 200)]
  );
  for (const r of rows) {
    queue.enqueue(r.id, 0);
  }
  return { resumed: rows.length, configured: true };
}

queue.configure({ attempt: syncLeadById });

module.exports = {
  syncLeadById,
  notifyLeadCreated,
  getStatus,
  resync,
  resumePending,
  buildRow,
  formatVnTime,
  resetForTest,
  SHEET_HEADERS,
  LEAD_STATUS_VN,
};
