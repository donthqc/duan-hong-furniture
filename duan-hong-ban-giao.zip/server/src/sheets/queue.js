"use strict";
/**
 * Hàng đợi thử lại trong tiến trình cho việc đồng bộ Google Sheets.
 *
 * Nguyên tắc:
 *  - Hàng đợi KHÔNG lưu lead. Nguồn sự thật là SQLite; tiến trình chết thì lead vẫn còn.
 *  - Mỗi lead chỉ có tối đa một job đang chờ và một job đang chạy → retry không nhân bản.
 *  - Timer được unref() để hàng đợi không giữ tiến trình sống khi tắt máy chủ.
 *  - Số lần thử bị chặn bởi maxAttempts; quá hạn thì dừng và để trạng thái `failed`
 *    cho quản trị bấm đồng bộ lại bằng tay.
 */
const jobs = new Map(); // leadId -> { timer, dueAt }
const running = new Set();
let handler = null;
let options = { maxAttempts: 3, baseMs: 5000 };

function configure({ attempt, maxAttempts, baseMs } = {}) {
  if (typeof attempt === "function") handler = attempt;
  options = {
    maxAttempts: Number(maxAttempts) > 0 ? Number(maxAttempts) : options.maxAttempts,
    baseMs: Number(baseMs) > 0 ? Number(baseMs) : options.baseMs,
  };
}

function pendingCount() {
  return jobs.size;
}

function runningCount() {
  return running.size;
}

/** Lead đang có job chờ hoặc đang chạy trong hàng đợi. */
function isQueued(leadId) {
  const id = Number(leadId);
  return jobs.has(id) || running.has(id);
}

function schedule(id, delayMs) {
  const wait = Math.max(0, Number(delayMs) || 0);
  const timer = setTimeout(() => fire(id), wait);
  if (typeof timer.unref === "function") timer.unref();
  jobs.set(id, { timer, dueAt: Date.now() + wait });
}

function fire(id) {
  jobs.delete(id);
  // Job cũ chưa xong (ví dụ retry được xếp ngay trong lúc đang gửi) → chờ tiếp.
  if (running.has(id)) {
    schedule(id, 25);
    return;
  }
  void execute(id);
}

/**
 * Đưa một lead vào hàng đợi.
 * @returns {boolean} true nếu đã tạo job mới
 */
function enqueue(leadId, delayMs = 0) {
  const id = Number(leadId);
  if (!handler || !Number.isInteger(id) || id <= 0) return false;
  const wait = Math.max(0, Number(delayMs) || 0);
  const existing = jobs.get(id);
  if (existing) {
    // Đã có job chờ: chỉ thay khi mốc mới sớm hơn, không tạo hai job.
    if (Date.now() + wait < existing.dueAt) {
      clearTimeout(existing.timer);
      schedule(id, wait);
    }
    return false;
  }
  schedule(id, wait);
  return true;
}

async function execute(leadId) {
  if (running.has(leadId)) return;
  running.add(leadId);
  try {
    await handler(leadId);
  } catch (err) {
    // Lỗi ở tầng hàng đợi không được làm chết máy chủ.
    console.error("[sheets] job lỗi ngoài dự kiến:", (err && err.message) || err);
  } finally {
    running.delete(leadId);
  }
}

/** Xoá toàn bộ job đang chờ (dùng khi tắt máy chủ hoặc trong test). */
function clear() {
  for (const { timer } of jobs.values()) clearTimeout(timer);
  jobs.clear();
}

module.exports = { configure, enqueue, pendingCount, runningCount, isQueued, clear, options: () => ({ ...options }) };
