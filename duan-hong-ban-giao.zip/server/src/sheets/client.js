"use strict";
/**
 * Client Google Sheets API viết tay bằng node:http/fetch + node:crypto.
 * Không thêm thư viện ngoài, giữ đúng kiến trúc dự án.
 *
 * Hỗ trợ 2 phương thức:
 *  1. Google Apps Script Web App (qua fetch HTTP POST với redirect follow)
 *  2. Google Sheets API v4 (Service Account -> ký JWT RS256 -> đổi access token -> gọi Sheets API)
 */
const crypto = require("node:crypto");

class SheetsApiError extends Error {
  constructor(message, extra = {}) {
    super(message);
    this.name = "SheetsApiError";
    this.code = extra.code || "SHEETS_API_ERROR";
    this.status = extra.status || 0;
  }
}

const b64url = (buf) =>
  Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

/** Escape tên tab cho A1 notation: tab có dấu cách/dấu tiếng Việt phải bọc nháy đơn. */
function quoteTab(tab) {
  return "'" + String(tab).replace(/'/g, "''") + "'";
}

/** Ký JWT RS256 cho service account. */
function signJwt({ clientEmail, privateKey, scope, aud, now }) {
  const iat = now || Math.floor(Date.now() / 1000);
  const header = { alg: "RS256", typ: "JWT" };
  const claims = {
    iss: clientEmail,
    scope,
    aud,
    iat,
    exp: iat + 3600,
  };
  const input = b64url(JSON.stringify(header)) + "." + b64url(JSON.stringify(claims));
  const signature = crypto.createSign("RSA-SHA256").update(input).sign(privateKey);
  return input + "." + b64url(signature);
}

/** Cắt ngắn nội dung lỗi trả về để log không phình và không lộ token. */
function safeSnippet(text) {
  const s = String(text || "").replace(/\s+/g, " ").trim();
  return s.length > 220 ? s.slice(0, 220) + "…" : s;
}

class GoogleSheetsClient {
  /**
   * @param {object} cfg cấu hình từ config.loadConfig()
   * @param {object} deps cho phép test tiêm fetch/đồng hồ khác
   */
  constructor(cfg, deps = {}) {
    this.cfg = cfg;
    this.fetch = deps.fetch || globalThis.fetch;
    this.now = deps.now || Date.now;
    this._token = null;
    this._tokenExpiresAt = 0;
    if (typeof this.fetch !== "function") {
      throw new SheetsApiError("Máy chủ Node không có fetch toàn cục (cần Node >= 18).");
    }
  }

  async accessToken() {
    if (this.cfg.accessToken) return this.cfg.accessToken;
    if (this._token && this.now() < this._tokenExpiresAt) return this._token;

    const assertion = signJwt({
      clientEmail: this.cfg.clientEmail,
      privateKey: this.cfg.privateKey,
      scope: this.cfg.scope,
      aud: this.cfg.tokenUri,
      now: Math.floor(this.now() / 1000),
    });

    const res = await this._fetchWithTimeout(this.cfg.tokenUri, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion,
      }).toString(),
    });
    const text = await res.text();
    if (!res.ok) {
      throw new SheetsApiError(
        `Không lấy được access token Google (HTTP ${res.status}): ${safeSnippet(text)}`,
        { status: res.status, code: "AUTH_FAILED" }
      );
    }
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new SheetsApiError("Phản hồi token của Google không phải JSON.", { code: "AUTH_BAD_RESPONSE" });
    }
    if (!data.access_token) {
      throw new SheetsApiError("Google không trả access_token.", { code: "AUTH_NO_TOKEN" });
    }
    const ttl = Number(data.expires_in) > 0 ? Number(data.expires_in) : 3600;
    this._token = data.access_token;
    this._tokenExpiresAt = this.now() + Math.max(30, ttl - 60) * 1000;
    return this._token;
  }

  async _fetchWithTimeout(url, options) {
    const signal = AbortSignal.timeout(this.cfg.timeoutMs);
    try {
      return await this.fetch(url, { ...options, signal });
    } catch (err) {
      const reason = err && err.name === "TimeoutError"
        ? `quá ${this.cfg.timeoutMs}ms`
        : (err && err.message) || "lỗi mạng";
      throw new SheetsApiError(`Không gọi được Google Sheets (${reason}).`, { code: "NETWORK" });
    }
  }

  /**
   * Đồng bộ lead sang Google Apps Script Web App.
   * Apps Script tự xử lý kiểm tra mã trùng, thêm dòng mới hoặc cập nhật.
   */
  async syncAppsScript(lead, values) {
    const payload = {
      code: String(lead.code || "").trim(),
      name: String(lead.name || "").trim(),
      phone: String(lead.phone || "").trim(),
      area: String(lead.area || "").trim(),
      need: String(lead.need || "").trim(),
      source: String(lead.source || "website").trim(),
      status: String(lead.status || "Mới nhận").trim(),
      note: String(lead.note || "").trim(),
      values: values,
      created_at: values && values[0] ? values[0] : undefined
    };

    const res = await this._fetchWithTimeout(this.cfg.appsScriptUrl, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload),
      redirect: "follow",
    });

    const text = await res.text();
    let data = null;
    try {
      data = JSON.parse(text);
    } catch {
      if (!res.ok) {
        throw new SheetsApiError(`Google Apps Script trả lỗi HTTP ${res.status}: ${safeSnippet(text)}`, { status: res.status });
      }
      throw new SheetsApiError(`Google Apps Script không trả về JSON hợp lệ: ${safeSnippet(text)}`);
    }

    if (data.ok === false || data.status === "error") {
      throw new SheetsApiError(`Google Apps Script báo lỗi: ${data.message || safeSnippet(text)}`);
    }

    const row = Number(data.row);
    if (!Number.isFinite(row) || row < 2) {
      throw new SheetsApiError("Google Apps Script không trả về số dòng hợp lệ.");
    }
    return row;
  }

  async _request(method, range, { suffix = "", query = {}, body } = {}) {
    const token = await this.accessToken();
    const base = `${this.cfg.apiBase}/v4/spreadsheets/${encodeURIComponent(this.cfg.spreadsheetId)}/values/`;
    // `:append` là phần cú pháp của Google, phải đứng SAU range đã encode.
    const url = new URL(base + encodeURIComponent(range) + suffix);
    for (const [k, v] of Object.entries(query)) url.searchParams.set(k, v);

    const res = await this._fetchWithTimeout(url.toString(), {
      method,
      headers: {
        Authorization: "Bearer " + token,
        ...(body ? { "Content-Type": "application/json; charset=utf-8" } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = null;
    }
    if (!res.ok) {
      const googleMsg = data && data.error && data.error.message ? data.error.message : safeSnippet(text);
      throw new SheetsApiError(
        `Google Sheets trả lỗi HTTP ${res.status}: ${safeSnippet(googleMsg)}`,
        { status: res.status, code: "SHEETS_HTTP_" + res.status }
      );
    }
    return data || {};
  }

  /** Đọc cột B, trả số dòng (1-based) của lead có mã tương ứng, hoặc null. */
  async findRowByCode(code) {
    const range = `${quoteTab(this.cfg.tab)}!B2:B`;
    const data = await this._request("GET", range);
    const rows = Array.isArray(data.values) ? data.values : [];
    for (let i = 0; i < rows.length; i++) {
      const value = Array.isArray(rows[i]) ? String(rows[i][0] || "").trim() : "";
      if (value === String(code)) return i + 2; // +2: bỏ dòng tiêu đề, chỉ số bắt đầu từ 1
    }
    return null;
  }

  /** Thêm một dòng mới, trả số dòng thực tế Google ghi. */
  async appendRow(values) {
    const range = `${quoteTab(this.cfg.tab)}!A:K`;
    const data = await this._request("POST", range, {
      suffix: ":append",
      query: { valueInputOption: "RAW", insertDataOption: "INSERT_ROWS" },
      body: { values: [values] },
    });
    const updatedRange = data && data.updates && data.updates.updatedRange;
    const m = typeof updatedRange === "string" ? updatedRange.match(/![A-Z]+(\d+)/) : null;
    if (!m) {
      throw new SheetsApiError(
        "Google đã nhận lệnh thêm dòng nhưng không trả updatedRange — không xác định được số dòng.",
        { code: "APPEND_NO_RANGE" }
      );
    }
    return Number(m[1]);
  }

  /** Cập nhật một dòng đã có; chỉ ghi các cột hệ thống A..G. */
  async updateRow(row, valuesAtoG) {
    const range = `${quoteTab(this.cfg.tab)}!A${row}:G${row}`;
    await this._request("PUT", range, {
      query: { valueInputOption: "RAW" },
      body: { values: [valuesAtoG] },
    });
    return row;
  }
}

module.exports = { GoogleSheetsClient, SheetsApiError, quoteTab, signJwt, b64url };
