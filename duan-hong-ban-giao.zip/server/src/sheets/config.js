"use strict";
/**
 * Cấu hình đồng bộ Google Sheets.
 *
 * Hỗ trợ 2 chế độ:
 *  1. apps-script (KHUYÊN DÙNG): Chỉ cần GOOGLE_APPS_SCRIPT_URL (hoặc APPS_SCRIPT_URL).
 *     Không cần tài khoản Google Cloud, không cần JSON key, không sợ timeout hay lỗi quyền.
 *  2. service-account / static-token: Dùng Google Sheets API v4 trực tiếp qua OAuth2 Service Account.
 */
const fs = require("node:fs");
const path = require("node:path");

const SHEETS_SCOPE = "https://www.googleapis.com/auth/spreadsheets";
const DEFAULT_TAB = "Khách hàng";
const DEFAULT_API_BASE = "https://sheets.googleapis.com";
const DEFAULT_TOKEN_URL = "https://oauth2.googleapis.com/token";
const PROJECT_ROOT = path.resolve(__dirname, "..", "..", "..");

class SheetsConfigError extends Error {
  constructor(message, missing = []) {
    super(message);
    this.name = "SheetsConfigError";
    this.code = "SHEETS_NOT_CONFIGURED";
    this.missing = missing;
  }
}

/** true nếu đường dẫn nằm trong thư mục dự án (credential không nên ở đây) */
function isInsideProject(filePath) {
  const rel = path.relative(PROJECT_ROOT, path.resolve(filePath));
  return rel !== "" && !rel.startsWith("..") && !path.isAbsolute(rel);
}

function readCredentialFile(filePath) {
  let raw;
  try {
    raw = fs.readFileSync(filePath, "utf8");
  } catch (err) {
    throw new SheetsConfigError(
      `Không đọc được file credential Google Sheets (${err.code || "lỗi đọc file"}).`,
      ["GOOGLE_SHEETS_CREDENTIALS_FILE"]
    );
  }
  return parseCredentialJson(raw, "file credential");
}

function parseCredentialJson(raw, label) {
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new SheetsConfigError(`Nội dung ${label} không phải JSON hợp lệ.`, ["credential"]);
  }
  const email = String(data.client_email || "").trim();
  const key = String(data.private_key || "").replace(/\\n/g, "\n").trim();
  if (!email || !key) {
    throw new SheetsConfigError(
      `Credential ${label} thiếu client_email hoặc private_key (phải là service account).`,
      ["client_email", "private_key"]
    );
  }
  if (!key.includes("BEGIN PRIVATE KEY") && !key.includes("BEGIN RSA PRIVATE KEY")) {
    throw new SheetsConfigError(`private_key trong ${label} không đúng định dạng PEM.`, ["private_key"]);
  }
  return {
    clientEmail: email,
    privateKey: key,
    tokenUri: String(data.token_uri || "").trim() || DEFAULT_TOKEN_URL,
    projectId: String(data.project_id || "").trim(),
  };
}

function numberFrom(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(n)));
}

/**
 * Đọc cấu hình. Ném SheetsConfigError với thông báo tiếng Việt nếu thiếu.
 * Không bao giờ đưa private key vào message.
 */
function loadConfig(env = process.env) {
  const warnings = [];
  const tab = String(env.GOOGLE_SHEETS_TAB || "").trim() || DEFAULT_TAB;

  // 1. Kiểm tra chế độ Google Apps Script Web App
  const appsScriptUrl = String(env.GOOGLE_APPS_SCRIPT_URL || env.APPS_SCRIPT_URL || "").trim();
  if (appsScriptUrl) {
    if (!appsScriptUrl.startsWith("http://") && !appsScriptUrl.startsWith("https://")) {
      throw new SheetsConfigError("GOOGLE_APPS_SCRIPT_URL phải bắt đầu bằng http:// hoặc https://", ["GOOGLE_APPS_SCRIPT_URL"]);
    }
    return {
      enabled: String(env.SHEETS_SYNC || "").toLowerCase() !== "off",
      mode: "apps-script",
      appsScriptUrl,
      spreadsheetId: "",
      tab,
      scope: "apps-script",
      accessToken: null,
      clientEmail: null,
      privateKey: null,
      tokenUri: null,
      apiBase: null,
      timeoutMs: numberFrom(env.SHEETS_TIMEOUT_MS, 15000, 500, 60000),
      maxAttempts: numberFrom(env.SHEETS_MAX_ATTEMPTS, 3, 1, 10),
      retryBaseMs: numberFrom(env.SHEETS_RETRY_BASE_MS, 5000, 10, 300000),
      credentialFile: null,
      warnings,
    };
  }

  // 2. Chế độ Google Sheets API v4 (Service Account hoặc Access Token)
  const missing = [];
  const spreadsheetId = String(env.GOOGLE_SHEETS_SPREADSHEET_ID || "").trim();
  if (!spreadsheetId) missing.push("GOOGLE_SHEETS_SPREADSHEET_ID");

  let credential = null;
  let mode = "none";
  let credentialFile = null;
  const staticToken = String(env.GOOGLE_SHEETS_ACCESS_TOKEN || "").trim();

  if (staticToken) {
    mode = "static-token";
    warnings.push(
      "Đang dùng GOOGLE_SHEETS_ACCESS_TOKEN: chỉ phù hợp thử máy cục bộ, token hết hạn sau ~1 giờ."
    );
  } else {
    const filePath = String(
      env.GOOGLE_SHEETS_CREDENTIALS_FILE || env.GOOGLE_APPLICATION_CREDENTIALS || ""
    ).trim();
    if (filePath) {
      credentialFile = path.resolve(filePath);
      if (isInsideProject(credentialFile)) {
        warnings.push(
          "File credential đang nằm trong thư mục dự án — phải chuyển ra ngoài và không commit lên Git."
        );
      }
      credential = readCredentialFile(credentialFile);
      mode = "service-account";
    } else if (String(env.GOOGLE_SHEETS_CREDENTIALS_JSON || "").trim()) {
      credential = parseCredentialJson(String(env.GOOGLE_SHEETS_CREDENTIALS_JSON), "biến môi trường");
      mode = "service-account";
    }
  }

  if (mode === "none") {
    missing.push("GOOGLE_SHEETS_CREDENTIALS_FILE (hoặc GOOGLE_APPLICATION_CREDENTIALS / GOOGLE_SHEETS_CREDENTIALS_JSON)");
  }

  if (missing.length) {
    throw new SheetsConfigError(
      "Chưa cấu hình Google Sheets: thiếu " + missing.join(", ") + ". Lead vẫn được lưu trong SQLite."
      ,
      missing
    );
  }

  return {
    enabled: String(env.SHEETS_SYNC || "").toLowerCase() !== "off",
    spreadsheetId,
    tab,
    scope: SHEETS_SCOPE,
    mode,
    accessToken: mode === "static-token" ? staticToken : null,
    clientEmail: credential ? credential.clientEmail : null,
    privateKey: credential ? credential.privateKey : null,
    tokenUri: (credential && credential.tokenUri) || String(env.GOOGLE_OAUTH_TOKEN_URL || "").trim() || DEFAULT_TOKEN_URL,
    apiBase: String(env.GOOGLE_SHEETS_API_BASE || "").trim().replace(/\/+$/, "") || DEFAULT_API_BASE,
    timeoutMs: numberFrom(env.SHEETS_TIMEOUT_MS, 8000, 500, 60000),
    maxAttempts: numberFrom(env.SHEETS_MAX_ATTEMPTS, 3, 1, 10),
    retryBaseMs: numberFrom(env.SHEETS_RETRY_BASE_MS, 5000, 10, 300000),
    credentialFile,
    warnings,
  };
}

/** Bản cấu hình an toàn để trả ra API quản trị: không có key, không có token. */
function publicSummary(cfg) {
  if (!cfg) {
    return {
      configured: false,
      tab: DEFAULT_TAB,
      mode: "none",
      scope: SHEETS_SCOPE,
      spreadsheetId: "",
      clientEmail: "",
      warnings: [],
    };
  }

  if (cfg.mode === "apps-script") {
    return {
      configured: true,
      enabled: cfg.enabled,
      tab: cfg.tab,
      mode: "apps-script",
      scope: "apps-script-webhook",
      spreadsheetId: "Quản lý tự động qua Apps Script",
      clientEmail: "Google Apps Script Web App",
      warnings: cfg.warnings,
    };
  }

  return {
    configured: true,
    enabled: cfg.enabled,
    tab: cfg.tab,
    mode: cfg.mode,
    scope: cfg.scope,
    // che bớt id: đủ để đối chiếu, không đủ để chia sẻ ra ngoài
    spreadsheetId: cfg.spreadsheetId.length > 10
      ? cfg.spreadsheetId.slice(0, 4) + "…" + cfg.spreadsheetId.slice(-4)
      : "…",
    clientEmail: cfg.clientEmail || "",
    warnings: cfg.warnings,
  };
}

module.exports = {
  loadConfig,
  publicSummary,
  SheetsConfigError,
  isInsideProject,
  SHEETS_SCOPE,
  DEFAULT_TAB,
  PROJECT_ROOT,
};
