"use strict";
/* BUG-08: node:sqlite chỉ có từ Node 22.5 — báo lỗi thân thiện thay vì crash khó hiểu */
const NODE_MIN = [22, 5];
const [NODE_MAJ, NODE_MINOR] = process.versions.node.split(".").map(Number);
if (NODE_MAJ < NODE_MIN[0] || (NODE_MAJ === NODE_MIN[0] && NODE_MINOR < NODE_MIN[1])) {
  const line = "=".repeat(66);
  console.error(line);
  console.error("  KHÔNG CHẠY ĐƯỢC: máy chủ cần Node.js >= 22.5");
  console.error(`  Máy bạn đang dùng: Node ${process.versions.node}`);
  console.error("");
  console.error("  Lý do: backend dùng module có sẵn 'node:sqlite' (từ Node 22.5)");
  console.error("  để không phải cài thêm SQLite. Không có bản tương thích cho Node 18/20.");
  console.error("");
  console.error("  Cách xử lý:");
  console.error("    1) Cài Node 22 LTS trở lên: https://nodejs.org/en/download");
  console.error("    2) Hoặc dùng nvm:  nvm install 22 && nvm use 22");
  console.error("    3) Kiểm tra lại:   node -v");
  console.error("");
  console.error("  Bắt buộc chạy Node 18/20: xem README.md mục 'Chạy trên Node 18/20'.");
  console.error(line);
  process.exit(1);
}
const http = require("node:http");
const { handle } = require("./app");
const { DB_PATH } = require("./db");
const sheets = require("./sheets");

const PORT = Number(process.env.PORT || 5055);
const HOST = process.env.HOST || "127.0.0.1";

// Bảo vệ tiến trình không bị dừng khi có lỗi mạng ngoại cảnh
process.on("unhandledRejection", (reason) => {
  console.error("[process] unhandledRejection:", (reason && reason.message) || reason);
});

process.on("uncaughtException", (err) => {
  console.error("[process] uncaughtException:", (err && err.message) || err);
});

const server = http.createServer((req, res) => {
  Promise.resolve(handle(req, res)).catch((err) => {
    const status = err && err.status ? err.status : 500;
    if (!res.headersSent) {
      const body = JSON.stringify({
        success: false,
        message: status === 413 ? "Dữ liệu gửi lên quá lớn." :
                 status === 400 ? "Dữ liệu không hợp lệ." :
                 "Lỗi máy chủ.",
      });
      res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
      res.end(body);
    }
    if (status >= 500) console.error("[api] lỗi:", err);
  });
});

server.listen(PORT, HOST, () => {
  console.log("=================================================================");
  console.log(`  DUANHONG API đang chạy: http://${HOST}:${PORT}`);
  console.log(`  SQLite: ${DB_PATH}`);
  console.log(`  Health: http://${HOST}:${PORT}/api/health`);
  console.log("=================================================================");
  // Lead còn trạng thái pending (tắt máy giữa lúc gửi) được đưa lại hàng đợi.
  const resumed = sheets.resumePending(50);
  if (!resumed.configured) {
    console.warn("[sheets] chưa cấu hình Google Sheets — lead vẫn lưu SQLite, không đồng bộ Sheet.");
  }
});

for (const sig of ["SIGINT", "SIGTERM"]) {
  process.on(sig, () => {
    console.log("\n[api] đang đóng...");
    sheets.queue.clear();
    server.close(() => process.exit(0));
  });
}
