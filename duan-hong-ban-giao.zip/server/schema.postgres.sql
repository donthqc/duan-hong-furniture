-- ==========================================================================
-- Duân Hồng — schema tương đương cho Postgres / Supabase.
-- Dùng khi chuyển khỏi SQLite. Chạy trong SQL Editor của Supabase.
-- ==========================================================================

create table if not exists products (
  id          serial primary key,
  slug        text not null unique,
  name        text not null,
  tag         text not null,
  room        text not null check (room in ('khach','ngu','tho','bep')),
  wood        text not null,
  spec        text not null,
  price       bigint,
  price_note  text not null default '',
  description text not null default '',
  active      boolean not null default true,
  sort        int not null default 0,
  created_at  timestamptz not null default now()
);

create table if not exists projects (
  id      serial primary key,
  title   text not null,
  place   text not null,
  room    text not null,
  area_m2 int,
  spec    text not null,
  wood    text not null,
  days    int,
  price   bigint,
  quote   text not null default '',
  status  text not null default 'done' check (status in ('done','in_progress')),
  sort    int not null default 0
);

create table if not exists orders (
  id            serial primary key,
  code          text not null unique,
  customer_name text not null,
  phone_last4   char(4) not null,
  phone_hash    text not null,
  product_name  text not null,
  stage         int not null default 1 check (stage between 1 and 5),
  stage_note    text not null default '',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists order_steps (
  id        serial primary key,
  order_id  int not null references orders(id) on delete cascade,
  step      int not null check (step between 1 and 5),
  title     text not null,
  note      text not null default '',
  photo_url text not null default '',
  done_at   date,
  unique (order_id, step)
);

create table if not exists leads (
  id         serial primary key,
  code       text not null unique,
  name       text not null,
  phone      text not null,
  phone_hash text not null,
  area       text not null default '',
  need       text not null default '',
  source     text not null default 'website',
  status     text not null default 'new' check (status in ('new','called','measured','quoted','won','lost')),
  note       text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists reviews (
  id           serial primary key,
  product_slug text not null references products(slug),
  order_code   text not null references orders(code),
  author_label text not null,
  rating       int not null check (rating between 1 and 5),
  body         text not null check (char_length(body) between 10 and 1000),
  approved     boolean not null default false,
  created_at   timestamptz not null default now(),
  unique (order_code, product_slug)
);

create index if not exists idx_projects_status on projects(status, sort);
create index if not exists idx_leads_created on leads(created_at desc);
create index if not exists idx_reviews_product on reviews(product_slug, approved);

-- --------------------------------------------------------------------------
-- RLS: bật cho bảng lộ ra client. API server dùng service_role nên vẫn ghi được.
-- --------------------------------------------------------------------------
alter table products enable row level security;
alter table projects enable row level security;
alter table reviews  enable row level security;
alter table leads    enable row level security;
alter table orders   enable row level security;

-- Ai cũng đọc được sản phẩm đang bán và công trình
create policy "public read products" on products for select using (active = true);
create policy "public read projects" on projects for select using (true);
-- Chỉ đọc đánh giá đã duyệt
create policy "public read approved reviews" on reviews for select using (approved = true);

-- KHÔNG tạo policy select cho leads và orders:
-- dữ liệu hai bảng này chỉ đi qua API server (service_role), không lộ ra anon key.
-- Tra cứu đơn bắt buộc mã + 4 số cuối, thực hiện ở server.
