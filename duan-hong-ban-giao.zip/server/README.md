# DUANHONG API — Backend + Database

Backend cho website xưởng mộc Duân Hồng. **Không có dependency npm nào** — dùng `node:http` + `node:sqlite` có sẵn trong Node 22.5+.

## Chạy

```bash
cd server
npm start                      # http://127.0.0.1:5055
npm test                      # 46 kiểm tra API (tự bật server ở cổng riêng + DB tạm)
npm run test:sheets           # 61 kiểm tra đồng bộ Google Sheets (Google giả lập, không cần credential)
```

Biến môi trường:

| Biến | Mặc định | Ghi chú |
|---|---|---|
| `PORT` | 5055 | |
| `HOST` | 127.0.0.1 | Đổi `0.0.0.0` khi chạy trong Docker/VPS |
| `DB_PATH` | `server/data/duanhong.db` | SQLite, tự tạo + seed lần đầu |
| `ADMIN_TOKEN` | *(rỗng)* | Rỗng = khoá toàn bộ `/api/admin/*` (503) |
| `PHONE_SALT` | `duanhong-local-salt-change-me` | **Đổi khi lên production** |
| `ALLOWED_ORIGINS` | localhost:8098, 127.0.0.1:8098, :8096 | Danh sách origin được CORS |
| `LEAD_DEDUPE_MINUTES` | 15 | Cửa sổ chống gửi trùng (cùng SĐT + cùng tên) |
| `GOOGLE_SHEETS_*` | *(rỗng)* | Đồng bộ Google Sheets — xem `../SPEC-GOOGLE-SHEETS.md` |

Ví dụ production:

```bash
PORT=5055 HOST=0.0.0.0 \
ADMIN_TOKEN="$(openssl rand -hex 32)" \
PHONE_SALT="$(openssl rand -hex 16)" \
ALLOWED_ORIGINS="https://duanhong.vn,https://www.duanhong.vn" \
node src/server.js
```

## Endpoints

### Công khai

| Method | Path | Mô tả |
|---|---|---|
| GET | `/api/health` | Trạng thái dịch vụ |
| GET | `/api/products?room=&wood=&q=` | Danh sách sản phẩm (chỉ `active=1`) |
| GET | `/api/products/:slug` | Chi tiết sản phẩm |
| GET | `/api/products/:slug/reviews` | Đánh giá **đã duyệt**, kèm điểm trung bình |
| POST | `/api/products/:slug/reviews` | Gửi đánh giá — cần `orderCode` + `phoneLast4` khớp đơn, rating 1–5, nội dung 10–1000 ký tự |
| GET | `/api/projects?room=` | Công trình đã bàn giao |
| POST | `/api/leads` | Đặt lịch đo: `name`, `phone`, `area`, `need` → trả mã `LH-xxxxxx` |
| GET | `/api/orders/:code?phone=xxxx` | Tra cứu tiến độ — **bắt buộc** đúng 4 số cuối |

### Quản trị (cần `Authorization: Bearer <ADMIN_TOKEN>`)

| Method | Path | Mô tả |
|---|---|---|
| GET | `/api/admin/leads?status=` | Danh sách lead (kèm `sheets_status`, `sheets_row`, `sheets_error`, `sync_attempts`) |
| PATCH | `/api/admin/leads/:id` | Đổi trạng thái: `new · called · measured · quoted · won · lost` |
| GET | `/api/admin/sheets/status` | Cấu hình Sheets + số đếm `pending/sent/failed` (không lộ secret) |
| POST | `/api/admin/sheets/resync` | `{leadId}` hoặc `{status:"failed", limit}` — đưa lead lỗi vào hàng đợi đồng bộ lại |
| GET | `/api/admin/reviews` | Tất cả đánh giá (kể cả chờ duyệt) |
| PATCH | `/api/admin/reviews/:id` | `{approved: true|false}` |
| PATCH | `/api/admin/orders/:code` | `{stage: 1..5, note}` — cập nhật bước xưởng |

## Schema

```
products(id, slug, name, tag, room, wood, spec, price, price_note, description, active, sort)
projects(id, title, place, room, area_m2, spec, wood, days, price, quote, status, sort)
orders(id, code, customer_name, phone_last4, phone_hash, product_name, stage, stage_note, ...)
order_steps(id, order_id, step, title, note, photo_url, done_at)
leads(id, code, name, phone, phone_hash, area, need, source, status, note, created_at,
      sheets_status, sheets_row, sheets_error, sheets_synced_at, sync_attempts)
reviews(id, product_slug, order_code, author_label, rating, body, approved, created_at)
```

Quan hệ: `order_steps.order_id → orders.id` (ON DELETE CASCADE). Unique: `products.slug`,
`orders.code`, `leads.code`, `reviews(order_code, product_slug)`.

## Nguyên tắc bảo mật đã áp dụng

- **Không lưu SĐT dạng thô để tra cứu**: chỉ lưu `phone_last4` + `phone_hash` (SHA-256 + salt). So sánh 4 số bằng `timingSafeEqual`.
- **Sai mã đơn và sai số điện thoại trả cùng một thông báo 404** → không dò được đơn.
- Tra cứu không trả số điện thoại, địa chỉ, hay danh sách đơn khác.
- Mọi truy vấn dùng prepared statement (không nối chuỗi SQL) → đã test payload `' OR 1=1--`.
- Rate limit theo IP: lead 5/giờ, review 10/giờ, tra cứu 30/10 phút → 429 kèm `Retry-After`.
- Body tối đa 32KB → 413; JSON hỏng → 400; không lộ stack trace.
- CORS theo allowlist (không dùng `*`), có `Vary: Origin`.
- Header: `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Cache-Control: no-store`; không có `X-Powered-By`.
- `/api/admin/*` khoá hoàn toàn nếu chưa đặt `ADMIN_TOKEN`.

## Nối vào frontend

`design/api.js` tự dùng `http://127.0.0.1:5055` khi mở bằng localhost, còn lại dùng
`https://api.duanhong.vn`. Đổi nhanh trong console: `DH_API.setBase("https://...")` (lưu localStorage).

Nếu API không chạy, site **không giả lập thành công**: hiện banner "Chế độ demo — dữ liệu không được lưu"
và form báo "Không gửi được" kèm hotline.

## Lên production

1. **Supabase/Postgres**: chuyển schema bằng `schema.postgres.sql` (đã kèm), bật RLS.
2. Bật HTTPS, đặt `HOST=0.0.0.0` sau reverse proxy (Nginx/Caddy), giới hạn `ALLOWED_ORIGINS`.
3. Đổi `PHONE_SALT`, đặt `ADMIN_TOKEN` dài ngẫu nhiên, không commit.
4. Sao lưu `data/duanhong.db` định kỳ (hoặc dùng Postgres managed).
5. Thông báo cho khách khi có lead mới (hiện chỉ lưu DB, chưa gửi tin).

## Chưa có (cần làm tiếp)

- Upload ảnh (Supabase Storage) cho ảnh xưởng và ảnh từng bước đơn.
- Gửi SMS/tin nhắn xác nhận lead (chưa nối cổng nào).
- Job tự động nhắc lịch đo.
- CMS UI cho admin (hiện chỉ có API; dùng Postman/curl hoặc dựng trang quản trị).
- Phân quyền nhiều vai trò (hiện chỉ một token admin).
