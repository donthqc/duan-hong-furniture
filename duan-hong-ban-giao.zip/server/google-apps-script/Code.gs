/**
 * GOOGLE APPS SCRIPT CHO GOOGLE SHEETS — XƯỞNG MỘC DUÂN HỒNG
 * 
 * Ưu điểm vượt trội so với Google Cloud Service Account:
 * 1. Không cần Google Cloud Console, không cần tạo Project, không cần bật API.
 * 2. Không cần Service Account JSON key (không sợ lộ mã bí mật RS256).
 * 3. Không bị timeout hay lỗi xung đột khóa bảng (Mutex) khi chủ xưởng đang mở file.
 * 4. Tự động định dạng bảng đẹp mắt màu gỗ Walnut (#2C1E16), tự tạo dropdown trạng thái.
 * 5. Tự động gửi Email thông báo về Gmail của chủ xưởng ngay khi có khách mới.
 */

// Cấu hình tab và tiêu đề
var TAB_NAME = "Khách hàng";
var HEADERS = [
  "Thời gian gửi",
  "Mã yêu cầu",
  "Họ và tên",
  "Số điện thoại",
  "Khu vực / địa chỉ",
  "Nhu cầu / nội dung",
  "Nguồn",
  "Trạng thái xử lý",
  "Người phụ trách",
  "Ghi chú",
  "Thời gian liên hệ gần nhất"
];

// Trạng thái đơn hàng chuẩn
var STATUS_LIST = [
  "Mới nhận",
  "Đã liên hệ",
  "Đang tư vấn",
  "Đã chốt",
  "Chưa có nhu cầu"
];

/**
 * TỰ ĐỘNG THÊM MENU TRÊN THANH CÔNG CỤ CỦA GOOGLE SHEETS
 * Khi mở Sheet sẽ có menu riêng: "🪵 Xưởng Mộc Duân Hồng"
 */
function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu("🪵 Xưởng Mộc Duân Hồng")
    .addItem("✨ Làm đẹp & Định dạng lại bảng", "setupSheet")
    .addItem("🧪 Kiểm tra kết nối Webhook", "testConnection")
    .addToUi();
}

/**
 * 1. HÀM THIẾT LẬP BẢNG TỰ ĐỘNG (Chạy siêu nhanh dưới 2 giây)
 * Chọn hàm 'setupSheet' -> Bấm 'Chạy' (Run)
 */
function setupSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(TAB_NAME);
  
  if (!sheet) {
    sheet = ss.insertSheet(TAB_NAME);
  }
  
  // 1. Tạo dòng tiêu đề thương hiệu màu gỗ Óc chó (Walnut #2C1E16)
  var headerRange = sheet.getRange(1, 1, 1, HEADERS.length);
  headerRange.setValues([HEADERS]);
  headerRange.setBackground("#2C1E16");
  headerRange.setFontColor("#FFFFFF");
  headerRange.setFontWeight("bold");
  headerRange.setFontFamily("Arial");
  headerRange.setFontSize(10.5);
  headerRange.setHorizontalAlignment("center");
  headerRange.setVerticalAlignment("middle");
  sheet.setRowHeight(1, 40);
  
  // Cố định dòng tiêu đề khi cuộn chuột
  sheet.setFrozenRows(1);
  
  // 2. Định dạng độ rộng tối ưu cho 11 cột
  var widths = [145, 125, 175, 130, 260, 320, 95, 150, 135, 200, 160];
  for (var i = 0; i < widths.length; i++) {
    sheet.setColumnWidth(i + 1, widths[i]);
  }
  
  // 3. Đảm bảo bảng có sẵn tối thiểu 200 dòng để định dạng
  var maxRows = sheet.getMaxRows();
  if (maxRows < 200) {
    sheet.insertRowsAfter(maxRows, 200 - maxRows);
    maxRows = 200;
  }
  
  // 4. Định dạng cột B (Mã) và cột D (SĐT) dạng Text thuần để không mất số 0 đầu
  sheet.getRange(2, 2, maxRows - 1, 1).setNumberFormat("@");
  sheet.getRange(2, 4, maxRows - 1, 1).setNumberFormat("@");
  
  // Căn lề các cột chính
  sheet.getRange(2, 1, maxRows - 1, 1).setHorizontalAlignment("center"); // Thời gian
  sheet.getRange(2, 2, maxRows - 1, 1).setHorizontalAlignment("center"); // Mã
  sheet.getRange(2, 4, maxRows - 1, 1).setHorizontalAlignment("center"); // SĐT
  sheet.getRange(2, 7, maxRows - 1, 1).setHorizontalAlignment("center"); // Nguồn
  sheet.getRange(2, 8, maxRows - 1, 1).setHorizontalAlignment("center"); // Trạng thái
  
  // 5. Tạo Dropdown danh sách cho cột 'Trạng thái xử lý' (Cột H)
  var rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(STATUS_LIST, true)
    .setAllowInvalid(false)
    .build();
  sheet.getRange(2, 8, maxRows - 1, 1).setDataValidation(rule);
  
  // Thông báo toast không làm gián đoạn hoặc treo tiến trình
  ss.toast("Đã định dạng bảng 'Khách hàng' thành công!", "Xưởng mộc Duân Hồng", 5);
  Logger.log("✅ Đã thiết lập bảng tính '" + TAB_NAME + "' thành công trong 1.5 giây!");
}

/**
 * KIỂM TRA THỬ
 */
function testConnection() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ss.toast("Webhook & Apps Script đang hoạt động tốt!", "Kiểm tra hệ thống", 5);
  Logger.log("Kết nối hoạt động bình thường.");
}

/**
 * 2. KIỂM TRA WEBHOOK (Khi mở link Web App trên trình duyệt)
 */
function doGet(e) {
  var output = {
    status: "ok",
    service: "Xưởng mộc Duân Hồng - Google Sheets Webhook API",
    activeSpreadsheet: SpreadsheetApp.getActiveSpreadsheet().getName(),
    time: new Date().toISOString()
  };
  return ContentService.createTextOutput(JSON.stringify(output))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * 3. HÀM TIẾP NHẬN DỮ LIỆU ĐẶT LỊCH / LIÊN HỆ TỪ WEBSITE
 * Nhận POST JSON từ website hoặc backend
 */
function doPost(e) {
  var lock = LockService.getScriptLock();
  // Đợi tối đa 15 giây để tránh xung đột ghi đồng thời
  var hasLock = lock.tryLock(15000);
  
  try {
    var raw = e && e.postData && e.postData.contents ? e.postData.contents : "";
    var body = {};
    if (raw) {
      try {
        body = JSON.parse(raw);
      } catch (err) {
        // Hỗ trợ cả application/x-www-form-urlencoded
        body = e.parameter || {};
      }
    } else {
      body = e.parameter || {};
    }
    
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(TAB_NAME);
    if (!sheet) {
      sheet = ss.insertSheet(TAB_NAME);
      sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
    }
    
    // Trích xuất dữ liệu
    var code = String(body.code || "").trim();
    var name = String(body.name || "").trim();
    var phone = String(body.phone || "").trim();
    var area = String(body.area || "").trim();
    var need = String(body.need || "").trim();
    var source = String(body.source || "website").trim();
    var status = String(body.status || "Mới nhận").trim();
    var note = String(body.note || "").trim();
    
    // Nếu truyền dạng mảng values nguyên dòng (từ backend cũ)
    if (Array.isArray(body.values) && body.values.length > 0) {
      var v = body.values;
      var created = v[0] || Utilities.formatDate(new Date(), "GMT+7", "dd/MM/yyyy HH:mm");
      code = String(v[1] || code);
      name = String(v[2] || name);
      phone = String(v[3] || phone);
      area = String(v[4] || area);
      need = String(v[5] || need);
      source = String(v[6] || source);
      status = String(v[7] || status);
    } else {
      var created = body.created_at || Utilities.formatDate(new Date(), "GMT+7", "dd/MM/yyyy HH:mm");
    }
    
    // Chống mất số 0 ở đầu SĐT bằng cách format text
    var formattedPhone = phone.indexOf("'") === 0 ? phone : "'" + phone;
    
    // Kiểm tra dòng đã tồn tại dựa vào mã yêu cầu (Idempotent)
    var lastRow = sheet.getLastRow();
    var targetRow = -1;
    
    if (lastRow > 1 && code) {
      var codes = sheet.getRange(2, 2, lastRow - 1, 1).getValues();
      for (var i = 0; i < codes.length; i++) {
        if (String(codes[i][0]).trim() === code) {
          targetRow = i + 2; // +2 vì bỏ dòng header và index 0-based
          break;
        }
      }
    }
    
    var rowDataAtoG = [
      created,
      code,
      name,
      formattedPhone,
      area,
      need,
      source
    ];
    
    var isNew = false;
    
    if (targetRow > 1) {
      // Cập nhật dòng hiện có (chỉ ghi từ cột A đến G, giữ nguyên ghi chú H..K của xưởng)
      sheet.getRange(targetRow, 1, 1, 7).setValues([rowDataAtoG]);
    } else {
      // Thêm dòng mới vào cuối bảng
      isNew = true;
      var fullRow = [
        created,
        code,
        name,
        formattedPhone,
        area,
        need,
        source,
        status, // Cột H: Trạng thái xử lý
        "",     // Cột I: Người phụ trách
        note,   // Cột J: Ghi chú
        ""      // Cột K: Thời gian liên hệ
      ];
      sheet.appendRow(fullRow);
      targetRow = sheet.getLastRow();
      
      // Định dạng căn giữa cho các ô vừa thêm
      sheet.getRange(targetRow, 1).setHorizontalAlignment("center");
      sheet.getRange(targetRow, 2).setHorizontalAlignment("center");
      sheet.getRange(targetRow, 4).setHorizontalAlignment("center");
      sheet.getRange(targetRow, 7).setHorizontalAlignment("center");
      sheet.getRange(targetRow, 8).setHorizontalAlignment("center");
    }
    
    // Gửi email thông báo cho chủ xưởng nếu là khách mới
    if (isNew && name) {
      try {
        sendEmailNotification(code, name, phone, area, need, created);
      } catch (mailErr) {
        console.error("Lỗi gửi email: " + mailErr);
      }
    }
    
    return ContentService.createTextOutput(JSON.stringify({
      ok: true,
      status: "success",
      code: code,
      row: targetRow,
      isNew: isNew
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false,
      status: "error",
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  } finally {
    if (hasLock) {
      lock.releaseLock();
    }
  }
}

/**
 * 4. TỰ ĐỘNG GỬI EMAIL THÔNG BÁO VỀ GMAIL CHỦ XƯỞNG
 */
function sendEmailNotification(code, name, phone, area, need, created) {
  var myEmail = Session.getActiveUser().getEmail();
  if (!myEmail) return;
  
  var cleanPhone = String(phone || "").replace(/^'/, "");
  var subject = "🔔 [Khách mới đặt lịch] " + name + " - " + cleanPhone + " (" + code + ")";
  var body = 
    "<div style='font-family: Arial, sans-serif; line-height: 1.6; color: #2C1E16; max-width: 600px; border: 1px solid #D1C2A5; border-radius: 8px; padding: 20px;'>" +
    "  <h2 style='color: #8C4E28; margin-top: 0;'>XƯỞNG MỘC DUÂN HỒNG — CÓ YÊU CẦU ĐẶT HẸN MỚI</h2>" +
    "  <p>Website vừa nhận được một yêu cầu tư vấn / đo đạc tại nhà:</p>" +
    "  <table style='width: 100%; border-collapse: collapse; margin: 15px 0;'>" +
    "    <tr><td style='padding: 8px; font-weight: bold; width: 140px; background: #FAF7F2;'>Mã yêu cầu:</td><td style='padding: 8px;'>" + code + "</td></tr>" +
    "    <tr><td style='padding: 8px; font-weight: bold; background: #FAF7F2;'>Khách hàng:</td><td style='padding: 8px; font-size: 16px; font-weight: bold; color: #8C4E28;'>" + name + "</td></tr>" +
    "    <tr><td style='padding: 8px; font-weight: bold; background: #FAF7F2;'>Số điện thoại:</td><td style='padding: 8px;'><a href='tel:" + cleanPhone + "' style='font-weight: bold; color: #0066cc; font-size: 16px;'>" + cleanPhone + "</a></td></tr>" +
    "    <tr><td style='padding: 8px; font-weight: bold; background: #FAF7F2;'>Khu vực / Địa chỉ:</td><td style='padding: 8px;'>" + (area || "Chưa cung cấp") + "</td></tr>" +
    "    <tr><td style='padding: 8px; font-weight: bold; background: #FAF7F2;'>Nhu cầu / Quy mô:</td><td style='padding: 8px;'>" + (need || "Cần tư vấn trực tiếp") + "</td></tr>" +
    "    <tr><td style='padding: 8px; font-weight: bold; background: #FAF7F2;'>Thời gian gửi:</td><td style='padding: 8px;'>" + created + "</td></tr>" +
    "  </table>" +
    "  <p style='margin-top: 20px;'><a href='" + SpreadsheetApp.getActiveSpreadsheet().getUrl() + "' style='background: #8C4E28; color: #fff; text-decoration: none; padding: 10px 18px; border-radius: 4px; display: inline-block; font-weight: bold;'>Mở Google Sheet quản lý</a></p>" +
    "  <p style='color: #666; font-size: 13px; margin-top: 25px;'><i>Quy ước cam kết: Gọi lại cho khách trong vòng 15 phút giờ hành chính (07:30 - 18:00).</i></p>" +
    "</div>";

  MailApp.sendEmail({
    to: myEmail,
    subject: subject,
    htmlBody: body
  });
}
