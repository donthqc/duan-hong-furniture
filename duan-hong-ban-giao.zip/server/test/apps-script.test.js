"use strict";
/**
 * Kiểm thử tích hợp Google Apps Script Web App cho Xưởng mộc Duân Hồng.
 * Giả lập endpoint Apps Script trên localhost để kiểm chứng luồng hoạt động mà không cần mạng ngoài.
 */
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");

const PORT = 5092;
const APPS_SCRIPT_URL = `http://127.0.0.1:${PORT}/macros/s/test/exec`;
const TMP_DIR = fs.mkdtempSync(path.join(os.tmpdir(), "dh-apps-script-test-"));
const DB_PATH = path.join(TMP_DIR, "test.db");

process.env.DB_PATH = DB_PATH;
process.env.GOOGLE_APPS_SCRIPT_URL = APPS_SCRIPT_URL;
process.env.SHEETS_MAX_ATTEMPTS = "2";
process.env.SHEETS_RETRY_BASE_MS = "50";
process.env.SHEETS_TIMEOUT_MS = "2000";

const { all, get, run } = require("../src/db");
const { loadConfig, publicSummary } = require("../src/sheets/config");
const { GoogleSheetsClient } = require("../src/sheets/client");
const { syncLeadById, resetForTest } = require("../src/sheets/sync");

let passed = 0;
let failed = 0;

function ok(title, condition, extra = "") {
  if (condition) {
    passed++;
    console.log(`PASS  ${title}${extra ? "  :: " + extra : ""}`);
  } else {
    failed++;
    console.error(`FAIL  ${title}${extra ? "  :: " + extra : ""}`);
  }
}

async function main() {
  resetForTest();

  // Tạo mock Apps Script Web App
  const receivedRequests = [];
  let shouldFail = false;

  const server = http.createServer((req, res) => {
    let body = "";
    req.on("data", (chunk) => { body += chunk; });
    req.on("end", () => {
      let parsed = {};
      try { parsed = JSON.parse(body); } catch {}
      receivedRequests.push({ method: req.method, url: req.url, body: parsed });

      if (shouldFail) {
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, status: "error", message: "Mô phỏng lỗi từ Google Script" }));
        return;
      }

      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({
        ok: true,
        status: "success",
        code: parsed.code || "LH-TEST",
        row: receivedRequests.length + 1, // Dòng 2 trở đi
        isNew: true
      }));
    });
  });

  await new Promise((r) => server.listen(PORT, "127.0.0.1", r));

  try {
    // 1. Kiểm tra cấu hình Apps Script
    const cfg = loadConfig(process.env);
    ok("loadConfig nhận diện mode = apps-script", cfg.mode === "apps-script");
    ok("Không yêu cầu spreadsheetId hay Service Account", !cfg.clientEmail && !cfg.privateKey);

    const summary = publicSummary(cfg);
    ok("publicSummary an toàn, đúng mode", summary.mode === "apps-script" && summary.configured === true);

    // 2. Tạo lead mẫu trong SQLite
    const inserted = run(
      "INSERT INTO leads (code, name, phone, phone_hash, area, need, source) VALUES (?, ?, ?, ?, ?, ?, ?)",
      ["LH-GAS001", "Bác Hoàng", "0912345678", "hash-gas", "TP. Hưng Yên", "Combo phòng khách sồi Nga", "website"]
    );
    const leadId = Number(inserted.lastInsertRowid);

    // 3. Đồng bộ sang Apps Script Web App
    const syncRes = await syncLeadById(leadId);
    ok("syncLeadById trả về ok: true", syncRes.ok === true && syncRes.row >= 2, `row=${syncRes.row}`);

    // 4. Kiểm tra dữ liệu gửi tới Apps Script
    ok("Apps Script nhận đúng 1 request POST", receivedRequests.length === 1);
    const firstReq = receivedRequests[0].body;
    ok("Request gửi đúng mã, tên, SĐT, khu vực", 
      firstReq.code === "LH-GAS001" && 
      firstReq.name === "Bác Hoàng" && 
      firstReq.phone === "0912345678" &&
      firstReq.area === "TP. Hưng Yên"
    );

    // 5. Kiểm tra SQLite được cập nhật trạng thái
    const savedLead = get("SELECT * FROM leads WHERE id = ?", [leadId]);
    ok("SQLite cập nhật sheets_status = 'sent'", savedLead.sheets_status === "sent");
    ok("SQLite lưu đúng số dòng sheets_row", savedLead.sheets_row === syncRes.row);
    ok("sheets_error để trống", savedLead.sheets_error === "");

    // 6. Kiểm tra xử lý khi Apps Script gặp sự cố
    shouldFail = true;
    const inserted2 = run(
      "INSERT INTO leads (code, name, phone, phone_hash, area, need, source) VALUES (?, ?, ?, ?, ?, ?, ?)",
      ["LH-GAS002", "Anh Nam", "0988776655", "hash-gas-2", "Mỹ Hào", "Tủ áo kịch trần gõ đỏ", "website"]
    );
    const leadId2 = Number(inserted2.lastInsertRowid);
    const failRes = await syncLeadById(leadId2);
    ok("Khi Apps Script lỗi, syncLeadById trả về ok: false", failRes.ok === false);
    const failedLead = get("SELECT * FROM leads WHERE id = ?", [leadId2]);
    ok("SQLite đánh dấu sheets_status = 'failed'", failedLead.sheets_status === "failed");
    ok("Ghi nhận đúng thông báo lỗi trong sheets_error", failedLead.sheets_error.includes("Mô phỏng lỗi từ Google Script"));

    console.log("================================================================");
    console.log(`KẾT QUẢ APPS SCRIPT: ${passed} PASS / ${failed} FAIL`);
    console.log("================================================================");

    if (failed > 0) process.exitCode = 1;
  } finally {
    server.close();
    try { fs.rmSync(TMP_DIR, { recursive: true, force: true }); } catch {}
  }
}

main().catch((err) => {
  console.error("FATAL:", err);
  process.exit(1);
});
