"use strict";
/** Test API: chạy server thật trên cổng riêng + DB tạm, gọi bằng fetch thật. */
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");

const PORT = 5099;
const BASE = `http://127.0.0.1:${PORT}`;
const DB = path.join(os.tmpdir(), `dh-test-${Date.now()}.db`);
const ADMIN = "test-admin-token";

let pass = 0, fail = 0;
const results = [];
function ok(name, cond, detail = "") {
  if (cond) { pass++; results.push(["PASS", name, detail]); }
  else { fail++; results.push(["FAIL", name, detail]); }
  console.log(`${cond ? "PASS" : "FAIL"}  ${name}${detail ? "  :: " + detail : ""}`);
}

const req = async (method, p, body, headers = {}) => {
  const res = await fetch(BASE + p, {
    method,
    headers: { "Content-Type": "application/json", ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data = null;
  try { data = await res.json(); } catch {}
  return { status: res.status, data, headers: res.headers };
};

(async () => {
  const srv = spawn(process.execPath, [path.join(__dirname, "..", "src", "server.js")], {
    env: { ...process.env, PORT: String(PORT), DB_PATH: DB, ADMIN_TOKEN: ADMIN, PHONE_SALT: "test-salt", RATE_LEAD: "5", RATE_REVIEW: "20" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  srv.stderr.on("data", (d) => process.stderr.write("[server] " + d));

  // chờ server lên
  for (let i = 0; i < 50; i++) {
    try { const r = await fetch(BASE + "/api/health"); if (r.ok) break; } catch {}
    await new Promise((r) => setTimeout(r, 120));
  }

  try {
    /* ---------- health ---------- */
    let r = await req("GET", "/api/health");
    ok("health 200 + status UP", r.status === 200 && r.data.status === "UP");

    /* ---------- products ---------- */
    r = await req("GET", "/api/products");
    ok("GET /api/products → 6 sản phẩm", r.status === 200 && r.data.count === 6, `count=${r.data?.count}`);
    ok("không trả cột nội bộ", r.data.data[0].price_note === undefined && r.data.data[0].priceNote !== undefined);

    r = await req("GET", "/api/products?room=ngu");
    ok("lọc room=ngu → 2", r.data.count === 2, `count=${r.data.count}`);

    r = await req("GET", "/api/products?wood=oc-cho");
    ok("lọc wood=oc-cho → 0", r.data.count === 0);

    r = await req("GET", "/api/products?q=sofa");
    ok("tìm q=sofa → 1", r.data.count === 1, `count=${r.data.count}`);

    r = await req("GET", "/api/products/sofa-go-do");
    ok("chi tiết theo slug", r.status === 200 && r.data.data.name.includes("Sofa"), r.data.data?.name);

    r = await req("GET", "/api/products/khong-ton-tai");
    ok("slug lạ → 404", r.status === 404);

    /* ---------- SQL injection ---------- */
    r = await req("GET", "/api/products?q=%27%20OR%201%3D1--");
    ok("SQL injection không trả toàn bộ", r.status === 200 && r.data.count === 0, `count=${r.data.count}`);

    /* ---------- leads ---------- */
    r = await req("POST", "/api/leads", { name: "Nguyễn Văn An", phone: "0901234567", area: "TP. Hưng Yên", need: "Bàn ăn 6 người" });
    ok("tạo lead 201 + mã LH-", r.status === 201 && /^LH-/.test(r.data.data.code), r.data?.data?.code);

    r = await req("POST", "/api/leads", { name: "A", phone: "0901234567" });
    ok("tên 1 ký tự → 400", r.status === 400);

    r = await req("POST", "/api/leads", { name: "Nguyễn Văn B", phone: "123" });
    ok("SĐT sai → 400", r.status === 400);

    r = await req("POST", "/api/leads", { name: "Nguyễn Văn C", phone: "+84901234567" });
    ok("SĐT +84 → 201", r.status === 201);

    r = await req("POST", "/api/leads", { name: "XSS", phone: "0901234567", need: "<script>alert(1)</script>" });
    ok("nhận payload XSS nhưng không thực thi (lưu text)", r.status === 201);

    const raw = await fetch(BASE + "/api/leads", { method: "POST", headers: { "Content-Type": "application/json", "X-Forwarded-For": "10.9.9.9" }, body: "{bad json" });
    ok("JSON hỏng → 400", raw.status === 400);

    const big = await fetch(BASE + "/api/leads", {
      method: "POST", headers: { "Content-Type": "application/json", "X-Forwarded-For": "10.9.9.8" },
      body: JSON.stringify({ name: "A".repeat(40000), phone: "0901234567" }),
    }).catch((e) => ({ status: "ERR:" + e.message }));
    ok("body quá lớn → 413", big.status === 413, `status=${big.status}`);

    // rate limit 5/giờ → lần thứ 6 phải 429
    let saw429 = false;
    for (let i = 0; i < 7; i++) {
      const x = await req("POST", "/api/leads", { name: "Rate Test", phone: "0901234567" }, { "X-Forwarded-For": "10.9.9.7" });
      if (x.status === 429) { saw429 = true; break; }
    }
    ok("rate limit lead → 429", saw429);

    /* ---------- orders ---------- */
    r = await req("GET", "/api/orders/DH-801?phone=5889");
    ok("tra cứu đúng → 200 + 5 bước", r.status === 200 && r.data.data.steps.length === 5, `stage=${r.data?.data?.stage}`);
    ok("không trả số điện thoại đầy đủ", !JSON.stringify(r.data).includes("0912445889"));

    r = await req("GET", "/api/orders/DH-801?phone=0000");
    ok("sai 4 số → 404, không lộ dữ liệu", r.status === 404 && !JSON.stringify(r.data).includes("Hoàng Nam"));

    r = await req("GET", "/api/orders/DH-999?phone=5889");
    ok("mã không tồn tại → cùng thông báo 404", r.status === 404 && r.data.message.includes("Không tìm thấy"));

    r = await req("GET", "/api/orders/DH-801?phone=58");
    ok("thiếu số → 400", r.status === 400);

    r = await req("GET", "/api/orders/dh-801?phone=5889");
    ok("mã chữ thường vẫn tra được", r.status === 200);

    /* ---------- reviews ---------- */
    r = await req("GET", "/api/products/sofa-go-do/reviews");
    ok("reviews công khai chỉ trả đã duyệt", r.status === 200 && r.data.count === 2, `count=${r.data?.count}`);

    r = await req("POST", "/api/products/an-gian-tho/reviews", { orderCode: "DH-999", phoneLast4: "1234", rating: 5, body: "Gỗ rất đẹp và chắc chắn" });
    ok("đánh giá sai mã đơn → 404", r.status === 404);

    r = await req("POST", "/api/products/an-gian-tho/reviews", { orderCode: "DH-802", phoneLast4: "6778", rating: 9, body: "Gỗ rất đẹp và chắc chắn" });
    ok("rating ngoài 1–5 → 400", r.status === 400);

    r = await req("POST", "/api/products/an-gian-tho/reviews", { orderCode: "DH-802", phoneLast4: "6778", rating: 5, body: "ngắn" });
    ok("nội dung < 10 ký tự → 400", r.status === 400);

    r = await req("POST", "/api/products/an-gian-tho/reviews", { orderCode: "DH-802", phoneLast4: "6778", rating: 5, body: "Án gian đóng rất chắc, đúng số đo đã chốt." });
    ok("đánh giá hợp lệ → 201 chờ duyệt", r.status === 201 && r.data.data.approved === false);

    r = await req("POST", "/api/products/an-gian-tho/reviews", { orderCode: "DH-802", phoneLast4: "6778", rating: 5, body: "Đánh giá lần hai cho cùng đơn." });
    ok("đánh giá trùng đơn → 409", r.status === 409);

    r = await req("GET", "/api/products/an-gian-tho/reviews");
    ok("review chưa duyệt không hiện công khai", r.data.count === 0, `count=${r.data.count}`);

    /* ---------- admin ---------- */
    r = await req("GET", "/api/admin/leads");
    ok("admin không token → 401", r.status === 401);

    r = await req("GET", "/api/admin/leads", undefined, { Authorization: "Bearer sai-token" });
    ok("admin token sai → 401", r.status === 401);

    r = await req("GET", "/api/admin/leads", undefined, { Authorization: "Bearer " + ADMIN });
    ok("admin token đúng → thấy lead", r.status === 200 && r.data.count >= 2, `count=${r.data?.count}`);

    r = await req("GET", "/api/admin/reviews", undefined, { Authorization: "Bearer " + ADMIN });
    const pending = r.data.data.find((x) => x.approved === 0);
    ok("admin thấy review chờ duyệt", !!pending);

    if (pending) {
      r = await req("PATCH", "/api/admin/reviews/" + pending.id, { approved: true }, { Authorization: "Bearer " + ADMIN });
      ok("duyệt review → 200", r.status === 200);
      r = await req("GET", "/api/products/an-gian-tho/reviews");
      ok("review đã duyệt hiện công khai", r.data.count === 1, `count=${r.data.count}`);
    }

    r = await req("PATCH", "/api/admin/orders/DH-801", { stage: 4, note: "Khách đã ký mộc 07/11" }, { Authorization: "Bearer " + ADMIN });
    ok("cập nhật bước đơn → 200", r.status === 200);
    r = await req("GET", "/api/orders/DH-801?phone=5889");
    ok("tracker thấy bước mới", r.data.data.stage === 4, `stage=${r.data.data.stage}`);

    r = await req("PATCH", "/api/admin/orders/DH-801", { stage: 9 }, { Authorization: "Bearer " + ADMIN });
    ok("stage ngoài 1–5 → 400", r.status === 400);

    /* ---------- rate limit review ---------- */
    let saw429r = false;
    for (let i = 0; i < 25; i++) {
      const x = await req("POST", "/api/products/sofa-go-do/reviews",
        { orderCode: "DH-801", phoneLast4: "5889", rating: 5, body: "Kiểm tra giới hạn tần suất." },
        { "X-Forwarded-For": "10.9.9.6" });
      if (x.status === 429) { saw429r = true; break; }
    }
    ok("rate limit review → 429", saw429r);

    /* ---------- protocol / security ---------- */
    r = await req("GET", "/api/khong-co");
    ok("endpoint lạ → 404 JSON", r.status === 404 && r.data.success === false);

    const h = await fetch(BASE + "/api/health");
    ok("không lộ X-Powered-By", !h.headers.get("x-powered-by"));
    ok("có X-Content-Type-Options", h.headers.get("x-content-type-options") === "nosniff");

    const cors = await fetch(BASE + "/api/products", { headers: { Origin: "https://evil.example" } });
    ok("CORS chặn origin lạ", cors.headers.get("access-control-allow-origin") === null);

    const cors2 = await fetch(BASE + "/api/products", { headers: { Origin: "http://127.0.0.1:8098" } });
    ok("CORS cho origin hợp lệ", cors2.headers.get("access-control-allow-origin") === "http://127.0.0.1:8098");

    const put = await fetch(BASE + "/api/products", { method: "PUT" });
    ok("method không hỗ trợ → 404 JSON (không crash)", put.status === 404);

    /* ---------- tổng kết ---------- */
    console.log(`\n${"=".repeat(60)}`);
    console.log(`KẾT QUẢ: ${pass} PASS / ${fail} FAIL trên ${pass + fail} kiểm tra`);
    console.log("=".repeat(60));
  } catch (e) {
    console.error("FATAL", e);
    fail++;
  } finally {
    srv.kill();
    try { fs.unlinkSync(DB); } catch {}
    try { fs.unlinkSync(DB + "-wal"); } catch {}
    try { fs.unlinkSync(DB + "-shm"); } catch {}
    process.exit(fail ? 1 : 0);
  }
})();
