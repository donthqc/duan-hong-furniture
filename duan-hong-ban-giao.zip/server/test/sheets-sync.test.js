"use strict";
/**
 * Test tích hợp đồng bộ Google Sheets — KHÔNG gọi Google thật.
 *
 * Cách ly:
 *  - Google giả lập là một HTTP server cục bộ (cổng 5097): vừa đóng vai
 *    oauth2.googleapis.com/token (kiểm tra chữ ký JWT RS256 bằng public key),
 *    vừa đóng vai sheets.googleapis.com (lưu dữ liệu trong bộ nhớ).
 *  - Backend thật được spawn trên cổng riêng 5098, database tạm trong thư mục temp.
 *  - Server thứ hai trên cổng 5096 chạy với database "cũ" (chưa có cột Sheets)
 *    và KHÔNG có credential, để kiểm tra migration + báo lỗi vận hành.
 *  - Không cần credential thật; khoá RSA sinh ngay trong test.
 *
 * Chạy (foreground):  node server/test/sheets-sync.test.js
 */
const http = require("node:http");
const crypto = require("node:crypto");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { spawn } = require("node:child_process");
const { DatabaseSync } = require("node:sqlite");

/* Thư mục tạm phải tạo TRƯỚC khi require module đồng bộ: module này kéo theo
   src/db.js, mà db.js mở DB theo DB_PATH. Nếu chưa đặt DB_PATH, nó sẽ mở
   database thật của xưởng — test phải tuyệt đối không chạm vào đó. */
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), "dh-sheets-"));
process.env.DB_PATH = path.join(TMP, "meta.db");

const { SHEET_HEADERS } = require("../src/sheets/sync");

const PORT_S1 = 5098;
const PORT_S2 = 5096;
const PORT_MOCK = 5097;
const BASE_S1 = `http://127.0.0.1:${PORT_S1}`;
const BASE_S2 = `http://127.0.0.1:${PORT_S2}`;
const ADMIN = "test-admin-token";
const DB1 = path.join(TMP, "s1.db");
const DB2 = path.join(TMP, "legacy.db");
const SA_FILE = path.join(TMP, "service-account.json");
const SPREADSHEET_ID = "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789";
const CLIENT_EMAIL = "duanhong-test@test-project.iam.gserviceaccount.com";

let pass = 0;
let fail = 0;
const failures = [];
function ok(name, cond, detail = "") {
  if (cond) {
    pass++;
    console.log(`PASS  ${name}${detail ? "  :: " + detail : ""}`);
  } else {
    fail++;
    failures.push(name + (detail ? " :: " + detail : ""));
    console.log(`FAIL  ${name}${detail ? "  :: " + detail : ""}`);
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitFor(fn, timeout = 8000, every = 50) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const v = await fn();
    if (v) return v;
    await sleep(every);
  }
  return null;
}

async function req(base, method, p, body, headers = {}) {
  const res = await fetch(base + p, {
    method,
    headers: { "Content-Type": "application/json", ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let data = null;
  try {
    data = await res.json();
  } catch {}
  return { status: res.status, data };
}

/* ------------------------- Google giả lập -------------------------------- */

function decodeB64url(s) {
  return Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64");
}

function createMockGoogle(publicKeyPem) {
  const state = {
    rows: [SHEET_HEADERS.slice()], // dòng 1 là tiêu đề, do xưởng tạo sẵn
    mode: "ok", // ok | fail
    failStatus: 503,
    tokens: new Set(),
    calls: { token: 0, read: 0, append: 0, update: 0, rejectedAuth: 0 },
    lastClaims: null,
    requests: [],
  };

  const server = http.createServer(async (rq, rs) => {
    const chunks = [];
    for await (const c of rq) chunks.push(c);
    const raw = Buffer.concat(chunks).toString("utf8");
    const u = new URL(rq.url, "http://127.0.0.1");
    const send = (status, obj) => {
      rs.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
      rs.end(JSON.stringify(obj));
    };

    state.requests.push({ method: rq.method, path: u.pathname });

    /* --- token endpoint: xác thực chữ ký JWT thật bằng public key --- */
    if (u.pathname === "/token") {
      state.calls.token++;
      const params = new URLSearchParams(raw);
      if (params.get("grant_type") !== "urn:ietf:params:oauth:grant-type:jwt-bearer") {
        return send(400, { error: "unsupported_grant_type" });
      }
      const jwt = params.get("assertion") || "";
      const parts = jwt.split(".");
      if (parts.length !== 3) return send(400, { error: "invalid_grant" });
      let signatureOk = false;
      try {
        signatureOk = crypto
          .createVerify("RSA-SHA256")
          .update(parts[0] + "." + parts[1])
          .verify(publicKeyPem, decodeB64url(parts[2]));
      } catch {
        signatureOk = false;
      }
      if (!signatureOk) return send(401, { error: "invalid_grant", error_description: "bad signature" });
      try {
        state.lastClaims = JSON.parse(decodeB64url(parts[1]).toString("utf8"));
      } catch {
        return send(400, { error: "invalid_grant" });
      }
      const token = "mock-token-" + crypto.randomBytes(8).toString("hex");
      state.tokens.add(token);
      return send(200, { access_token: token, expires_in: 3600, token_type: "Bearer" });
    }

    /* --- mọi endpoint còn lại phải có Bearer token do mock cấp --- */
    const auth = rq.headers.authorization || "";
    const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
    if (!state.tokens.has(token)) {
      state.calls.rejectedAuth++;
      return send(401, { error: { code: 401, message: "Unauthenticated" } });
    }

    const isAppend = u.pathname.endsWith(":append");
    const rawPath = isAppend ? u.pathname.slice(0, -":append".length) : u.pathname;
    const m = rawPath.match(/^\/v4\/spreadsheets\/([^/]+)\/values\/(.+)$/);
    if (!m) return send(404, { error: { code: 404, message: "not found" } });
    const range = decodeURIComponent(m[2]);

    if (state.mode === "fail") {
      return send(state.failStatus, {
        error: { code: state.failStatus, message: "Google giả lập đang lỗi có chủ đích" },
      });
    }

    const a1 = range.includes("!") ? range.slice(range.lastIndexOf("!") + 1) : range;

    // Đọc danh sách mã ở cột B
    if (rq.method === "GET" && /^B\d*:B\d*$/.test(a1)) {
      state.calls.read++;
      return send(200, { range, majorDimension: "ROWS", values: state.rows.slice(1).map((r) => [r[1] || ""]) });
    }
    // Đọc toàn bộ vùng để đối chiếu
    if (rq.method === "GET") {
      state.calls.read++;
      const rq9 = a1.match(/^A(\d+):/);
      const from = rq9 ? Number(rq9[1]) - 1 : 0;
      return send(200, { range, majorDimension: "ROWS", values: state.rows.slice(from).map((r) => r.slice()) });
    }
    // Thêm dòng
    if (rq.method === "POST" && isAppend) {
      state.calls.append++;
      const body = JSON.parse(raw || "{}");
      const values = (body.values && body.values[0]) || [];
      state.rows.push(values);
      const rowNumber = state.rows.length;
      return send(200, {
        spreadsheetId: SPREADSHEET_ID,
        updates: {
          spreadsheetId: SPREADSHEET_ID,
          updatedRange: `'Khách hàng'!A${rowNumber}:K${rowNumber}`,
          updatedRows: 1,
        },
      });
    }
    // Cập nhật dòng đã có
    if (rq.method === "PUT") {
      state.calls.update++;
      const body = JSON.parse(raw || "{}");
      const values = (body.values && body.values[0]) || [];
      const rm = a1.match(/^A(\d+):G(\d+)$/);
      if (!rm) return send(400, { error: { code: 400, message: "range không hỗ trợ: " + a1 } });
      const rowIndex = Number(rm[1]) - 1;
      if (!state.rows[rowIndex]) return send(400, { error: { code: 400, message: "dòng không tồn tại" } });
      for (let i = 0; i < values.length && i < 7; i++) state.rows[rowIndex][i] = values[i];
      return send(200, {
        spreadsheetId: SPREADSHEET_ID,
        updatedRange: a1,
        updatedRows: 1,
      });
    }
    return send(405, { error: { code: 405, message: "method not allowed" } });
  });

  return { server, state };
}

/* ------------------------------ Database --------------------------------- */

function openDb(file) {
  try {
    return new DatabaseSync(file, { readOnly: true });
  } catch {
    return new DatabaseSync(file);
  }
}

function leadByCode(dbFile, code) {
  const d = openDb(dbFile);
  try {
    return d.prepare("SELECT * FROM leads WHERE code = ?").get(code);
  } finally {
    d.close();
  }
}

function countLeads(dbFile) {
  const d = openDb(dbFile);
  try {
    return d.prepare("SELECT COUNT(*) AS c FROM leads").get().c;
  } finally {
    d.close();
  }
}

function allLeads(dbFile) {
  const d = openDb(dbFile);
  try {
    return d.prepare("SELECT * FROM leads ORDER BY id").all();
  } finally {
    d.close();
  }
}

function exec(dbFile, sql, params = []) {
  const d = new DatabaseSync(dbFile);
  try {
    return d.prepare(sql).run(...params);
  } finally {
    d.close();
  }
}

/* ------------------------------- Chạy test -------------------------------- */

async function main() {
  const { privateKey, publicKey } = crypto.generateKeyPairSync("rsa", {
    modulusLength: 2048,
    publicKeyEncoding: { type: "spki", format: "pem" },
    privateKeyEncoding: { type: "pkcs8", format: "pem" },
  });

  fs.writeFileSync(
    SA_FILE,
    JSON.stringify(
      {
        type: "service_account",
        project_id: "test-project",
        client_email: CLIENT_EMAIL,
        private_key: privateKey,
        token_uri: `http://127.0.0.1:${PORT_MOCK}/token`,
      },
      null,
      2
    )
  );

  /* DB "cũ": đúng schema leads trước Giai đoạn 2, có sẵn 1 lead thật */
  const legacy = new DatabaseSync(DB2);
  legacy.exec(`
    CREATE TABLE leads (
      id         INTEGER PRIMARY KEY,
      code       TEXT NOT NULL UNIQUE,
      name       TEXT NOT NULL,
      phone      TEXT NOT NULL,
      phone_hash TEXT NOT NULL,
      area       TEXT NOT NULL DEFAULT '',
      need       TEXT NOT NULL DEFAULT '',
      source     TEXT NOT NULL DEFAULT 'website',
      status     TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','called','measured','quoted','won','lost')),
      note       TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  legacy
    .prepare("INSERT INTO leads (code,name,phone,phone_hash,area,need) VALUES (?,?,?,?,?,?)")
    .run("LH-OLD01", "Khách Cũ", "0900000001", "hash-cu", "Hưng Yên", "Bàn thờ");
  legacy.close();

  const mock = createMockGoogle(publicKey);
  await new Promise((r) => mock.server.listen(PORT_MOCK, "127.0.0.1", r));
  const state = mock.state;

  const baseEnv = { ...process.env, PORT: String(PORT_S1), DB_PATH: DB1, ADMIN_TOKEN: ADMIN, PHONE_SALT: "test-salt", RATE_LEAD: "500", RATE_REVIEW: "50", RATE_TRACK: "500" };
  for (const k of Object.keys(baseEnv)) if (/^(GOOGLE_|SHEETS_)/.test(k)) delete baseEnv[k];
  const envS1 = {
    ...baseEnv,
    GOOGLE_SHEETS_SPREADSHEET_ID: SPREADSHEET_ID,
    GOOGLE_SHEETS_TAB: "Khách hàng",
    GOOGLE_SHEETS_CREDENTIALS_FILE: SA_FILE,
    GOOGLE_SHEETS_API_BASE: `http://127.0.0.1:${PORT_MOCK}`,
    SHEETS_MAX_ATTEMPTS: "2",
    SHEETS_RETRY_BASE_MS: "60",
    SHEETS_TIMEOUT_MS: "3000",
  };

  const srv1 = spawn(process.execPath, [path.join(__dirname, "..", "src", "server.js")], {
    env: envS1,
    stdio: ["ignore", "pipe", "pipe"],
  });
  const log1 = [];
  srv1.stdout.on("data", (d) => log1.push("[s1] " + d.toString().trim()));
  srv1.stderr.on("data", (d) => log1.push("[s1:err] " + d.toString().trim()));

  const srv2 = spawn(process.execPath, [path.join(__dirname, "..", "src", "server.js")], {
    env: { ...baseEnv, PORT: String(PORT_S2), DB_PATH: DB2 },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const log2 = [];
  srv2.stdout.on("data", (d) => log2.push("[s2] " + d.toString().trim()));
  srv2.stderr.on("data", (d) => log2.push("[s2:err] " + d.toString().trim()));

  const up = async (base) => {
    for (let i = 0; i < 60; i++) {
      try {
        const r = await fetch(base + "/api/health");
        if (r.ok) return true;
      } catch {}
      await sleep(100);
    }
    return false;
  };

  try {
    ok("server có credential (5098) sống", await up(BASE_S1));
    ok("server thiếu credential (5096) sống", await up(BASE_S2));

    /* ================= 1. Migration và cột bảng leads ================= */
    {
      const d = openDb(DB1);
      const cols = d.prepare("PRAGMA table_info(leads)").all().map((c) => c.name);
      d.close();
      const needed = ["sheets_status", "sheets_row", "sheets_error", "sheets_synced_at", "sync_attempts"];
      ok("DB mới có đủ 5 cột đồng bộ", needed.every((n) => cols.includes(n)), cols.join(","));
    }
    {
      const d = openDb(DB2);
      const cols = d.prepare("PRAGMA table_info(leads)").all().map((c) => c.name);
      d.close();
      const needed = ["sheets_status", "sheets_row", "sheets_error", "sheets_synced_at", "sync_attempts"];
      ok("DB cũ được migration thêm 5 cột (không xoá dữ liệu)", needed.every((n) => cols.includes(n)));
      const old = leadByCode(DB2, "LH-OLD01");
      ok("lead cũ trong DB cũ vẫn còn nguyên", !!old && old.name === "Khách Cũ", old ? old.name : "mất");
      ok("lead cũ nhận trạng thái pending mặc định", old && old.sheets_status === "pending", old && old.sheets_status);
    }

    /* ================= 2. Gửi lead hợp lệ → 1 dòng, sent ============== */
    const r1 = await req(BASE_S1, "POST", "/api/leads", {
      name: "Nguyễn Văn An",
      phone: "0912345678",
      area: "TP. Hưng Yên",
      need: "Bàn ăn 6 người gỗ gõ đỏ",
    });
    ok("lead hợp lệ → 201 + mã LH-", r1.status === 201 && /^LH-/.test(r1.data?.data?.code || ""), r1.data?.data?.code);
    const code1 = r1.data?.data?.code;
    ok("response công khai không hứa đã đồng bộ Sheet",
      !/sheets|đồng bộ google/i.test(JSON.stringify(r1.data)));

    const sent1 = await waitFor(() => {
      const l = code1 && leadByCode(DB1, code1);
      return l && l.sheets_status === "sent" ? l : null;
    });
    ok("lead đạt trạng thái sent", !!sent1, sent1 ? `row=${sent1.sheets_row}` : "quá hạn chờ");

    ok("Sheet có đúng 1 dòng dữ liệu", state.rows.length === 2, `rows=${state.rows.length}`);
    const sheetRow1 = state.rows[1] || [];
    ok("mã lead trên Sheet khớp mã trả về", sheetRow1[1] === code1, `sheet=${sheetRow1[1]} api=${code1}`);
    ok("cột A đúng định dạng giờ Việt Nam DD/MM/YYYY HH:mm",
      /^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/.test(String(sheetRow1[0] || "")), String(sheetRow1[0]));
    ok("số điện thoại giữ nguyên dạng text", sheetRow1[3] === "0912345678", String(sheetRow1[3]));
    ok("cột nguồn = website, trạng thái xử lý = Mới nhận", sheetRow1[6] === "website" && (sheetRow1[7] === "Mới" || sheetRow1[7] === "Mới nhận"),
      `${sheetRow1[6]} / ${sheetRow1[7]}`);
    ok("khu vực và nhu cầu lên đúng cột", sheetRow1[4] === "TP. Hưng Yên" && sheetRow1[5].includes("Bàn ăn"),
      `${sheetRow1[4]} | ${sheetRow1[5]}`);

    ok("DB lưu sheets_row khớp số dòng Sheet", sent1 && Number(sent1.sheets_row) === 2, sent1 && String(sent1.sheets_row));
    ok("DB có sheets_synced_at, sheets_error rỗng, sync_attempts = 1",
      sent1 && !!sent1.sheets_synced_at && sent1.sheets_error === "" && sent1.sync_attempts === 1,
      sent1 ? `${sent1.sheets_synced_at} / "${sent1.sheets_error}" / ${sent1.sync_attempts}` : "");

    const claims = state.lastClaims || {};
    ok("JWT: đúng iss/scope/aud, chỉ xin quyền Sheets",
      claims.iss === CLIENT_EMAIL &&
        claims.scope === "https://www.googleapis.com/auth/spreadsheets" &&
        claims.aud === `http://127.0.0.1:${PORT_MOCK}/token`,
      `${claims.iss} | ${claims.scope}`);
    ok("mock xác thực được chữ ký JWT RS256 và cấp token", state.calls.token === 1 && state.calls.rejectedAuth === 0,
      `token=${state.calls.token} rejected=${state.calls.rejectedAuth}`);

    /* ================= 3. Google lỗi → lead còn, failed =============== */
    state.mode = "fail";
    const r2 = await req(BASE_S1, "POST", "/api/leads", {
      name: "Lê Thị Hoa",
      phone: "0987654321",
      area: "Văn Giang",
      need: "Tủ bếp chữ L",
    });
    ok("Google lỗi vẫn trả 201 cho khách (lead đã lưu)", r2.status === 201, `status=${r2.status}`);
    const code2 = r2.data?.data?.code;
    const failed2 = await waitFor(() => {
      const l = code2 && leadByCode(DB1, code2);
      return l && l.sheets_status === "failed" ? l : null;
    });
    ok("lead ở trạng thái failed, vẫn còn trong SQLite", !!failed2, failed2 ? "ok" : "không thấy");
    ok("sheets_error ghi lỗi Google (HTTP 503)", failed2 && /503/.test(failed2.sheets_error), failed2 && failed2.sheets_error.slice(0, 80));
    ok("Sheet không thêm dòng khi Google lỗi", state.rows.length === 2, `rows=${state.rows.length}`);

    /* ================= 4. Retry thủ công → sent, không nhân bản ==== */
    state.mode = "ok";
    const resync2 = await req(BASE_S1, "POST", "/api/admin/sheets/resync", { leadId: failed2.id },
      { Authorization: "Bearer " + ADMIN });
    ok("admin resync nhận lệnh (200, queued=1)", resync2.status === 200 && resync2.data?.data?.queued === 1,
      JSON.stringify(resync2.data?.data));
    const sent2 = await waitFor(() => {
      const l = leadByCode(DB1, code2);
      return l && l.sheets_status === "sent" ? l : null;
    });
    ok("retry đưa lead lỗi thành sent", !!sent2);
    ok("Sheet có 2 dòng dữ liệu, không nhân bản", state.rows.length === 3, `rows=${state.rows.length}`);
    ok("mỗi mã chỉ xuất hiện đúng 1 lần trên Sheet",
      state.rows.slice(1).filter((r) => r[1] === code2).length === 1);

    /* ================= 5. Retry khi mất sheets_row → không trùng ==== */
    state.rows[1][7] = "Đang gọi"; // xưởng sửa tay cột H
    state.rows[1][8] = "Chị Lan"; // xưởng sửa tay cột I
    exec(DB1, "UPDATE leads SET sheets_row = NULL, sheets_status = 'pending', sheets_error = '', sync_attempts = 0 WHERE code = ?", [code1]);
    const rowsBefore = state.rows.length;
    await req(BASE_S1, "POST", "/api/admin/sheets/resync", { leadId: sent1.id }, { Authorization: "Bearer " + ADMIN });
    const again1 = await waitFor(() => {
      const l = leadByCode(DB1, code1);
      return l && l.sheets_status === "sent" ? l : null;
    });
    ok("đồng bộ lại khi DB mất sheets_row vẫn thành công", !!again1);
    ok("không sinh dòng trùng (dùng mã lead làm khoá)", state.rows.length === rowsBefore, `rows=${state.rows.length}`);
    ok("không ghi đè cột xưởng nhập tay (H, I)",
      state.rows[1][7] === "Đang gọi" && state.rows[1][8] === "Chị Lan",
      `${state.rows[1][7]} / ${state.rows[1][8]}`);

    /* ================= 6. 10 lead hợp lệ → 10 mã, 10 dòng =========== */
    const codes10 = [];
    for (let i = 1; i <= 10; i++) {
      const rr = await req(BASE_S1, "POST", "/api/leads", {
        name: "Khách Thử " + i,
        phone: "09000000" + String(i).padStart(2, "0"),
        area: "Hưng Yên",
        need: "Đóng tủ áo số " + i,
      });
      if (rr.status === 201) codes10.push(rr.data.data.code);
    }
    ok("10 lần gửi tạo đúng 10 mã khác nhau", codes10.length === 10 && new Set(codes10).size === 10,
      `n=${codes10.length} unique=${new Set(codes10).size}`);
    const done10 = await waitFor(() => {
      const ids = allLeads(DB1).filter((l) => codes10.includes(l.code) && l.sheets_status === "sent");
      return ids.length === 10 ? ids : null;
    }, 12000);
    ok("cả 10 lead đạt sent", !!done10, done10 ? "10/10" : "chưa đủ");
    ok("Sheet tăng đúng 10 dòng", state.rows.length === 3 + 10, `rows=${state.rows.length}`);
    const allCodes = state.rows.slice(1).map((r) => r[1]);
    ok("không có mã nào lặp trên Sheet", new Set(allCodes).size === allCodes.length,
      `dòng=${allCodes.length} unique=${new Set(allCodes).size}`);

    /* ================= 7. Double submit → không tạo 2 lead ========== */
    const countBeforeDup = countLeads(DB1);
    const rowsBeforeDup = state.rows.length;
    const dup = await req(BASE_S1, "POST", "/api/leads", {
      name: "Nguyễn Văn An",
      phone: "0912345678",
      area: "TP. Hưng Yên",
      need: "Bàn ăn 6 người gỗ gõ đỏ",
    });
    ok("double submit trả 200 + cờ duplicate", dup.status === 200 && dup.data?.duplicate === true, `status=${dup.status}`);
    ok("double submit trả lại đúng mã cũ", dup.data?.data?.code === code1, String(dup.data?.data?.code));
    ok("không tạo thêm lead trong SQLite", countLeads(DB1) === countBeforeDup, `${countBeforeDup} → ${countLeads(DB1)}`);
    ok("không thêm dòng Sheet", state.rows.length === rowsBeforeDup, `rows=${state.rows.length}`);

    const samePhoneOtherName = await req(BASE_S1, "POST", "/api/leads", {
      name: "Nguyễn Thị Em",
      phone: "0912345678",
      area: "TP. Hưng Yên",
      need: "Đóng thêm tủ giày",
    });
    ok("cùng số điện thoại nhưng khác người → vẫn tạo lead mới", samePhoneOtherName.status === 201,
      `status=${samePhoneOtherName.status}`);

    /* ================= 8. XSS và SQL injection ====================== */
    const xssName = `<img src=x onerror=alert(1)>`;
    const xssNeed = `<script>alert("xss")</script> đóng bàn`;
    const rx = await req(BASE_S1, "POST", "/api/leads", { name: xssName, phone: "0901112223", need: xssNeed });
    ok("tên/nhu cầu chứa HTML vẫn nhận (lưu dạng text)", rx.status === 201, `status=${rx.status}`);
    const codeX = rx.data?.data?.code;
    const sx = await waitFor(() => {
      const l = codeX && leadByCode(DB1, codeX);
      return l && l.sheets_status === "sent" ? l : null;
    });
    const sheetX = sx && state.rows.find((r) => r[1] === codeX);
    ok("Sheet giữ nguyên chuỗi HTML, không escape/biến đổi",
      !!sheetX && sheetX[2] === xssName && sheetX[5] === xssNeed,
      sheetX ? sheetX[2] : "không thấy dòng");

    const sqlName = "Robert'); DROP TABLE leads;--";
    const rs = await req(BASE_S1, "POST", "/api/leads", { name: sqlName, phone: "0901112224", need: "x" });
    ok("tên chứa chuỗi SQL vẫn được lưu an toàn", rs.status === 201, `status=${rs.status}`);
    const codeS = rs.data?.data?.code;
    await waitFor(() => {
      const l = codeS && leadByCode(DB1, codeS);
      return l && l.sheets_status === "sent" ? l : null;
    });
    ok("bảng leads vẫn tồn tại sau payload SQL injection", (() => {
      try {
        return countLeads(DB1) > 0;
      } catch {
        return false;
      }
    })());
    const sheetS = codeS && state.rows.find((r) => r[1] === codeS);
    ok("Sheet nhận đúng nguyên văn tên có dấu nháy", !!sheetS && sheetS[2] === sqlName, sheetS ? sheetS[2] : "không thấy");

    /* ================= 9. Số điện thoại sai → không ghi ============ */
    const countBeforeBad = countLeads(DB1);
    const rowsBeforeBad = state.rows.length;
    const rbad = await req(BASE_S1, "POST", "/api/leads", { name: "Sai Số", phone: "12345" });
    ok("SĐT sai → 400", rbad.status === 400, `status=${rbad.status}`);
    ok("SĐT sai không tạo lead và không ghi Sheet",
      countLeads(DB1) === countBeforeBad && state.rows.length === rowsBeforeBad,
      `leads=${countLeads(DB1)} rows=${state.rows.length}`);

    /* ================= 10. Retry có giới hạn ======================== */
    state.mode = "fail";
    const rlimit = await req(BASE_S1, "POST", "/api/leads", { name: "Khách Lỗi", phone: "0901112225", need: "thử retry" });
    const codeL = rlimit.data?.data?.code;
    const stopped = await waitFor(() => {
      const l = codeL && leadByCode(DB1, codeL);
      return l && l.sync_attempts >= 2 && l.sheets_status === "failed" ? l : null;
    }, 8000);
    ok("lỗi Google dừng sau đúng số lần thử tối đa (2)", !!stopped && stopped.sync_attempts === 2,
      stopped ? `attempts=${stopped.sync_attempts}` : "không dừng");
    await sleep(500);
    const afterStop = leadByCode(DB1, codeL);
    ok("không thử lại vô hạn sau khi chạm giới hạn", afterStop && afterStop.sync_attempts === 2,
      afterStop ? `attempts=${afterStop.sync_attempts}` : "");
    ok("lead lỗi vẫn nằm trong SQLite", !!afterStop, afterStop && afterStop.code);
    state.mode = "ok";

    /* ================= 11. Admin status không lộ secret ============= */
    const noAuth = await req(BASE_S1, "GET", "/api/admin/sheets/status");
    ok("admin status không token → 401", noAuth.status === 401, `status=${noAuth.status}`);

    const st = await req(BASE_S1, "GET", "/api/admin/sheets/status", undefined, { Authorization: "Bearer " + ADMIN });
    ok("admin status báo đã cấu hình + đếm trạng thái",
      st.status === 200 && st.data?.data?.configured === true && typeof st.data.data.counts?.sent === "number",
      JSON.stringify(st.data?.data?.counts));
    const stText = JSON.stringify(st.data);
    ok("admin status không chứa private key/token",
      !stText.includes("PRIVATE KEY") && !stText.includes("mock-token") && !stText.includes(privateKey.slice(0, 40)));

    const callsBefore = state.calls.append + state.calls.update;
    const resyncSent = await req(BASE_S1, "POST", "/api/admin/sheets/resync", { leadId: sent1.id },
      { Authorization: "Bearer " + ADMIN });
    ok("resync lead đã sent → không làm gì (ALREADY_SENT)",
      resyncSent.status === 200 && resyncSent.data?.data?.reason === "ALREADY_SENT",
      JSON.stringify(resyncSent.data?.data));
    await sleep(150);
    ok("không gọi Google thêm cho lead đã sent", state.calls.append + state.calls.update === callsBefore);

    /* ================= 12. Thiếu credential → báo lỗi vận hành ===== */
    const rowsBeforeNoCred = state.rows.length;
    const rNoCred = await req(BASE_S2, "POST", "/api/leads", {
      name: "Khách Không Credential",
      phone: "0902223334",
      need: "thử thiếu cấu hình",
    });
    ok("thiếu credential vẫn trả 201 (lead không bị mất)", rNoCred.status === 201, `status=${rNoCred.status}`);
    const codeN = rNoCred.data?.data?.code;
    const leadN = codeN && leadByCode(DB2, codeN);
    ok("lead ghi trạng thái failed thay vì báo thành công giả", leadN && leadN.sheets_status === "failed",
      leadN && leadN.sheets_status);
    ok("sheets_error nói rõ thiếu cấu hình", leadN && /Chưa cấu hình Google Sheets/.test(leadN.sheets_error),
      leadN && leadN.sheets_error.slice(0, 90));
    ok("không có dòng nào được gửi lên Google",
      state.rows.length === rowsBeforeNoCred, `rows=${state.rows.length}`);

    const st2 = await req(BASE_S2, "GET", "/api/admin/sheets/status", undefined, { Authorization: "Bearer " + ADMIN });
    ok("admin status báo configured=false + reason + missing",
      st2.status === 200 && st2.data?.data?.configured === false &&
        /Chưa cấu hình/.test(st2.data.data.reason) && st2.data.data.missing.length >= 2,
      JSON.stringify(st2.data?.data?.missing));
    ok("admin status server thiếu credential không lộ secret",
      !JSON.stringify(st2.data).includes("PRIVATE KEY"));

    /* ================= 13. JWT chỉ được lấy token một lần =========== */
    ok("access token được cache (chỉ 1 lần gọi token endpoint)", state.calls.token === 1,
      `token=${state.calls.token}`);

    /* ================= Tổng kết ===================================== */
    console.log("\n" + "=".repeat(64));
    console.log(`KẾT QUẢ: ${pass} PASS / ${fail} FAIL trên ${pass + fail} kiểm tra`);
    console.log("Bằng chứng phụ: Sheet giả lập có " + state.rows.length + " dòng (1 tiêu đề + " + (state.rows.length - 1) + " dữ liệu)");
    console.log(`append=${state.calls.append} update=${state.calls.update} read=${state.calls.read} token=${state.calls.token}`);
    console.log("=".repeat(64));
    if (fail) {
      console.log("\nCác ca FAIL:");
      failures.forEach((f) => console.log("  - " + f));
    }
  } catch (err) {
    fail++;
    console.error("FATAL:", err);
  } finally {
    srv1.kill();
    srv2.kill();
    mock.server.close();

    if (fail) {
      console.log("\n--- log server có credential ---");
      console.log(log1.slice(-25).join("\n"));
      console.log("--- log server thiếu credential ---");
      console.log(log2.slice(-15).join("\n"));
      console.log("Thư mục tạm giữ lại để điều tra: " + TMP);
    } else {
      try {
        fs.rmSync(TMP, { recursive: true, force: true });
      } catch {}
    }
    await sleep(150);
    process.exit(fail ? 1 : 0);
  }
}

main();
