# VIỆC GIAO CHO BOT KỸ THUẬT — 2026-11-13

Nguồn: `C:\Users\DELL\Documents\qa-web-ban-hang\KE-HOACH-PHAT-TRIEN-WEBSITE-2026.md`

## Bối cảnh
Website Duân Hồng hiện có: 8 trang HTML tĩnh trong `design/`, API `node:http` + SQLite trong `server/`,
bộ test trong `qa-node/`. Lead từ form lưu vào SQLite nhưng **chưa** đồng bộ Google Sheets.
Chưa có Google credential, chưa có domain production, chưa có ảnh thật.

## Phạm vi được giao (Giai đoạn 2 — phần chuẩn bị)

1. Đọc kế hoạch `KE-HOACH-PHAT-TRIEN-WEBSITE-2026.md`, mục GIAI ĐOẠN 2.
2. Rà soát `server/src/db.js` và `server/src/app.js`: xác định chính xác bảng `leads` hiện có cột gì.
3. Thiết kế và viết module đồng bộ Google Sheets ở backend:
   - Thêm cột trạng thái đồng bộ vào schema `leads` (`sheets_status`, `sheets_row`, `sheets_error`, `sheets_synced_at`, `sync_attempts`) — dùng migration idempotent, tôn trọng DB cũ.
   - Module gọi Google Sheets API bằng service account hoặc OAuth, **đọc credential từ biến môi trường/file ngoài repo**, không hardcode.
   - Hàm đồng bộ idempotent: dùng mã lead (`code`) làm khoá, không tạo dòng trùng khi retry.
   - Hàng đợi thử lại có giới hạn; lỗi Google không làm mất lead trong SQLite.
4. Viết test **dùng Google giả lập (mock)**, không gọi API thật, không cần credential thật:
   - Gửi lead hợp lệ → 1 dòng, trạng thái `sent`.
   - Google lỗi → lead vẫn còn, trạng thái `failed`, có `sheets_error`.
   - Retry → không nhân bản.
   - Double submit → không tạo 2 lead.
   - Thiếu credential → báo lỗi vận hành rõ ràng, không báo thành công giả.
5. Viết `SPEC-GOOGLE-SHEETS.md`: cột Sheet, luồng dữ liệu, cách cấu hình credential, cách chạy test,
   và danh sách câu hỏi chủ xưởng phải trả lời trước khi bật production.

## Ràng buộc bắt buộc

- **Không** sửa database thật, **không** chạy `npm run reset`, **không** xoá dữ liệu.
- Test phải dùng database tạm và cổng riêng; chạy foreground (chạy nền sẽ in "stdin is not a tty" và không thực thi).
- **Không** gọi Google API thật, **không** nhập credential thật, **không** xin token qua chat.
- **Không** deploy, **không** mở cổng ra Internet, **không** đụng cấu hình `deploy/`.
- Giữ nguyên kiến trúc: HTML/CSS/JS thuần + `node:http`, không thêm framework.
- Mọi truy vấn SQL dùng prepared statement; chèn dữ liệu vào DOM bằng `textContent`.
- Comment và tài liệu bằng tiếng Việt có dấu.
- Mỗi kết luận phải kèm bằng chứng: output lệnh hoặc `file:dòng`. Không bịa số liệu.
- Chỉ báo "xong" khi đã chạy lại test và dán kết quả thật.

## Đầu ra cần báo lại
- Danh sách file đã tạo/sửa (đường dẫn tuyệt đối).
- Kết quả chạy test: số PASS/FAIL thật.
- Điều gì chưa làm được và vì sao (ví dụ cần credential thật).
- Câu hỏi cần chủ xưởng trả lời.
