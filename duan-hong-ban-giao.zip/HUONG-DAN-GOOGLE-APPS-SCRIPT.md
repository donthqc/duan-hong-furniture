# HƯỚNG DẪN TÍCH HỢP GOOGLE APPS SCRIPT CHO XƯỞNG MỘC DUÂN HỒNG

> **Giải pháp tối ưu**: Thay thế hoàn toàn cơ chế Service Account rườm rà của Google Cloud bằng **Google Apps Script Web App** — cài đặt xong trong 2 phút, không cần tài khoản GCP, không cần tạo JSON key, không bao giờ bị lỗi khóa bảng hay timeout.

---

## 1. Tại sao Google Apps Script tối ưu hơn hẳn Google Cloud API?

| Tiêu chí | Cơ chế cũ (Service Account API v4) | Cơ chế mới (Google Apps Script) |
|---|---|---|
| **Độ phức tạp cài đặt** | Cực kỳ phức tạp: Phải mở Google Cloud Console, tạo Project, tạo Service Account, gán vai trò IAM, tải JSON Private Key RS256, chia sẻ quyền Sheet cho email bot. | **Siêu đơn giản**: Mở chính trang Google Sheet của xưởng -> Bấm `Tiện ích mở rộng` -> `Apps Script` -> Dán code -> Bấm `Triển khai`. |
| **Bảo mật & Quản lý** | Phải lưu trữ file `.json` chứa private key bí mật, có nguy cơ lộ key nếu không cẩn thận. | **An toàn tuyệt đối**: Không cần lưu bất kỳ file key bí mật nào trong mã nguồn server. |
| **Hiện tượng khóa bảng (Mutex)** | Khi chủ xưởng đang mở file trên trình duyệt, API v4 ngoài internet rất dễ bị Google hoãn hoặc timeout (503). | **Chạy mượt mà 100%**: Script chạy trực tiếp bên trong hạ tầng Google Drive của chính bạn, ghi dữ liệu êm đẹp ngay tức thì. |
| **Tự động làm đẹp bảng tính** | Không làm được hoặc phải viết hàng trăm dòng code phức tạp để format ô. | **1 Click tự động**: Tạo Header màu gỗ Óc chó `#2C1E16`, chữ trắng, bo viền, tự tạo dropdown menu 5 trạng thái cho nhân viên trực. |
| **Thông báo tức thì** | Cần tích hợp thêm dịch vụ gửi mail/SMS trả phí. | **Miễn phí có sẵn**: Tự động gửi Email thông báo về Gmail của chủ xưởng ngay khi khách nhấn "Gửi lịch hẹn". |

---

## 2. Hướng dẫn cài đặt 5 bước (Chỉ mất 2 phút)

### Bước 1: Mở Google Apps Script từ trang tính của xưởng
1. Mở file Google Sheet của xưởng: **KHÁCH HÀNG LIÊN HỆ — XƯỞNG MỘC DUÂN HỒNG**.
2. Trên thanh menu, chọn: **Tiện ích mở rộng** (Extensions) ➔ **Apps Script**.

### Bước 2: Dán mã nguồn `Code.gs`
1. Xóa toàn bộ đoạn code mặc định `function myFunction() { ... }` đang có trong trình soạn thảo.
2. Mở file [`server/google-apps-script/Code.gs`](file:///C:/Users/DELL/Documents/qa-web-ban-hang/server/google-apps-script/Code.gs), sao chép toàn bộ nội dung và dán vào Apps Script.
3. Nhấn biểu tượng đĩa mềm 💾 **Lưu dự án** (hoặc phím tắt `Ctrl + S`).

### Bước 3: Tự động làm đẹp & tạo bảng chuẩn xưởng mộc (Chỉ cần chạy 1 lần)
1. Ở thanh công cụ trên cùng của Apps Script, cạnh nút "Gỡ lỗi", chọn hàm **`setupSheet`**.
2. Bấm nút **Chạy** (Run).
3. Google sẽ hiện hộp thoại yêu cầu cấp quyền:
   - Bấm **Xem lại quyền** (Review permissions) ➔ Chọn tài khoản Google của bạn.
   - Bấm **Nâng cao** (Advanced) ➔ Bấm **Đi tới Dự án không có tiêu đề (không an toàn)** *(đây là cảnh báo tiêu chuẩn vì script do bạn tự viết)*.
   - Bấm **Cho phép** (Allow).
4. Quay lại Google Sheet, bạn sẽ thấy:
   - ✅ Dòng 1 biến thành Header màu nâu gỗ Óc chó (`#2C1E16`), chữ trắng in đậm sang trọng.
   - ✅ Cột **Trạng thái xử lý (H)** có sẵn Dropdown chọn nhanh: `Mới nhận`, `Đã liên hệ`, `Đang tư vấn`, `Đã chốt`, `Chưa có nhu cầu`.
   - ✅ Cột **Số điện thoại (D)** được định dạng Text chuẩn để không bao giờ bị mất số 0 ở đầu.
   - ✅ Cột được căn chỉnh độ rộng vừa vặn, dòng 1 được cố định khi cuộn.

### Bước 4: Triển khai ứng dụng Web (Deploy Web App)
1. Ở góc trên bên phải màn hình Apps Script, bấm nút xanh **Triển khai** (Deploy) ➔ Chọn **Quản lý bản triển khai mới** (New deployment).
2. Nhấn vào biểu tượng bánh răng ⚙️ (Chọn loại) ➔ Chọn **Ứng dụng web** (Web app).
3. Điền các trường như sau:
   - **Mô tả**: `Webhook Web Duân Hồng`
   - **Thực thi dưới dạng** (Execute as): **Tôi (địa chỉ email của bạn)**
   - **Người có quyền truy cập** (Who has access): **Bất kỳ ai (Anyone)** *(BẮT BUỘC chọn mục này để website có thể gửi dữ liệu vào mà không bị chặn đăng nhập)*.
4. Bấm **Triển khai** (Deploy).
5. Sau khi triển khai xong, copy đường dẫn ở mục **URL của ứng dụng web** (Web app URL).
   - Đường dẫn có dạng: `https://script.google.com/macros/s/AKfycb.../exec`

### Bước 5: Gắn link vào hệ thống
Mở file `server/.env` và thêm dòng sau:
```env
GOOGLE_APPS_SCRIPT_URL=https://script.google.com/macros/s/AKfycb.../exec
```

Khởi động lại server backend:
```bash
cd server
node --env-file=.env src/server.js
```
Từ lúc này, mọi yêu cầu đặt lịch hẹn hoặc tư vấn trên website sẽ được chuyển thẳng về trang tính Google Sheet của xưởng trong tích tắc!

---

## 3. Tùy chọn: Gửi thẳng từ Web tĩnh (Không cần Backend Server)

Nếu sau này bạn xuất bản website lên các hosting tĩnh miễn phí như GitHub Pages, Netlify, Cloudflare Pages mà không bật server Node.js:
Trong file `design/ui.js`, bạn chỉ cần cấu hình đường dẫn `appsScriptUrl`:
```javascript
const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycb.../exec";

// Gửi thẳng sang Google Apps Script:
fetch(APPS_SCRIPT_URL, {
  method: "POST",
  mode: "no-cors",
  headers: { "Content-Type": "text/plain" },
  body: JSON.stringify(leadData)
});
```
Form sẽ hoạt động 100% độc lập, không tốn bất kỳ chi phí duy trì máy chủ nào!

---

## 4. Kiểm tra & Giám sát

Hệ thống đã có sẵn bộ kiểm thử tự động cho cơ chế Apps Script:
```bash
cd server
node test/apps-script.test.js
```
Kết quả kiểm thử: **12 PASS / 0 FAIL**.
