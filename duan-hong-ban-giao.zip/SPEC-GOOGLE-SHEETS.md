# SPEC — Đồng bộ lead website Duân Hồng sang Google Sheets

Phiên bản: 2026-11-13 · Giai đoạn 2 · Trạng thái: **đã có mã + test, CHƯA bật production**

Tài liệu mô tả đúng những gì đang có trong `server/src/sheets/`, cách cấu hình credential,
cách chạy test, cách đồng bộ lại lead lỗi, và những câu hỏi **phải** được chủ xưởng trả lời
trước khi bật đồng bộ thật.

> Chưa có credential Google thật trong dự án. Mọi bằng chứng hiện tại đến từ Google giả lập
> (HTTP server cục bộ trong test). Chưa có lần nào gọi `sheets.googleapis.com` thật.

---

## 1. Phạm vi và file mã nguồn

| File | Việc |
|---|---|
| `server/src/sheets/config.js` | Đọc credential từ biến môi trường / file ngoài repo, kiểm tra, che secret khi trả ra API |
| `server/src/sheets/client.js` | Ký JWT RS256, đổi access token, gọi Sheets API bằng `fetch` + `node:crypto` (không thêm thư viện) |
| `server/src/sheets/sync.js` | Dựng 11 ô dữ liệu, chống nhân bản, ghi trạng thái, `resync`, `resumePending` |
| `server/src/sheets/queue.js` | Hàng đợi retry trong tiến trình: mỗi lead tối đa 1 job chờ + 1 job chạy |
| `server/src/sheets/index.js` | Điểm vào duy nhất của module (`sync` + `queue` + `client` + `config`) |
| `server/src/db.js` | Migration idempotent thêm 5 cột Sheets vào bảng `leads` |
| `server/src/app.js` | `POST /api/leads` (chống gửi trùng) + 2 endpoint quản trị Sheets |
| `server/src/server.js` | Khi khởi động: `resumePending(50)`; khi SIGINT/SIGTERM: `queue.clear()` |
| `server/test/sheets-sync.test.js` | 61 kiểm tra với Google giả lập |

---

## 2. Luồng dữ liệu

```text
Form (design/*.html + design/ui.js)
        │  POST /api/leads  {name, phone, area, need}
        ▼
server/src/app.js
        ├─ validate: tên 2..80 ký tự, SĐT đúng định dạng VN, area ≤120, need ≤800  → sai: 400
        ├─ rate limit theo IP (RATE_LEAD, mặc định 5/giờ) → vượt: 429
        ├─ chống gửi trùng: cùng phone_hash + cùng tên trong LEAD_DEDUPE_MINUTES (15)
        │        └─ trùng → 200 {duplicate:true, data.code = mã cũ}, KHÔNG tạo lead, KHÔNG thêm dòng
        ├─ INSERT INTO leads (...)  ← SQLite là nguồn sự thật
        ├─ trả 201 {data:{code}} NGAY, không chờ Google
        └─ sheets.notifyLeadCreated(lead)
                 │  (không bao giờ ném lỗi ra ngoài)
                 ▼
        queue.enqueue(leadId, 0)   ← hàng đợi RAM, setTimeout().unref()
                 ▼
        sync.syncLeadById(leadId)
          ├─ lead không tồn tại → {ok:false, error:"LEAD_NOT_FOUND"}
          ├─ đã sent + có sheets_row → bỏ qua, không gọi Google
          ├─ thiếu cấu hình → markFailed("Chưa cấu hình Google Sheets: …")
          ├─ có sheets_row            → PUT  '<tab>'!A{row}:G{row}
          ├─ chưa có sheets_row:
          │     GET '<tab>'!B2:B  tìm mã lead
          │        ├─ thấy  → PUT  '<tab>'!A{row}:G{row}
          │        └─ không → POST '<tab>'!A:K:append  (RAW, INSERT_ROWS)
          │                   đọc updates.updatedRange để lấy số dòng thật
          ├─ thành công → sheets_status='sent', sheets_row=<n>,
          │               sheets_error='', sheets_synced_at=datetime('now'),
          │               sync_attempts+1
          └─ lỗi → sheets_status='failed', sheets_error=<≤500 ký tự>,
                   sync_attempts+1, hẹn lại nếu chưa chạm SHEETS_MAX_ATTEMPTS
```

Điểm bất biến (đều có test canh):

1. **Chỉ backend gọi Google.** Frontend không giữ, không thấy credential.
2. **SQLite là nguồn sự thật.** Google lỗi — kể cả lỗi kéo dài — không làm mất lead.
3. **Chỉ ghi `sent` sau khi Google xác nhận.** Không có nhánh nào đặt `sent` trước.
4. **Không hứa với khách là đã lên Sheet.** Response `POST /api/leads` chỉ có mã yêu cầu.
5. **Khoá idempotency là `code`** (cột B), không phải số dòng.
6. **Cập nhật dòng đã có chỉ ghi A–G**, không đè cột H–K do xưởng nhập tay.

---

## 3. 11 cột trên Google Sheet

Tab mặc định: **`Khách hàng`** (`GOOGLE_SHEETS_TAB`). Dòng 1 là tiêu đề **do xưởng tạo tay**;
hệ thống không ghi dòng tiêu đề, chỉ ghi từ dòng 2 trở xuống.

Thứ tự này chính là hằng `SHEET_HEADERS` trong `server/src/sheets/sync.js` (dòng 19–31) và
là thứ tự ô do `buildRow()` dựng ra (dòng 97–111):

| Cột | Tiêu đề (đúng nguyên văn) | Nguồn dữ liệu | Ai ghi |
|---|---|---|---|
| A | `Thời gian gửi` | `leads.created_at` (UTC trong SQLite) → đổi sang giờ VN `DD/MM/YYYY HH:mm` | Hệ thống |
| B | `Mã yêu cầu` | `leads.code` dạng `LH-XXXXXX` — **khoá chống trùng** | Hệ thống |
| C | `Họ và tên` | `leads.name` | Hệ thống |
| D | `Số điện thoại` | `leads.phone` — ghi `RAW` để giữ dạng text | Hệ thống |
| E | `Khu vực / địa chỉ` | `leads.area` | Hệ thống |
| F | `Nhu cầu / nội dung` | `leads.need` | Hệ thống |
| G | `Nguồn` | `leads.source` (mặc định `website`) | Hệ thống |
| H | `Trạng thái xử lý` | `leads.status` dịch sang tiếng Việt: `Mới`, `Đã gọi`, `Đã đo`, `Đã báo giá`, `Chốt`, `Không chốt` | Hệ thống ghi lần đầu, **xưởng sửa sau** |
| I | `Người phụ trách` | — (hệ thống luôn ghi chuỗi rỗng khi tạo) | **Xưởng** |
| J | `Ghi chú` | `leads.note` (thường rỗng) | Hệ thống ghi lần đầu, xưởng sửa sau |
| K | `Thời gian liên hệ gần nhất` | — (hệ thống luôn ghi chuỗi rỗng khi tạo) | **Xưởng** |

Quy tắc vàng: `updateRow()` chỉ gửi 7 ô (`values.slice(0, 7)`) vào range `A{row}:G{row}`.
**H–K là vùng tay của xưởng, không bị ghi đè** — test ca 5 kiểm đúng việc này.

Định dạng phải đặt tay trong Google Sheet (làm một lần):

- Cột D: định dạng **Plain text**, nếu không `0901234567` sẽ bị đổi thành số và mất số 0 đầu.
- Cố định hàng 1 (View → Freeze → 1 row) và bật bộ lọc.
- Chia sẻ chế độ **hạn chế**; chỉ service account + người của xưởng, không "ai có link cũng xem".

---

## 4. Trạng thái đồng bộ trong SQLite

5 cột được thêm vào `leads` bằng migration idempotent (`db.js` dòng 163–181): chỉ `ALTER TABLE`
khi cột còn thiếu, chạy lại bao nhiêu lần cũng an toàn, **không xoá dữ liệu cũ**.

| Cột | Kiểu | Ý nghĩa |
|---|---|---|
| `sheets_status` | TEXT, mặc định `pending` | `pending` = chờ gửi · `sent` = Google đã xác nhận · `failed` = lỗi, chờ xử lý |
| `sheets_row` | INTEGER | Số dòng thật trên Sheet, dùng để `PUT` thay vì append |
| `sheets_error` | TEXT, mặc định `''` | Lỗi gần nhất, cắt còn 500 ký tự; rỗng khi thành công |
| `sheets_synced_at` | TEXT | Thời điểm ghi thành công gần nhất (UTC) |
| `sync_attempts` | INTEGER, mặc định 0 | Số lần đã gọi Google cho lead này |

Có thêm index `idx_leads_sheets ON leads(sheets_status)`.

---

## 5. Chống nhân bản và chống gửi trùng

### 5.1 Retry không sinh dòng thứ hai

1. Đã có `sheets_row` → `PUT` đúng dòng đó.
2. Chưa có `sheets_row` (DB mất cột, tiến trình chết giữa đường, append xong nhưng mất response)
   → đọc `B2:B` tìm mã; thấy → `PUT`; không thấy → `POST :append`.
3. Chỉ lưu `sheets_row` sau khi Google trả `updatedRange`; nếu Google nhận lệnh nhưng không trả
   `updatedRange` thì ném `APPEND_NO_RANGE` và **không** đánh dấu `sent`.

Nhờ vậy append bị mất response vẫn không tạo dòng thứ hai.

### 5.2 Chống double submit từ phía khách

Trong `app.js` (dòng 279–299): cùng `phone_hash` **và** cùng họ tên (đã chuẩn hoá khoảng trắng/
hoa thường) trong `LEAD_DEDUPE_MINUTES` (mặc định 15 phút) → trả **200** kèm `duplicate: true`
và mã cũ; không tạo lead, không thêm dòng Sheet. Nếu lead cũ **chưa** `sent` thì nhân dịp này
đẩy lại vào hàng đợi.

Cùng số điện thoại nhưng **khác tên** → vẫn tạo lead mới (người nhà dùng chung số).

---

## 6. Hàng đợi và giới hạn thử lại

`server/src/sheets/queue.js`:

- Mỗi lead tối đa **một** job chờ và **một** job đang chạy → bấm gửi lại nhiều lần không sinh job trùng.
- Lỗi lần thứ *n* → hẹn lại sau `SHEETS_RETRY_BASE_MS × 2^(n-1)` (mặc định 5s, 10s, 20s…).
- Dừng khi `sync_attempts >= SHEETS_MAX_ATTEMPTS` (mặc định 3) → giữ `failed`, chờ quản trị.
- Timer `unref()` → hàng đợi không giữ tiến trình sống khi tắt máy chủ.
- Khởi động lại: `resumePending(50)` chỉ đưa lead `pending` trở lại hàng đợi (bù lần tắt máy giữa
  lúc gửi). **Không** tự retry `failed` để tránh vòng lặp vô hạn.
- Hàng đợi nằm trong RAM và **không lưu lead**; mất lịch hẹn không mất dữ liệu.

---

## 7. Biến môi trường

Thứ tự ưu tiên credential: `GOOGLE_SHEETS_ACCESS_TOKEN` → `GOOGLE_SHEETS_CREDENTIALS_FILE`
(hoặc `GOOGLE_APPLICATION_CREDENTIALS`) → `GOOGLE_SHEETS_CREDENTIALS_JSON`.

| Biến | Bắt buộc | Mặc định | Ghi chú |
|---|---|---|---|
| `GOOGLE_SHEETS_SPREADSHEET_ID` | ✔ | — | Thiếu → lead vẫn lưu, `failed` kèm lý do |
| `GOOGLE_SHEETS_CREDENTIALS_FILE` | ✔* | — | Đường dẫn file JSON service account, **ngoài repo** |
| `GOOGLE_APPLICATION_CREDENTIALS` | ✔* | — | Tên chuẩn của Google, dùng khi biến trên trống |
| `GOOGLE_SHEETS_CREDENTIALS_JSON` | ✔* | — | Nội dung JSON qua biến môi trường (cho secret manager) |
| `GOOGLE_SHEETS_ACCESS_TOKEN` | — | — | **Chỉ thử cục bộ**, token sống ~1 giờ; bị cảnh báo trong status |
| `GOOGLE_SHEETS_TAB` | — | `Khách hàng` | Tên tab; có dấu cách/dấu tiếng Việt được bọc nháy đơn trong A1 |
| `GOOGLE_SHEETS_API_BASE` | — | `https://sheets.googleapis.com` | Chỉ đổi khi test |
| `GOOGLE_OAUTH_TOKEN_URL` | — | `https://oauth2.googleapis.com/token` | Chỉ đổi khi test |
| `SHEETS_TIMEOUT_MS` | — | `8000` | Timeout mỗi request; kẹp trong 500–60000 |
| `SHEETS_MAX_ATTEMPTS` | — | `3` | Số lần thử tối đa mỗi lead; kẹp trong 1–10 |
| `SHEETS_RETRY_BASE_MS` | — | `5000` | Chờ cơ sở giữa các lần thử; kẹp trong 10–300000 |
| `SHEETS_SYNC` | — | bật | Đặt `off` để tắt đồng bộ hoàn toàn (lead vẫn lưu SQLite, `failed`) |

\* cần đúng một trong ba cách cung cấp credential.

Ngoài ra endpoint quản trị cần **`ADMIN_TOKEN`** (không có token này thì `/api/admin/*` trả 503;
sai token trả 401).

Scope xin cấp: **`https://www.googleapis.com/auth/spreadsheets`** — chỉ Sheets, không Drive, không Gmail.
Access token được cache trong RAM (`expires_in - 60s`), không ghi token ra đĩa.
`/api/admin/sheets/status` chỉ trả `spreadsheetId` **đã che** (`1AbC…6789`) và **không bao giờ**
trả `private_key` hay access token (có test canh).

### 7.1 Phía Google (làm một lần)

1. Google Cloud Console → tạo/chọn project → bật **Google Sheets API**.
2. Tạo **Service Account** → tạo **khoá JSON** và tải về.
3. Mở Sheet → **Share** → dán email `...@....iam.gserviceaccount.com` → **Editor**, bỏ "Notify people".
4. Ghi lại **Spreadsheet ID**: phần giữa `/d/` và `/edit` trong URL.

### 7.2 Phía máy chủ

Đặt file JSON **ngoài thư mục dự án** (ví dụ `/etc/duanhong/google-sheets.json`), quyền `600`,
chủ sở hữu là user chạy service. Không commit, không dán vào chat, không chụp ảnh màn hình.

```bash
export GOOGLE_SHEETS_SPREADSHEET_ID="<id sheet>"
export GOOGLE_SHEETS_TAB="Khách hàng"
export GOOGLE_SHEETS_CREDENTIALS_FILE="/etc/duanhong/google-sheets.json"
node server/src/server.js
```

Nếu file credential nằm trong thư mục dự án, hệ thống **vẫn chạy** nhưng gắn cảnh báo vào
`/api/admin/sheets/status` (`warnings`) để nhắc chuyển ra ngoài.

---

## 8. Cách chạy test

Test dùng **Google giả lập**: một HTTP server cục bộ vừa đóng vai token endpoint (xác thực chữ ký
JWT RS256 bằng public key) vừa đóng vai Sheets API (lưu dữ liệu trong RAM). Backend thật được spawn
ở cổng riêng, database tạm trong thư mục temp, khoá RSA sinh ngay trong lúc chạy.
**Không cần credential thật, không gọi mạng ra ngoài.**

Cổng đang dùng — phải trống trước khi chạy: `5098` (server có credential), `5096` (server thiếu
credential, DB schema cũ), `5097` (Google giả lập). Yêu cầu Node ≥ 22.5 (`node:sqlite`);
đã chạy được trên Node v24.21.0.

```bash
cd C:/Users/DELL/Documents/qa-web-ban-hang
node server/test/sheets-sync.test.js        # foreground, ~5–10 giây
# hoặc
cd server && npm run test:sheets
```

Chạy **foreground**. Chạy nền trong Git Bash sẽ in `stdin is not a tty` và không thực thi.
Test tự `process.exit(fail ? 1 : 0)`; giữ thư mục temp khi có FAIL để điều tra.

### Kết quả thật lần chạy 2026-11-13 (3 lần liên tiếp, cùng kết quả)

```
KẾT QUẢ: 61 PASS / 0 FAIL trên 61 kiểm tra
Bằng chứng phụ: Sheet giả lập có 16 dòng (1 tiêu đề + 15 dữ liệu)
append=15 update=1 read=16 token=1
```

Đã từng có 1 ca FAIL (`admin resync nhận lệnh`) và **đã sửa**: `resync` trước đây trả `queued: 0`
khi lead đã có job retry đang hẹn sẵn, dù lead vẫn sẽ được đẩy đi. Nay `queue.isQueued(lead.id)`
được dùng để tính cả job đang chờ/đang chạy là "đã xếp hàng", nên phản hồi khớp thực tế:

```
KẾT QUẢ: 61 PASS / 0 FAIL trên 61 kiểm tra
PASS  admin resync nhận lệnh (200, queued=1)
```

Các nhóm đã kiểm (61 ca PASS):

1. Migration: DB mới đủ 5 cột; DB cũ (schema trước Giai đoạn 2) được thêm cột, **lead cũ còn nguyên**,
   nhận `sheets_status='pending'`.
2. Lead hợp lệ → đúng 1 dòng Sheet, `sent`, `sheets_row` khớp, đúng cột A–G, giờ VN `DD/MM/YYYY HH:mm`,
   SĐT giữ dạng text, nguồn `website`, trạng thái `Mới`.
3. JWT: đúng `iss`/`scope`/`aud`; mock xác thực chữ ký RS256 rồi mới cấp token; token cache (chỉ 1 lần gọi).
4. Google 503 → lead còn trong SQLite, `failed`, `sheets_error` ghi HTTP 503, Sheet không thêm dòng.
5. Retry → `sent`, Sheet không nhân bản.
6. Mất `sheets_row` rồi đồng bộ lại → tìm lại dòng theo mã, không thêm dòng, **không ghi đè cột H/I xưởng đã sửa**.
7. 10 lead liên tiếp → 10 mã khác nhau, 10 dòng, không mã lặp.
8. Double submit → 200 + `duplicate:true` + mã cũ, không thêm lead, không thêm dòng.
9. Cùng SĐT khác tên → tạo lead mới.
10. Tên/nhu cầu chứa HTML → lưu nguyên văn, không escape; chuỗi `'); DROP TABLE leads;--` không phá bảng.
11. SĐT sai → 400, không ghi DB, không ghi Sheet.
12. Retry có giới hạn: dừng đúng số lần, không thử vô hạn, lead còn trong SQLite.
13. Admin status: 401 khi không token; không lộ private key/token; lead đã `sent` không bị gọi Google lại
    (`ALREADY_SENT`).
14. Thiếu credential: vẫn 201 cho khách, lead `failed`, `sheets_error` nói rõ thiếu gì, không có request nào tới Google.
15. Access token chỉ lấy một lần (cache hoạt động).

Chạy lại bộ test API cũ để chắc không hồi quy: `node server/test/api.test.js`.

Test **không** chứng minh được: hành vi thật của `sheets.googleapis.com` (quota, parse range thật,
cách Sheet thật hiển thị số điện thoại). Phải thử có kiểm soát trên Sheet nháp trước khi bật production.

---

## 9. Cách đồng bộ lại lead lỗi

Hai endpoint, đều cần `Authorization: Bearer $ADMIN_TOKEN` (`/api/admin/*` trả 503 nếu máy chủ
chưa đặt `ADMIN_TOKEN`, 401 nếu sai token). Không in token ra log/chat.

### 9.1 Xem tình hình trước

```bash
curl -s http://127.0.0.1:5055/api/admin/sheets/status \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

Trả về: `configured`, `reason` (vì sao chưa cấu hình), `missing[]`, `mode`
(`service-account` | `static-token` | `none`), `tab`, `spreadsheetId` đã che, `clientEmail`,
`warnings[]`, `queue {pending, running, maxAttempts, retryBaseMs}`, `counts {pending, sent, failed}`,
`headers` (11 tiêu đề). Không chứa secret.

### 9.2 Đồng bộ lại một lead

```bash
curl -s -X POST http://127.0.0.1:5055/api/admin/sheets/resync \
  -H "Authorization: Bearer $ADMIN_TOKEN" -H "Content-Type: application/json" \
  -d '{"leadId": 12}'
```

- Lead `failed`/`pending` → đặt `pending`, xoá `sheets_error`, đưa vào hàng đợi.
- Lead đã `sent` → trả `{"queued":0,"reason":"ALREADY_SENT","ids":[]}`, **không** gọi Google.
  Muốn cưỡng bức: thêm `"force": true`.
- `leadId` không phải số nguyên dương → 400. Không tồn tại → `reason:"LEAD_NOT_FOUND"`.

### 9.3 Đồng bộ lại hàng loạt

```bash
# tối đa 50 lead đang failed (mặc định)
curl -s -X POST http://127.0.0.1:5055/api/admin/sheets/resync \
  -H "Authorization: Bearer $ADMIN_TOKEN" -H "Content-Type: application/json" \
  -d '{"status":"failed","limit":50}'
```

- `status` chỉ nhận `pending` hoặc `failed`; giá trị khác bị coi là `failed`.
- `limit` mặc định 50, kẹp trong 1–200.
- Trả `{queued, configured, reason, ids[]}` — `queued` là số job được xác nhận **đang xếp hàng**,
  tính cả job retry đã hẹn sẵn (không chỉ job tạo mới).

### 9.4 Lưu ý khi đọc kết quả resync

`queued: 0` nghĩa là **không có lead nào được xếp hàng** — thường vì không còn lead ở trạng thái
yêu cầu (`reason` cho biết `LEAD_NOT_FOUND` / `ALREADY_SENT`), hoặc vì chưa cấu hình Google
(`configured: false`). Lead đã có job retry đang hẹn sẵn vẫn được tính vào `queued`
(nhờ `queue.isQueued()`), nên không còn trường hợp "báo 0 nhưng vẫn đang chờ". Muốn chắc chắn,
kiểm lại bằng `status` (`counts.failed`) hoặc đọc `sheets_status` của lead sau 10–20 giây.

Nếu lead kẹt `failed` mà resync không đẩy được, kiểm theo thứ tự:

1. `status.configured` = `false`? → xem `reason` + `missing[]`, sửa biến môi trường rồi khởi động lại.
2. `sheets_error` trong SQLite: 401/403 (chưa share Sheet cho service account), 404 (sai
   Spreadsheet ID), 400 "Unable to parse range" (sai tên tab), timeout (`SHEETS_TIMEOUT_MS`).
3. Đã chạm `SHEETS_MAX_ATTEMPTS` → resync là cách duy nhất để thử tiếp (hệ thống không tự retry `failed`).
4. File credential hỏng/không đọc được → `Không đọc được file credential Google Sheets (ENOENT)`.

Đọc trạng thái trực tiếp trong SQLite khi cần (chỉ đọc, không sửa tay khi production đang chạy):

```bash
node -e "const{DatabaseSync}=require('node:sqlite');const d=new DatabaseSync('server/data/duanhong.db',{readOnly:true});console.table(d.prepare(\"SELECT id,code,sheets_status,sheets_row,sync_attempts,substr(sheets_error,1,80) e FROM leads WHERE sheets_status<>'sent' ORDER BY id DESC LIMIT 20\").all())"
```

---

## 10. Câu hỏi chủ xưởng phải trả lời trước khi bật production

1. **Sheet nào là sheet thật?** Tên file, tên tab, và email Google của chủ sở hữu?
2. **Có đồng ý cấp quyền Editor cho service account** vào đúng sheet đó không? Ai khác được xem/sửa
   (thợ cả, kế toán, người ngoài)?
3. **Ai điền cột "Người phụ trách"**, và quy trình đổi "Trạng thái xử lý" ra sao (ai được đổi, đổi khi nào)?
4. **Lưu dữ liệu lead bao lâu?** Sau bao lâu thì xoá/ẩn thông tin khách? Xoá cả trên Sheet hay chỉ trong SQLite?
5. Khách có cần được **thông báo là thông tin được lưu trên Google Sheets** không? (form hiện chưa có
   dòng thông báo riêng tư — cần câu chữ do chủ xưởng duyệt)
6. **15 phút chống gửi trùng** (cùng SĐT + cùng tên) có đúng nghiệp vụ không? Có trường hợp khách gửi
   hai yêu cầu khác nhau trong 15 phút mà xưởng vẫn cần thấy cả hai không?
7. **Giờ trên Sheet để giờ Việt Nam (UTC+7)** đúng chưa? Có cần thêm cột giờ UTC để đối chiếu?
8. **Số điện thoại** hiển thị đúng như khách nhập (`0901234567`) hay cần chuẩn hoá `+84…`?
9. Có cần thêm cột nghiệp vụ: **sản phẩm quan tâm, ngân sách dự kiến, kênh quảng cáo/UTM,
   hẹn giờ gọi lại**? (mỗi cột thêm phải sửa `SHEET_HEADERS`, `buildRow`, range `A:K` và test)
10. **Khi Google lỗi kéo dài, ai được báo và bằng cách nào?** Hiện chỉ có log máy chủ và
    `/api/admin/sheets/status`; chưa có email/Zalo/SMS cảnh báo. Có cần làm không?
11. Có cần **báo cho thợ cả mỗi khi có lead mới** (Zalo/SMS/Telegram) hay chỉ xem Sheet?
12. **Ai được xuất/tải sheet ra ngoài**, và có yêu cầu sao lưu sheet (hằng tuần/hằng tháng) không?
13. Sheet có cần **ẩn/xoá dữ liệu test** trước khi bật thật? Ai duyệt lần ghi thử đầu tiên?
14. Chấp nhận rằng **backend giữ quyền ghi vào Sheet** (máy chủ bị chiếm thì kẻ tấn công ghi được
    vào sheet) hay muốn giới hạn thêm theo IP/hạ tầng?
15. **Ai là người bấm "đồng bộ lại"** khi có lead `failed`, và dùng cách nào (curl/Postman) khi chưa có UI?

---

## 11. Checklist trước khi bật production

- [ ] Chủ xưởng trả lời đủ 15 câu ở mục 10.
- [ ] Đã tạo Sheet thật với đúng 11 tiêu đề ở mục 3, cột D là Plain text, cố định hàng 1, bật bộ lọc.
- [ ] Đã share Sheet cho service account (Editor), không public.
- [ ] File credential ngoài repo, quyền `600`, không nằm trong `qa-web-ban-hang`.
- [ ] `ADMIN_TOKEN` dài ngẫu nhiên (`openssl rand -hex 32`); `ALLOWED_ORIGINS` chỉ domain thật.
- [ ] Chạy `node server/test/sheets-sync.test.js` trên máy chủ đích và xác nhận **61/61 PASS**
      trước khi coi test là cổng chặn.
- [ ] Gửi **một** lead thử bằng tay → đọc lại SQLite **và** mở Sheet: đúng một dòng, đúng cột,
      số điện thoại không mất số 0 đầu.
- [ ] Đánh dấu lead thử (`TEST`) hoặc xoá theo quy trình đã thống nhất.
- [ ] Thử một lỗi có kiểm soát (đổi tạm Spreadsheet ID sai) → thấy `failed` + `sheets_error`, lead vẫn còn;
      trả lại ID đúng rồi `resync`.
- [ ] Log máy chủ có dòng `[sheets] LH-… → dòng N (đã đồng bộ)`.
- [ ] Chốt lịch xem `/api/admin/sheets/status` hằng ngày trong tuần đầu.

---

## 12. Giới hạn đã biết

- **Chưa gọi Google thật lần nào.** Toàn bộ bằng chứng là Google giả lập; chưa xác minh quota,
  parse range thật, hay cách Sheet thật hiển thị số điện thoại.
- **Chưa có UI quản trị.** Đồng bộ lại phải gọi API bằng curl/Postman.
- **Hàng đợi trong RAM.** Thiết kế chỉ đúng cho **một** tiến trình; chạy nhiều instance sẽ tranh nhau
  ghi, phải thay bằng hàng đợi ngoài (Redis/DB).
- **Một tab, một sheet.** Chưa hỗ trợ nhiều sheet theo chi nhánh/khu vực.
- **Chỉ một chiều DB → Sheet.** Cột H–K xưởng sửa tay không được đọc ngược về SQLite.
- **Múi giờ cố định UTC+7** trong `formatVnTime()`; có chi nhánh khác múi giờ phải sửa.
- **SQLite chưa mã hoá.** Dữ liệu khách nằm dạng thô trong `server/data/duanhong.db`.
