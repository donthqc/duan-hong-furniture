"use strict";
/**
 * Quản lý ảnh: quét design/assets/img, sinh manifest.json + báo cáo thiếu ảnh.
 *
 *   node tools/photos.js            # quét và sinh manifest
 *   node tools/photos.js --check    # chỉ báo cáo, không ghi
 *
 * Quy ước tên file (đuôi .webp / .jpg / .jpeg / .png đều được):
 *   hero-workshop         ảnh lớn đầu trang chủ
 *   step-1 .. step-5      ảnh 5 công đoạn
 *   project-1 .. project-5 ảnh công trình
 *   product-<slug>        ảnh đại diện sản phẩm (sofa-go-do, an-gian-tho, ...)
 *   product-<slug>-2..-4  ảnh phụ cho gallery PDP
 *   order-latest          ảnh cập nhật mới nhất ở trang tra cứu
 */
const fs = require("node:fs");
const path = require("node:path");

// Hỗ trợ 2 vị trí: repo gốc (tools/photos.js) và trong gói bàn giao (04-website/_tools/photos.js)
const HERE = __dirname;
const isInBundle = path.basename(HERE) === "_tools";
const ROOT = isInBundle ? path.join(HERE, "..") : path.join(HERE, "..", "design");
const IMG_DIR = path.join(ROOT, "assets", "img");
const MANIFEST = path.join(IMG_DIR, "manifest.json");
const EXTS = [".webp", ".jpg", ".jpeg", ".png", ".avif"];

const checkOnly = process.argv.includes("--check");

fs.mkdirSync(IMG_DIR, { recursive: true });

const files = fs.readdirSync(IMG_DIR).filter((f) => EXTS.includes(path.extname(f).toLowerCase()));
const byKey = {};
for (const f of files) {
  const key = path.basename(f, path.extname(f)).toLowerCase();
  // ưu tiên webp > avif > jpg > png
  const rank = { ".webp": 1, ".avif": 2, ".jpg": 3, ".jpeg": 4, ".png": 5 };
  const ext = path.extname(f).toLowerCase();
  if (!byKey[key] || rank[ext] < rank[byKey[key].ext]) {
    byKey[key] = { file: f, ext };
  }
}

/* Danh sách ảnh website cần — khớp với data-photo trong HTML */
const PRODUCT_SLUGS = [
  "sofa-go-do", "an-gian-tho", "combo-phong-ngu",
  "ban-an-live-edge", "tu-bep-mdf", "tu-quan-ao-soi",
];
const REQUIRED = [
  "hero-workshop",
  ...Array.from({ length: 5 }, (_, i) => `step-${i + 1}`),
  ...Array.from({ length: 5 }, (_, i) => `project-${i + 1}`),
  ...PRODUCT_SLUGS.map((s) => `product-${s}`),
  "order-latest",
];
const OPTIONAL = PRODUCT_SLUGS.flatMap((s) => [2, 3, 4].map((n) => `product-${s}-${n}`));

const manifest = {};
for (const [key, v] of Object.entries(byKey)) {
  manifest[key] = { src: "assets/img/" + v.file };
}

const missing = REQUIRED.filter((k) => !byKey[k]);
const present = REQUIRED.filter((k) => byKey[k]);
const extra = Object.keys(byKey).filter((k) => !REQUIRED.includes(k) && !OPTIONAL.includes(k));

if (!checkOnly) {
  fs.writeFileSync(MANIFEST, JSON.stringify(manifest, null, 2) + "\n", "utf8");
}

const pct = Math.round((present.length / REQUIRED.length) * 100);
console.log("Thư mục ảnh : " + IMG_DIR);
console.log(`Đã có       : ${present.length}/${REQUIRED.length} ảnh bắt buộc (${pct}%)`);
if (present.length) console.log("  ✓ " + present.join(", "));
if (missing.length) console.log("  ✗ thiếu: " + missing.join(", "));
if (extra.length) console.log("  ? không dùng trong HTML: " + extra.join(", "));
console.log(checkOnly ? "\n(chỉ kiểm tra, không ghi manifest)" : "\nĐã ghi: " + MANIFEST);
if (missing.length) process.exitCode = 2;
