// Kiểm chứng vận hành khi CHƯA có credential Google: lead vẫn phải được lưu,
// trạng thái phải là failed kèm lý do, admin API phải fail closed và không lộ secret.
const http = require("node:http");
const { DatabaseSync } = require("node:sqlite");
const path = require("node:path");

const DB = path.join(process.env.LOCALAPPDATA, "Temp", "dh-regress.db");
const req = (method, p, body, token) => new Promise((resolve) => {
  const data = body ? JSON.stringify(body) : null;
  const r = http.request(
    { host: "127.0.0.1", port: 5055, path: p, method,
      headers: { ...(data ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data) } : {}),
                 ...(token ? { Authorization: "Bearer " + token } : {}) } },
    (res) => { let d = ""; res.on("data", c => d += c); res.on("end", () => {
      let j = null; try { j = JSON.parse(d); } catch {}
      resolve({ status: res.statusCode, body: j, raw: d });
    }); });
  r.on("error", e => resolve({ status: 0, body: null, raw: e.message }));
  if (data) r.write(data);
  r.end();
});

(async () => {
  const phone = "09" + String(Date.now()).slice(-8);
  const created = await req("POST", "/api/leads", { name: "QA Kiểm Sheets", phone, need: "Kiểm tra chưa có credential" });
  console.log("1) POST /api/leads →", created.status, JSON.stringify(created.body?.data || created.body).slice(0, 140));
  const code = created.body?.data?.code || created.body?.code;

  await new Promise(r => setTimeout(r, 1200)); // chờ worker thử đồng bộ
  const d = new DatabaseSync(DB, { readOnly: true });
  const row = d.prepare("SELECT code,name,sheets_status,sheets_row,sheets_error,sync_attempts FROM leads WHERE code = ?").get(code);
  console.log("2) dòng trong SQLite →", JSON.stringify(row));
  console.log("   lead KHÔNG mất:", !!row, "· trạng thái:", row && row.sheets_status,
              "· có lý do lỗi:", !!(row && row.sheets_error));

  const noTok = await req("GET", "/api/admin/sheets/status");
  const tok = await req("GET", "/api/admin/sheets/status", null, "local-admin-token");
  console.log("3) admin/status không token →", noTok.status);
  console.log("   admin/status có token   →", tok.status, JSON.stringify(tok.body?.data));
  const leak = /private_key|BEGIN PRIVATE|client_secret|ya29\./i.test(tok.raw);
  console.log("   lộ secret trong response:", leak);

  const resync = await req("POST", "/api/admin/sheets/resync", { codes: [code] }, "local-admin-token");
  console.log("4) resync khi chưa cấu hình →", resync.status, JSON.stringify(resync.body?.data || resync.body).slice(0, 160));

  const d2 = new DatabaseSync(DB, { readOnly: true });
  const after = d2.prepare("SELECT sheets_status,sync_attempts FROM leads WHERE code = ?").get(code);
  console.log("5) sau resync →", JSON.stringify(after));
})();
