# -*- coding: utf-8 -*-
"""
Sinh 2 ảnh OG banner 1200x630 cho website Duân Hồng.
    python tools/make_og.py
Yêu cầu: Pillow (đã cài trong C:\\Python314).
"""
import os
from PIL import Image, ImageDraw, ImageFont

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "design", "assets")
os.makedirs(OUT, exist_ok=True)

W, H = 1200, 630
BG = (23, 12, 6)          # #170c06 nền gỗ
GOLD = (214, 163, 84)     # #d6a354 vàng kim
CREAM = (245, 236, 222)
MUTED = (170, 150, 128)


def font(size, bold=False):
    """Tìm font Việt hoá có sẵn trên Windows."""
    names = [
        "C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf",
        "C:/Windows/Fonts/tahomabd.ttf" if bold else "C:/Windows/Fonts/tahoma.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/timesbd.ttf" if bold else "C:/Windows/Fonts/times.ttf",
    ]
    for n in names:
        if os.path.exists(n):
            try:
                return ImageFont.truetype(n, size)
            except Exception:
                continue
    return ImageFont.load_default()


def base():
    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img)
    # vân gỗ: các dải sáng mờ chéo
    for i in range(0, H + 400, 34):
        d.line([(0, i), (W, i - 260)], fill=(34, 20, 11), width=9)
    # viền vàng mảnh
    d.rectangle([28, 28, W - 29, H - 29], outline=(92, 68, 42), width=2)
    # dải vàng dọc bên trái
    d.rectangle([28, 28, 36, H - 29], fill=GOLD)
    return img, d


def watermark(d):
    """Chữ ký góc phải dưới."""
    d.text((W - 300, H - 66), "duanhong.vn", font=font(22, True), fill=(120, 96, 70))


def make_xuong():
    img, d = base()
    d.text((86, 92), "XƯỞNG MỘC · HƯNG YÊN", font=font(24, True), fill=GOLD)
    d.text((86, 150), "Đúng kích thước phòng.", font=font(66, True), fill=CREAM)
    d.text((86, 232), "Ký tên trước khi sơn.", font=font(66, True), fill=CREAM)
    # gạch vàng
    d.rectangle([86, 330, 246, 336], fill=GOLD)
    d.text((86, 372), "Đồ gỗ may đo · sấy phôi 11% · bảo hành 5 năm", font=font(27), fill=MUTED)
    d.text((86, 424), "Gọi thợ cả: 0378.914.207", font=font(34, True), fill=GOLD)
    d.text((86, H - 92), "Đường Nguyễn Du, TP. Hưng Yên · 07:30–18:00", font=font(23), fill=MUTED)
    watermark(d)
    img.save(os.path.join(OUT, "og-xuong.jpg"), quality=90, optimize=True)
    return img


def make_sofa():
    img, d = base()
    d.text((86, 92), "SOFA GÕ ĐỎ CHÂN QUỲ", font=font(24, True), fill=GOLD)
    d.text((86, 150), "Bộ 5 món đóng theo", font=font(62, True), fill=CREAM)
    d.text((86, 228), "số đo phòng khách", font=font(62, True), fill=CREAM)
    d.rectangle([86, 322, 246, 328], fill=GOLD)
    # bảng giá
    d.text((86, 360), "74.500.000 ₫", font=font(54, True), fill=GOLD)
    d.text((86, 430), "Gỗ Gõ Đỏ Pachy · văng 2m80 + 1m90", font=font(26), fill=MUTED)
    d.text((86, 470), "62 ngày · gia chủ ký mộc trước khi sơn PU", font=font(26), fill=MUTED)
    d.text((86, H - 92), "Xưởng mộc Duân Hồng · 0378.914.207", font=font(23), fill=MUTED)
    watermark(d)
    img.save(os.path.join(OUT, "og-sofa.jpg"), quality=90, optimize=True)
    return img


if __name__ == "__main__":
    for name, fn in (("og-xuong.jpg", make_xuong), ("og-sofa.jpg", make_sofa)):
        im = fn()
        path = os.path.join(OUT, name)
        print(f"{name}: {im.size[0]}x{im.size[1]} · {os.path.getsize(path)//1024} KB")
