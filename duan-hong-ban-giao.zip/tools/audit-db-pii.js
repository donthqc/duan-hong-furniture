// Kiểm tra một file .db có chứa dữ liệu khách thật hay không (chỉ đếm, không in PII).
const { DatabaseSync } = require("node:sqlite");
const p = process.argv[2];
const db = new DatabaseSync(p, { readOnly: true });
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r => r.name);
console.log("bảng:", tables.join(", "));
for (const tb of tables) {
  try { console.log("  " + tb + ":", db.prepare("SELECT COUNT(*) c FROM " + tb).get().c, "dòng"); } catch (e) {}
}
const withPhone = db.prepare("SELECT COUNT(*) c FROM leads WHERE phone IS NOT NULL AND phone<>''").get().c;
console.log(">>> lead có SĐT (dữ liệu cá nhân):", withPhone);
const named = db.prepare("SELECT COUNT(*) c FROM orders WHERE customer_name<>''").get().c;
console.log(">>> đơn có tên khách:", named);
