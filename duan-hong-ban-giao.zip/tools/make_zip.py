# -*- coding: utf-8 -*-
"""
Đóng gói bàn giao — bản 4 (loại bỏ dữ liệu khách và bí mật).

    python make_zip_v4.py          # dựng stage + nén + tự kiểm tra

Thay đổi so với bản trước:
  - KHÔNG bao giờ đưa vào gói: `.env`, mọi file `.db`/`-wal`/`-shm`, `node_modules`,
    ảnh chụp tạm `probe-*.png`, script probe một lần.
  - Đưa `server/google-apps-script/Code.gs` + `HUONG-DAN-GOOGLE-APPS-SCRIPT.md` vào gói.
  - Sau khi nén, TỰ KIỂM TRA gói: không có `.env`, không có `.db`, không có chuỗi bí mật.
    Nếu vi phạm thì xoá file ZIP và thoát mã 1.
"""
import os
import re
import shutil
import sys
import zipfile
import datetime

ROOT = r"C:\Users\DELL\Documents\qa-web-ban-hang"
STAGE_PARENT = os.path.join(ROOT, "_ban_giao")
STAGE = os.path.join(STAGE_PARENT, "duan-hong-ban-giao")
ZIP = os.path.join(ROOT, "duan-hong-ban-giao.zip")

SKIP_NAMES = {"node_modules", "__pycache__", ".git", ".cache"}
# Chặn theo phần mở rộng — quan trọng nhất là .env và .db
SKIP_EXT = {
    ".db", ".db-wal", ".db-shm", ".db-journal",
    ".env", ".pem", ".p12", ".key", ".log",
}
# Chặn theo tên chính xác (file bí mật không có đuôi)
SKIP_FILES = {
    ".env", ".env.local", ".env.production",
    "probe.js", "probe2.js", "probe3.js", "probe4.js", "probe5.js",
    "probe-1440.png", "probe-1440-full.png",
}
# Bắt buộc KHÔNG được xuất hiện trong gói (kiểm sau khi nén)
FORBIDDEN_RE = [
    (re.compile(r"AKfycb[A-Za-z0-9_-]{20,}"), "URL Apps Script thật"),
    (re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"), "private key"),
    (re.compile(r"ya29\.[A-Za-z0-9_-]{20,}"), "access token Google"),
]
SECRET_ENV_KEYS = ("ADMIN_TOKEN", "PHONE_SALT", "GOOGLE_APPS_SCRIPT_URL")


def skip_file(name):
    if name in SKIP_FILES:
        return True
    base = os.path.basename(name)
    if base in SKIP_FILES:
        return True
    ext = os.path.splitext(name)[1].lower()
    if ext in SKIP_EXT:
        return True
    if ext == ".db-wal" or name.endswith(("-wal", "-shm", "-journal")):
        return True
    return False


def copy(src, dst_rel):
    if not os.path.exists(src):
        print(f"  [bỏ qua — không có] {os.path.relpath(src, ROOT)}")
        return
    dst = os.path.join(STAGE, dst_rel)
    if os.path.isdir(src):
        for base, dirs, files in os.walk(src):
            dirs[:] = [d for d in dirs if d not in SKIP_NAMES]
            rel = os.path.relpath(base, src)
            target = dst if rel == "." else os.path.join(dst, rel)
            os.makedirs(target, exist_ok=True)
            for f in files:
                if skip_file(f):
                    continue
                shutil.copy2(os.path.join(base, f), os.path.join(target, f))
    else:
        if skip_file(os.path.basename(src)):
            print(f"  [CHẶN bí mật] {os.path.basename(src)}")
            return
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)


def build_stage():
    if os.path.isdir(STAGE_PARENT):
        shutil.rmtree(STAGE_PARENT)
    os.makedirs(STAGE, exist_ok=True)

    # 01 — kế hoạch & test case
    copy(f"{ROOT}/test-plan-web-ban-hang.md", "01-ke-hoach-va-test-case/test-plan-web-ban-hang.md")
    copy(f"{ROOT}/test-cases-web-ban-hang.xlsx", "01-ke-hoach-va-test-case/test-cases-web-ban-hang.xlsx")
    copy(f"{ROOT}/ket-qua-kiem-thu-web-ban-hang.xlsx", "01-ke-hoach-va-test-case/ket-qua-kiem-thu-web-ban-hang.xlsx")
    copy(f"{ROOT}/plan-test-web-moi", "01-ke-hoach-va-test-case/plan-test-web-moi")

    # 02 — báo cáo QA + bằng chứng
    copy(f"{ROOT}/bao-cao-kiem-thu-web-ban-hang.md", "02-bao-cao-qa/bao-cao-kiem-thu-web-ban-hang.md")
    copy(f"{ROOT}/evidence", "02-bao-cao-qa/evidence")

    # 03 — tài liệu thiết kế & kế hoạch
    copy(f"{ROOT}/ke-hoach-thiet-ke-lai-web-xuong-moc.md", "03-thiet-ke/ke-hoach-thiet-ke-lai-web-xuong-moc.md")
    copy(f"{ROOT}/kien-truc-website-xuong-moc.md", "03-thiet-ke/kien-truc-website-xuong-moc.md")
    copy(f"{ROOT}/design/15-skill-playbook.md", "03-thiet-ke/15-skill-playbook.md")
    copy(f"{ROOT}/KE-HOACH-PHAT-TRIEN-WEBSITE-2026.md", "03-thiet-ke/KE-HOACH-PHAT-TRIEN-WEBSITE-2026.md")

    # 04 — website: copy nguyên design/
    copy(f"{ROOT}/design", "04-website")
    os.makedirs(os.path.join(STAGE, "04-website", "_build"), exist_ok=True)
    for f in ("build_pages.py", "build_pages2.py", "build_pages3.py"):
        src = os.path.join(STAGE, "04-website", f)
        if os.path.isfile(src):
            shutil.move(src, os.path.join(STAGE, "04-website", "_build", f))
    os.makedirs(os.path.join(STAGE, "04-website", "_tools"), exist_ok=True)
    for f in ("photos.js", "make_og.py"):
        s = f"{ROOT}/tools/{f}"
        if os.path.isfile(s):
            shutil.copy2(s, os.path.join(STAGE, "04-website", "_tools", f))
    copy(f"{ROOT}/HUONG-DAN-THEM-ANH.md", "04-website/HUONG-DAN-THEM-ANH.md")

    # 05 — backend + database (KHÔNG có .env, KHÔNG có data/)
    B = "05-backend-database"
    for f in ("package.json", "README.md", "schema.postgres.sql"):
        copy(f"{ROOT}/server/{f}", f"{B}/{f}")
    copy(f"{ROOT}/server/.env.example", f"{B}/.env.example")
    copy(f"{ROOT}/server/src", f"{B}/src")
    copy(f"{ROOT}/server/test", f"{B}/test")
    copy(f"{ROOT}/server/google-apps-script", f"{B}/google-apps-script")
    copy(f"{ROOT}/SPEC-GOOGLE-SHEETS.md", f"{B}/SPEC-GOOGLE-SHEETS.md")
    copy(f"{ROOT}/HUONG-DAN-GOOGLE-APPS-SCRIPT.md", f"{B}/HUONG-DAN-GOOGLE-APPS-SCRIPT.md")

    # 06 — bộ test tự động
    copy(f"{ROOT}/qa-node/package.json", "06-bo-test/package.json")
    for f in ["site-check.js", "design-check.js", "a11y.js", "completeness-audit.js",
              "e2e-api.js", "e2e-9bugs.js", "test-photos.js", "verify-zip.js",
              "code-review.js", "motion-smoke.js", "motion-public-check.js"]:
        copy(f"{ROOT}/qa-node/{f}", f"06-bo-test/{f}")

    # 08 — triển khai
    for f in ("README.md", ".env.example", "duanhong-api.service", "nginx-duanhong.conf", "deploy.sh"):
        copy(f"{ROOT}/deploy/{f}", f"08-trien-khai/{f}")

    # 07 — log (sinh sau khi chạy test từ chính gói này)
    os.makedirs(os.path.join(STAGE, "07-ket-qua-kiem-thu"), exist_ok=True)

    # README + .gitignore ở gốc gói
    copy(f"{ROOT}/README.md", "README.md")
    copy(f"{ROOT}/.gitignore", ".gitignore")
    print("STAGE xong:", STAGE)


README = """# BÀN GIAO — XƯỞNG MỘC DUÂN HỒNG

Ngày đóng gói: {today}

Gói này **không chứa** bí mật hay dữ liệu khách: không có `.env`, không có `*.db`,
không có `node_modules`. Cấu hình thật phải tự tạo lại theo mục 3.

---

## 1. Gói này có gì

| Thư mục | Nội dung |
|---|---|
| `01-ke-hoach-va-test-case` | Kế hoạch test, test case, kết quả chạy |
| `02-bao-cao-qa` | Báo cáo QA bản cũ (kết luận **NO-GO**) + ảnh bằng chứng |
| `03-thiet-ke` | Kiến trúc site, kế hoạch thiết kế lại, lộ trình 2026, skill playbook |
| `04-website` | 8 trang HTML + CSS/JS + lớp giao diện động `motion-*` |
| `05-backend-database` | API + SQLite, `src/sheets/`, `google-apps-script/Code.gs`, `.env.example`, 46+61+12 test |
| `06-bo-test` | 8 bộ test giao diện chạy lại được |
| `07-ket-qua-kiem-thu` | Log chạy từ **chính gói này** sau khi giải nén |
| `08-trien-khai` | systemd, Nginx, deploy.sh, mẫu biến môi trường |

---

## 2. Xem website

```bash
cd 04-website
python -m http.server 8098 --bind 127.0.0.1
# http://127.0.0.1:8098/trang-chu.html
```

Website chỉ gọi được API khi mở qua `127.0.0.1:8096 / 8098 / 8099` (CORS allowlist).
Mở cổng khác → site tự chuyển chế độ demo.

---

## 3. Chạy backend (phải tự tạo `.env`)

Yêu cầu **Node ≥ 22.5**.

```bash
cd 05-backend-database
cp .env.example .env          # rồi điền giá trị thật vào .env
node --env-file=.env src/server.js      # http://127.0.0.1:5055
npm test                                 # 46 kiểm tra API
npm run test:sheets                      # 61 kiểm tra đồng bộ Sheets (Google giả lập)
npm run test:apps                        # 12 kiểm tra Apps Script Webhook
```

**Bắt buộc đổi trước khi dùng thật:**
- `ADMIN_TOKEN` — `openssl rand -hex 32`. Để trống thì `/api/admin/*` bị khoá (503, cố ý).
- `PHONE_SALT` — muốn tra cứu được đơn cũ thì phải giữ nguyên giá trị đã dùng.
- `ALLOWED_ORIGINS` — production chỉ để domain thật.

Lần chạy đầu tự tạo `data/duanhong.db` + dữ liệu mẫu (6 sản phẩm · 5 công trình · 3 đơn).

---

## 4. Đồng bộ Google Sheets

**Cách khuyên dùng — Apps Script Webhook** (không cần service account, không cần tải khoá JSON):

1. Mở `05-backend-database/google-apps-script/Code.gs`, dán vào Apps Script của Sheet xưởng.
2. Deploy → Web app → Execute as **Me**, Who has access **Anyone**.
3. Chép URL `.../exec` vào `GOOGLE_APPS_SCRIPT_URL` trong `.env`.

Chi tiết 5 bước: `05-backend-database/HUONG-DAN-GOOGLE-APPS-SCRIPT.md`
Đặc tả kỹ thuật + 15 câu hỏi cần chốt: `05-backend-database/SPEC-GOOGLE-SHEETS.md`

Luồng: lead lưu SQLite trước (nguồn chính) → `pending` → `sent` khi Apps Script trả OK →
`failed` + `sheets_error` khi lỗi. Retry có giới hạn, chống nhân bản bằng mã lead.
Admin cần `ADMIN_TOKEN`: `GET /api/admin/sheets/status`, `POST /api/admin/sheets/resync`.

---

## 5. Kết quả kiểm thử (log trong `07-ket-qua-kiem-thu/`)

{results}

---

## 6. Bảo mật — những gì đã làm

- Tra cứu đơn bắt buộc **mã đơn + 4 số cuối**; sai mã và sai số trả cùng một thông báo.
- Không lưu SĐT thô để tra cứu đơn — chỉ `phone_last4` + `phone_hash` (SHA-256 + salt).
- Toàn bộ SQL là prepared statement; đã test `' OR 1=1--` → 0 kết quả.
- `/api/admin/*` cần token so bằng `timingSafeEqual`; thiếu token → 503 (fail closed).
- Rate limit, body 32KB, CORS allowlist, không lộ stack trace.
- Đánh giá phải khớp đơn đã mua và **chờ duyệt** mới hiện.
- Gói bàn giao **không chứa** `.env`, `*.db`, khoá riêng tư hay token.

---

## 7. Còn thiếu (không giấu)

1. **0/18 ảnh thật** — mọi ô ghi "VỊ TRÍ ẢNH". Cách thêm: `04-website/HUONG-DAN-THEM-ANH.md`.
2. **Chưa có CMS UI** — hiện chỉ có API quản trị (curl/Postman).
3. **Upload ảnh tiến độ đơn** — cột `photo_url` chỉ nhận URL có sẵn.
4. **SMS/Zalo báo lead mới** — chưa nối cổng nào.
5. **Chưa deploy production** — `08-trien-khai/` đã có cấu hình nhưng chưa chạy trên VPS thật.

Cần xưởng xác nhận: **loại thước Lỗ Ban** (38,8 / 42,9 / 52,2 cm) và **giá công bố**.
"""


def write_readme(results_md):
    today = datetime.date.today().strftime("%d/%m/%Y")
    body = README.replace("{today}", today).replace("{results}", results_md)
    open(os.path.join(STAGE, "README.md"), "w", encoding="utf-8").write(body)


def scan_stage_secrets():
    """Quét stage trước khi nén: trả danh sách file nghi chứa bí mật."""
    bad = []
    for base, dirs, files in os.walk(STAGE):
        for f in files:
            full = os.path.join(base, f)
            rel = os.path.relpath(full, STAGE)
            if f == ".env" or f.startswith(".env.") and f != ".env.example":
                bad.append((rel, "file .env"))
                continue
            if os.path.splitext(f)[1].lower() in (".db", ".db-wal", ".db-shm", ".pem", ".p12", ".key"):
                bad.append((rel, "file dữ liệu/bí mật"))
                continue
            if os.path.getsize(full) > 3_000_000:
                continue
            try:
                text = open(full, "r", encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            for rx, label in FORBIDDEN_RE:
                if rx.search(text):
                    bad.append((rel, label))
                    break
            else:
                # dòng gán trực tiếp bí mật (bỏ qua dòng mẫu có dấu ... hoặc $()
                for line in text.splitlines():
                    for key in SECRET_ENV_KEYS:
                        if line.strip().startswith(key + "="):
                            val = line.split("=", 1)[1].strip().strip('"').strip("'")
                            if val and "..." not in val and "$(" not in val and not val.startswith("<"):
                                bad.append((rel, key + " có giá trị"))
    return bad


def make_zip():
    if os.path.isfile(ZIP):
        os.remove(ZIP)
    with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for base, dirs, files in os.walk(STAGE):
            dirs[:] = [d for d in dirs if d not in SKIP_NAMES]
            for f in files:
                if skip_file(f):
                    continue
                full = os.path.join(base, f)
                z.write(full, os.path.relpath(full, os.path.dirname(STAGE)))

    # --- tự kiểm tra sau khi nén ---
    size = os.path.getsize(ZIP) / 1024 / 1024
    with zipfile.ZipFile(ZIP) as z:
        names = z.namelist()
        print(f"\nZIP : {ZIP}\n{size:.1f} MB · {len(names)} mục · testzip "
              f"{'OK' if z.testzip() is None else 'LỖI'}")
        leaks = [n for n in names if n.endswith(".env") or "/.env" in n or n.startswith(".env")]
        dbz = [n for n in names if n.endswith((".db", ".db-wal", ".db-shm"))]
        print("file .env trong gói :", leaks or "KHÔNG CÓ ✔")
        print("file .db trong gói  :", dbz or "KHÔNG CÓ ✔")
        print("html / js / md      :",
              sum(1 for n in names if n.endswith(".html")),
              "/", sum(1 for n in names if n.endswith(".js")),
              "/", sum(1 for n in names if n.endswith(".md")))

    found = scan_stage_secrets()
    if found:
        print("\n!!! PHÁT HIỆN BÍ MẬT TRONG GÓI — ĐÃ XOÁ FILE ZIP !!!")
        for rel, why in found[:20]:
            print(f"   {rel} :: {why}")
        os.remove(ZIP)
        return 1
    print("quét bí mật        : SẠCH ✔")
    return 0


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode in ("stage", "all"):
        build_stage()
        write_readme("_(chạy lại test từ chính gói rồi điền kết quả vào đây)_")
    if mode in ("zip", "all"):
        sys.exit(make_zip())
