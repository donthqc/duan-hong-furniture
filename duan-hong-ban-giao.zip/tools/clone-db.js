// Sao lưu nhất quán DB dev sang file tạm (VACUUM INTO) để chạy regression,
// không ghi gì vào database đang dùng.
const { DatabaseSync } = require("node:sqlite");
const fs = require("node:fs");
const path = require("node:path");

const SRC = "C:/Users/DELL/Documents/qa-web-ban-hang/server/data/duanhong.db";
const DST = path.join(process.env.LOCALAPPDATA, "Temp", "dh-regress.db");

if (fs.existsSync(DST)) fs.unlinkSync(DST);
const db = new DatabaseSync(SRC, { readOnly: true });
db.exec("VACUUM INTO '" + DST.replace(/\\/g, "/") + "'");
const copy = new DatabaseSync(DST, { readOnly: true });
console.log("bản sao:", DST, fs.statSync(DST).size, "bytes");
console.log("leads:", copy.prepare("SELECT COUNT(*) c FROM leads").get().c,
            "· orders:", copy.prepare("SELECT COUNT(*) c FROM orders").get().c);
