"use strict";
/**
 * Phục vụ website tĩnh + proxy /api sang backend trên CÙNG một cổng.
 * Dùng cho deploy demo (LAN hoặc tunnel), để mở từ máy khác không bị lỗi CORS.
 *
 *   node tools/serve.js            # http://0.0.0.0:8096
 *   PORT=9000 node tools/serve.js
 */
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.join(__dirname, "..", "design");
const PORT = Number(process.env.PORT || 8096);
const HOST = process.env.HOST || "0.0.0.0";
const API_HOST = process.env.API_HOST || "127.0.0.1";
const API_PORT = Number(process.env.API_PORT || 5055);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".xml": "application/xml; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
};

function proxy(req, res) {
  const opts = {
    hostname: API_HOST,
    port: API_PORT,
    path: req.url,
    method: req.method,
    headers: { ...req.headers, host: `${API_HOST}:${API_PORT}` },
  };
  const up = http.request(opts, (r) => {
    res.writeHead(r.statusCode || 502, r.headers);
    r.pipe(res);
  });
  up.on("error", () => {
    if (!res.headersSent) {
      res.writeHead(502, { "Content-Type": "application/json; charset=utf-8" });
    }
    res.end(JSON.stringify({ success: false, message: "Máy chủ API không phản hồi." }));
  });
  req.pipe(up);
}

const server = http.createServer((req, res) => {
  // API đi qua proxy → cùng origin, không cần CORS
  if (req.url.startsWith("/api/")) return proxy(req, res);

  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p === "/") p = "/trang-chu.html";

  // chặn path traversal
  const target = path.join(ROOT, path.normalize(p).replace(/^(\.\.[/\\])+/, ""));
  if (!target.startsWith(ROOT)) {
    res.writeHead(403); return res.end("Forbidden");
  }

  // thử file, rồi .html, rồi index
  const candidates = [target, target + ".html", path.join(target, "index.html")];
  for (const f of candidates) {
    try {
      const st = fs.statSync(f);
      if (!st.isFile()) continue;
      const ext = path.extname(f).toLowerCase();
      const type = MIME[ext] || "application/octet-stream";
      const noCache = ext === ".html" || f.endsWith("manifest.json");
      res.writeHead(200, {
        "Content-Type": type,
        "Content-Length": st.size,
        "Cache-Control": noCache ? "no-cache" : "public, max-age=86400",
        "X-Content-Type-Options": "nosniff",
      });
      return fs.createReadStream(f).pipe(res);
    } catch (e) { /* thử tiếp */ }
  }

  res.writeHead(404, { "Content-Type": "text/html; charset=utf-8" });
  res.end("<h1>404 — Không tìm thấy trang</h1><p><a href='/'>Về trang chủ</a></p>");
});

server.listen(PORT, HOST, () => {
  console.log(`Web + API  http://${HOST}:${PORT}`);
  console.log(`  tĩnh : ${ROOT}`);
  console.log(`  /api → http://${API_HOST}:${API_PORT}`);
});
