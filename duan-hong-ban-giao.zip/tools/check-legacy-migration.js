// Kiểm chứng migration idempotent trên một DB kiểu CŨ (bảng leads chưa có cột Sheets).
// Chạy db.js hai lần trên cùng file, xác nhận: thêm đủ 5 cột, không mất dòng nào, lần 2 không lỗi.
const { DatabaseSync } = require("node:sqlite");
const fs = require("node:fs");
const path = require("node:path");

const DB = path.join(process.env.LOCALAPPDATA, "Temp", "dh-legacy-check.db");
if (fs.existsSync(DB)) fs.unlinkSync(DB);

// 1. Dựng DB cũ đúng schema trước Giai đoạn 2 (không có 5 cột sheets)
const old = new DatabaseSync(DB);
old.exec(`
CREATE TABLE leads (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  phone_hash TEXT NOT NULL,
  area TEXT NOT NULL DEFAULT '',
  need TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT 'website',
  status TEXT NOT NULL DEFAULT 'new',
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
INSERT INTO leads (code,name,phone,phone_hash,area,need) VALUES
  ('LH-OLD001','Khách cũ 1','0901111222','hash1','Hưng Yên','Bàn ăn'),
  ('LH-OLD002','Khách cũ 2','0903333444','hash2','Mỹ Hào','Tủ bếp');
`);
old.close();
console.log("DB cũ dựng xong, 2 lead, cột:",
  new DatabaseSync(DB).prepare("PRAGMA table_info(leads)").all().map(c => c.name).join(","));

// 2. Chạy db.js (migration) hai lần
process.env.DB_PATH = DB;
for (const lan of [1, 2]) {
  delete require.cache[require.resolve("../server/src/db.js")];
  require("../server/src/db.js");
  const d = new DatabaseSync(DB, { readOnly: true });
  const cols = d.prepare("PRAGMA table_info(leads)").all().map(c => c.name);
  const rows = d.prepare("SELECT code,name,sheets_status,sync_attempts FROM leads ORDER BY id").all();
  console.log(`lần ${lan}: ${cols.length} cột · có sheets_status=${cols.includes("sheets_status")}` +
    ` · có sheets_row=${cols.includes("sheets_row")} · dòng=${rows.length}` +
    ` · ${rows.map(r => r.code + "/" + r.sheets_status + "/" + r.sync_attempts).join(" ")}`);
  d.close();
}
